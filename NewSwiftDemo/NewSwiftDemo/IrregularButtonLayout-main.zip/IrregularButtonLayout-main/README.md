# IrregularButtonLayout
不规则按钮布局，包括单选、多选、全选状态。

## 项目运行效果图
<video src="https://v.youku.com/v_show/id_XNTA1NjkxMjUwMA==.html?spm=a2hcb.profile.app.5~5!2~5~5!3~5!2~5~5~A" controls="controls" width="500" height="300">您的浏览器不支持播放该视频！</video>
