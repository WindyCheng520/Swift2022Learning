//
//  SceneDelegate.h
//  IrregularButtonLayoutDemo
//
//  Created by Devin on 2021/1/9.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

