//
//  MSOEMThemesManager.m
//  MSReactNative
//
//  Created by Neil 韦学宁 on 2021/7/6.
//

#import "MSOEMThemesManager.h"
#import "OEMThemesDefine.h"
#import "MSWeakWrapper.h"

NSString * const OEMThemeDidChangeNotification = @"com.midea.iot.oem.OEMThemeDidChangeNotification";

#if OEMTHEMESWITCHMODE

@interface MSOEMThemesManager(DEBUGHelper)
@end

@implementation MSOEMThemesManager (DEBUGHelper)

- (void)toggleStyle{
    if (self.currentStyle == OEMThemesStyle_Light) {
        [self updateStyle:OEMThemesStyle_Dark];
    }else{
        [self updateStyle:OEMThemesStyle_Light];
    }
}

- (void)foo{
    UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    __block UIView * parentView = [UIApplication sharedApplication].keyWindow;
    [[UIApplication sharedApplication].windows enumerateObjectsUsingBlock:^(__kindof UIWindow * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj isKindOfClass:NSClassFromString(@"DOFEntryWindow")]) {
            parentView = obj;
            *stop = YES;
        }
    }];
    
    [parentView addSubview:button];
    if (!parentView) {
        return;
    }
    [button mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(button.superview);
        make.size.mas_equalTo(CGSizeMake(30, 30));
    }];
    button.backgroundColor = [UIColor redColor];
    [button addTarget:self action:@selector(onToggle) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton * btn2 = [UIButton buttonWithType:UIButtonTypeCustom];
    [parentView addSubview:btn2];
    [btn2 mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(30, 30));
        make.leading.equalTo(button.mas_trailing);
        make.centerY.equalTo(button);
    }];
    btn2.backgroundColor = [UIColor greenColor];
    [btn2 addTarget:self action:@selector(onbtn2Click) forControlEvents:UIControlEventTouchUpInside];
    
}

- (void)onToggle{
    [self toggleStyle];
}

- (void)onbtn2Click{
    UIAlertController * alertCtrl = [UIAlertController alertControllerWithTitle:@"提示" message:@"123123123" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
    }];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    }];
    [alertCtrl addAction:cancelAction];
    [alertCtrl addAction:okAction];
    [UIApplication.sharedApplication.keyWindow.rootViewController showViewController:alertCtrl sender:nil];
}

+ (void)load{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [[self sharedManager] foo];
    });
}

@end


#endif


#define MSOEMThemesManager_Follow_System_Key    @"MSOEMThemesManager_Follow_System_Key"
#define MSOEMThemesManager_LastThemeStyle_Key   @"MSOEMThemesManager_LastThemeStyle_Key"
#define BackgroundStatePreviousUIStyleUnset (99)

@interface MSOEMThemesManager()

@property(nonatomic, strong)NSMutableDictionary <NSString *, NSDictionary *> * responderProperties;

@property(nonatomic, strong)NSMutableArray <MSWeakWrapper *> * responderWrappers;

@property(nonatomic, assign)NSInteger backgroundStatePreviousUIStyle;

@property(nonatomic, assign)BOOL themeEnable;

@end

@implementation MSOEMThemesManager

+ (instancetype)sharedManager{
    static MSOEMThemesManager * manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[MSOEMThemesManager alloc] init];
    });
    return manager;
}

- (void)configureThemeEnable:(BOOL)themeEnable{
    _themeEnable = themeEnable;
    [self initDefaultThemeData];
    if (!_themeEnable) {
        //如果不支持暗黑模式，则默认浅色模式
        self.themeFollowSystem = NO;
        [self updateStyle:OEMThemesStyle_Light];
    }
}

#pragma mark - ====== APIs ======

- (OEMThemesStyle)currentStyle{
    return _currentStyle;
}

- (void)updateStyle:(OEMThemesStyle)style{
    if (style == self.currentStyle) {
        return;
    }
    if (self.themeEnable) {
        self.currentStyle = style;
    }else{
        self.currentStyle = OEMThemesStyle_Light;
    }
    
    NSString * statusDes = @"";
    switch ([UIApplication sharedApplication].applicationState) {
        case UIApplicationStateActive:
            statusDes = @"Active";
            break;
        case UIApplicationStateInactive:
            statusDes = @"Inactive";
            break;
        case UIApplicationStateBackground:
            statusDes = @"Background";
            break;
    }
    DDLogThemeDebug(@"currentStyle:%@ status:%@", self.currentStyle == OEMThemesStyle_Dark ? @" dark" : @"light", statusDes);
    [[NSUserDefaults standardUserDefaults] setValue:@(self.currentStyle) forKey:MSOEMThemesManager_LastThemeStyle_Key];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    [self setGlobalThemeSettings];
    [[NSNotificationCenter defaultCenter] postNotificationName:OEMThemeDidChangeNotification object:nil];
}

- (void)setGlobalThemeSettings{
    if (@available(iOS 13.0, *)) {
        if (self.currentStyle == OEMThemesStyle_Dark) {
            UIApplication.sharedApplication.keyWindow.overrideUserInterfaceStyle = UIUserInterfaceStyleDark;
        }else{
            UIApplication.sharedApplication.keyWindow.overrideUserInterfaceStyle = UIUserInterfaceStyleLight;
        }
    } else {
        // Fallback on earlier versions
    }
}

- (void)onTraitCollectionDidChange:(UITraitCollection *)previousTraitCollection obj:(id)obj API_AVAILABLE(ios(13.0)){
    if (!self.themeEnable) {
        return;
    }
    UIApplicationState state = [UIApplication sharedApplication].applicationState;
    if (state == UIApplicationStateBackground) {
        //APP后台快照,避免闪烁
        if (self.backgroundStatePreviousUIStyle != previousTraitCollection.userInterfaceStyle || self.backgroundStatePreviousUIStyle == BackgroundStatePreviousUIStyleUnset) {
            self.backgroundStatePreviousUIStyle = previousTraitCollection.userInterfaceStyle;
            DDLogThemeDebug(@"UIApplicationStateBackground previousTraitCollection:%ld", (long)previousTraitCollection.userInterfaceStyle);
            if (self.themeFollowSystem) {
                [self performTraitChange];
            }
        }
        
    }
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(performTraitChange) object:nil];
    [self performSelector:@selector(performTraitChange) withObject:nil afterDelay:0.1];
}

- (void)performTraitChange{
    if (@available(iOS 13.0, *)) {
        UIUserInterfaceStyle style = UITraitCollection.currentTraitCollection.userInterfaceStyle;
        if (self.themeFollowSystem) {
            OEMThemesStyle targetStyle = OEMThemesStyle_Light;
            if (style == UIUserInterfaceStyleDark) {
                targetStyle = OEMThemesStyle_Dark;
            }
            [self updateStyle:targetStyle];
        }
    } else {
        // Fallback on earlier versions
    }
    DDLogThemeDebug(@"OEMTheme performTraitChange");
}

- (void)setThemeFollowSystem:(BOOL)themeFollowSystem{
    DDLogThemeDebug(@"OEMTheme setThemeFollowSystem:%@", themeFollowSystem ? @"YES" : @"NO");
    _themeFollowSystem = themeFollowSystem;
    OEMThemesStyle targetStyle = self.currentStyle;
    if (_themeFollowSystem) {
        //如果是跟随系统，需要取到系统的值
        if (@available(iOS 13.0, *)) {
            UIUserInterfaceStyle style = UITraitCollection.currentTraitCollection.userInterfaceStyle;
            if (style == UIUserInterfaceStyleDark) {
                targetStyle = OEMThemesStyle_Dark;
            }else{
                targetStyle = OEMThemesStyle_Light;
            }
        } else {
            // Fallback on earlier versions
            // 对于iOS13一下的系统,设置跟随系统无效，（应隐藏跟随系统一栏）
        }
    }
    [self updateStyle:targetStyle];
    [[NSUserDefaults standardUserDefaults] setValue:@(_themeFollowSystem) forKey:MSOEMThemesManager_Follow_System_Key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (void)registerSpecialPropertiesForResponser:(UIResponder *)responsder
                                   properties:(NSDictionary <NSNumber *, NSDictionary *> *)properties{
    [[self sharedManager] registerSpecialPropertiesForResponser:responsder properties:properties];
}

#pragma mark - ====== Internal ======

- (void)initDefaultThemeData{
    self.responderProperties = [[NSMutableDictionary alloc] init];
    self.responderWrappers = [[NSMutableArray alloc] init];
    
    NSNumber * followSysNum = [[NSUserDefaults standardUserDefaults] valueForKey:MSOEMThemesManager_Follow_System_Key];
    if (!followSysNum ||
        ![followSysNum isKindOfClass:[NSNumber class]]) {
        BOOL initialConfig = NO;
        if (@available(iOS 13.0, *)) {
            initialConfig = YES;
        }
        DDLogThemeDebug(@"OEMTheme set initialConfig ThemeFollowSystem:%@", initialConfig ? @"YES" : @"NO");
        [[NSUserDefaults standardUserDefaults] setValue:@(initialConfig) forKey:MSOEMThemesManager_Follow_System_Key];
        self.themeFollowSystem = initialConfig;
    }else{
        NSNumber * followSysNum = [[NSUserDefaults standardUserDefaults] valueForKey:MSOEMThemesManager_Follow_System_Key];
        if ([followSysNum isKindOfClass:[NSNumber class]]) {
            self.themeFollowSystem = followSysNum.boolValue;
        }
    }
    
    NSNumber * lastStyle = [[NSUserDefaults standardUserDefaults] valueForKey:MSOEMThemesManager_LastThemeStyle_Key];
    if (!lastStyle ||
        ![lastStyle isKindOfClass:[NSNumber class]]) {
        //无配置
        OEMThemesStyle style = OEMThemesStyle_Light;
        if (self.themeFollowSystem) {
            if (@available(iOS 13.0, *)) {
                UIUserInterfaceStyle sysStyle = UITraitCollection.currentTraitCollection.userInterfaceStyle;
                if (sysStyle == UIUserInterfaceStyleDark) {
                    style = OEMThemesStyle_Dark;
                }
            }
        }
        [self updateStyle:style];
    }else{
        OEMThemesStyle style = OEMThemesStyle_Light;
        if ([lastStyle unsignedIntValue] == OEMThemesStyle_Dark) {
            style = OEMThemesStyle_Dark;
        }
        [self updateStyle:style];
    }
    
    self.backgroundStatePreviousUIStyle = BackgroundStatePreviousUIStyleUnset;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onAPPWillEnterForeground) name:UIApplicationWillEnterForegroundNotification object:nil];
}

+ (NSDictionary *)specialPropertiesForResponsder:(UIResponder *)responsder{
    return  [[self sharedManager] specialPropertiesForResponsder:responsder];
}

- (void)registerSpecialPropertiesForResponser:(UIResponder *)responsder
                              properties:(NSDictionary <NSNumber *, NSDictionary *> *)properties{
    [self cleanResponders];
    MSWeakWrapper * wrapper = [MSWeakWrapper wrapperWithObj:responsder];
    NSDictionary * property = [self.responderProperties objectForKey:wrapper.address];
    if (property) {
        //目前是追加及覆盖
        NSMutableDictionary * darkMerge = [NSMutableDictionary dictionaryWithDictionary:[property objectForKey:@(OEMThemesStyle_Dark)] ?: @{}];
        NSMutableDictionary * lightMerge = [NSMutableDictionary dictionaryWithDictionary:[property objectForKey:@(OEMThemesStyle_Light)] ?: @{}];
        [darkMerge addEntriesFromDictionary:[properties objectForKey:@(OEMThemesStyle_Dark)]];
        [lightMerge addEntriesFromDictionary:[properties objectForKey:@(OEMThemesStyle_Light)]];
        NSDictionary * newProperty = @{
            @(OEMThemesStyle_Dark) : darkMerge,
            @(OEMThemesStyle_Light) : lightMerge,
        };
        [self.responderProperties setValue:newProperty forKey:wrapper.address];
        /*
        NSLog(@"😄 register addr:%@ des:%@ property:%@ overwrite",
                    wrapper.address,
                    wrapper.objectDescription,
              newProperty);
         */
    }else{
        
        [self.responderProperties setValue:properties forKey:wrapper.address];
        [self.responderWrappers addObject:wrapper];
    }
    /*
        NSLog(@"😄 register addr:%@ des:%@ property:%@",
          wrapper.address,
          wrapper.objectDescription,
          properties);
     */
    
}

- (NSDictionary *)specialPropertiesForResponsder:(UIResponder *)responsder{
    __block MSWeakWrapper * found = nil;
    [self.responderWrappers enumerateObjectsUsingBlock:^(MSWeakWrapper * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if (obj.weakContentObj == responsder) {
            found = obj;
        }
    }];
    if (!found || [found.address length] == 0) {
        return nil;
    }

    NSDictionary * dic = [self.responderProperties objectForKey:found.address];
    /*
    NSLog(@"😄 found addr:%@ des:%@ property:%@",
          found.address,
          found.objectDescription,
          dic);
     */
    
    return dic;
}

- (void)cleanResponders{
    NSArray * wrappers = [NSArray arrayWithArray:self.responderWrappers];
    [wrappers enumerateObjectsUsingBlock:^(MSWeakWrapper * obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if (obj.weakContentObj == nil) {
            /*
            NSLog(@"😄 clean addr:%@ des:%@ property:%@",
                  obj.address,
                  obj.objectDescription,
                  [self.responderProperties objectForKey:obj.address]);
             */
            [self.responderWrappers removeObject:obj];
            [self.responderProperties removeObjectForKey:obj.address];
        }
    }];
}

- (void)onAPPWillEnterForeground{
    self.backgroundStatePreviousUIStyle = BackgroundStatePreviousUIStyleUnset;
}

@end
