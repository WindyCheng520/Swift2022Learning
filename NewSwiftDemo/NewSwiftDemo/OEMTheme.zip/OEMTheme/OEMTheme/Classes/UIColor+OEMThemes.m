//
//  UIColor+OEMThemes.m
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/7.
//

#import "UIColor+OEMThemes.h"
#import "NSObject+Swizzle.h"
#import "UIView+OEMThemes.h"
#import "MSOEMThemesManager.h"

@implementation UIColor (OEMThemes)

+ (UIColor *)oem_colorWithLightColor:(UIColor *)lightColor darkColor:(UIColor *)darkColor {
  if (@available(iOS 13.0, *)) {
    return [UIColor colorWithDynamicProvider:^UIColor * _Nonnull(UITraitCollection * _Nonnull traitCollection) {
      return OEMThemeIsDarkMode ? darkColor : lightColor;
    }];
  }
    return OEMThemeIsDarkMode ? darkColor : lightColor;
}

@end
