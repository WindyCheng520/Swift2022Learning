//
//  UIView+OEMThemes.h
//  MSReactNative
//
//  Created by Neil 韦学宁 on 2021/7/6.
//

#import <UIKit/UIKit.h>
#import "OEMThemesDefine.h"

NS_ASSUME_NONNULL_BEGIN

@interface UIView (OEMThemes)

- (void)addThemeBottomSeplineWithOffset:(CGFloat)offset;

- (void)addThemeBottomSeplineWithLeading:(CGFloat)leading trailing:(CGFloat)trailing;

- (void)disableSepline;

+ (nullable UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size;

@end

NS_ASSUME_NONNULL_END
