//
//  OEMHGCollectionViewCell.h
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/14.
//

#import <OEMFoundation/HGCollectionViewCell.h>

NS_ASSUME_NONNULL_BEGIN

@interface OEMHGCollectionViewCell : HGCollectionViewCell

- (void)cellStyleWithCount:(NSInteger)count perRow:(NSInteger)perRow;

- (void)configureGridEdge;

@end

NS_ASSUME_NONNULL_END
