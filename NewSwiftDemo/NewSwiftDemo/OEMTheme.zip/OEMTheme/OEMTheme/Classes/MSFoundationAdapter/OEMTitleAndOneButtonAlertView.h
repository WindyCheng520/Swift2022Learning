//
//  OEMTitleAndOneButtonAlertView.h
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/13.
//

#import <OEMFoundation/HGView.h>
#import <OEMFoundation/HGLabel.h>
#import <OEMFoundation/HGButton.h>
#import <OEMFoundation/HGView.h>
#import <OEMFoundation/MSTitleAndOneButtonAlertView.h>

NS_ASSUME_NONNULL_BEGIN

@interface OEMTitleAndOneButtonAlertView : MSTitleAndOneButtonAlertView

@property (nonatomic, strong) HGView *backView;
@property (nonatomic, strong) HGLabel *titleLabel;
@property (nonatomic, strong) HGButton *confirmButton;
@property (nonatomic, strong) HGView *firstLineView;

@end

NS_ASSUME_NONNULL_END
