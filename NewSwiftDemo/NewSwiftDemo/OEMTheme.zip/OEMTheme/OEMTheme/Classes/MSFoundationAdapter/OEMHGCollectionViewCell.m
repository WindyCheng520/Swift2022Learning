//
//  OEMHGCollectionViewCell.m
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/14.
//

#import "OEMHGCollectionViewCell.h"
#import "UIResponder+OEMThemes.h"

@implementation OEMHGCollectionViewCell

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self configureOEMTheme];
    }
    return self;
}

- (void)configureOEMTheme{
    [self.contentView configureThemeTag:OEMThemesTag_UIView_Foreground];
}

@end
