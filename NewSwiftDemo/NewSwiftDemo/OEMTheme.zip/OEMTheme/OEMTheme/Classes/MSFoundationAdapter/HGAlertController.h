//
//  HGAlertController.h
//  OEMFoundation
//
//  Created by syp on 2020/6/23.
//

#import <UIKit/UIKit.h>
#import "HGButton.h"
/*example
HGAlertAction *cancelAction = [HGAlertAction actionWithTitle:@"cancel" action:nil];
HGAlertAction *okAction = [HGAlertAction actionWithTitle:@"ok" action:^{
    
}];
okAction.font = [UIFont boldSystemFontOfSize:17];

[[HGAlertController alertControllerWithTitle:@"" message:@"message message message message message message message message message message message message message message message " actions:@[cancelAction, okAction]] show];
*/



@protocol HGAlertContentViewProtocol <NSObject>

- (CGSize)contentSize;

@optional
- (void)setMessageLabelTextAlignment:(NSTextAlignment)textAlignment;

@end

@interface HGAlertAction : NSObject

+ (instancetype)actionWithTitle:(NSString *)title action:(dispatch_block_t)action;
+ (instancetype)actionWithTitle:(NSString *)title style:(HGAlertActionStyle)style action:(dispatch_block_t)action;

@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) UIFont *font;
@property (nonatomic, strong) UIColor *textColor;
@property (nonatomic, assign) HGAlertActionStyle style;
@property (nonatomic, copy) dispatch_block_t actionBlock;

@end

@interface HGAlertController : UIViewController

+ (instancetype)alertControllerWithTitle:(NSString *)title
                                 message:(NSString *)message
                                 actions:(NSArray<HGAlertAction *> *)actions;

+ (instancetype)alertControllerWithAttributedTitle:(NSAttributedString *)title
                                 attributedMessage:(NSAttributedString *)message
                                           actions:(NSArray<HGAlertAction *> *)actions;

//自定义contentView
- (instancetype)initWithContentView:(UIView<HGAlertContentViewProtocol> *)contentView;

- (void)setSubtitleTextAlignment:(NSTextAlignment)textAlignment;
- (void)show;
- (void)showInParentViewController:(UIViewController *)parentViewController;

- (void)dismiss;

@property (nonatomic, strong) UIView<HGAlertContentViewProtocol> *contentView;

@end

@interface HGAlertView : UIView<HGAlertContentViewProtocol>

@property (nonatomic, strong) NSArray<HGAlertAction *> *actions;

- (instancetype)initWithTitle:(NSAttributedString *)title message:(NSAttributedString *)message actions:(NSArray<HGAlertAction *> *)actions;


@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *messageLabel;

@property (nonatomic, strong) UIView *lineView;
@property (nonatomic, strong) NSArray<HGButton *> *actionButtons;
@property (nonatomic, strong) NSArray<UIView *> *actionButtonLines;
@end
