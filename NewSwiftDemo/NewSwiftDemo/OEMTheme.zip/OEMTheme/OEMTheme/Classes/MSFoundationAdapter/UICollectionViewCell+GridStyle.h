//
//  UICollectionViewCell+GridStyle.h
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, CollectionViewCellGrid) {
    CollectionViewCellGrid_None     = 1 << 0,
    CollectionViewCellGrid_Leading  = 1 << 1,
    CollectionViewCellGrid_Top      = 1 << 2,
    CollectionViewCellGrid_Trailing = 1 << 3,
    CollectionViewCellGrid_Bottom   = 1 << 4,
};

@interface UICollectionViewCell (GridStyle)

- (void)configureCellWithTotalCount:(NSInteger)totalCount
                             perRow:(NSInteger)perRow
                       currentIndex:(NSInteger)currentIndex;

- (void)configureGrid:(CollectionViewCellGrid)grid;

@end

NS_ASSUME_NONNULL_END
