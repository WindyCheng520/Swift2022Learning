//
//  OEMMSInputView.m
//  MSLogin
//
//  Created by Neil 韦学宁 on 2021/7/15.
//

#import "OEMMSInputView.h"

@interface MSInputView ()

@property (nonatomic, strong) HGTextField *textField;
@property (nonatomic, strong) HGImageView *iconImageView;
@property (nonatomic, strong) HGButton *actionButton;

@end

@implementation OEMMSInputView
-(void)makeConstraints{
    if (self.iconImageView.image) {
        [self.iconImageView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.leading.equalTo(self.mas_leading);
            make.centerY.equalTo(self.mas_centerY);
        }];
        [self.actionButton mas_updateConstraints:^(MASConstraintMaker *make) {
            make.trailing.equalTo(self.mas_trailing);
            make.centerY.equalTo(self.mas_centerY);
        }];
        
        [self.textField mas_updateConstraints:^(MASConstraintMaker *make) {
            make.leading.equalTo(self.iconImageView.mas_trailing);
            make.trailing.equalTo(self.actionButton.mas_leading);
            make.centerY.equalTo(self.mas_centerY);
            make.height.equalTo(self.mas_height);
        }];
        
    }else{
        [self.actionButton mas_updateConstraints:^(MASConstraintMaker *make) {
            make.trailing.equalTo(self.mas_trailing);
            make.centerY.equalTo(self.mas_centerY);
            make.width.mas_equalTo(24);
        }];
        
        [self.textField mas_updateConstraints:^(MASConstraintMaker *make) {
            make.leading.equalTo(self.mas_leading);
            make.trailing.equalTo(self.actionButton.mas_leading);
            make.centerY.equalTo(self.mas_centerY);
            make.height.equalTo(self.mas_height);
        }];
    }
}
@end
