//
//  HGAlertController.m
//  OEMFoundation
//
//  Created by syp on 2020/6/23.
//

#import "HGAlertController.h"
#import "HGFoundationMacros.h"
#define HGAlertViewMargin MIN(52, HG_SCREEN_SCALE_WIDTH(52))
#define HGAlertViewMaxWidth (HG_SCREEN_WIDTH - HGAlertViewMargin - HGAlertViewMargin)
#define HGAlertViewActionButtonHeight 44

static const NSInteger tagPrefix = 1234;




@interface HGAlertController()

@end

@implementation HGAlertController

+ (instancetype)alertControllerWithTitle:(NSString *)title
                                 message:(NSString *)message
                                 actions:(NSArray<HGAlertAction *> *)actions
{
    return [self alertControllerWithAttributedTitle:[[NSAttributedString alloc] initWithString:title] attributedMessage:[[NSAttributedString alloc] initWithString:message] actions:actions];
}

+ (instancetype)alertControllerWithAttributedTitle:(NSAttributedString *)title
                                 attributedMessage:(NSAttributedString *)message
                                           actions:(NSArray<HGAlertAction *> *)actions
{
    HGAlertView *contentView = [[HGAlertView alloc] initWithTitle:title message:message actions:actions];
    
    HGAlertController *alertController = [[[self class] alloc] initWithContentView:contentView];
    WEAKIFY_OBJECT(alertController);
    [actions enumerateObjectsUsingBlock:^(HGAlertAction * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        dispatch_block_t action = obj.actionBlock;
        obj.actionBlock = ^{
            safeCallBlock(action);
            [weakalertController dismiss];
        };
    }];
    return alertController;
}

- (instancetype)initWithContentView:(UIView<HGAlertContentViewProtocol> *)contentView
{
    self = [super initWithNibName:nil bundle:nil];
    if (self) {
        self.contentView = contentView;
        self.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor = RGBA_HEX(0x000000, 0.3);
    [self.view addSubview:self.contentView];
}

- (void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    CGFloat width = CGRectGetWidth(self.view.bounds);
    CGFloat height = CGRectGetHeight(self.view.bounds);
    
    CGSize contentSize = [self.contentView contentSize];
    self.contentView.frame = CGRectMake((width - contentSize.width) / 2,
                                        (height - contentSize.height) / 2,
                                        contentSize.width,
                                        contentSize.height);
}

- (void)setSubtitleTextAlignment:(NSTextAlignment)textAlignment {
    [self.contentView setMessageLabelTextAlignment:textAlignment];
}

- (void)show
{
    UIViewController *rootViewController = [UIApplication sharedApplication].keyWindow.rootViewController;
    if (rootViewController.presentedViewController) {
        [self showInParentViewController:rootViewController.presentedViewController];
    } else {
        [self showInParentViewController:rootViewController];
    }
}

- (void)showInParentViewController:(UIViewController *)parentViewController
{
    [parentViewController presentViewController:self animated:NO completion:nil];
}

- (void)dismiss
{
    [self dismissViewControllerAnimated:NO completion:nil];
}

@end


@interface HGAlertView ()

@property (nonatomic, assign) CGSize titleLabelSize;
@property (nonatomic, assign) CGSize messageLabelSize;
@property (nonatomic, assign) CGSize actionButtonSize;

@property (nonatomic, assign) CGSize contentSize;
@property (nonatomic, assign) BOOL isVerticalButton;  //按钮是否竖排

@end


@implementation HGAlertView

- (instancetype)initWithTitle:(NSAttributedString *)title message:(NSAttributedString *)message actions:(NSArray<HGAlertAction *> *)actions
{
    self = [super initWithFrame:CGRectZero];
    if (self) {
        self.actions = actions;
        
        self.backgroundColor = [UIColor whiteColor];
        self.layer.cornerRadius = 13;
        
        self.titleLabel = [UILabel new];
        self.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightRegular];
        self.titleLabel.textColor = RGB_HEX(0x000000);
        self.titleLabel.numberOfLines = 0;
        self.titleLabel.attributedText = title;
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.titleLabel];
        
        self.messageLabel = [UILabel new];
        self.messageLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightRegular];
        self.messageLabel.textColor = RGB_HEX(0x111111);
        self.messageLabel.numberOfLines = 0;
        self.messageLabel.attributedText = message;
        self.messageLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.messageLabel];
        
        CGFloat maxButtonWidth = 0;
        NSMutableArray<UIButton *> *buttons = [[NSMutableArray alloc] initWithCapacity:actions.count];
        for (NSInteger i = 0; i < actions.count; i++) {
            HGButton *button = [HGButton new];
            button.tag = tagPrefix + i;
            button.actionStyle = actions[i].style;
            [button addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
            [button setTitle:actions[i].title forState:UIControlStateNormal];
            [button setTitleColor:actions[i].textColor forState:UIControlStateNormal];
            button.titleLabel.font = actions[i].font;
            
            [button sizeToFit];
            if (button.frame.size.width > maxButtonWidth) {
                maxButtonWidth = button.frame.size.width;
            }
            
            [self addSubview:button];
            [buttons addObject:button];
        }
        self.actionButtons = [buttons copy];
        
        if (self.actionButtons.count > 0) {
            self.lineView = [UIView new];
            self.lineView.backgroundColor = RGB_HEX(0xC8C7CC);
            [self addSubview:self.lineView];
            
            if (self.actionButtons.count > 1) {
                NSMutableArray<UIView *> *buttonLines = [[NSMutableArray alloc] initWithCapacity:self.actionButtons.count - 1];
                for (NSInteger i = 0; i < self.actionButtons.count - 1; i++) {
                    UIView *buttonLine = [UIView new];
                    buttonLine.backgroundColor = RGB_HEX(0xC8C7CC);
                    [self addSubview:buttonLine];
                    [buttonLines addObject:buttonLine];
                    self.actionButtonLines = [buttonLines copy];
                }
            }
        }

        self.titleLabelSize = [self.titleLabel sizeThatFits:CGSizeMake(HGAlertViewMaxWidth - 15 - 15, 0)];
        self.messageLabelSize = [self.messageLabel sizeThatFits:CGSizeMake(HGAlertViewMaxWidth - 15 - 15, 0)];
        
        CGFloat horizonButtonWidth = self.actionButtons.count > 0 ? (HGAlertViewMaxWidth - ONE_POINT * (self.actionButtons.count - 1)) / self.actionButtons.count : 0;
        //如果按钮的最大文本宽度大于按钮的宽度，则采用上下排列布局
        self.isVerticalButton = maxButtonWidth + 10 > horizonButtonWidth;
        CGFloat height;
        if (self.titleLabelSize.height > 0 && self.messageLabelSize.height > 0) {
            height = 18 + self.titleLabelSize.height + 10 + self.messageLabelSize.height + 18;
        } else if (self.titleLabelSize.height > 0) {
            height = 18 + self.titleLabelSize.height + 18;
        } else if (self.messageLabelSize.height > 0) {
            height = 18 + self.messageLabelSize.height + 18;
        } else {
            height = 18;
        }
        if (self.isVerticalButton) {
            self.actionButtonSize = CGSizeMake(HGAlertViewMaxWidth - 15 - 15, HGAlertViewActionButtonHeight);
            height += self.actionButtons.count * (self.actionButtonSize.height + ONE_POINT);
            
            //竖排时，取消按钮要放在下面
            if (self.actions.count == self.actionButtons.count) {
                NSMutableArray *sortActionsArray = [NSMutableArray arrayWithCapacity:self.actions.count];
                NSMutableArray *sortActionButtonsArray = [NSMutableArray arrayWithCapacity:self.actionButtons.count];
                NSMutableArray *sortActionsCancelArray = [NSMutableArray array];
                NSMutableArray *sortActionButtonsCancelArray = [NSMutableArray array];
                
                for (NSInteger i = 0; i < self.actions.count; i++) {
                    HGAlertAction *action = self.actions[i];
                    UIButton *button = self.actionButtons[i];
                    if (action.style == HGAlertActionStyleCancel) {
                        [sortActionsCancelArray addObject:action];
                        [sortActionButtonsCancelArray addObject:button];
                    } else {
                        [sortActionsArray addObject:action];
                        [sortActionButtonsArray addObject:button];
                    }
                }
                if (sortActionsCancelArray.count > 0) {
                    [sortActionsArray addObjectsFromArray:[sortActionsCancelArray copy]];
                    [sortActionButtonsArray addObjectsFromArray:[sortActionButtonsCancelArray copy]];
                }
                self.actions = [sortActionsArray copy];
                self.actionButtons = [sortActionButtonsArray copy];
                for (NSInteger i = 0; i < self.actionButtons.count; i++) {
                    UIButton *button = self.actionButtons[i];
                    button.tag = tagPrefix + i;
                }
            }
            
        } else {
            self.actionButtonSize = CGSizeMake(horizonButtonWidth, HGAlertViewActionButtonHeight);
            
            if (self.actionButtons.count > 0) {
                height += self.actionButtonSize.height + ONE_POINT;
            } else {
                height += 18;
            }
        }
        self.contentSize = CGSizeMake(HGAlertViewMaxWidth, height);

        
//        if (maxButtonWidth > 0) {
//            maxButtonWidth += 30;
//            if (maxButtonWidth * buttons.count > HGAlertViewMaxWidth) {
//                maxButtonWidth = (HGAlertViewMaxWidth - ONE_POINT * (buttons.count - 1)) / buttons.count;
//            }
//            self.actionButtonSize = CGSizeMake(maxButtonWidth, HGAlertViewActionButtonHeight);
//        } else {
//            self.actionButtonSize = CGSizeZero;
//        }
//
//        CGFloat width = MAX(MAX(self.actionButtonSize.width * self.actionButtons.count + ONE_POINT * MAX(0 ,(self.actionButtons.count - 1)), self.titleLabelSize.width + 30), self.messageLabelSize.width + 30);
//
//        if (self.actionButtons.count > 0) {
//            self.actionButtonSize = CGSizeMake(width / self.actionButtons.count, HGAlertViewActionButtonHeight);
//        }
        
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    CGFloat width = CGRectGetWidth(self.bounds);
//    CGFloat height = CGRectGetHeight(self.bounds);
    
    CGFloat y;
    if (self.titleLabelSize.height > 0 && self.messageLabelSize.height > 0) {
        self.titleLabel.frame = CGRectMake((width - self.titleLabelSize.width) / 2, 18, self.titleLabelSize.width, self.titleLabelSize.height);
        self.messageLabel.frame = CGRectMake((width - self.messageLabelSize.width) / 2, CGRectGetMaxY(self.titleLabel.frame) + 10, self.messageLabelSize.width, self.messageLabelSize.height);
        y = CGRectGetMaxY(self.messageLabel.frame) + 18;
    } else if (self.titleLabelSize.height > 0) {
        self.titleLabel.frame = CGRectMake((width - self.titleLabelSize.width) / 2, 18, self.titleLabelSize.width, self.titleLabelSize.height);
        y = CGRectGetMaxY(self.titleLabel.frame) + 18;
    } else if (self.messageLabelSize.height > 0) {
        self.messageLabel.frame = CGRectMake((width - self.messageLabelSize.width) / 2, 18, self.messageLabelSize.width, self.messageLabelSize.height);
        y = CGRectGetMaxY(self.messageLabel.frame) + 18;
    } else {
        y = 18;
    }
    
    if (self.actionButtons.count > 0) {
        self.lineView.frame = CGRectMake(0, y, width, ONE_POINT);
        y += ONE_POINT;
        
        if (self.isVerticalButton) {
            for (NSInteger i = 0; i < self.actionButtons.count; i++) {
                self.actionButtons[i].frame = CGRectMake(15, y, self.actionButtonSize.width, self.actionButtonSize.height);
                y += self.actionButtonSize.height;
                
                if (i < self.actionButtonLines.count) {
                    self.actionButtonLines[i].frame = CGRectMake(0, y, width, ONE_POINT);
                    y += ONE_POINT;
                }
            }
            
        } else {
            CGFloat x = 0;
            for (NSInteger i = 0; i < self.actionButtons.count; i++) {
                self.actionButtons[i].frame = CGRectMake(x, y, self.actionButtonSize.width, self.actionButtonSize.height);
                x += self.actionButtonSize.width;
                
                if (i < self.actionButtonLines.count) {
                    self.actionButtonLines[i].frame = CGRectMake(x, y, ONE_POINT, self.actionButtonSize.height);
                    x += ONE_POINT;
                }
            }
        }
    }
}

- (void)setMessageLabelTextAlignment:(NSTextAlignment)textAlignment{
    self.messageLabel.textAlignment = textAlignment;
}

#pragma mark - click button

- (void)clickButton:(UIButton *)button
{
    NSInteger index = button.tag - tagPrefix;
    if (index < self.actions.count) {
        safeCallBlock(self.actions[index].actionBlock);
    }
}

@end

@implementation HGAlertAction

+ (instancetype)actionWithTitle:(NSString *)title action:(dispatch_block_t)action {
    return [self actionWithTitle:title style:HGAlertActionStyleDefault action:action];
}

+ (instancetype)actionWithTitle:(NSString *)title style:(HGAlertActionStyle)style action:(dispatch_block_t)action {
    HGAlertAction *alertAction = [HGAlertAction new];
    alertAction.title = title;
    alertAction.actionBlock = action;
    alertAction.style = style;
    
    switch (style) {
        case HGAlertActionStyleDefault:{
            alertAction.font = [UIFont systemFontOfSize:16 weight:UIFontWeightRegular];
        }
            break;
            
        case HGAlertActionStyleCancel:{
            alertAction.font = [UIFont systemFontOfSize:16 weight:UIFontWeightRegular];
        }
            break;
        case HGAlertActionStyleCustom:{
            //alertAction.font = [UIFont systemFontOfSize:16 weight:UIFontWeightRegular];
        }
            break;
            
            
        default:
            break;
    }
    
    return alertAction;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        self.textColor = RGBA_HEX(0x000000, 0.4);
    }
    return self;
}

@end
