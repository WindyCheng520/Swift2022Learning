//
//  OEMBaseViewController.m
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/18.
//

#import "OEMBaseViewController.h"
#import <HBDNavigationBar/UIViewController+HBD.h>
#import "UIResponder+OEMThemes.h"
#import "MSOEMThemesManager.h"

@interface OEMBaseViewController ()<UIGestureRecognizerDelegate>
@property (nonatomic, assign) BOOL preNavigationBarHidden;
@property (nonatomic, strong) UITapGestureRecognizer *hideKeyboardWhenTapGestureRecognizer;
@end

@implementation OEMBaseViewController

static UIImage *__defaultBackImage;
+ (void)setDefaultBackImage:(UIImage *)defaultBackImage
{
    __defaultBackImage = defaultBackImage;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.preNavigationBarHidden = self.navigationController.navigationBarHidden;
    self.view.backgroundColor = [UIColor whiteColor];
    self.canRightSlideBack = YES;
    [self createLeftButtonWithImage:__defaultBackImage];
    [self printStack];
    
    // 隐藏导航栏，就这样，不需要调用 setNavigationBarHidden:animated:
    // 也不需要担心其它页面会受到影响
    self.hbd_barHidden = [self navigationBarHidden];
    
    /*
     背景的计算规则如下：
     https://github.com/listenzz/HBDNavigationBar
     hbd_barImage 是否有值，如果有，将其设置为背景，否则下一步
     hbd_barTintColor 是否有值，如果有，将其设置为背景，否则下一步
     [[UINavigationBar appearance] backgroundImageForBarMetrics:UIBarMetricsDefault] 是否有返回值，如果有，将其设置为背景，否则下一步
     [UINavigationBar appearance].barTintColor 是否有值，如果有，将其设置为背景，否则下一步
     根据 barStyle 计算出默认的背景颜色，并将其设置为背景
     */
    
    
    [self registerTraitDidChangeCallback:^{
        if (OEMThemeIsDarkMode) {
            self.hbd_barTintColor = CommonDarkThemeForegroudColor;
        }else{
            self.hbd_barTintColor = CommonLightThemeForegroudColor;
        }
    } callImmidiately:YES];
    
    
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];

    if([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.delegate = self;
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (BOOL)navigationBarHidden
{
    return NO;
}

- (UIButton *)createRightButtonWithTitle:(NSString *)title font:(UIFont *)font color:(UIColor *)color
{
    if (title.length == 0 || !font || !color) return nil;
    
    UIButton *rightButton = [[UIButton alloc] initWithFrame:CGRectZero];
    [rightButton setTitle:title forState:UIControlStateNormal];
    rightButton.titleLabel.font = font;
    [rightButton sizeToFit];
    [rightButton setTitleColor:color forState:UIControlStateNormal];
    [rightButton addTarget:self action:@selector(rightBarButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
    self.navigationItem.rightBarButtonItem = rightItem;
    return rightButton;
}

- (UIButton *)createRightButtonWithImage:(UIImage *)image
{
    if (!image) return nil;
    
    return [self createRightButtonWithTitlesWithImages:@[image]].firstObject;
}

- (NSArray<UIButton *> *)createRightButtonWithTitlesWithImages:(NSArray<UIImage *> *)images
{
    if (images.count == 0) return nil;
    
    NSMutableArray<UIButton *> *buttons = [NSMutableArray new];
    NSMutableArray *itemArray = NSMutableArray.new;
    [images enumerateObjectsUsingBlock:^(UIImage *image, NSUInteger idx, BOOL * _Nonnull stop) {
        UIButton *rightButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, image.size.width, image.size.height)];
        [rightButton setImage:image forState:UIControlStateNormal];
        [rightButton addTarget:self action:@selector(rightBarButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        rightButton.tag = idx;
        UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
        [itemArray addObject:rightItem];
        [buttons addObject:rightButton];
    }];
    self.navigationItem.rightBarButtonItems = itemArray;
    return buttons;
}

- (void)rightBarButtonClick:(UIButton *)button
{
    
}

- (UIButton *)createLeftButtonWithImage:(UIImage *)image
{
    if (!image) return nil;
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setImage:image forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 0, image.size.width, image.size.height);
    [button addTarget:self action:@selector(leftBarButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *Item = [[UIBarButtonItem alloc] initWithCustomView:button];
    [Item setBackgroundImage:image forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    self.navigationItem.leftBarButtonItem = Item;
    return button;
}

- (void)leftBarButtonClick:(UIButton *)button
{
    if (self.navigationController.viewControllers.count > 1) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else {
        [self dismissViewControllerAnimated:YES completion:Nil];
    }
}

- (void)setHiddenKeyboardWhenTap:(BOOL)hiddenKeyboardWhenTap
{
    _hiddenKeyboardWhenTap = hiddenKeyboardWhenTap;
    
    if (hiddenKeyboardWhenTap) {
        if (!self.hideKeyboardWhenTapGestureRecognizer) {
            self.hideKeyboardWhenTapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideKeyboard)];
            self.hideKeyboardWhenTapGestureRecognizer.cancelsTouchesInView = NO;
            [self.view addGestureRecognizer:self.hideKeyboardWhenTapGestureRecognizer];
        }
    } else {
        if (self.hideKeyboardWhenTapGestureRecognizer) {
            [self.view removeGestureRecognizer:self.hideKeyboardWhenTapGestureRecognizer];
        }
    }
}

- (void)hideKeyboard
{
    [self.view endEditing:YES];
}

- (void)printStack {
    if (self.navigationController.viewControllers.count > 0) {
        NSLog(@"+++++++++++++++++++++++++++++++++++++");
        for (NSInteger i = 0; i < self.navigationController.viewControllers.count; i++) {
            UIViewController *VC = self.navigationController.viewControllers[i];
            NSLog(@"栈编号%ld,类名==%@",(long)i,NSStringFromClass([VC class]));
        }
        NSLog(@"+++++++++++++++++++++++++++++++++++++");
    }
    
}

#pragma mark - UIGestureRecognizerDelegate
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer
{
    if (self.navigationController.viewControllers.count <= 1 || !self.canRightSlideBack) {
        return NO;
    }
    return YES;
}


@end
