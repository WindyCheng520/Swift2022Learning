//
//  OEMTitleAndOneButtonAlertView.m
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/13.
//

#import "OEMTitleAndOneButtonAlertView.h"
#import "UIResponder+OEMThemes.h"

@implementation OEMTitleAndOneButtonAlertView

- (instancetype)initWithTitle:(NSString *)title confirmButtonName:(NSString *)confirmButtonName{
    if (self = [super initWithTitle:title confirmButtonName:confirmButtonName]) {
        [self configureOEMTheme];
    }
    return self;
}

- (void)configureOEMTheme{
    [self.backView configureThemeTag:OEMThemesTag_UIView_Background];
    [self.backView specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIView_Background) : OEMDarkAlertViewBackground
    } lightModeProperties:@{
        @(OEMThemesTag_UIView_Background) : OEMLightAlertViewBackground
    }];
    [self.confirmButton configureThemeTag:OEMThemesTag_UIButton_TitleThemeColor];
    [self.titleLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
    self.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
}
@end
