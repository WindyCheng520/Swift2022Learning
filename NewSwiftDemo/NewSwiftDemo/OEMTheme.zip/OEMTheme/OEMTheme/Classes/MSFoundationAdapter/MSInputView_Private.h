//
//  MSInputView_Private.h
//  Pods
//
//  Created by Neil 韦学宁 on 2021/6/24.
//

#ifndef MSInputView_Private_h
#define MSInputView_Private_h

#import <OEMFoundation/MSInputView.h>
#import <UIKit/UIKit.h>

@interface MSInputView()

@property (nonatomic, strong) UITextField *textField;

@end

#endif /* MSInputView_Private_h */
