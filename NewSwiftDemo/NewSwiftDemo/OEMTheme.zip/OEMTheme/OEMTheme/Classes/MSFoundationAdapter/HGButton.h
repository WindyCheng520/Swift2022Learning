//
//  HGButton.h
//  HGUIKit
//
//  Created by syp on 2020/6/17.
//

#import <UIKit/UIKit.h>


typedef NS_ENUM(NSInteger, HGAlertActionStyle) {
    HGAlertActionStyleDefault = 0,
    HGAlertActionStyleCancel,
    HGAlertActionStyleCustom
};

typedef enum : NSUInteger {
    HGButtonStyleDefault = 0,         // 默认，不做处理
    HGButtonStyleLeftTitleRightImage, //文字在左，图片在右
    HGButtonStyleTopImageBottomTitle, //文字在下，图片在上
    HGButtonStyleLeftImageRightTitle, //文字在右，图片在左
} HGButtonStyle;



@interface HGButton : UIButton

@property (nonatomic, assign) UIEdgeInsets enlargeTouchAreaInsets;
@property (nonatomic, assign) HGButtonStyle style;
@property (nonatomic, assign) CGFloat span;
@property(nonatomic,assign)HGAlertActionStyle actionStyle;
@end
