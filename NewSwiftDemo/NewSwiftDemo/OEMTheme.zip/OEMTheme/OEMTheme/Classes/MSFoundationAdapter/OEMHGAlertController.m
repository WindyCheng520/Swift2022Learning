//
//  OEMHGAlertController.m
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/14.
//

#import "OEMHGAlertController.h"
#import "UIResponder+OEMThemes.h"
#import "UILabel+OEMThemes.h"

@interface OEMHGAlertController ()

@end

@implementation OEMHGAlertController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configureOEMTheme];
}

- (void)configureOEMTheme{
    self.view.backgroundColor = CommonAlertViewBackgroundColor;
    if (!self.contentView || ![self.contentView isKindOfClass:[HGAlertView class]]) {
        return;
    }
    HGAlertView *content = (HGAlertView *)self.contentView;
    [content configureThemeTag:OEMThemesTag_UIView_Foreground];
    [content.titleLabel configure90TranslucentTrait];
    [content.messageLabel configure40TranslucentTrait];
    [content.actionButtons enumerateObjectsUsingBlock:^(HGButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if(obj.actionStyle == HGAlertActionStyleCancel){
            [obj configureThemeTag:OEMThemesTag_UIButton_TitleTraitColor];
        }else if(obj.actionStyle ==  HGAlertActionStyleDefault){
            [obj configureThemeTag:OEMThemesTag_UIButton_TitleThemeColor];
        }else{
        }
    }];
    [content.lineView configureThemeTag:OEMThemesTag_UIView_Sepline];
    [content.lineView specialPropertiesForDarkMode:@{
            @(OEMThemesTag_UIView_Sepline) : CommonDarkSeplineColor
        } lightModeProperties:@{
            @(OEMThemesTag_UIView_Sepline) : CommonDarkSeplineColor
        }];
    [content.actionButtonLines enumerateObjectsUsingBlock:^(UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [obj configureThemeTag:OEMThemesTag_UIView_Sepline];
        [obj specialPropertiesForDarkMode:@{
                    @(OEMThemesTag_UIView_Sepline) : CommonDarkSeplineColor
                } lightModeProperties:@{
                    @(OEMThemesTag_UIView_Sepline) : CommonDarkSeplineColor
                }];
    }];
}

@end
