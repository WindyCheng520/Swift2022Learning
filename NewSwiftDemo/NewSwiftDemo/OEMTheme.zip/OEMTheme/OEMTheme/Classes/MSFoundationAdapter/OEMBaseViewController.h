//
//  OEMBaseViewController.h
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface OEMBaseViewController : UIViewController

+ (void)setDefaultBackImage:(UIImage *)defaultBackImage;

@property (nonatomic, assign) BOOL hiddenKeyboardWhenTap;
@property (nonatomic, assign) BOOL canRightSlideBack;

- (BOOL)navigationBarHidden;

- (UIButton *)createRightButtonWithImage:(UIImage *)image;
- (NSArray<UIButton *> *)createRightButtonWithTitlesWithImages:(NSArray<UIImage *> *)images;

- (UIButton *)createRightButtonWithTitle:(NSString *)title font:(UIFont *)font color:(UIColor *)color;

- (UIButton *)createLeftButtonWithImage:(UIImage *)image;

- (void)rightBarButtonClick:(UIButton *)button;
- (void)leftBarButtonClick:(UIButton *)button;

@end

NS_ASSUME_NONNULL_END
