//
//  UICollectionViewCell+GridStyle.m
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/23.
//

#import "UICollectionViewCell+GridStyle.h"
#import <Masonry/Masonry.h>
#import "UIResponder+OEMThemes.h"

@implementation UICollectionViewCell (GridStyle)

- (void)configureGrid:(CollectionViewCellGrid)grid{
    [self configureTop:grid];
    [self configureLeading:grid];
    [self configureTraling:grid];
    [self configureBottom:grid];
}

- (void)configureCellWithTotalCount:(NSInteger)totalCount
                             perRow:(NSInteger)perRow
                       currentIndex:(NSInteger)currentIndex{
    CollectionViewCellGrid style = CollectionViewCellGrid_None;
    if (currentIndex % perRow < perRow - 1) {
        style |= CollectionViewCellGrid_Trailing;
    }
    
    if ((currentIndex / perRow) < (totalCount / perRow)) {
        style |= CollectionViewCellGrid_Bottom;
    }
    
    if (currentIndex < perRow) {
        style |= CollectionViewCellGrid_Top;
    }
    
    [self configureGrid:style];
}


#define CollectionViewCellLineSize     (0.5)

#define CollectionViewCellGridTagOfTop (1100)

- (void)configureTop:(CollectionViewCellGrid)grid{
    UIView * sep = [self viewWithTag:CollectionViewCellGridTagOfTop];
    if (!sep) {
        sep = [[UIView alloc] initWithFrame:CGRectZero];
        sep.tag = CollectionViewCellGridTagOfTop;
        [self addSubview:sep];
    }
    [sep mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self).offset(0);
        make.trailing.equalTo(self).offset(0);
        make.top.equalTo(self);
        make.height.mas_equalTo(CollectionViewCellLineSize);
    }];
    sep.hidden = !(grid & CollectionViewCellGrid_Top);
    [sep configureThemeTag:OEMThemesTag_UIView_Sepline];
}

#define CollectionViewCellGridTagOfLeading (1102)

- (void)configureLeading:(CollectionViewCellGrid)grid{
    UIView * sep = [self viewWithTag:CollectionViewCellGridTagOfLeading];
    if (!sep) {
        sep = [[UIView alloc] initWithFrame:CGRectZero];
        sep.tag = CollectionViewCellGridTagOfLeading;
        [self addSubview:sep];
    }
    [sep mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self).offset(0);
        make.top.equalTo(self).offset(0);
        make.bottom.equalTo(self);
        make.width.mas_equalTo(CollectionViewCellLineSize);
    }];
    sep.hidden = !(grid & CollectionViewCellGrid_Leading);
    [sep configureThemeTag:OEMThemesTag_UIView_Sepline];
}

#define CollectionViewCellGridTagOfTrailing (1103)

- (void)configureTraling:(CollectionViewCellGrid)grid{
    UIView * sep = [self viewWithTag:CollectionViewCellGridTagOfTrailing];
    if (!sep) {
        sep = [[UIView alloc] initWithFrame:CGRectZero];
        sep.tag = CollectionViewCellGridTagOfTrailing;
        [self addSubview:sep];
    }
    [sep mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).offset(0);
        make.trailing.equalTo(self).offset(0);
        make.bottom.equalTo(self);
        make.width.mas_equalTo(CollectionViewCellLineSize);
    }];
    sep.hidden = !(grid & CollectionViewCellGrid_Trailing);
    [sep configureThemeTag:OEMThemesTag_UIView_Sepline];
}

#define CollectionViewCellGridTagOfBottom (1104)

- (void)configureBottom:(CollectionViewCellGrid)grid{
    UIView * sep = [self viewWithTag:CollectionViewCellGridTagOfBottom];
    if (!sep) {
        sep = [[UIView alloc] initWithFrame:CGRectZero];
        sep.tag = CollectionViewCellGridTagOfBottom;
        [self addSubview:sep];
    }
    [sep mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self).offset(0);
        make.trailing.equalTo(self).offset(0);
        make.bottom.equalTo(self);
        make.height.mas_equalTo(CollectionViewCellLineSize);
    }];
    sep.hidden = !(grid & CollectionViewCellGrid_Bottom);
    [sep configureThemeTag:OEMThemesTag_UIView_Sepline];
}

@end
