//
//  UINavigationController+OEMThemes.m
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2022/3/29.
//

#import "UINavigationController+OEMThemes.h"
#import <objc/runtime.h>
#import "OEMThemesDefine.h"
#import "NSObject+Swizzle.h"
#import "UIResponder+OEMThemes.h"
#import "MSOEMThemesManager.h"
#import "UIColor+OEMThemes.h"

@implementation UINavigationController (OEMThemes)

+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [self methodSwizzleForClass:[self class] rawSEL:@selector(childViewControllerForStatusBarStyle) replaceSEL:@selector(UINavigationControllerOMEChildViewControllerForStatusBarStyle)];
    });
}

- (UIViewController *)UINavigationControllerOMEChildViewControllerForStatusBarStyle{
    if ([self containTheme:OEMThemesTag_Background_UnSpecified]) {
        return [self UINavigationControllerOMEChildViewControllerForStatusBarStyle];
    }
    return self.topViewController;
}

@end
