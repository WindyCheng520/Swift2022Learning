//
//  UITextField+OEMThemes.m
//  MSReactNative
//
//  Created by Neil 韦学宁 on 2021/7/6.
//

#import "UITextField+OEMThemes.h"
#import <objc/runtime.h>
#import "OEMThemesDefine.h"
#import "NSObject+Swizzle.h"
#import "UIResponder+OEMThemes.h"
#import "MSOEMThemesManager.h"
#import "UIColor+OEMThemes.h"

@implementation UITextField (OEMThemes)

+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [self methodSwizzleForClass:[self class] rawSEL:@selector(setTextColor:) replaceSEL:@selector(UITextFieldOEMStyleSetTextColor:)];
        [self methodSwizzleForClass:[self class] rawSEL:@selector(setBackgroundColor:) replaceSEL:@selector(UITextFieldOEMStyleSetBackgroundColor:)];
    });
}

- (void)UITextFieldOEMStyleSetTextColor:(UIColor *)textColor{
    if ([self containTheme:OEMThemesTag_Background_UnSpecified]) {
        [self UITextFieldOEMStyleSetTextColor:textColor];
        return;
    }
    
    UIColor * config_text = [self handleCollorSettingWithTag:OEMThemesTag_UITextField_Textcolor
                        defaultDarkColor:CommonDarkThemeInputTextColor
                       defaultLightColor:CommonLightThemeInputTextColor];
    if (config_text) {
        [self UITextFieldOEMStyleSetTextColor:config_text];
        return;
    }
}

- (void)UITextFieldOEMStyleSetBackgroundColor:(UIColor *)backgroundColor{
    if ([self containTheme:OEMThemesTag_Background_UnSpecified]) {
        [self UITextFieldOEMStyleSetBackgroundColor:backgroundColor];
        return;
    }
    UIColor * color = [self handleCollorSettingWithTag:OEMThemesTag_UITextField_BackgroundColor
                        defaultDarkColor:CommonDarkThemeInputTextColor
                       defaultLightColor:CommonLightThemeInputTextColor];
    if (color) {
        //这里overwrite的意义是 背景颜色或许跟输入的文本长度相关
        [self UITextFieldOEMStyleSetBackgroundColor:color];
        return;
    }
}

- (void)syncTheme{
    if ([self containTheme:OEMThemesTag_UITextField_BackgroundColor]) {
        self.backgroundColor = self.backgroundColor;
    }
    if ([self containTheme:OEMThemesTag_UITextField_Textcolor]) {
        self.textColor = self.textColor;
        if (self.placeholder.length > 0) {
            UIColor * tcolor = OEMThemeColorWithTrait(LightThemeTextFieldPlaceHolder, DarkThemeTextFieldPlaceHolder);
            self.attributedPlaceholder = [[NSAttributedString alloc]
                                          initWithString:self.placeholder
                                          attributes:@{
                                              NSForegroundColorAttributeName : tcolor
                                          }];
        }
    }
}

@end
