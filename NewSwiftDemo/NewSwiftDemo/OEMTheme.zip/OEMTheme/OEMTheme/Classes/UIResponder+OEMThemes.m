//
//  UIResponder+OEMThemes.m
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/7.
//

#import "UIResponder+OEMThemes.h"
#import <objc/runtime.h>
#import "OEMThemesDefine.h"
#import "NSObject+Swizzle.h"
#import "MSOEMThemesManager.h"
#import "UIColor+OEMThemes.h"

@implementation UIResponder (OEMThemes)

- (void)configureThemeTag:(OEMThemesTag)tag{
    [self setThemeTag:tag];
    [self syncTheme];
}

- (void)updateThemeTag:(OEMThemesTag)tag{
    [self setThemeTag:tag];
}

#pragma mark - ====== APIs ======

static const void *const kOEMUIViewThemeAssociatedObjectKey = &kOEMUIViewThemeAssociatedObjectKey;

- (void)setThemeTag:(OEMThemesTag)tag{
    NSMutableSet * originSets = [self themeTagSets];
    [originSets addObject:[self tagIdentifier:tag]];
     objc_setAssociatedObject(self,
                              kOEMUIViewThemeAssociatedObjectKey,
                              originSets,
                              OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:OEMThemeDidChangeNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onRecvOEMThemeDidChangeNotification:) name:OEMThemeDidChangeNotification object:nil];
}

- (BOOL)containTheme:(OEMThemesTag)tag{
    NSString * tagStr = [self tagIdentifier:tag];
    NSMutableSet * set = [self themeTagSets];
    if (tag == OEMThemesTag_Background_UnSpecified && [set count] == 0) {
        return YES;
    }
    if ([set containsObject:tagStr]) {
        return YES;
    }
    return NO;
}

- (NSString *)tagIdentifier:(OEMThemesTag)tag{
    NSString * tagStr = [NSString stringWithFormat:@"%lu", (unsigned long)tag];
    return tagStr;
}

- (NSMutableSet <NSString *> *)themeTagSets{
    NSMutableSet * sets = objc_getAssociatedObject(self,
                                              kOEMUIViewThemeAssociatedObjectKey);
    if (![sets isKindOfClass:[NSMutableSet class]]) {
        return [NSMutableSet new];
    }
    return sets;
}

static const void *const kOEMUIResponseThemeAssociatedObjectTaitCallbackKey = &kOEMUIResponseThemeAssociatedObjectTaitCallbackKey;

- (void)setTraitDidChangeCallback:(os_block_t)callback{
     objc_setAssociatedObject(self,
                              kOEMUIResponseThemeAssociatedObjectTaitCallbackKey,
                              callback,
                              OBJC_ASSOCIATION_COPY);
}

- (os_block_t)getTraitDidChangeCallback{
    os_block_t callblack = objc_getAssociatedObject(self,
                                              kOEMUIResponseThemeAssociatedObjectTaitCallbackKey);
    if (callblack) {
        return callblack;
    }
    return nil;
}

- (void)syncTheme{
    //should overwrite
    //"⚠️ should overwrite"
}

- (void)registerTraitDidChangeCallback:(os_block_t)callback
                       callImmidiately:(BOOL)callImmidiately{
    [self setTraitDidChangeCallback:callback];
    if (callImmidiately) {
        [self TraitDidChange];
    }
    [[NSNotificationCenter defaultCenter] removeObserver:self name:OEMThemeDidChangeNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onRecvOEMThemeDidChangeNotification:) name:OEMThemeDidChangeNotification object:nil];
}

- (void)specialPropertiesForDarkMode:(NSDictionary *)darkModeProperties
                 lightModeProperties:(NSDictionary *)lightModeProperties{
    NSArray <NSNumber *> * darkKeys = [darkModeProperties allKeys];
    NSArray <NSNumber *> * lightKeys = [lightModeProperties allKeys];
    [darkKeys enumerateObjectsUsingBlock:^(NSNumber * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if (![obj isKindOfClass:[NSNumber class]]) {
            NSAssert(false, @"wrong property value must be NSNumber Object with value OEMThemesTag");
            return;
        }
        if (obj.intValue > OEMThemesTag_Boundry_End) {
            NSAssert(false, @"out of OEMThemesTag boundry");
            return;
        }
        [self updateThemeTag:obj.intValue];
    }];
    
    [lightKeys enumerateObjectsUsingBlock:^(NSNumber * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if (![obj isKindOfClass:[NSNumber class]]) {
            NSAssert(false, @"wrong property value must be NSNumber Object with value OEMThemesTag");
            return;
        }
        if (obj.intValue > OEMThemesTag_Boundry_End) {
            NSAssert(false, @"out of OEMThemesTag boundry");
            return;
        }
        [self updateThemeTag:obj.intValue];
    }];
    
    [MSOEMThemesManager registerSpecialPropertiesForResponser:self properties:@{
        @(OEMThemesStyle_Dark): darkModeProperties ?: @{},
        @(OEMThemesStyle_Light): lightModeProperties ?: @{},
    }];
    [self syncTheme];
}

- (NSDictionary *)darkModeSpecialProperties{
    NSDictionary * allPro = [MSOEMThemesManager specialPropertiesForResponsder:self];
    if ([allPro isKindOfClass:[NSDictionary class]]) {
        NSDictionary * dark = [allPro objectForKey:@(OEMThemesStyle_Dark)];
        return dark;
    }
    return nil;
}

- (NSDictionary *)lightModeSpecialProperties{
    NSDictionary * allPro = [MSOEMThemesManager specialPropertiesForResponsder:self];
    if ([allPro isKindOfClass:[NSDictionary class]]) {
        NSDictionary * dark = [allPro objectForKey:@(OEMThemesStyle_Light)];
        return dark;
    }
    return nil;
}

- (UIColor *)darkModePropertiesWithTag:(OEMThemesTag)tag defaultColor:(UIColor *)defaultColor{
    NSDictionary * pro = [self darkModeSpecialProperties];
    if (pro && [[pro objectForKey:@(tag)] isKindOfClass:[UIColor class]]) {
        UIColor * color =  [pro objectForKey:@(tag)];
        return color;
    }
    return  defaultColor;
}

- (UIColor *)lightModePropertiesWithTag:(OEMThemesTag)tag defaultColor:(UIColor *)defaultColor{
    NSDictionary * pro = [self lightModeSpecialProperties];
    if (pro && [[pro objectForKey:@(tag)] isKindOfClass:[UIColor class]]) {
        UIColor * color =  [pro objectForKey:@(tag)];
        return color;
    }
    return  defaultColor;
}

- (UIColor *)colorForTag:(OEMThemesTag)tag
            colorForDark:(UIColor *)colorForDark
           colorForLight:(UIColor *)colorForLight{
    return OEMThemeIsDarkMode ? [self darkModePropertiesWithTag:tag defaultColor:colorForDark]: [self lightModePropertiesWithTag:tag defaultColor:colorForLight];
}

- (NSNumber *)valueForTag:(OEMThemesTag)tag
                darkValue:(NSNumber *)darkValue
               lightValue:(NSNumber *)lightValue{
    NSDictionary * pro = OEMThemeIsDarkMode? [self darkModeSpecialProperties] : [self lightModeSpecialProperties];
    if (pro && [[pro objectForKey:@(tag)] isKindOfClass:[NSNumber class]]) {
        NSNumber * v =  [pro objectForKey:@(tag)];
        return v;
    }
    return OEMThemeIsDarkMode ? darkValue: lightValue;
}

- (UIColor * _Nullable )handleCollorSettingWithTag:(OEMThemesTag)tag
                                  defaultDarkColor:(UIColor *)defaultDarkColor
                                 defaultLightColor:(UIColor *)defaultLightColor{
    if ([self containTheme:tag]) {
        if (@available(iOS 13.0, *)) {
            __weak typeof(self) weakSelf = self;
            UIColor * tcolor = [UIColor colorWithDynamicProvider:^UIColor * _Nonnull(UITraitCollection * _Nonnull traitCollection) {
                return OEMThemeIsDarkMode ? [weakSelf darkModePropertiesWithTag:tag defaultColor:defaultDarkColor] : [weakSelf lightModePropertiesWithTag:tag defaultColor:defaultLightColor];
            }];
            return tcolor;
        } else {
            UIColor * color =  [self colorForTag:tag
                                    colorForDark:defaultDarkColor
                                   colorForLight:defaultLightColor];
            return color;
        }
    }
    return nil;
}

#pragma mark - ====== Internal ======

- (void)TraitDidChange{
    if ([UIApplication sharedApplication].applicationState == UIApplicationStateBackground) {
        //进入后台时，系统会截屏两次（一次暗黑，一次浅色），此时需要在当前runloop完成截屏，确保App switcher能正常显示
        os_block_t block = [self getTraitDidChangeCallback];
        if (block) {
            block();
        }
    }else{
        //避免一次性大量渲染造成卡顿
        dispatch_async(dispatch_get_main_queue(), ^{
            os_block_t block = [self getTraitDidChangeCallback];
            if (block) {
                block();
            }
        });
    }
}

- (void)onRecvOEMThemeDidChangeNotification:(NSNotification *)notification{
    if ([UIApplication sharedApplication].applicationState == UIApplicationStateBackground) {
        [self TraitDidChange];
        //进入后台时，系统会截屏两次（一次暗黑，一次浅色），此时需要在当前runloop完成截屏，确保App switcher能正常显示
        [self syncTheme];
    }else{
        dispatch_async(dispatch_get_main_queue(), ^{
            //避免一次性大量渲染造成卡顿
            [self TraitDidChange];
            [self syncTheme];
        });
    }
}


@end
