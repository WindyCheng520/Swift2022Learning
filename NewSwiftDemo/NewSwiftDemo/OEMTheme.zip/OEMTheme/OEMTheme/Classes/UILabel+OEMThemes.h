//
//  UILabel+OEMThemes.h
//  MSReactNative
//
//  Created by Neil 韦学宁 on 2021/7/6.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UILabel (OEMThemes)

- (void)configure90TranslucentTrait;

- (void)configure60TranslucentTrait;

- (void)configure40TranslucentTrait;

- (void)configure20TranslucentTrait;

@end

NS_ASSUME_NONNULL_END
