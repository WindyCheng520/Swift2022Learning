//
//  UIView+OEMThemes.m
//  MSReactNative
//
//  Created by Neil 韦学宁 on 2021/7/6.
//

#import "UIView+OEMThemes.h"
#import <objc/runtime.h>
#import "OEMThemesDefine.h"
#import "NSObject+Swizzle.h"
#import "UIResponder+OEMThemes.h"
#import "MSOEMThemesManager.h"

@implementation UIView (OEMThemes)

+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [self methodSwizzleForClass:[self class] rawSEL:@selector(setBackgroundColor:) replaceSEL:@selector(UIViewOEMStyleSetBackgroundColor:)];
        [self methodSwizzleForClass:[self class] rawSEL:@selector(traitCollectionDidChange:) replaceSEL:@selector(UIViewOEMStyleTraitCollectionDidChange:)];
    });
}

#pragma mark - ====== hooks ======

- (void)UIViewOEMStyleSetBackgroundColor:(UIColor *)backgroundColor{
    if ([self containTheme:OEMThemesTag_Background_UnSpecified]) {
        [self UIViewOEMStyleSetBackgroundColor:backgroundColor];
        return;
    }
    
    //自定义，根据OEMThemesTag_Background_EnableCustom字段获取对应的颜色
    UIColor * config_custom = [self handleCollorSettingWithTag:OEMThemesTag_Background_EnableCustom
                                                   defaultDarkColor:CommonDarkThemeBackgroudColor
                                                  defaultLightColor:CommonLightThemeBackgroudColor];
    if (config_custom) {
        [self UIViewOEMStyleSetBackgroundColor:config_custom];
        return;
    }
    
    UIColor * config_bg = [self handleCollorSettingWithTag:OEMThemesTag_UIView_Background
                                          defaultDarkColor:CommonDarkThemeBackgroudColor
                                         defaultLightColor:CommonLightThemeBackgroudColor];
    if (config_bg) {
        [self UIViewOEMStyleSetBackgroundColor:config_bg];
        return;
    }
    
    
    UIColor * config_forground = [self handleCollorSettingWithTag:OEMThemesTag_UIView_Foreground
                                          defaultDarkColor:CommonDarkThemeForegroudColor
                                         defaultLightColor:CommonLightThemeForegroudColor];
    if (config_forground) {
        [self UIViewOEMStyleSetBackgroundColor:config_forground];
        return;
    }
    

    UIColor * config_seprator = [self handleCollorSettingWithTag:OEMThemesTag_UIView_Sepline
                                          defaultDarkColor:CommonDarkSeplineColor
                                         defaultLightColor:CommonLightSeplineColor];
    if (config_seprator) {
        [self UIViewOEMStyleSetBackgroundColor:config_seprator];
        return;
    }
    
    [self UIViewOEMStyleSetBackgroundColor:backgroundColor];
}

- (void)UIViewOEMStyleTraitCollectionDidChange:(UITraitCollection *)previousTraitCollection{
    //call origin method
    [self UIViewOEMStyleTraitCollectionDidChange:previousTraitCollection];
    if (@available(iOS 13.0, *)) {
        [[MSOEMThemesManager sharedManager] onTraitCollectionDidChange:previousTraitCollection obj:self];
    } else {
        // Fallback on earlier versions
    }
}

- (void)addThemeBottomSeplineWithOffset:(CGFloat)offset{
    UIView * sep = [self viewWithTag:UIViewOEMThemesSeplineTag];
    if (!sep) {
        sep = [[UIView alloc] initWithFrame:CGRectZero];
        sep.tag = UIViewOEMThemesSeplineTag;
        [self addSubview:sep];
    }
    [sep mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self).offset(offset);
        make.trailing.equalTo(self).offset(-offset);
        make.bottom.equalTo(self);
        make.height.mas_equalTo(0.5);
    }];
    sep.hidden = NO;
    [sep configureThemeTag:OEMThemesTag_UIView_Sepline];
}

- (void)addThemeBottomSeplineWithLeading:(CGFloat)leading trailing:(CGFloat)trailing{
    UIView * sep = [self viewWithTag:UIViewOEMThemesSeplineTag];
    if (!sep) {
        sep = [[UIView alloc] initWithFrame:CGRectZero];
        sep.tag = UIViewOEMThemesSeplineTag;
        [self addSubview:sep];
    }
    [sep mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self).offset(leading);
        make.trailing.equalTo(self).offset(-trailing);
        make.bottom.equalTo(self);
        make.height.mas_equalTo(0.5);
    }];
    sep.hidden = NO;
    [sep configureThemeTag:OEMThemesTag_UIView_Sepline];
}

- (void)disableSepline{
    UIView * sep = [self viewWithTag:UIViewOEMThemesSeplineTag];
    if (sep) {
        sep.hidden = YES;
    }
}

- (void)syncTheme{
    if ([self containTheme:OEMThemesTag_Background_UnSpecified]) {
        return;
    }
    self.backgroundColor = self.backgroundColor;
}

+ (nullable UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size{
    if (!color || size.width <= 0 || size.height <= 0){
        return nil;
    }
    CGRect rect = CGRectMake(0.0f, 0.0f, size.width, size.height);
    UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, color.CGColor);
    CGContextFillRect(context, rect);
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

@end
