//
//  MSWeakWrapper.h
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/12.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MSWeakWrapper : NSObject

@property(nonatomic, readonly, weak)id weakContentObj;

@property(nonatomic, copy)NSString * address;

@property(nonatomic, copy)NSString * objectDescription;

+ (instancetype)wrapperWithObj:(id)obj;

@end

NS_ASSUME_NONNULL_END
