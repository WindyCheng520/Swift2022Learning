//
//  MSWeakWrapper.m
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/12.
//

#import "MSWeakWrapper.h"

@interface MSWeakWrapper()

@property(nonatomic, weak)id weakContentObj;

@end

@implementation MSWeakWrapper

+ (instancetype)wrapperWithObj:(id)obj{
    if (!obj) {
        return [MSWeakWrapper new];
    }
    MSWeakWrapper * wrapper = [[MSWeakWrapper alloc] init];
    wrapper.weakContentObj = obj;
    wrapper.address = [NSString stringWithFormat:@"%lu", (unsigned long)[obj hash]];
    wrapper.objectDescription = [NSString stringWithFormat:@"%@", NSStringFromClass([obj class])];
    return wrapper;
}

@end
