//
//  UIButton+OEMThemes.m
//  MSReactNative
//
//  Created by Neil 韦学宁 on 2021/7/6.
//

#import "UIButton+OEMThemes.h"
#import "NSObject+Swizzle.h"
#import "UIView+OEMThemes.h"
#import "UIResponder+OEMThemes.h"
#import "MSOEMThemesManager.h"

@implementation UIButton (OEMThemes)

+ (void)load{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [self methodSwizzleForClass:[self class] rawSEL:@selector(setTitleColor:forState:) replaceSEL:@selector(OEMThemeButtonSetTitleColor:forState:)];
        [self methodSwizzleForClass:[self class] rawSEL:@selector(setBackgroundColor:) replaceSEL:@selector(OEMThemeButtonSetBackgroundColor:)];
        [self methodSwizzleForClass:[self class] rawSEL:@selector(setEnabled:) replaceSEL:@selector(OEMThemeSetEnabled:)];
        [self methodSwizzleForClass:[self class] rawSEL:@selector(setImage:forState:) replaceSEL:@selector(OEMThemeButtonSetImage:forState:)];
        [self methodSwizzleForClass:[self class] rawSEL:@selector(setAttributedTitle:forState:) replaceSEL:@selector(OEMThemeButtonSetAttributedTitle:forState:)];
    });
}

static const void *const kOEMButtonThemeStyleAssociatedObjectKey = &kOEMButtonThemeStyleAssociatedObjectKey;

static const void *const kOEMButtonThemeStyleAssociatedObjectLightImage = &kOEMButtonThemeStyleAssociatedObjectLightImage;

static const void *const kOEMButtonThemeStyleAssociatedObjectDarkImage = &kOEMButtonThemeStyleAssociatedObjectDarkImage;

#pragma mark - ====== Internal ======

- (nullable NSArray <UIImage *> *)getDarkImages{
    UIImage * dark = objc_getAssociatedObject(self,
                                              kOEMButtonThemeStyleAssociatedObjectDarkImage);
    UIImage * light = objc_getAssociatedObject(self,
                                               kOEMButtonThemeStyleAssociatedObjectLightImage);
    if ([dark isKindOfClass:[UIImage class]]
        && [light isKindOfClass:[UIImage class]]) {
        return @[ dark, light];
    }
    return nil;
}

#pragma mark - ====== overwrite ======

- (void)syncTheme{
    if ([self containTheme:OEMThemesTag_UIButton_TitleTraitColor] ||
        [self containTheme:OEMThemesTag_UIButton_TitleThemeColor]) {
        [self setTitleColor:CommonDarkThemeTextColor forState:UIControlStateNormal];
    }
    if ([self containTheme:OEMThemesTag_UIButton_Background]) {
        self.backgroundColor = self.backgroundColor;
    }
    if ([self containTheme:OEMThemesTag_UIButton_Image]) {
        [self setImage:[UIImage new] forState:UIControlStateNormal];
    }
    if ([self containTheme:OEMThemesTag_UIButton_AttributedTraitColor] ||
        [self containTheme:OEMThemesTag_UIButton_AttributedThemeColor]) {
        [self setAttributedTitle:self.currentAttributedTitle forState:UIControlStateNormal];
    }
}

#pragma mark - ====== hooks ======

- (void)OEMThemeButtonSetTitleColor:(UIColor *)color forState:(UIControlState)state{
    if ([self containTheme:OEMThemesTag_Background_UnSpecified]) {
        [self OEMThemeButtonSetTitleColor:color forState:state];
        return;
    }
    UIColor * config_title = [self handleCollorSettingWithTag:OEMThemesTag_UIButton_TitleThemeColor
                    defaultDarkColor:CommonThemeColor
                   defaultLightColor:CommonThemeColor];
    if (config_title && state == UIControlStateNormal) {
        if (self.isEnabled) {
            [self OEMThemeButtonSetTitleColor:config_title forState:state];
        }else{
            if (![self containTheme:OEMThemesTag_UIButton_TitleThemeColor_Disable]) {
                [self OEMThemeButtonSetTitleColor:CommonDarkThemeButtonDisableColor forState:state];
            }else{
                UIColor * disableColor = [self handleCollorSettingWithTag:OEMThemesTag_UIButton_TitleThemeColor_Disable
                                defaultDarkColor:CommonThemeColor
                               defaultLightColor:CommonThemeColor];
                [self OEMThemeButtonSetTitleColor:disableColor forState:state];
            }
            
        }
        return;
    }
    
    UIColor * config_trait = [self handleCollorSettingWithTag:OEMThemesTag_UIButton_TitleTraitColor
                    defaultDarkColor:CommonThemeColor
                   defaultLightColor:CommonThemeColor];
    if (config_trait && state == UIControlStateNormal) {
        [self OEMThemeButtonSetTitleColor:config_trait forState:state];
        return;
    }
}

- (void)OEMThemeButtonSetBackgroundColor:(UIColor *)backgroundColor{
    //这里overwrite的意义是背景颜色会跟button 的enable关联，UIView
    if ([self containTheme:OEMThemesTag_Background_UnSpecified]) {
        [self OEMThemeButtonSetBackgroundColor:backgroundColor];
        return;
    }
    if ([self containTheme:OEMThemesTag_UIButton_Background]) {
        if (self.isEnabled) {
            UIColor * targetColor = [self handleCollorSettingWithTag:OEMThemesTag_UIButton_Background
                            defaultDarkColor:CommonThemeColor
                           defaultLightColor:CommonThemeColor];
            [self OEMThemeButtonSetBackgroundColor:targetColor];
        }else{
            if (![self containTheme:OEMThemesTag_UIButton_Background_Disable]) {
                [self OEMThemeButtonSetBackgroundColor:CommonDarkThemeButtonDisableColor];
            }else{
                UIColor * targetColor = [self handleCollorSettingWithTag:OEMThemesTag_UIButton_Background_Disable
                                defaultDarkColor:CommonDarkThemeButtonDisableColor
                               defaultLightColor:CommonDarkThemeButtonDisableColor];
                [self OEMThemeButtonSetBackgroundColor:targetColor];
                
            }
        }
        return;
    }
}

- (void)OEMThemeSetEnabled:(BOOL)enabled{
    if ([self containTheme:OEMThemesTag_Background_UnSpecified]) {
        [self OEMThemeSetEnabled:enabled];
        return;
    }
    [self OEMThemeSetEnabled:enabled];
    [self syncTheme];
}

- (void)OEMThemeButtonSetImage:(UIImage *)image forState:(UIControlState)state{
    [self OEMThemeButtonSetImage:image forState:state];
}

- (void)OEMThemeButtonSetAttributedTitle:(NSAttributedString *)title forState:(UIControlState)state{
    UIColor * config_attributed = [self handleCollorSettingWithTag:OEMThemesTag_UIButton_AttributedTraitColor
                    defaultDarkColor:DarkThemeClearBackgroundButtonTitle
                   defaultLightColor:LightThemeClearBackgroundButtonTitle];
    if (config_attributed) {
        NSMutableAttributedString * attributedString = [[NSMutableAttributedString alloc] initWithAttributedString:title];
        NSDictionary *attributes = @{
            NSForegroundColorAttributeName : config_attributed,
        };
        [attributedString addAttributes:attributes range:NSMakeRange(0, title.length)];
        [self OEMThemeButtonSetAttributedTitle:attributedString forState:state];
        return;
    }
    
    UIColor * config_attributed_theme = [self handleCollorSettingWithTag:OEMThemesTag_UIButton_AttributedThemeColor
                    defaultDarkColor:CommonThemeColor
                   defaultLightColor:CommonThemeColor];
    if (config_attributed_theme) {
        NSMutableAttributedString * attributedString = [[NSMutableAttributedString alloc] initWithAttributedString:title];
        NSDictionary *attributes = @{
            NSForegroundColorAttributeName : config_attributed_theme,
        };
        [attributedString addAttributes:attributes range:NSMakeRange(0, title.length)];
        [self OEMThemeButtonSetAttributedTitle:attributedString forState:state];
        return;
    }
    [self OEMThemeButtonSetAttributedTitle:title forState:state];
}

@end
