//
//  UITextView+OEMThemes.m
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/15.
//

#import "UITextView+OEMThemes.h"
#import <objc/runtime.h>
#import "OEMThemesDefine.h"
#import "NSObject+Swizzle.h"
#import "UIResponder+OEMThemes.h"
#import "MSOEMThemesManager.h"

@implementation UITextView (OEMThemes)

+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [self methodSwizzleForClass:[self class] rawSEL:@selector(setTextColor:) replaceSEL:@selector(UITextViewOEMStyleSetTextColor:)];
        [self methodSwizzleForClass:[self class] rawSEL:@selector(setBackgroundColor:) replaceSEL:@selector(UITextViewOEMStylesetBackgroundColor:)];
    });
}


- (void)UITextViewOEMStyleSetTextColor:(UIColor *)textColor{
    if ([self containTheme:OEMThemesTag_Background_UnSpecified]) {
        [self UITextViewOEMStyleSetTextColor:textColor];
        return;
    }
    UIColor * color = [self handleCollorSettingWithTag:OEMThemesTag_UITextView_Textcolor
                        defaultDarkColor:CommonDarkThemeInputTextColor
                       defaultLightColor:CommonLightThemeInputTextColor];
    if ([self containTheme:OEMThemesTag_UITextView_Textcolor]) {
        [self UITextViewOEMStyleSetTextColor:color];
        return;
    }
    [self UITextViewOEMStyleSetTextColor:textColor];
}

- (void)UITextViewOEMStylesetBackgroundColor:backgroundColor{
    if ([self containTheme:OEMThemesTag_Background_UnSpecified]) {
        [self UITextViewOEMStylesetBackgroundColor:backgroundColor];
        return;
    }
    UIColor * color = [self handleCollorSettingWithTag:OEMThemesTag_UITextView_Background
                        defaultDarkColor:CommonDarkThemeForegroudColor
                       defaultLightColor:CommonLightThemeForegroudColor];
    if ([self containTheme:OEMThemesTag_UITextView_Background]) {
        [self UITextViewOEMStylesetBackgroundColor:color];
        return;
    }
    
    [self UITextViewOEMStylesetBackgroundColor:backgroundColor];
    
}

- (void)syncTheme{
    if ([self containTheme:OEMThemesTag_UITextView_Textcolor]) {
        self.textColor = self.textColor;
    }
    if ([self containTheme:OEMThemesTag_UITextView_Background]) {
        //使用父类
        self.backgroundColor = self.backgroundColor;
    }
}

@end
