//
//  NSObject+Swizzle.h
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/7.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSObject (Swizzle)

+ (void)methodSwizzleForClass:(Class)class rawSEL:(SEL)rawSEL replaceSEL:(SEL)replaceSEL;

@end

NS_ASSUME_NONNULL_END
