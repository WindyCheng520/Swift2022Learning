//
//  UIResponder+OEMThemes.h
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/7.
//

#import <UIKit/UIKit.h>
#import "OEMThemesDefine.h"

NS_ASSUME_NONNULL_BEGIN

@interface UIResponder (OEMThemes)

//===== UI样式自动适配 API Begin ======

//配置tag，调用此接口适配通用的主题颜色，如需自定义，使用specialPropertiesForDarkMode接口
- (void)configureThemeTag:(OEMThemesTag)tag;

///设置主题变化回调
- (void)registerTraitDidChangeCallback:(os_block_t)callback
                       callImmidiately:(BOOL)callImmidiately;

///根据tag设置属性值，每个tag仅支持一个属性设置
/// 调用时机：
/// @param darkModeProperties e.g. @(OEMThemesTag_UIView_Background) : [UIColor redColor],
/// @param lightModeProperties e.g. @(OEMThemesTag_UIView_Background) : [UIColor redColor],
- (void)specialPropertiesForDarkMode:(NSDictionary *)darkModeProperties
                 lightModeProperties:(NSDictionary *)lightModeProperties;


//===== UI样式自动适配 API End ======



//===== 以下接口为模块私有API ======

//根据主题色，刷新页面
- (void)syncTheme;

//查看是否包含tag
- (BOOL)containTheme:(OEMThemesTag)tag;

///根据Tag获取配置的属性值
- (NSNumber *)valueForTag:(OEMThemesTag)tag
                darkValue:(NSNumber *)darkValue
               lightValue:(NSNumber *)lightValue;

///根据Tag获取配置的颜色值
- (UIColor * _Nullable )handleCollorSettingWithTag:(OEMThemesTag)tag
                                  defaultDarkColor:(UIColor *)defaultDarkColor
                                 defaultLightColor:(UIColor *)defaultLightColor;

@end

NS_ASSUME_NONNULL_END
