//
//  UITabBar+OEMThemes.m
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/12.
//

#import "UITabBar+OEMThemes.h"
#import <objc/runtime.h>
#import "OEMThemesDefine.h"
#import "NSObject+Swizzle.h"
#import "UIResponder+OEMThemes.h"
#import "MSOEMThemesManager.h"
#import "UIView+OEMThemes.h"

@implementation UITabBar (OEMThemes)

+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [self methodSwizzleForClass:[self class] rawSEL:@selector(setBackgroundImage:) replaceSEL:@selector(UITabbarOEMThemeSetBackgroundImage:)];
    });
}

- (void)UITabbarOEMThemeSetBackgroundImage:(UIImage *)backgroundImage{
    if([self containTheme:OEMThemesTag_UITabBar_BackgroundImage]){
        CGFloat width = [UIScreen mainScreen].bounds.size.width;
        CGFloat height = 49;
        UIImage * img = [UIView imageWithColor:OEMThemeIsDarkMode ? CommonDarkThemeForegroudColor : CommonLightThemeBackgroudColor size:CGSizeMake(width, height)];
        [self UITabbarOEMThemeSetBackgroundImage:img];
        return;
    }
    [self UITabbarOEMThemeSetBackgroundImage:backgroundImage];
}

- (void)syncTheme{
    if ([self containTheme:OEMThemesTag_UITabBar_BackgroundImage]) {
        self.backgroundImage = self.backgroundImage;
    }
}

@end
