//
//  OEMThemesDefine.h
//  Pods
//
//  Created by Neil 韦学宁 on 2021/7/6.
//

#ifndef OEMThemesDefine_h
#define OEMThemesDefine_h

#import <Foundation/Foundation.h>
#import "UIColor+OEMThemes.h"

typedef NS_ENUM(NSUInteger, OEMThemesTag) {
    ///未设置
    OEMThemesTag_Background_UnSpecified = 0,
    
    ///允许自定义设置，如果需要自定义设置，则UIView设置为此值
    OEMThemesTag_Background_EnableCustom = 1,
    
    ///背景颜色
    OEMThemesTag_UIView_Background = 2,
    
    ///前景色，注册页面，设置密码页面，如果没有层次，那么就以前景色作为背景色（区别于类似UITableView那种有层次的页面）
    OEMThemesTag_UIView_Foreground = 3,
    
    ///主色调
    OEMThemesTag_UIView_Main_Color = 4,
    
    ///警告色
    OEMThemesTag_UILabel_warning = 5,
    
    ///成功色
    OEMThemesTag_UIView_Success = 6,
    
    ///失败色
    OEMThemesTag_UIView_Fail = 7,
    
    ///标签文本
    OEMThemesTag_UILabel_TextColor,
    
    //imageview
    OEMThemesTag_UIImageView_BackgroundColor,
    
    ///
    OEMThemesTag_UITextView_Textcolor,
    
    ///重写背景颜色，背景颜色有可能需要自定义
    OEMThemesTag_UITextView_Background,
    
    ///输入文本
    OEMThemesTag_UITextField_Textcolor,
    
    ///输入框背景颜色
    OEMThemesTag_UITextField_BackgroundColor,
    
    //分割线
    OEMThemesTag_UIView_Sepline,
    
    //导航栏背景色
    OEMThemesTag_UINavigationBar_Tint,
    
    //tab背景图片
    OEMThemesTag_UITabBar_BackgroundImage,
    
    //主界面颜色
    OEMThemesTag_UIViewController_Behavior,
    
    //自定义UIViewController Based状态栏颜色
    OEMThemesTag_UIViewController_BasedStatusBarAppearance,
    
    //按钮背景
    OEMThemesTag_UIButton_Background,
    
    //按钮背景: disable样式
    OEMThemesTag_UIButton_Background_Disable,
    
    //标题颜色 颜色Dark/Light不同 通用颜色
    OEMThemesTag_UIButton_TitleTraitColor,
    
    //标题颜色 颜色Dark/Light相同 通用颜色
    OEMThemesTag_UIButton_TitleThemeColor,
    
    //标题颜色 可自定义Diasble颜色
    OEMThemesTag_UIButton_TitleThemeColor_Disable,
    
    //图片
    OEMThemesTag_UIButton_Image,
    
    //属性字符串，颜色Dark/Light不同
    OEMThemesTag_UIButton_AttributedTraitColor,
    
    //属性字符串，颜色Dark/Light相同
    OEMThemesTag_UIButton_AttributedThemeColor,
    
    //导航栏堆栈下的状态栏样式，设置此tag会强制覆盖原值
    OEMThemesTag_UINavigationController_StatusBarStyle,
    
    //此枚举放在最后，边界判断
    OEMThemesTag_Boundry_End,

};

typedef NS_ENUM(NSUInteger, OEMThemesStyle) {
    OEMThemesStyle_Light,
    OEMThemesStyle_Dark,
};

//通用颜色配置宏
#define OEMThemeColorWithTrait(dark, light)  [UIColor oem_colorWithLightColor:light darkColor:dark]

//==================  Theme color  ==================

#define CommonLightThemeBackgroudColor            RGB_HEX(0xF4F4F4) //水泥白

#define CommonLightThemeForegroudColor            RGB_HEX(0xFFFFFF) //纯白

#define CommonLightThemeColor                     RGB_HEX(0x000000) //纯黑

#define CommonLightThemeButtonDisableColor        RGB_HEX(0x000000) //纯黑

#define CommonLightThemeUnexpectedColor           RGB_HEX(0x000000) //纯黑

#define CommonDarkThemeBackgroudColor            RGB_HEX(0x000000) //纯黑

#define CommonDarkThemeForegroudColor            RGB_HEX(0x1A1A1A) //暗黑灰

#define CommonThemeColor                         RGB_HEX(0x267AFF) //主题：蓝色

#define CommonDarkThemeButtonDisableColor        RGBA_HEX(0x267AFF, 0.4f) //主题：蓝色

#define CommonDarkThemeUnexpectedColor           RGB_HEX(0x00FF00) //主题：红色

#define ComoonThemeDotBackground                 RGBA_HEX(0x999999, 1.0f) //主题：

#define CommonThemeWarningColor                  RGB_HEX(0xF4B746) //警告色

//==================  Text style  ==================

#define DarkThemeNavigatorTextColor                 RGBA_HEX(0x000000, 0.9f) //

#define LightThemeNavigatorTextColor                 RGBA_HEX(0xFFFFFF, 0.9f) //

#define CommonDarkThemeTextColor                 RGBA_HEX(0xFFFFFF, 0.9f) //

#define CommonLightThemeTextColor                 RGBA_HEX(0x000000, 1.0f)

#define CommonDarkThemeInputTextColor                 RGBA_HEX(0xFFFFFF, 0.9f) //

#define CommonLightThemeInputTextColor                 RGBA_HEX(0x000000, 0.9f)

#define CommonDarkThemeContentTextColor                 RGBA_HEX(0xFFFFFF, 0.6f) //

#define CommonLightThemeContentTextColor                 RGBA_HEX(0x000000, 0.6f) //

#define CommonDarkThemeSubContentTextColor                 RGBA_HEX(0xFFFFFF, 0.2f) //

#define CommonLightThemeSubContentTextColor                 RGBA_HEX(0x000000, 0.2f) //


#define LightThemeTextFieldLightBackground                 RGBA_HEX(0xCCCCCC, 0.2f)

#define LightThemeTextFieldDarkBackground                 RGBA_HEX(0xCCCCCC, 0.2f)

#define LightThemeTextFieldPlaceHolder                    RGBA_HEX(0xFFFFFF, 0.4f)

#define DarkThemeTextFieldPlaceHolder                     RGBA_HEX(0x000000, 0.4f)

//==================  sepline color  ==================

#define DarkThemeClearBackgroundButtonTitle                 RGBA_HEX(0xFFFFFF, 0.4f)

#define LightThemeClearBackgroundButtonTitle                     RGBA_HEX(0x000000, 0.4f)

//==================  sepline color  ==================

#define CommonDarkSeplineColor                 RGBA_HEX(0x999999, 0.15f)//RGBA_HEX(0xBBBBBB, 0.2f)
#define CommonLightSeplineColor                 RGBA_HEX(0x999999, 0.15f)//RGBA_HEX(0xBBBBBB, 0.2f)

//==================  search textfield color  ==================

#define DarkThemeSearchTextFieldBackground RGBA_HEX(0x3D3D3D, 1.0f)

#define LightThemeSearchTextFieldBackground RGBA_HEX(0xF4F4F4, 1.0f)

//==================  view tag definition  ==================

#define UIViewOEMThemesSeplineTag 5341

//==================  AlertView  ==================

#define OEMDarkAlertViewBackground                 RGBA_HEX(0x222222, 0.9f)
#define OEMLightAlertViewBackground                 RGBA_HEX(0xFFFFFF, 0.9f)

#define CommonAlertViewBackgroundColor                         RGBA_HEX(0x000000, 0.5f)

//==================  Device status  ==================

#define OEMDarkDeviceStatusLabel                 RGBA_HEX(0x8A8A8F, 0.9f)

#pragma mark - ====== HUD ======

#define HUDCommonBackgroundColor                         RGBA_HEX(0x111111, 0.7f)



FOUNDATION_EXPORT NSString * const OEMThemeDidChangeNotification;


#endif /* OEMThemesDefine_h */
