//
//  UIImageView+OEMThemes.m
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/15.
//

#import "UIImageView+OEMThemes.h"
#import <objc/runtime.h>
#import "OEMThemesDefine.h"
#import "NSObject+Swizzle.h"
#import "UIResponder+OEMThemes.h"
#import "MSOEMThemesManager.h"

@implementation UIImageView (OEMThemes)

+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [self methodSwizzleForClass:[self class] rawSEL:@selector(setBackgroundColor:) replaceSEL:@selector(UIImageViewOEMStylesetBackgroundColor:)];
    });
}

- (void)UIImageViewOEMStylesetBackgroundColor:(UIColor *)backgroundColor{
    if ([self containTheme:OEMThemesTag_Background_UnSpecified]) {
        [self UIImageViewOEMStylesetBackgroundColor:backgroundColor];
        return;
    }
    UIColor * color = [self handleCollorSettingWithTag:OEMThemesTag_UIImageView_BackgroundColor
                                      defaultDarkColor:[UIColor clearColor]
                                     defaultLightColor:[UIColor clearColor]];
    if ([self containTheme:OEMThemesTag_UIImageView_BackgroundColor]) {
        [self UIImageViewOEMStylesetBackgroundColor:color];
        return;
    }
    [self UIImageViewOEMStylesetBackgroundColor:backgroundColor];
}

@end
