//
//  UINavigationBar+OEMThemes.m
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/9.
//

#import "UINavigationBar+OEMThemes.h"
#import <objc/runtime.h>
#import "OEMThemesDefine.h"
#import "NSObject+Swizzle.h"
#import "UIResponder+OEMThemes.h"
#import "MSOEMThemesManager.h"

@implementation UINavigationBar (OEMThemes)

+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [self methodSwizzleForClass:[self class] rawSEL:@selector(setBarTintColor:) replaceSEL:@selector(UINavigationBarOEMSetBarTintColor:)];
    });
}


- (void)UINavigationBarOEMSetBarTintColor:(UIColor *)tintColor{
    if ([self containTheme:OEMThemesTag_Background_UnSpecified]) {
        [self UINavigationBarOEMSetBarTintColor:tintColor];
        return;
    }
    UIColor * color = [self handleCollorSettingWithTag:OEMThemesTag_UINavigationBar_Tint
                    defaultDarkColor:CommonDarkThemeForegroudColor
                   defaultLightColor:CommonLightThemeForegroudColor];
    if ([self containTheme:OEMThemesTag_UINavigationBar_Tint]) {
        [self UINavigationBarOEMSetBarTintColor:color];
        return;
    }
    
}

- (void)syncTheme{
    if ([self containTheme:OEMThemesTag_UINavigationBar_Tint]) {
        self.barTintColor = self.barTintColor;
    }
}

@end
