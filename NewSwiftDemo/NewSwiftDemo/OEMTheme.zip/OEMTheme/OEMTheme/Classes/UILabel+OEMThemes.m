//
//  UILabel+OEMThemes.m
//  MSReactNative
//
//  Created by Neil 韦学宁 on 2021/7/6.
//

#import "UILabel+OEMThemes.h"
#import <objc/runtime.h>
#import "UIView+OEMThemes.h"
#import <NSObject+Swizzle.h>
#import "UIResponder+OEMThemes.h"
#import "MSOEMThemesManager.h"

@implementation UILabel (OEMThemes)

+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [self methodSwizzleForClass:[self class] rawSEL:@selector(setTextColor:) replaceSEL:@selector(msOEMStyleSetTextColor:)];
    });
}

- (void)msOEMStyleSetTextColor:(UIColor *)textColor{
    if ([self containTheme:OEMThemesTag_Background_UnSpecified]) {
        [self msOEMStyleSetTextColor:textColor];
        return;
    }
    UIColor * config_text = [self handleCollorSettingWithTag:OEMThemesTag_UILabel_TextColor
                        defaultDarkColor:CommonDarkThemeTextColor
                       defaultLightColor:CommonLightThemeTextColor];
    if (config_text) {
        [self msOEMStyleSetTextColor:config_text];
        return;
    }
    [self msOEMStyleSetTextColor:textColor];
}

- (void)syncTheme{
    if ([self containTheme:OEMThemesTag_UILabel_TextColor]) {
        self.textColor = self.textColor;
        self.text = self.text;
    }
}

#pragma mark - ====== APIs ======

- (void)configure90TranslucentTrait{
    [self configureThemeTag:OEMThemesTag_UILabel_TextColor];
    [self specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : CommonDarkThemeInputTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : CommonLightThemeInputTextColor
    }];
}


- (void)configure60TranslucentTrait{
    [self configureThemeTag:OEMThemesTag_UILabel_TextColor];
    [self specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : CommonDarkThemeContentTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : CommonLightThemeContentTextColor
    }];
}


- (void)configure40TranslucentTrait{
    [self configureThemeTag:OEMThemesTag_UILabel_TextColor];
    [self specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : DarkThemeClearBackgroundButtonTitle
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : LightThemeClearBackgroundButtonTitle
    }];
}

- (void)configure20TranslucentTrait{
    [self configureThemeTag:OEMThemesTag_UILabel_TextColor];
    [self specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : CommonDarkThemeSubContentTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : CommonLightThemeSubContentTextColor
    }];
}


@end
