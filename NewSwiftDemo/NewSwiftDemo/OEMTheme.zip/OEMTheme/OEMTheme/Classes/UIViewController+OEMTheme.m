//
//  UIViewController+OEMTheme.m
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/9.
//

#import "UIViewController+OEMTheme.h"
#import <objc/runtime.h>
#import "OEMThemesDefine.h"
#import "NSObject+Swizzle.h"
#import "UIResponder+OEMThemes.h"
#import "MSOEMThemesManager.h"
#import "UIColor+OEMThemes.h"

@implementation UIViewController (OEMTheme)

+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [self methodSwizzleForClass:[self class] rawSEL:@selector(preferredStatusBarStyle) replaceSEL:@selector(UIViewOEMStylPreferredStatusBarStyle)];
        [self methodSwizzleForClass:[self class] rawSEL:@selector(prefersStatusBarHidden) replaceSEL:@selector(UIViewOEMStylePrefersStatusBarHidden)];
        [self methodSwizzleForClass:[self class] rawSEL:@selector(preferredStatusBarUpdateAnimation) replaceSEL:@selector(UIViewOEMStylePreferredStatusBarUpdateAnimation)];
        [self methodSwizzleForClass:[self class] rawSEL:@selector(traitCollectionDidChange:) replaceSEL:@selector(UIViewControllerOEMStyleTraitCollectionDidChange:)];
    });
}

#pragma mark - ====== hooks ======

- (void)UIViewControllerOEMStyleTraitCollectionDidChange:(UITraitCollection *)previousTraitCollection{
    //call origin method
    [self UIViewControllerOEMStyleTraitCollectionDidChange:previousTraitCollection];
    if (@available(iOS 13.0, *)) {
        [[MSOEMThemesManager sharedManager] onTraitCollectionDidChange:previousTraitCollection obj:self];
    } else {
        // Fallback on earlier versions
    }
}

- (UIStatusBarStyle)UIViewOEMStylPreferredStatusBarStyle {
    if ([self containTheme:OEMThemesTag_Background_UnSpecified]) {
        return [self UIViewOEMStylPreferredStatusBarStyle];
    }
    UIStatusBarStyle target = UIStatusBarStyleLightContent;
    if (OEMThemeIsDarkMode) {
        target = UIStatusBarStyleLightContent;
    }else{
        target = UIStatusBarStyleDefault;
        if (@available(iOS 13.0, *)) {
            target = UIStatusBarStyleDarkContent;
        }
    }
    if ([self containTheme:OEMThemesTag_UIViewController_BasedStatusBarAppearance]) {
        UIStatusBarStyle light = UIStatusBarStyleDefault;
        if (@available(iOS 13.0, *)) {
            light = UIStatusBarStyleDarkContent;
        }
        return [self valueForTag:OEMThemesTag_UIViewController_BasedStatusBarAppearance darkValue:@(UIStatusBarStyleLightContent) lightValue:@(light)].intValue;
    }
    return target;
}

- (BOOL)UIViewOEMStylePrefersStatusBarHidden {
        if ([self containTheme:OEMThemesTag_Background_UnSpecified]) {
        return [self UIViewOEMStylePrefersStatusBarHidden];
    }
    return NO;
}

- (UIStatusBarAnimation)UIViewOEMStylePreferredStatusBarUpdateAnimation {
    if ([self containTheme:OEMThemesTag_Background_UnSpecified]) {
        return [self UIViewOEMStylePreferredStatusBarUpdateAnimation];
    }
    return UIStatusBarAnimationNone;
}

- (void)syncTheme{
    if ([self containTheme:OEMThemesTag_UIViewController_Behavior]) {
        //update status bar
        [self setNeedsStatusBarAppearanceUpdate];
        self.navigationController.navigationBar.titleTextAttributes = [self navigationTitleAttributes];
        //update navigator
    }
}

- (NSDictionary *)navigationTitleAttributes{
    return @{
        NSForegroundColorAttributeName : OEMThemeColorWithTrait(LightThemeNavigatorTextColor, DarkThemeNavigatorTextColor),
        NSFontAttributeName:[UIFont systemFontOfSize:18 weight:UIFontWeightMedium],
    };
}

- (void)updateNavigationAppearance{
    //iOS15 状态栏适配
    if (!self.navigationController.navigationBar) {
        return;
    }
    if (@available(iOS 15.0, *)) {
        UINavigationBarAppearance *appearance = [[UINavigationBarAppearance alloc] init];
        [appearance configureWithTransparentBackground];
        //设置导航条背景色
        UIColor * tcolor = OEMThemeColorWithTrait(CommonDarkThemeForegroudColor, CommonLightThemeForegroudColor);
        appearance.backgroundColor = tcolor;
        //隐藏线条
        appearance.shadowColor = UIColor.clearColor;
        //导航栏颜色
        appearance.titleTextAttributes = [self navigationTitleAttributes];
        self.navigationController.navigationBar.standardAppearance = appearance;
        self.navigationController.navigationBar.scrollEdgeAppearance = appearance;
    }
}




@end
