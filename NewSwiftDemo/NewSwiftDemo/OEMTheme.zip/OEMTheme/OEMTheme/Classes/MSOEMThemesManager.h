//
//  MSOEMThemesManager.h
//  MSReactNative
//
//  Created by Neil 韦学宁 on 2021/7/6.
//

#import <Foundation/Foundation.h>
#import "OEMThemesDefine.h"

#define OEMTHEMEDEBUGMODE (0)

#define OEMTHEMESWITCHMODE (0)

#define OEMThemeIsDarkMode (([MSOEMThemesManager sharedManager].currentStyle == OEMThemesStyle_Dark))

#define OEMThemeEnableChecking_ReturnVoid                    \
  do{                                                        \
    if (![MSOEMThemesManager sharedManager].themeEnable) {   \
        return;                                              \
    }                                                        \
} while (0);

NS_ASSUME_NONNULL_BEGIN

@interface MSOEMThemesManager : NSObject

@property(nonatomic, assign)BOOL themeFollowSystem;

@property(nonatomic, assign, readwrite)OEMThemesStyle currentStyle;

@property(nonatomic, assign, readonly)BOOL themeEnable;

+ (instancetype)sharedManager;

- (void)updateStyle:(OEMThemesStyle)style;

- (void)configureThemeEnable:(BOOL)themeEnable;

- (void)onTraitCollectionDidChange:(UITraitCollection *)previousTraitCollection obj:(id)obj API_AVAILABLE(ios(13.0));

+ (void)registerSpecialPropertiesForResponser:(UIResponder *)responsder
                                properties:(NSDictionary <NSNumber *, NSDictionary *> *)properties;

+ (NSDictionary *)specialPropertiesForResponsder:(UIResponder *)responsder;

@end

NS_ASSUME_NONNULL_END
