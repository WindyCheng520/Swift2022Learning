//
//  MSThirdLoginSetPasswordViewController.h
//  MSLogin
//
//  Created by 及时行乐 on 2020/7/16.
//

#import <MSBusiness/MVPViewController.h>
#import "MSThirdLoginSetPasswordPresenter.h"

@interface MSThirdLoginSetPasswordViewController : MVPViewController<MSThirdLoginSetPasswordPresenter*><MSThirdLoginSetPasswordViewProtocol>

@property (nonatomic, assign) BOOL isDevice;  //如果是点击添加设备进来，登录成功要跳转配网的指南页面
@property (nonatomic, assign) BOOL isLoginExpired;   //如果是登录过期进来，登录成功返回之前的页面

@property (nonatomic, copy) NSString *userId;   //第三方登录的userId
@property (nonatomic, copy) NSString *thirdType;  //第三方登录的src参数 32 facebook ,89 twitter
@property (nonatomic, copy) NSString *taccessToken;   //第三方登录获取的token
@property (nonatomic, copy) NSString *email;        //需要绑定的邮箱
@property (nonatomic, copy) NSString *verifyCode;   //验证码



@property (nonatomic, copy)NSString *account;   //账号，邮箱或手机号码

@property (nonatomic, copy)NSString *accountInfo; //额外信息，邮箱或uid


@end

