//
//  MSAccountCancellationViewController.m
//  MSLogin
//
//  Created by WindyCheng on 2021/8/5.
//

#import "MSAccountCancellationViewController.h"
#import "MSRegistPresenter.h"
#import "MSLoginBundle.h"
#import "MSCancellationCell1.h"
#import "MSCancellationCell2.h"
#import "MSLoginUtils.h"
#import <MSBusiness/MSRouterUrl.h>
#import "MSCancellationHeadView.h"
#import <OEMFoundation/OEMMacros.h>
#import <OEMTheme/OEMHGAlertController.h>

#import <MSBusiness/MSAppInfo.h>
#import <MSBusiness/MideaTool.h>
#import <MSBusiness/MSNotificationConst.h>
#import <OEMFoundation/OEMCustomize.h>



@interface MSAccountCancellationViewController ()<UITableViewDelegate, UITableViewDataSource>

@property(strong, nonatomic)MSCancellationHeadView *headView;
@property(strong, nonatomic)HGTableView *tableView;
@property(strong, nonatomic)HGView *bottomView;
@property(strong, nonatomic)HGView *containerView;
@property(strong, nonatomic)HGButton *checkButton;
@property(strong, nonatomic)HGLabel *tipsLabel;
@property(strong, nonatomic)HGButton *confirmButton;

@property(strong, nonatomic)NSArray *dataSource;

@end

@implementation MSAccountCancellationViewController

#pragma mark - lifecycle
- (void)viewDidLoad {
    [super viewDidLoad];
    self.presenter = [[MSRegistPresenter alloc] initWithView:self];
    self.title = @"";
    NSString * firstPagraph = [NSString stringWithFormat:MSResourceString(@"account_cancellation_page_main_content"), [OEMCustomize getStringValueWithKey:@"ContactEmail"]];
    self.dataSource = @[firstPagraph,MSResourceString(@"account_cancellation_page_content1"),MSResourceString(@"account_cancellation_page_content2"), MSResourceString(@"account_cancellation_page_content3"), MSResourceString(@"account_cancellation_page_content4"), MSResourceString(@"account_cancellation_page_content5"), MSResourceString(@"account_cancellation_page_content6"),MSResourceString(@"account_cancellation_page_content7")];
    self.tableView = [[HGTableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
    self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.estimatedRowHeight = 100;
    self.tableView.estimatedSectionHeaderHeight = 0;
    self.tableView.estimatedSectionFooterHeight = 0;
    [self.tableView registerClass:[MSCancellationCell1 class] forCellReuseIdentifier:NSStringFromClass([MSCancellationCell1 class])];
    [self.tableView registerClass:[MSCancellationCell2 class] forCellReuseIdentifier:NSStringFromClass([MSCancellationCell2 class])];
    self.tableView.allowsSelection = NO;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:self.tableView];
    
    self.headView = [[MSCancellationHeadView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 117)];
    self.tableView.tableHeaderView = self.headView;
    
    
    self.bottomView = [[HGView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 120)];
    self.bottomView.backgroundColor = [UIColor whiteColor];
    self.bottomView.layer.cornerRadius = 12.0;
  //  self.bottomView.clipsToBounds = YES; 无法出现阴影
    // 阴影颜色
    self.bottomView.layer.shadowColor = [UIColor grayColor].CGColor;
    // 阴影偏移，默认(0, -3)
    self.bottomView.layer.shadowOffset = CGSizeMake(0,0);
    // 阴影透明度，默认0
    self.bottomView.layer.shadowOpacity = 0.25;
    // 阴影半径，默认3
    self.bottomView.layer.shadowRadius = 2.5;
    
    
    // 单边阴影 顶边
    CGFloat shadowPathWidth = self.bottomView.layer.shadowRadius;
    
    CGRect shadowRect = CGRectMake(-shadowPathWidth / 2.0, 0 - shadowPathWidth / 2.0, self.bottomView.bounds.size.width + shadowPathWidth, shadowPathWidth);
    
    UIBezierPath *path = [UIBezierPath bezierPathWithRect:shadowRect];
    self.bottomView.layer.shadowPath = path.CGPath;
    
    [self.view addSubview:self.bottomView];
    
    self.containerView = [HGView new];
    self.containerView.backgroundColor = [UIColor clearColor];
    [self.bottomView addSubview:self.containerView];
    
    self.checkButton = [HGButton new];
    self.checkButton.layer.cornerRadius = 9.0;
    self.checkButton.clipsToBounds = YES;
    [self.checkButton setImage:MSResourceImage(@"ic_checkbox") forState:UIControlStateNormal];
    [self.checkButton setImage:MSResourceImage(@"ic_checkbox_s") forState:UIControlStateSelected];
    [self.checkButton addTarget:self action:@selector(checkClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.containerView addSubview:self.checkButton];
    
    
    self.tipsLabel = [HGLabel new];
    self.tipsLabel.font =  [UIFont systemFontOfSize:12 weight:UIFontWeightRegular];
    self.tipsLabel.textAlignment = NSTextAlignmentLeft;
    self.tipsLabel.backgroundColor = [UIColor clearColor];
    self.tipsLabel.text =  MSResourceString(@"account_cancellation_page_instruction");
    self.tipsLabel.textColor = RGBA_HEX(0x000000, 0.9);
    self.tipsLabel.numberOfLines = 1;
    [self.tipsLabel sizeToFit];
    [self.containerView addSubview:self.tipsLabel];
    
    self.confirmButton = [HGButton new];
    self.confirmButton.backgroundColor = RGB_HEX(0x267AFF);
    [self.confirmButton setTitle:MSResourceString(@"login_page_thirdpart_login_confirm") forState:UIControlStateNormal];
    self.confirmButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    self.confirmButton.enabled = NO;
    self.confirmButton.layer.cornerRadius = 22.0;
    self.confirmButton.clipsToBounds = YES;
    [self.confirmButton addTarget:self action:@selector(confirmClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.bottomView addSubview:self.confirmButton];
    
    [self makeConstraints];
    [self configureOEMTheme];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.navigationController.interactivePopGestureRecognizer.enabled = YES;
}

-(void)checkClick:(UIButton *)sender{
    sender.selected = !sender.selected;
    if (sender.selected) {
        self.confirmButton.backgroundColor = RGBA_HEX(0xEC1C24 ,1);
        self.confirmButton.enabled = YES;
     } else {
        self.confirmButton.backgroundColor = RGBA_HEX(0xEC1C24 ,0.3);
        self.confirmButton.enabled = NO;
    }
}

-(void)confirmClick:(UIButton *)sender{
    if (!self.checkButton.selected) {
        return;
    }
    
    WEAK_SELF;
    HGAlertAction *cancelAction = [HGAlertAction actionWithTitle:MSResourceString(@"login_page_thirdpart_login_cancel") style:HGAlertActionStyleCancel action:^{
      
    }];
    
    NSString *title = MSResourceString(@"account_cancellation_page_reconfirm");
    NSString *message = MSResourceString(@"account_cancellation_page_warning");
    HGAlertAction *confirmAction = [HGAlertAction actionWithTitle:MSResourceString(@"login_page_thirdpart_login_confirm") action:^{
        weak_self.presenter.account = weak_self.account;
        weak_self.presenter.verifyCode = weak_self.verifyId;
        [weak_self.presenter userUnregister];
    }];
    HGAlertController *alertController = [OEMHGAlertController alertControllerWithTitle:title message:message actions:@[cancelAction, confirmAction]];
    [alertController show];
}


-(void)leftBarButtonClick:(UIButton *)button{
    [self popToReactNativeViewContrller];
}

- (void)configureOEMTheme{
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    [self.view configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.tableView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.bottomView configureThemeTag:OEMThemesTag_UIView_Foreground];
    
    [self.tipsLabel configure90TranslucentTrait];
    
    [self.confirmButton configureThemeTag:OEMThemesTag_UIView_Main_Color];
    [self.confirmButton configureThemeTag:OEMThemesTag_UIButton_Background];
    [self.confirmButton configureThemeTag:OEMThemesTag_UIButton_AttributedTraitColor];
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        [weakSelf setNavButton];
    } callImmidiately:YES];
}

- (void)setNavButton{
    if (OEMThemeIsDarkMode) {
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_dm")];
    }else{
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_lg")];
    }
}


#pragma mark - UI
- (void)makeConstraints {
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.top.equalTo(self.view);
        make.bottom.equalTo(self.view.mas_bottom).offset(-120);
    }];
    
    [self.bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.bottom.equalTo(self.view);
        make.height.mas_equalTo(120);
    }];
    
    
    CGFloat tipsLabelWidth  = [self.tipsLabel.text sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:12 weight:UIFontWeightRegular]}].width;
    [self.containerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.bottomView.mas_top).offset(0);
        make.centerX.equalTo(self.bottomView);
        make.height.mas_equalTo(40);
        make.width.mas_equalTo(tipsLabelWidth + 28);
    }];
    
    [self.checkButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.containerView.mas_top).offset(10);
        make.leading.mas_equalTo(self.containerView.mas_leading).offset(0);
        make.height.mas_equalTo(18);
        make.width.mas_equalTo(18);
    }];
    [self.tipsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.containerView.mas_top).offset(11);
        make.leading.mas_equalTo(self.checkButton.mas_trailing).offset(9);
        make.height.mas_equalTo(14);
//        make.width.mas_equalTo(18);
    }];
    
    
    [self.confirmButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.bottomView.mas_top).offset(40);
        make.leading.mas_equalTo(self.bottomView.mas_leading).offset(16);
        make.trailing.mas_equalTo(self.bottomView.mas_trailing).offset(-16);
        make.height.mas_equalTo(44);
    }];
    
   
}


#pragma mark - UITableView datasource and delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSString *contentString = self.dataSource[indexPath.section];
    if (indexPath.section == 0) {
        MSCancellationCell1  *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([MSCancellationCell1  class]) forIndexPath:indexPath];
        cell.contentLabel.text = contentString;
        return cell;
    }else{
        MSCancellationCell2  *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([MSCancellationCell2 class]) forIndexPath:indexPath];
        cell.indexItemLabel.text = [NSString stringWithFormat:@"%ld", indexPath.section];
        cell.contentLabel.text = contentString;
        return cell;
    }
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return CGFLOAT_MIN;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 8;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    return  nil;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView * sectionView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 8)];
    sectionView.backgroundColor = [UIColor clearColor];
    return  sectionView;
}


- (void)presenter:(MSRegistPresenter *)presenter userUnregisterCompletion:(MSBusinessError *)error{
    if (error) {
        [self toastText:error.localizedDescription];
    } else {
        [[NSNotificationCenter defaultCenter] postNotificationName:kMideaQuitLoginNotification object:nil userInfo:@{@"account cancellation":@"1"}];
        [OEMRouter handleURL:MSRouterHomeIndex];
    }
}


- (void)popToReactNativeViewContrller{
    NSMutableArray *mvcvs = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
    __block UIViewController *tempViewController = nil;
    [mvcvs enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        UIViewController *viewController =   (UIViewController *)obj;
        if ([viewController isKindOfClass:NSClassFromString(@"MSReactNativeViewController")]) {
            tempViewController = viewController;
            *stop = YES;
            return;
        }
    }];
    if (tempViewController){
        [self.navigationController popToViewController:tempViewController animated:YES];
    }
}

@end
