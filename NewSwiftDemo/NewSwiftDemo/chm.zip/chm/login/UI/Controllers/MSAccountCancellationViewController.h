//
//  MSAccountCancellationViewController.h
//  MSLogin
//
//  Created by WindyCheng on 2021/8/5.
//

#import <MSBusiness/MVPViewController.h>
#import "MSRegistPresenter.h"

NS_ASSUME_NONNULL_BEGIN

@interface MSAccountCancellationViewController : MVPViewController<MSRegistPresenter *><MSRegistViewProtocol>

@property (nonatomic, strong) NSString *account;
@property (nonatomic, strong) NSString *verifyId;        //注册用新验证码

@end

NS_ASSUME_NONNULL_END
