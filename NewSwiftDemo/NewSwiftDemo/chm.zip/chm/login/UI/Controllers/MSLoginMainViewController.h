//
//  MSLoginMainViewController.h
//  MSLogin
//
//  Created by syp on 2020/6/11.
//

#import <MSBusiness/MVPViewController.h>
#import "MSLoginPresenter.h"


@interface MSLoginMainViewController : MVPViewController<MSLoginPresenter *> <MSLoginViewProtocol>

@property (nonatomic, assign) BOOL isDevice;  //如果是点击添加设备进来，登录成功要跳转配网的指南页面
@property (nonatomic, assign) BOOL isLoginExpired;   //如果是登录过期进来，登录成功返回之前的页面
@property (nonatomic, copy) void(^clickLeftButtonBlock)(void);

@property (nonatomic, copy) NSString *previousPageName;  // 上个页面的名称，用于埋点上报数据

@property (nonatomic, assign) BOOL isForAuthorize; //为了跳转授权


@property (nonatomic, copy) void (^viewControllerSuccessBlock)(void); //成功跳转

@end
