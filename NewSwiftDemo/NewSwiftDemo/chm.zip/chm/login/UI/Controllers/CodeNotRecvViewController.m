//
//  CodeNotRecvViewController.m
//  MSLogin
//
//  Created by Neil 韦学宁 on 2021/7/14.
//

#import "CodeNotRecvViewController.h"
#import "CodeNotRecvTableViewCell.h"
#import "MSLoginBundle.h"

@interface CodeNotRecvViewController ()<UITableViewDelegate, UITableViewDataSource>

@property(nonatomic, strong)UITableView * tableView;
@property(nonatomic, strong)UILabel * headerLabel;

@property(nonatomic, strong)NSArray <NSString *> * dataSource;
@property(nonatomic, strong)NSMutableDictionary <NSNumber *, NSNumber *> * heightData;

@end

@implementation CodeNotRecvViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero];
    [self.view addSubview:self.tableView];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.tableView.superview);
    }];
    
    self.headerLabel = [UILabel new];
    self.headerLabel.numberOfLines = 0;
    self.headerLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightSemibold];
    self.headerLabel.text = MSResourceString(@"verification_code_page_tip");
    
    CGFloat height = [CodeNotRecvTableViewCell boundingRectWithSize:CGSizeMake(SCREEN_WIDTH - 32, MAXFLOAT) font:self.headerLabel.font lineSpacing:0 string:self.headerLabel.text].height;
    
    UIView * header = [UIView new];
    header.backgroundColor = [UIColor clearColor];
    [header addSubview:self.headerLabel];
    [self.headerLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.headerLabel.superview).offset(16);
        make.trailing.equalTo(self.headerLabel.superview).offset(-16);
        make.top.equalTo(self.headerLabel.superview).offset(16);
    }];
    
    header.bounds = CGRectMake(0, 0, SCREEN_WIDTH, height + 32);
    self.tableView.tableHeaderView = header;
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
    self.tableView.estimatedSectionHeaderHeight = 0;
    self.tableView.estimatedSectionFooterHeight = 0;
    [self.tableView registerClass:[CodeNotRecvTableViewCell class] forCellReuseIdentifier:NSStringFromClass([CodeNotRecvTableViewCell class])];
    
    self.dataSource = @[
        MSResourceString(@"verification_code_page_content_1"),
        MSResourceString(@"verification_code_page_content_2"),
        MSResourceString(@"verification_code_page_content_3")
    ];
    self.heightData = [NSMutableDictionary new];
    
    self.title = MSResourceString(@"verification_code_page_title");
    
    [self configureOEMTheme];
}

- (void)configureOEMTheme{
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    [self.view configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.tableView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.headerLabel configure90TranslucentTrait];
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        [weakSelf setNavButton];
    } callImmidiately:YES];
}

- (void)setNavButton{
    if (OEMThemeIsDarkMode) {
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_dm")];
    }else{
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_lg")];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CodeNotRecvTableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([CodeNotRecvTableViewCell class])];
    if (indexPath.row < [self.dataSource count]) {
        [cell setText:self.dataSource[indexPath.row] index:indexPath.row];
    }
    return cell;
}

- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.dataSource count];
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSNumber * num = [self.heightData objectForKey:@(indexPath.row)];
    if ([num isKindOfClass:[NSNumber class]]) {
        return num.floatValue;
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row >= [self.dataSource count]) {
        return 0;
    }
    NSString * data = self.dataSource[indexPath.row];
    CGFloat height = [CodeNotRecvTableViewCell textHeightWithString:data];
    [self.heightData setObject:@(height) forKey:@(indexPath.row)];
    return height;
}

@end
