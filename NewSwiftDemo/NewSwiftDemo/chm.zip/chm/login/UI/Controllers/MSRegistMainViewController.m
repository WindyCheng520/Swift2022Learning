//
//  MSRegistViewController.m
//  MSLogin
//
//  Created by syp on 2020/6/11.
//

#import "MSRegistMainViewController.h"
#import <OEMFoundation/HGInternationalization.h>
#import "MSLoginBundle.h"
#import "MSCountrySelectViewController.h"
#import "MSSetPasswordViewController.h"
#import "MSUIConfiguration.h"
#import <MSBusiness/MSRouterUrl.h>
#import <YYText/YYText.h>
#import <OEMFoundation/MSTitleAndOneButtonAlertView.h>
#import <OEMTheme/MSInputView_Private.h>
#import "UIView+LoginUtilities.h"
#import "MSValidCodeView.h"
#import <OEMTheme/OEMTitleAndOneButtonAlertView.h>
#import <OEMTheme/OEMMSInputView.h>
#import "CodeNotRecvViewController.h"
#import "MSAccountCancellationViewController.h"
#import <MSBusiness/MSUserInfoManager.h>
#import <MSBusiness/MSUserDefaultTools.h>
#import <MSBusiness/NSString+Toshiba.h>
#import <OEMFoundation/OEMCustomize.h>

#import "MSLoginUtils.h"




static const NSInteger textFieldTag = 1234;
static const NSInteger verifyCodeMaxErrorCount = 3100;   //验证码输错五次



#define kAlphaNum @"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-.@"

@interface TouchableScrollView : HGScrollView

@end

@implementation TouchableScrollView

@end

@interface MSRegistMainViewController ()<MSInputViewDelegate>

@property (nonatomic, strong) TouchableScrollView * scrollContainer;
@property (nonatomic, strong) HGView * mailInputViewContainer;    //账号输入框容器（左屏）
@property (nonatomic, strong) HGView * validCodeViewContainer;     //验证码输入框容器（右屏）

@property (nonatomic, strong) HGLabel *createAccountTitle;       //注册（标题）
@property (nonatomic, strong) HGLabel *createAccountDesLabel;     //去掉（副标题）

@property (nonatomic, strong) OEMMSInputView *regionInputView; //国家地区
@property (nonatomic, strong) HGButton *regionButton;       //国家地区覆盖按钮

@property (nonatomic, strong) OEMMSInputView *emailInputView;  //账号输入框
@property (nonatomic, strong) HGButton *codeButton;        //获取验证码按钮

@property (nonatomic, strong) HGButton *backButton;         //返回登录按钮
@property (nonatomic, strong) HGButton *selectButton;
@property (nonatomic, strong) YYLabel *selectLabel;


@property (nonatomic, strong) HGLabel * confirmCodeTitle;
@property (nonatomic, strong) HGLabel * confirmCodeDesLabel;
@property (nonatomic, strong) MSValidCodeView *confirmationCodeInputView;
@property (nonatomic, assign) CGFloat selectTextHeight;
@property (nonatomic, strong) HGButton *retryButton;
@property (nonatomic, strong) HGButton *codeNotRecvBtn;

@property (nonatomic, assign) BOOL isInputValidCodeStage;

@end

@implementation MSRegistMainViewController



- (void)msRouterParams:(NSDictionary *)params{
    if(params){
        self.isFromRN = [params[@"isFromRN"] boolValue];
    }
}


- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.presenter = [[MSRegistPresenter alloc]initWithView:self];
        
        self.scrollContainer = [TouchableScrollView new];
        
        self.mailInputViewContainer = [HGView new];
        self.validCodeViewContainer = [HGView new];
        
        self.createAccountTitle = [HGLabel new];
        self.createAccountDesLabel = [HGLabel new];
        
        
        self.regionInputView = [OEMMSInputView new];
        self.regionButton = [HGButton new];
        
        self.emailInputView = [OEMMSInputView new];
        self.codeButton = [HGButton new];
        self.selectButton = [HGButton new];
        self.selectLabel = [YYLabel new];
        self.backButton = [HGButton new];
        
        self.confirmCodeTitle = [HGLabel new];
        self.confirmCodeDesLabel = [HGLabel new];
        self.confirmationCodeInputView = [MSValidCodeView new];
        self.retryButton = [HGButton new];
        self.codeNotRecvBtn = [HGButton new];
    }
    return self;
}

- (void)configOEMTheme{
    
    self.regionInputView.layer.borderColor = [UIColor clearColor].CGColor;
    self.regionInputView.layer.borderWidth = 0.0;
    [self.regionInputView addThemeBottomSeplineWithOffset:0];
    
    self.emailInputView.layer.borderColor = [UIColor clearColor].CGColor;
    self.emailInputView.layer.borderWidth = 0.0;
    [self.emailInputView addThemeBottomSeplineWithOffset:0];
    if ([self.emailInputView.textField isKindOfClass:[UITextField class]]) {
        self.emailInputView.textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    }
    

    [self.view specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIView_Background) : CommonDarkThemeForegroudColor,
    } lightModeProperties:@{
        @(OEMThemesTag_UIView_Background) : CommonLightThemeForegroudColor,
    }];
    
    
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    
    [self.createAccountTitle configure90TranslucentTrait];
    [self.createAccountDesLabel configure40TranslucentTrait];
    
    [self.codeButton configureThemeTag:OEMThemesTag_UIView_Main_Color];
    [self.codeButton configureThemeTag:OEMThemesTag_UIButton_Background];
    [self.codeButton configureThemeTag:OEMThemesTag_UIButton_AttributedTraitColor];
    
    [self.regionInputView.textField configureThemeTag:OEMThemesTag_UITextField_Textcolor];
    [self.emailInputView.textField configureThemeTag:OEMThemesTag_UITextField_Textcolor];
    [self.backButton configureThemeTag:OEMThemesTag_UIButton_TitleThemeColor];
    
    
    [self.confirmCodeTitle  configure90TranslucentTrait];
    [self.confirmCodeDesLabel configure40TranslucentTrait];
    [self.retryButton configureThemeTag:OEMThemesTag_UIButton_TitleThemeColor];
    
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        if (OEMThemeIsDarkMode){
            weakSelf.navigationController.navigationBar.tintColor = RGBA_HEX(0x1A1A1A, 1.0);
        }else{
            weakSelf.navigationController.navigationBar.tintColor = RGBA_HEX(0x1A1A1A, 1.0);
        }
        [weakSelf setNavButton];
        [weakSelf updateAttributeString];
    } callImmidiately:YES];
}

- (void)updateAttributeString{
    NSMutableAttributedString * selectAttributedString = [UIView getProtocolString:NO];
    self.selectLabel.attributedText = selectAttributedString;
    self.selectTextHeight = [YYTextLayout layoutWithContainerSize:CGSizeMake(SCREEN_WIDTH-30*2-16-8, MAXFLOAT) text:selectAttributedString].textBoundingSize.height;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setUpView];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillEnterForeground:) name:UIApplicationWillEnterForegroundNotification object:nil];
    
    [self configOEMTheme];
    
    if(self.isFromRN){
      //  MSUserInfoManager *mgr = [MSUserInfoManager shareManager];
        self.account = [MSUserDefaultTools getLastLoginAccount];
       // self.email = [MSUserDefaultTools getLastLoginAccount];
        self.createAccountTitle.text = MSResourceString(@"register_page_account_cancellation_button");
        self.confirmCodeDesLabel.text = MSResourceString(@"register_page_enter_verivication_code");
        self.confirmCodeDesLabel.adjustsFontSizeToFitWidth = YES;
        self.createAccountDesLabel.text = MSResourceString(@"register_page_email_verify_first");
        
        BOOL isEmail = [MSLoginUtils isValidEmail:self.account]; //是否邮箱
        if (isEmail) {
            self.confirmCodeDesLabel.text = [NSString stringWithFormat:@"%@ %@", MSResourceString(@"register_page_did_sent_code"), self.account];
        }else{
            self.confirmCodeDesLabel.text = [NSString stringWithFormat:@"%@ +00%@ %@", MSResourceString(@"register_page_did_sent_code"),HGCurrentCountry.phoneCode,self.account];
        }
        
        [self.emailInputView setRightImage:nil];
        self.emailInputView.text = self.account;
        self.emailInputView.userInteractionEnabled = NO;
        self.codeButton.enabled = YES;
        self.selectLabel.hidden = self.selectButton.hidden = self.backButton.hidden = YES;
        self.selectButton.selected = YES;
        self.presenter.account = self.account;
    }
    
    self.backButton.hidden = YES;
}

- (void)setUpView{
    
    [self.view addSubview:self.scrollContainer];
    [self.scrollContainer mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.scrollContainer.superview);
    }];
    self.scrollContainer.pagingEnabled = YES;
    self.scrollContainer.scrollEnabled = NO;

    self.scrollContainer.alwaysBounceVertical = NO;
    [self.scrollContainer addSubview:self.mailInputViewContainer];
    [self.scrollContainer addSubview:self.validCodeViewContainer];
    self.scrollContainer.showsVerticalScrollIndicator = NO;
    self.scrollContainer.showsHorizontalScrollIndicator = NO;
    self.scrollContainer.userInteractionEnabled = YES;
    
    if (NO == isRTL()) {
        [self.mailInputViewContainer mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leading.top.bottom.equalTo(self.mailInputViewContainer.superview);
            make.width.mas_equalTo(BHScreenWidth);
            make.height.equalTo(self.view);
        }];
        
        [self.validCodeViewContainer mas_makeConstraints:^(MASConstraintMaker *make) {
            make.trailing.top.bottom.equalTo(self.mailInputViewContainer.superview);
            make.width.mas_equalTo(BHScreenWidth);
            make.height.equalTo(self.mailInputViewContainer);
            make.leading.equalTo(self.mailInputViewContainer.mas_trailing);
        }];
    }else{
        [self.mailInputViewContainer mas_makeConstraints:^(MASConstraintMaker *make) {
            make.trailing.top.bottom.equalTo(self.mailInputViewContainer.superview);
            make.width.mas_equalTo(BHScreenWidth);
            make.height.equalTo(self.view);
        }];
        [self.validCodeViewContainer mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leading.top.bottom.equalTo(self.mailInputViewContainer.superview);
            make.width.mas_equalTo(BHScreenWidth);
            make.height.equalTo(self.mailInputViewContainer);
            make.trailing.equalTo(self.mailInputViewContainer.mas_leading);
        }];
    }
    
    
    [self setUpMainInputViwe];
    [self setUPCodeValidateView];
    
    [self makeConstraints];
}

- (void)setUpMainInputViwe{
    
    self.hiddenKeyboardWhenTap = YES;

    self.createAccountTitle.text = MSResourceString(@"register_page_new_account");
    self.createAccountTitle.font = [UIFont systemFontOfSize:22 weight:UIFontWeightBold];
    self.createAccountTitle.textColor = RGB_HEX(0x000000);
    [self.mailInputViewContainer addSubview:self.createAccountTitle];
    
    
    [self.regionInputView setRightImage:MSResourceImage(@"ic_16_arrow")];
    self.regionInputView.font = [UIFont systemFontOfSize:16 weight:UIFontWeightSemibold];
    [self.mailInputViewContainer addSubview:self.regionInputView];
    
    self.regionButton.backgroundColor = [UIColor clearColor];
    [self.regionButton addTarget:self action:@selector(rightBarButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.regionInputView addSubview:self.regionButton];
    
//    self.createAccountDesLabel.text = MSResourceString(@"register_page_will_send_verification_code_tip");
//    self.createAccountDesLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
//    self.createAccountDesLabel.textColor = RGB_HEX(0x999999);
//    [self.mailInputViewContainer addSubview:self.createAccountDesLabel];
    
    [self.emailInputView setRightImage:MSResourceImage(@"ic_Input_close")];
    [self.emailInputView setFont:[UIFont systemFontOfSize:16 weight:UIFontWeightSemibold]];
    [self.emailInputView setTextColor:RGB_HEX(0x000000)];
    @weakify(self)
    self.emailInputView.clickRightButtonBlock = ^{
        weak_self.emailInputView.text = nil;
        weak_self.presenter.account = @"";
    };
    self.emailInputView.delegate = self;
    [self.emailInputView setTextFieldTag:textFieldTag];
    self.emailInputView.keyboardType = UIKeyboardTypeEmailAddress;
    [self.emailInputView setRightButtonHidden:YES];
    
    if ([OEMCustomize getUIntValueWithKey:@"SupportedAccount"] == 0) {
        self.emailInputView.placeholder = MSResourceString(@"register_page_enter_mail_placeholder");
    }else{
        self.emailInputView.placeholder = MSResourceString(@"register_page_enter_mail_placeholder_email_account_only");
    }
    [self.mailInputViewContainer addSubview:self.emailInputView];
    
    
    self.codeButton.backgroundColor = RGBA_HEX(0xEC1C24 ,0.3);
    self.codeButton.enabled = NO;
    self.codeButton.layer.cornerRadius = 22;
    [self.codeButton setTitle:MSResourceString(@"register_page_button_get_verification_code") forState:UIControlStateNormal];
    [self.codeButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
    self.codeButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    [self.codeButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.mailInputViewContainer addSubview:self.codeButton];
    
    [self.backButton setTitle:MSResourceString(@"register_page_backt_to_login") forState:UIControlStateNormal];
    [self.backButton setTitleColor:RGB_HEX(0xEC1C24) forState:UIControlStateNormal];
    self.backButton.titleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
    [self.backButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.mailInputViewContainer addSubview:self.backButton];
    
    self.selectButton.enlargeTouchAreaInsets = UIEdgeInsetsMake(5, 5, 5, 5);
    [self.selectButton setImage:MSResourceImage(@"ic_checkbox") forState:UIControlStateNormal];
    [self.selectButton setImage:MSResourceImage(@"ic_checkbox_s") forState:UIControlStateSelected];
    [self.selectButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.mailInputViewContainer addSubview:self.selectButton];
    
    self.selectLabel.numberOfLines = 0;
    [self updateAttributeString];
    [self.mailInputViewContainer addSubview:self.selectLabel];
}

- (void)setUPCodeValidateView{
    self.confirmCodeTitle.text = MSResourceString(@"register_page_input_verify_code_tip");
    self.confirmCodeTitle.font = [UIFont systemFontOfSize:22 weight:UIFontWeightBold];
    self.confirmCodeTitle.textColor = RGB_HEX(0x999999);
    [self.validCodeViewContainer addSubview:self.confirmCodeTitle];
    
    self.confirmCodeDesLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
    self.confirmCodeDesLabel.textColor = RGB_HEX(0x999999);
    self.confirmCodeDesLabel.numberOfLines = 0;
    [self.confirmCodeDesLabel sizeToFit];
    
    [self.validCodeViewContainer addSubview:self.confirmCodeDesLabel];
    
    
    WEAKSELF
    self.confirmationCodeInputView.lastCodeDidInput = ^{
        if ([weakSelf.confirmationCodeInputView.text length] == 6) {
            [weakSelf.presenter setVerifyCode:weakSelf.confirmationCodeInputView.text];
        }
        [weakSelf.presenter verifyCodeAuth];
    };
    
    [self.validCodeViewContainer addSubview:self.confirmationCodeInputView];
    
    self.retryButton.enabled = YES;
    [self.retryButton.titleLabel setFont:[UIFont systemFontOfSize:14 weight:UIFontWeightMedium]];
    self.retryButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [self.retryButton setTitle:MSResourceString(@"register_page_resend_verification_code") forState:UIControlStateNormal];
    [self.retryButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.validCodeViewContainer addSubview:self.retryButton];
    
    NSString * forgetPWDString = [NSString stringWithFormat:@"%@?",MSResourceString(@"register_page_code_not_recvive")]; //没有收到验证码
    NSAttributedString *forgetpasswordButtonAttrText = [UIView attributedText:forgetPWDString color:RGB_HEX(0x999999) arrow:nil isSmallScreen:NO];
    [self.codeNotRecvBtn setAttributedTitle:forgetpasswordButtonAttrText forState:UIControlStateNormal];
    [self.codeNotRecvBtn addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.validCodeViewContainer addSubview:self.codeNotRecvBtn];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    NSString *countryName = HGCurrentCountry.name;
    self.regionInputView.text = countryName;
    [self setNavButton];
}

- (void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    if (self.scrollContainer.contentSize.height != 0) {
        self.scrollContainer.contentSize = CGSizeMake(BHScreenWidth * 2, 0);
    }
}

- (void)setNavButton{
    if (OEMThemeIsDarkMode) {
        UIImage * img = MSResourceImage(@"ic_nav_back_dm");// self.isInputValidCodeStage ? MSResourceImage(@"ic_nav_back_dm") : MSResourceImage(@"ic_nav_close_dm");
        NSString * title = self.isInputValidCodeStage ? @"" :HGCurrentCountry.name;
        
        if (self.isFromRN) {
            img = MSResourceImage(@"ic_nav_back_dm");
            title = @"";
        }
        [self createLeftButtonWithImage:img];
      //  [self createRightButtonWithTitle:title font:[UIFont boldSystemFontOfSize:14] color:CommonThemeColor];
    }else{
        UIImage * img = MSResourceImage(@"ic_nav_back_lg"); // self.isInputValidCodeStage ? MSResourceImage(@"ic_nav_back_lg") : MSResourceImage(@"ic_nav_close_lg");
        NSString * title = self.isInputValidCodeStage ? @"" :HGCurrentCountry.name;
        if (self.isFromRN) {
          img =  MSResourceImage(@"ic_nav_back_lg");
          title = @"";
        }
        [self createLeftButtonWithImage:img];
       // [self createRightButtonWithTitle:title font:[UIFont boldSystemFontOfSize:14] color:CommonThemeColor];
    }
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)makeConstraints
{
    //注册页面布局
    [self.createAccountTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.createAccountTitle.superview).offset(30);
        make.trailing.equalTo(self.createAccountTitle.superview).offset(-30);
        make.top.equalTo(self.createAccountTitle.superview).offset(40);
    }];
    
//    [self.createAccountDesLabel mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.leading.equalTo(self.createAccountTitle.mas_leading);
//        make.top.equalTo(self.createAccountTitle.mas_bottom).offset(12);
//    }];
    
    CGFloat height = 48;
    CGFloat space = 30;
    if (self.isFromRN) {
        height = 0.5;
        space = 0;
        self.regionInputView.hidden = YES;
    }
    
    [self.regionInputView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.createAccountTitle.mas_bottom).offset(space);
        make.leading.equalTo(self.createAccountTitle.mas_leading);
        make.trailing.equalTo(self.createAccountTitle.mas_trailing);
        make.height.mas_equalTo(height);
    }];
    
    [self.regionButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.top.bottom.equalTo(self.regionInputView);
    }];
    
    [self.emailInputView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.regionInputView.mas_bottom).offset(20);
        make.leading.equalTo(self.createAccountTitle.mas_leading);
        make.trailing.equalTo(self.createAccountTitle.mas_trailing);
        make.height.mas_equalTo(48);
    }];
    
    [self.codeButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.createAccountTitle.mas_leading);
        make.trailing.equalTo(self.createAccountTitle.mas_trailing);
        make.top.equalTo(self.emailInputView.mas_bottom).offset(60);
        make.height.mas_equalTo(44);
    }];

    [self.selectButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(30);
        make.size.mas_equalTo(CGSizeMake(16, 16));
        make.top.equalTo(self.selectLabel.mas_top);
    }];
    
    [self.selectLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.selectButton.mas_trailing).offset(8);
        make.trailing.mas_equalTo(-30);
        make.top.equalTo(self.codeButton.mas_bottom).offset(24);
        make.height.mas_equalTo(self.selectTextHeight);
    }];
    
    [self.backButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.selectLabel.mas_bottom).offset(54);
        make.height.mas_equalTo(16);
        make.centerX.equalTo(self.backButton.superview);
    }];
    
    //验证码区域布局
    [self.confirmCodeTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.confirmCodeTitle.superview).offset(30);
        make.leading.equalTo(self.confirmCodeTitle.superview).offset(30);
    }];
    
    [self.confirmCodeDesLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.confirmCodeTitle.mas_leading);
        make.trailing.equalTo(self.confirmCodeTitle.superview).offset(-30);
        make.top.equalTo(self.confirmCodeTitle.mas_bottom).offset(5);
    }];

    [self.confirmationCodeInputView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.confirmationCodeInputView.superview).offset(30);
        make.trailing.equalTo(self.confirmationCodeInputView.superview).offset(-30);
        make.top.equalTo(self.confirmCodeDesLabel.mas_bottom).offset(43);
        make.height.mas_equalTo(40);
    }];

    [self.retryButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.retryButton.superview).offset(30);
        make.top.equalTo(self.confirmationCodeInputView.mas_bottom).offset(20);
        make.size.mas_equalTo(CGSizeMake(120, 30));
    }];
    
    [self.codeNotRecvBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.confirmationCodeInputView.mas_bottom).offset(158);
        make.centerX.equalTo(self.codeNotRecvBtn.superview);
    }];
}

#pragma mark - click event

- (void)clickButton:(UIButton*)sender{
    self.presenter.isNeedVerifyAccount = self.isFromRN?NO:YES;
    if (sender == self.codeButton) {
        //发送验证码，开始倒计时
        if (!self.selectButton.selected) {
            [self selectButtonAnimation];
            return;
        }
        [self.presenter getVerifyCode];
    } else if (sender == self.backButton) {
        [self.navigationController popViewControllerAnimated:YES];
    } else if (sender == self.retryButton) {
        [self.presenter getVerifyCode];
    } else if (sender == self.selectButton) {
        self.selectButton.selected = !self.selectButton.isSelected;
    }else if (sender == self.codeNotRecvBtn){
#if OEMTHEMEDEBUGMODE
        MSSetPasswordViewController* setPasswordViewController = [[MSSetPasswordViewController alloc] init];
        setPasswordViewController.isDevice = self.isDevice;
        setPasswordViewController.isLoginExpired = self.isLoginExpired;
        setPasswordViewController.email = self.presenter.email;
        setPasswordViewController.verifyCode = @"1234";
        [self.navigationController pushViewController:setPasswordViewController animated:YES];
        return;
#endif
        CodeNotRecvViewController * vc = [[CodeNotRecvViewController alloc] init];
        [self.navigationController pushViewController:vc animated:true];
    }
}

- (void)leftBarButtonClick:(UIButton *)button{
    if (self.isInputValidCodeStage) {
        [self shouldMoveToValidationCodeInputState:NO];
        return;
    }
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)rightBarButtonClick:(UIButton *)button{

    MSCountrySelectViewController *countrySelectViewController = [MSCountrySelectViewController new];
    countrySelectViewController.enterType = MSCountrySelectEnterType_Right;
    [self.navigationController pushViewController:countrySelectViewController animated:YES];
}

- (void)enableGetCodeButton:(BOOL)enable{
    
}

- (void)applicationWillEnterForeground:(NSNotification *)notification {
    [self.presenter applicationWillEnterForeground:notification];
}

- (void)selectButtonAnimation {
    [self toastText:MSResourceString(@"login_page_privacy_no_check_toast")];

    CGPoint selectButtonPoint = self.selectButton.center;
    CAKeyframeAnimation *selectButtonAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    selectButtonAnimation.duration = 0.4f;
    selectButtonAnimation.values = @[@(CGPointMake(selectButtonPoint.x-10, selectButtonPoint.y)), @(selectButtonPoint), @(CGPointMake(selectButtonPoint.x-10, selectButtonPoint.y)), @(selectButtonPoint)];
    
    CGPoint selectLabelPoint = self.selectLabel.center;
    CAKeyframeAnimation *selectLabelAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    selectLabelAnimation.duration = 0.4f;
    selectLabelAnimation.values = @[@(CGPointMake(selectLabelPoint.x-10, selectLabelPoint.y)), @(selectLabelPoint), @(CGPointMake(selectLabelPoint.x-10, selectLabelPoint.y)), @(selectLabelPoint)];
    
    [self.selectButton.layer addAnimation:selectButtonAnimation forKey:nil];
    [self.selectLabel.layer addAnimation:selectLabelAnimation forKey:nil];
}

#pragma mark -MSLoginInputViewDelegate

- (void)inputView:(MSInputView *)inputView didChangeText:(NSString *)text
{
    text = [text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if (inputView == self.emailInputView) {
        self.presenter.account = text;
        self.account = text;
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    if (textField.tag == textFieldTag) {
        [self.emailInputView setRightButtonHidden:YES];
    }
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    if (textField.tag == textFieldTag && ![self.emailInputView.text isEqualToString:@""]) {
        [self.emailInputView setRightButtonHidden:NO];
    }
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {

    if ([[string disable_emoji] isEqualToString:@"&&&&****"] || [[string disable_emoji] isEqualToString:@"&&&&****&&&&****"]) {
        [textField becomeFirstResponder];
        return NO;
    }
    
    //限制空格
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    newString = [newString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if ([newString isEqualToString:textField.text] && range.length == 0) {
        return NO;
    }
    
    if (newString.length > OEMLoginAccountInputLimit) {
        return NO;
    }
    
    NSCharacterSet *cs;
    cs = [[NSCharacterSet characterSetWithCharactersInString:kAlphaNum] invertedSet];
    NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""]; //按cs分离出数组,数组按@""分离出字符串
    BOOL canChange = [string isEqualToString:filtered];
    if (!canChange) {
        return NO;
    }
    
    
    return YES;
}




//去除字符串中所带的表情
- (NSString *)disable_emoji:(NSString *)text{
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"[^\\u0020-\\u007E\\u00A0-\\u00BE\\u2E80-\\uA4CF\\uF900-\\uFAFF\\uFE30-\\uFE4F\\uFF00-\\uFFEF\\u0080-\\u009F\\u2000-\\u201f\r\n]"
                                                                           options:NSRegularExpressionCaseInsensitive
                                                                             error:nil];
    NSString *modifiedString = [regex stringByReplacingMatchesInString:text
                                                               options:0
                                                                 range:NSMakeRange(0, [text length])
                                                          withTemplate:@"&&&&****"];
    
    return modifiedString;
}




#pragma mark - MSRegistViewProtocol

- (void)presenterDidEnableGetVerifyCode:(MSRegistPresenter *)presenter
{
    if (presenter.enableGetVerifyCode) {
        self.codeButton.backgroundColor = RGBA_HEX(0xEC1C24 ,1);
        self.codeButton.enabled = YES;
        [self.emailInputView setRightButtonHidden:NO];
     } else {
        self.codeButton.backgroundColor = RGBA_HEX(0xEC1C24 ,0.3);
        self.codeButton.enabled = NO;
    }
}

- (void)presenter:(MSRegistPresenter *)presenter updateGetVerifyCodeCountDown:(NSUInteger)count
{
    if (count == 0) {
        NSString * timeDes = [NSString stringWithFormat:@"%@", MSResourceString(@"register_page_resend_verification_code")];
        [self.retryButton setTitle:timeDes forState:UIControlStateNormal];
        self.retryButton.enabled = YES;
        
    }else{
        NSString * timeDes = [NSString stringWithFormat:@"%@(%lus)", MSResourceString(@"register_page_resend_verification_code"), (unsigned long)count];
        [self.retryButton setTitle:timeDes forState:UIControlStateNormal];
        self.retryButton.enabled = NO;
    }
}

- (void)presenterDidEnableVerifyCodeAuth:(MSRegistPresenter *)presenter{
    self.retryButton.enabled = presenter.enableVerifyCodeAuth;
}

- (void)presenter:(MSRegistPresenter *)presenter verifyCodeAuthCompletion:(NSError *)error
{
    if (error) {
        if (error.code == verifyCodeMaxErrorCount) {
            //[self.presenter resetTimer];
            OEMTitleAndOneButtonAlertView *alertView = [[OEMTitleAndOneButtonAlertView alloc]initWithTitle:MSResourceString(@"register_page_verifycode_maxcount_error") confirmButtonName:MSResourceString(@"register_page_button_confirm")];
            [alertView showWithSuperview:self.view.window];
            @weakify(self)
            alertView.clickConfirmBlock = ^{
                weak_self.presenter.verifyCode = nil;
            };
            
            [self.confirmationCodeInputView cleanInputWithFocusFirstInput:NO];
            
        } else {
            [self toastText:error.localizedDescription];
            [self.confirmationCodeInputView cleanInputWithFocusFirstInput:NO];
        }
    } else {
        
        if (self.isFromRN){
            MSAccountCancellationViewController *dest = [[MSAccountCancellationViewController alloc] init];
            dest.account = self.account;
            dest.verifyId = presenter.verifyId;
            [self.navigationController pushViewController:dest animated:YES];
            return;
        }
        
        //获取验证码成功，跳转设置密码页，完成最终注册流程
        MSSetPasswordViewController *setPasswordViewController = [[MSSetPasswordViewController alloc] init];
        setPasswordViewController.isDevice = self.isDevice;
        setPasswordViewController.isLoginExpired = self.isLoginExpired;
        setPasswordViewController.account = self.presenter.account;
        setPasswordViewController.verifyCode = presenter.verifyId;
        [self.confirmationCodeInputView cleanInputWithFocusFirstInput:NO];
        [self.navigationController pushViewController:setPasswordViewController animated:YES];
    }
}

- (void)presenter:(MSRegistPresenter *)presenter getVerifyCodeCompletion:(NSError *)error
{
    if (error) {
        [self toastText:error.localizedDescription];
        return;
    } else {
        [self shouldMoveToValidationCodeInputState:YES];
        [self.confirmationCodeInputView becomResponder];
    }
}

- (void)shouldMoveToValidationCodeInputState:(BOOL)inputValidCodeStage{
    self.isInputValidCodeStage = inputValidCodeStage;
    [self.scrollContainer setContentOffset:CGPointMake(inputValidCodeStage ? SCREEN_WIDTH : 0, 0) animated:YES];
    [self setNavButton];
    if (!inputValidCodeStage) {
        [self.confirmationCodeInputView cleanInputWithFocusFirstInput:NO];
    }else{
        BOOL isEmail = [MSLoginUtils isValidEmail:self.account]; //是否邮箱
        if (isEmail) {
            self.confirmCodeDesLabel.text = [NSString stringWithFormat:@"%@ %@", MSResourceString(@"register_page_did_sent_code"), self.account];
        }else{
            self.confirmCodeDesLabel.text = [NSString stringWithFormat:@"%@ +00%@ %@", MSResourceString(@"register_page_did_sent_code"),HGCurrentCountry.phoneCode,self.account];
        }
    }
}

//隐藏或显示下一步相关的视图
- (void)showOrHiddenNextView:(BOOL)hidden {
    if (hidden) {
        self.codeButton.hidden = NO;
        self.confirmCodeTitle.hidden = NO;
        self.confirmationCodeInputView.hidden = NO;
        self.selectLabel.hidden = NO;
        self.selectButton.hidden = NO;
        
        self.selectButton.selected = NO;
        
        [self.backButton mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.codeButton.mas_bottom).offset(20);
            make.height.mas_equalTo(16);
            make.centerX.equalTo(self.view);
        }];
    } else {
        self.codeButton.hidden = NO;
        self.confirmCodeTitle.hidden = NO;
        self.confirmationCodeInputView.hidden = NO;
        self.selectLabel.hidden = NO;
        self.selectButton.hidden = NO;
    
        [self enableGetCodeButton:NO];
    }
}


@end
