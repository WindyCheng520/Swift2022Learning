//
//  MSCountrySelectViewController.m
//  MSLogin
//
//  Created by syp on 2020/6/16.
//

#import "MSCountrySelectViewController.h"
#import <OEMFoundation/HGInternationalization.h>
#import <MSLoginBundle.h>
#import <MSBusiness/MSRouterUrl.h>
#import "MSBottomAlertView.h"
#import "MSCountrySelectCell.h"
#import <MSBusiness/MSUIConfiguration.h>
#import <MSBusiness/AuthorizationManager.h>

static NSString *const MSCountrySelectCellIdentifier = @"MSCountrySelectCellIdentifier";


@interface MSCountrySelectViewController () <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate>

@property (nonatomic, strong) UIView * searchBackgoundView;
@property (nonatomic, strong) HGTextField *searchTextField;
@property (nonatomic, strong) HGButton *cancelSearchButton;

@property (nonatomic, strong) HGTableView *tableView;
@property (nonatomic, strong) HGLabel *noResultLabel;
@property (nonatomic, strong) UIView *lineView;


@end

@implementation MSCountrySelectViewController


- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.presenter = [[MSCountrySelectPresenter alloc]initWithView:self];
        
        self.searchBackgoundView = [HGView new];
        self.searchTextField = [HGTextField new];
        self.cancelSearchButton = [HGButton new];
        
        self.tableView = [HGTableView new];
        self.noResultLabel = [HGLabel new];
    }
    return self;
}

- (void)configureOEMTheme{
    [self.view configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.searchBackgoundView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.tableView configureThemeTag:OEMThemesTag_UIView_Background];
    [self.noResultLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    [self.searchTextField configureThemeTag:OEMThemesTag_UITextField_Textcolor];
    [self.searchTextField specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UITextField_BackgroundColor): DarkThemeSearchTextFieldBackground
    } lightModeProperties:@{
        @(OEMThemesTag_UITextField_BackgroundColor): LightThemeSearchTextFieldBackground
    }];
    
    [self.cancelSearchButton configureThemeTag:OEMThemesTag_UIButton_TitleThemeColor];
    [self.cancelSearchButton specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : CommonDarkThemeInputTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : CommonLightThemeInputTextColor
    }];
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        [weakSelf setNavButton];
    } callImmidiately:YES];
}


- (void)setNavButton{
    if (OEMThemeIsDarkMode) {
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_dm")];
    }else{
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_lg")];
    }
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = MSResourceString(@"select_region_page_Title");
    
    self.hiddenKeyboardWhenTap = YES;
    
    [self.view addSubview:self.searchBackgoundView];
    
    UIView *leftView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 31, 36)];
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(8, 0, 20, 36)];
    imageView.image = MSResourceImage(@"ic_input_sratch");
    imageView.contentMode = UIViewContentModeCenter;
    [leftView addSubview:imageView];
    NSMutableParagraphStyle* paragraphStyle = [[NSMutableParagraphStyle alloc]init];
    if (isRTL()) {
        self.searchTextField.rightView = leftView;
        self.searchTextField.rightViewMode = UITextFieldViewModeAlways;
        paragraphStyle.alignment = NSTextAlignmentRight;

    }else{
        self.searchTextField.leftView = leftView;
        self.searchTextField.leftViewMode = UITextFieldViewModeAlways;
        paragraphStyle.alignment = NSTextAlignmentLeft;
    }
    self.searchTextField.layer.cornerRadius = 8;
    self.searchTextField.textAlignment = NSTextAlignmentLeft;
    NSMutableAttributedString *mutableString = [[NSMutableAttributedString alloc]initWithString:MSResourceString(@"select_region_page_search_placeholder") attributes:@{NSParagraphStyleAttributeName : paragraphStyle}];
    self.searchTextField.attributedPlaceholder = mutableString;
//    self.searchTextField.placeholder =  MSResourceString(@"select_region_page_search_placeholder");
    self.searchTextField.font = [UIFont systemFontOfSize:14];
    self.searchTextField.delegate = self;
    [self.searchBackgoundView addSubview:self.searchTextField];
    
    [self.searchBackgoundView addSubview:self.cancelSearchButton];
    [self.cancelSearchButton setTitle:MSResourceString(@"select_region_page_search_cancel") forState:UIControlStateNormal];
    [self.cancelSearchButton.titleLabel setFont:[UIFont systemFontOfSize:14]];
    [self.cancelSearchButton addTarget:self action:@selector(onCancelSearch) forControlEvents:UIControlEventTouchUpInside];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(textFieldDidChanged) name:UITextFieldTextDidChangeNotification object:self.searchTextField];
    
    self.lineView = [UIView new];
    self.lineView.backgroundColor = RGB_HEX(0xEBEBEB);
    [self.view addSubview:self.lineView];
    
    
    self.tableView.rowHeight = 50;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.backgroundColor = RGB_HEX(0xFAFAFA);
    [self.view addSubview:self.tableView];
    
    self.noResultLabel.textColor = RGB_HEX(0x7A7979);
    self.noResultLabel.font = [UIFont systemFontOfSize:12];
    self.noResultLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:self.noResultLabel];
    self.noResultLabel.hidden = YES;
    
    [self makeConstraints];
    [self.presenter getCountryData];
    
    [self configureOEMTheme];
}

-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)makeConstraints {
    [self.searchBackgoundView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.searchBackgoundView.superview).offset(0);
        make.trailing.equalTo(self.searchBackgoundView.superview).offset(0);
        //make.top.mas_equalTo(STATUSBAR_HEIGHT + 44 + 12);
        make.top.equalTo(self.searchBackgoundView.superview).offset(0);
        make.height.mas_equalTo(60);
    }];
    
    [self updateTextFiledEditing:NO animated:YES];
    
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.searchTextField.mas_bottom).offset(11.5f);
        make.leading.trailing.equalTo(self.view);
        make.height.mas_equalTo(0.0f);
    }];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.equalTo(self.view);
        make.top.equalTo(self.searchTextField.mas_bottom).offset(12);
        make.bottom.equalTo(self.view);
    }];
    
    [self.noResultLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(16);
        make.trailing.mas_equalTo(-16);
        make.top.equalTo(self.tableView).offset(80);
    }];
}

#pragma mark - UITableViewDelegate, UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.searchTextField.text.length == 0 && self.searchTextField.isFirstResponder) {
        return 0;
    }
    return self.presenter.showDataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MSCountrySelectCell *cell = [tableView dequeueReusableCellWithIdentifier:MSCountrySelectCellIdentifier];
    if (!cell) {
        cell = [[MSCountrySelectCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MSCountrySelectCellIdentifier];
    }
    if (indexPath.row < self.presenter.showDataArray.count) {
        MSCountryGetResult *country = [self.presenter.showDataArray objectAtIndex:indexPath.row];
        cell.titleLabel.text = country.area;
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.checkMark.hidden = [country.countryCode isEqualToString:self.presenter.selectCountry.countryCode] ? NO : YES;
        //cell.accessoryType = [country.countryCode isEqualToString:self.presenter.selectCountry.countryCode] ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row < self.presenter.showDataArray.count) {
        MSCountryGetResult *country = [self.presenter.showDataArray objectAtIndex:indexPath.row];
        if ([country.countryCode isEqualToString:self.presenter.selectCountry.countryCode]) {
            [tableView deselectRowAtIndexPath:indexPath animated:YES];
            return;
        }
        
        if (!HGCurrentCountry) { //首次选择国家地区直接切换回登录页
            [self.presenter setCountryData:country];
            [self.tableView reloadData];
            if (self.enterType == MSCountrySelectEnterType_Right) {
                [self.navigationController popViewControllerAnimated:YES];
            } else {
                BOOL isDevice = self.enterType == MSCountrySelectEnterType_Device;
                [OEMRouter handleURL:MSRouterLoginIndex withParams:@{@"isDevice":@(isDevice),@"previousPageName":@"", @"isForAuthorize":@(self.isForAuthorize)} sourceController:self andCompletion:nil];
            }
            return;
        }
        
        MSBottomAlertView* alertView = [[MSBottomAlertView alloc]initWithTitle:[NSString stringWithFormat:MSResourceString(@"select_region_page_change_area_confirm_title"), country.area?:@""] actionTitle:[NSString stringWithFormat:MSResourceString(@"select_region_page_changeto"), country.area?:@""]];
        [alertView show];
        WEAK_SELF;
        alertView.clickActionBlock = ^{
            STRONG_SELF;
            [self.presenter setCountryData:country];
            [self.tableView reloadData];
            
            if (self.enterType == MSCountrySelectEnterType_Right) {
                [self.navigationController popViewControllerAnimated:YES];
            } else {
                BOOL isDevice = self.enterType == MSCountrySelectEnterType_Device;
                [OEMRouter handleURL:MSRouterLoginIndex withParams:@{@"isDevice":@(isDevice),@"previousPageName":@"", @"isForAuthorize":@(self.isForAuthorize)} sourceController:self andCompletion:nil];
            }
            
            [MSUIConfiguration sh_showBlackToastHudToView:[UIApplication sharedApplication].keyWindow text:MSResourceString(@"select_region_page_change_success")];
            
        };
        alertView.clickCancleBlock = ^{
            [tableView deselectRowAtIndexPath:indexPath animated:YES];
        };
        
    }
}

#pragma mark - Notification
- (void)textFieldDidChanged {
    [self.presenter searchCountryDataWithText:self.searchTextField.text];
}

#pragma mark - event
- (void)leftBarButtonClick:(UIButton *)button {
    [super leftBarButtonClick:button];
    safeCallBlock(self.clickLeftButtonBlock);
}

- (void)onCancelSearch{
    self.searchTextField.text = @"";
    [self textFieldDidChanged];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.searchTextField resignFirstResponder];
        [self.tableView reloadData];
    });
}

#pragma mark - MSCountrySelectViewProtocol
- (void)presenter:(MSCountrySelectPresenter *)presenter getCountryCompletion:(MSBusinessError *)error{
    if (error) {
        [self toastText:error.localizedDescription];
    } else {
        [self.tableView reloadData];
    }
}

- (void)presenter:(MSCountrySelectPresenter *)presenter setCountryCompletion:(MSBusinessError *)error{
    
}

- (void)presenterDidSearchCountryData:(MSCountrySelectPresenter *)presenter {
    if (self.presenter.showDataArray.count > 0) {
        self.noResultLabel.hidden = YES;
    } else {
        self.noResultLabel.hidden = NO;
        self.noResultLabel.text = [NSString stringWithFormat:MSResourceString(@"select_region_page_search_no_result"), self.searchTextField.text];
    }
    [self.tableView reloadData];
}

#pragma mark - ====== UITextFieldDelegate ======


- (void)textFieldDidBeginEditing:(UITextField *)textField{
    [self updateTextFiledEditing:YES animated:YES];
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    [self updateTextFiledEditing:NO animated:YES];
}

- (void)updateTextFiledEditing:(BOOL)isEditing animated:(BOOL)animated{
    if (isEditing) {
        [UIView animateWithDuration:0.25 animations:^{
            [self.searchTextField mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.leading.equalTo(self.searchTextField.superview).offset(16);
                make.trailing.equalTo(self.searchTextField.superview).offset(-78);
                make.top.equalTo(self.searchTextField.superview).offset(12);
                make.height.mas_equalTo(36);
            }];
            [self.cancelSearchButton mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.leading.equalTo(self.searchTextField.mas_trailing).offset(16);
                make.height.mas_equalTo(30);
                make.centerY.equalTo(self.cancelSearchButton.superview);
            }];
        }];
    }else{
        [UIView animateWithDuration:0.25 animations:^{
            [self.searchTextField mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.leading.equalTo(self.searchTextField.superview).offset(16);
                make.trailing.equalTo(self.searchTextField.superview).offset(-16);
                make.top.equalTo(self.searchTextField.superview).offset(12);
                make.height.mas_equalTo(36);
            }];
            [self.cancelSearchButton mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.leading.equalTo(self.searchTextField.mas_trailing).offset(16);
                make.height.mas_equalTo(30);
                make.width.mas_equalTo(0);
                make.centerY.equalTo(self.cancelSearchButton.superview);
            }];
        }];
    }
    [self.tableView reloadData];
}





@end


