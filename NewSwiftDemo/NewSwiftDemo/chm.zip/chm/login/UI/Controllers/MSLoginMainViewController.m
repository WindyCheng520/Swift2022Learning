//
//  MSLoginViewController.m
//  MSLogin
//
//  Created by syp on 2020/6/11.
//

#import "MSLoginMainViewController.h"
#import <OEMFoundation/HGInternationalization.h>
#import <OEMFoundation/MSInputView.h>
#import "MSCountrySelectViewController.h"
#import "MSLoginBundle.h"
#import "MSRegistMainViewController.h"
#import "MSThirdLoginBindEmailViewController.h"
#import <MSBusiness/MSRouterUrl.h>
#import "MSUserDefaultTools.h"
#import "MSLoginUtils.h"
#import <MSBusiness/MSAppInfo.h>
#import <YYText/YYText.h>
#import <MSBusiness/MideaTool.h>
#import <MSBusiness/MSNotificationConst.h>
#import "UIView+LoginUtilities.h"
#import <OEMTheme/OEMHGAlertController.h>
#import <OEMTheme/MSInputView_Private.h>
#import <OEMTheme/OEMMSInputView.h>
#import <MSBusiness/NSString+Toshiba.h>

#import <MSBusiness/MSAppInfo.h>
#import <MSBusiness/MSUserDefaultTools.h>
#import <OEMTheme/UIViewController+OEMTheme.h>
#import <OEMFoundation/OEMCustomize.h>

static const NSInteger textFieldTag = 1234;  //账号输入框

#define kAlphaNum @"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-.@"

@interface MSLoginMainViewController () <MSInputViewDelegate>

@property (nonatomic, strong) HGView *backView;
@property (nonatomic, strong) HGImageView *backImageView;
@property (nonatomic, strong) HGImageView *backImageView1;
@property (nonatomic, strong) HGImageView *iconImageView;

@property (nonatomic, strong) HGLabel *appNameLabel;  //app 名字

@property (nonatomic, strong) MSInputView *regionInputView; //国家地区
@property (nonatomic, strong) HGButton *regionButton;       //国家地区覆盖按钮

@property (nonatomic, strong) MSInputView *accountInputView;
@property (nonatomic, strong) MSInputView *passwordInputView;
@property (nonatomic, strong) HGButton *SignInButton;
@property (nonatomic, strong) HGButton *forgetpasswordButton;
@property (nonatomic, strong) HGButton *signUpButton;
@property (nonatomic, strong) HGButton *selectButton;
@property (nonatomic, strong) YYLabel *selectLabel;
@property (nonatomic, assign) CGFloat selectTextHeight;
@property (nonatomic, strong) HGLabel *orSignInLabel;
@property (nonatomic, strong) HGButton *facebookButton;
@property (nonatomic, strong) HGButton *twButton;
@property (nonatomic, strong) HGButton *appleButton;
@property (nonatomic, strong) CAGradientLayer * backgroundGradientLayer;
@property (nonatomic,strong)UIImageView * logoImageView;
@property (nonatomic, strong) UIButton *leftButton;
@property (nonatomic, assign) BOOL isSmallScreen;    //针对320的屏幕宽度，进行适配


@property (nonatomic, weak) UISegmentedControl *segment;
@property (nonatomic, assign) NSInteger count;




@end

@implementation MSLoginMainViewController


- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.presenter = [[MSLoginPresenter alloc] initWithView:self];
        self.canRightSlideBack = NO;

        self.iconImageView = [HGImageView new];
        self.appNameLabel = [HGLabel new];
        
        self.regionInputView = [OEMMSInputView new];
        self.regionButton = [HGButton new];
        
        self.accountInputView = [OEMMSInputView new];
        self.passwordInputView = [OEMMSInputView new];
        self.SignInButton = [HGButton new];
        self.forgetpasswordButton = [HGButton new];
        self.signUpButton = [HGButton new];
        self.selectButton = [HGButton new];
        self.selectLabel = [YYLabel new];
        self.orSignInLabel = [HGLabel new];
        self.facebookButton = [HGButton new];
        self.twButton = [HGButton new];
        self.appleButton = [HGButton new];
        self.logoImageView = [UIImageView new];
    }
    return self;
}

- (void)configureOEMTheme{
    
    [self.appNameLabel configure90TranslucentTrait];
    self.regionInputView.layer.borderColor = [UIColor clearColor].CGColor;
    self.regionInputView.layer.borderWidth = 0.0;
    
    self.accountInputView.layer.borderColor = [UIColor clearColor].CGColor;
    self.accountInputView.layer.borderWidth = 0.0;
    
    self.passwordInputView.layer.borderColor = [UIColor clearColor].CGColor;
    self.passwordInputView.layer.borderWidth = 0.0;
    
    [self.regionInputView addThemeBottomSeplineWithOffset:0];
    [self.accountInputView addThemeBottomSeplineWithOffset:0];
    [self.passwordInputView addThemeBottomSeplineWithOffset:0];
    
    [self.SignInButton configureThemeTag:OEMThemesTag_UIView_Main_Color];
    [self.SignInButton configureThemeTag:OEMThemesTag_UIButton_Background];
    [self.SignInButton configureThemeTag:OEMThemesTag_UIButton_AttributedTraitColor];

    [self.view configureThemeTag:OEMThemesTag_UIView_Background];
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    
    [self.regionInputView.textField configureThemeTag:OEMThemesTag_UITextField_Textcolor];
    [self.accountInputView.textField configureThemeTag:OEMThemesTag_UITextField_Textcolor];
    [self.passwordInputView.textField configureThemeTag:OEMThemesTag_UITextField_Textcolor];
    
    [self.forgetpasswordButton configureThemeTag:OEMThemesTag_UIButton_AttributedTraitColor];
    [self.signUpButton configureThemeTag:OEMThemesTag_UIButton_AttributedThemeColor];
    
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        [weakSelf addGradientLayer];
        [weakSelf setNavButton];
        [weakSelf updateAttributeString];
        [weakSelf updateNavigationAppearance];
    } callImmidiately:YES];
}

- (void)setNavButton{
    if (OEMThemeIsDarkMode) {
        UIImage * image = MSResourceImage(@"ic_nav_close_dm");
        [self.leftButton setImage:image forState:UIControlStateNormal];
    }else{
        UIImage * image = MSResourceImage(@"ic_nav_close_lg");
        [self.leftButton setImage:image forState:UIControlStateNormal];
    }
}

- (void)updateAttributeString{
    NSMutableAttributedString * selectAttributedString = [UIView getProtocolString:self.isSmallScreen];
    self.selectLabel.attributedText = selectAttributedString;
    self.selectTextHeight =  self.isSmallScreen ? [YYTextLayout layoutWithContainerSize:CGSizeMake(SCREEN_WIDTH-33.5*2-15-6.9, MAXFLOAT) text:selectAttributedString].textBoundingSize.height : [YYTextLayout layoutWithContainerSize:CGSizeMake(SCREEN_WIDTH-40*2-16-8, MAXFLOAT) text:selectAttributedString].textBoundingSize.height;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.canRightSlideBack = NO;
    self.hiddenKeyboardWhenTap = YES;
    self.view.clipsToBounds = YES;
    self.isSmallScreen = (SCREEN_WIDTH <= 375 && SCREEN_HEIGHT <= 667);
    [self createUI];
    [self makeConstraints];
    
    if (self.isLoginExpired) {
        [self toastText:MSResourceString(@"login_page_exipred_token")];
    }
    
    [self addBackImageViewAnimation];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        if (self.previousPageName.length > 0) {
            NSDictionary *action_result = @{@"prevPageName":self.previousPageName};
        } else {
            NSDictionary *action_result = @{@"prevPageName":@""};
        }
    });
    
   [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(passwordModify:) name:kMideaPasswordModifyNotification object:nil];
    
    [self configureOEMTheme];
    
    if (self.isForAuthorize) {
        [self toastText:MSResourceString(@"login_first_tips")];
    }
   
#if AppStore_ENV==0
    self.iconImageView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(presse)];
    [self.iconImageView addGestureRecognizer:tapGestureRecognizer];
    
    NSArray *array = @[@"sit",@"dev",@"uat",@"pro"];
    UISegmentedControl *segment = [[UISegmentedControl alloc] initWithItems:array];
    [self.view addSubview:segment];
    NSInteger currentIndex = [MSUserDefaultTools getUrlEnvironmentType];
    segment.apportionsSegmentWidthsByContent = YES;
    segment.selectedSegmentIndex = currentIndex;

    if (@available(iOS 13, *)) {
        segment.selectedSegmentTintColor = RGB_HEX(0x267AFF);
    } else {
        segment.tintColor = RGB_HEX(0x267AFF);
    }
    
    NSDictionary *normaltextAttr = @{NSFontAttributeName:[UIFont systemFontOfSize:20 weight:UIFontWeightMedium]};
    [segment setTitleTextAttributes:normaltextAttr forState:UIControlStateNormal];

    
    //添加事件
    [segment addTarget:self action:@selector(change:) forControlEvents:UIControlEventValueChanged];
    [segment mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.selectLabel.mas_bottom).offset(20);
        make.leading.equalTo(self.view).offset(26);
        make.trailing.equalTo(self.view).offset(-26);
        make.height.mas_equalTo(44);
    }];
    
    self.segment = segment;
    self.segment.hidden = YES;
    self.navigationController.navigationBar.hidden = YES;
#endif
}

-(void)presse{
    self.count ++;
    NSLog(@"点击了————————————%ld次", self.count);
    if (self.count >= 5) {
        self.segment.hidden = NO;
    }
}


-(void)change:(UISegmentedControl *)sender{
    [self toastText:@"切换环境后请重新选择国家或地区，然后重新启动App"];
    NSInteger currentIndex = sender.selectedSegmentIndex;
    [MSUserDefaultTools saveUrlEnvironmentType:currentIndex];
}

- (void)addGradientLayer{
    if (OEMCustomizableImage(@"login_page_bg")) {
        //如果支持自定义背景图片，则不需要渐变图
        return;
    }
    if (self.backgroundGradientLayer) {
        [self.backgroundGradientLayer removeFromSuperlayer];
        self.backgroundGradientLayer = nil;
    }
    CAGradientLayer *colorLayer = [CAGradientLayer layer];
    colorLayer.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    [self.view.layer insertSublayer:colorLayer above:self.backView.layer];
    
    NSArray * color = @[(__bridge id)OEMThemeColorWithTrait(RGBA_HEX(0x1A1A1A, 1.0), RGBA_HEX(0xFFFFFF, 1.0)).CGColor,
                        (__bridge id)OEMThemeColorWithTrait(RGBA_HEX(0x1A1A1A, 0.6), RGBA_HEX(0xFFFFFF, 0.6)).CGColor,
                        (__bridge id)OEMThemeColorWithTrait(RGBA_HEX(0x1A1A1A, 0.0), RGBA_HEX(0xFFFFFF, 0.0)).CGColor];

    colorLayer.colors = color;
    colorLayer.locations  = @[@(0.0), @(0.5), @(1.0)];
    colorLayer.startPoint = CGPointMake(0.5, 0);
    colorLayer.endPoint   = CGPointMake(0.5, 1);
    self.backgroundGradientLayer = colorLayer;
}

- (void)createUI{
    [self addAnimationBackView];
    
    [self addGradientLayer];
    
    WEAK_SELF;
    
    self.iconImageView.image = OEMCustomizableImage(@"login_page_icon");
    [self.view addSubview:self.iconImageView];
    
    
    self.appNameLabel.text = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleDisplayName"];
    self.appNameLabel.textColor = RGB_HEX(0x999999);
    self.appNameLabel.font = self.isSmallScreen ? [UIFont systemFontOfSize:14] : [UIFont systemFontOfSize:16];
    self.appNameLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:self.appNameLabel];
    
    
    [self.regionInputView setRightImage:MSResourceImage(@"ic_16_arrow")];
    self.regionInputView.font = self.isSmallScreen ? [UIFont systemFontOfSize:14 weight:UIFontWeightMedium] : [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    [self.view addSubview:self.regionInputView];
    
    self.regionButton.backgroundColor = [UIColor clearColor];
    [self.regionButton addTarget:self action:@selector(rightBarButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.regionInputView addSubview:self.regionButton];
    
    //[self.accountInputView setLeftIcon:MSResourceImage(@"ic_Input_me")];
    [self.accountInputView setRightImage:MSResourceImage(@"ic_Input_close")];
    if ([self.accountInputView.textField isKindOfClass:[UITextField class]]) {
        self.accountInputView.textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    }
    self.accountInputView.clickRightButtonBlock = ^{
        weak_self.accountInputView.text = nil;
        weak_self.presenter.account = @"";
    };
    self.accountInputView.delegate = self;
    if ([OEMCustomize getUIntValueWithKey:@"SupportedAccount"] == 0) {
        self.accountInputView.placeholder = MSResourceString(@"register_page_enter_mail_placeholder");
    }else{
        self.accountInputView.placeholder = MSResourceString(@"register_page_enter_mail_placeholder_email_account_only");
    }
    self.accountInputView.text = [MSUserDefaultTools getLastLoginAccount];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *text = [MSUserDefaultTools getLastLoginAccount];
        dispatch_async(dispatch_get_main_queue(), ^{
            weak_self.accountInputView.text = text;
            weak_self.presenter.account = weak_self.accountInputView.text;
        });
    });
    
    [self.accountInputView setRightButtonHidden:YES];
    [self.accountInputView setTextFieldTag:textFieldTag];
    self.accountInputView.font = self.isSmallScreen ? [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold] : [UIFont systemFontOfSize:16 weight:UIFontWeightSemibold];
    [self.view addSubview:self.accountInputView];
    
    //[self.passwordInputView setLeftIcon:MSResourceImage(@"ic_input_password")];
    [self.passwordInputView setRightImage:MSResourceImage(@"ic_input_view")];
    self.passwordInputView.secureTextEntry = YES;
    self.passwordInputView.clickRightButtonBlock = ^{
        if (weak_self.passwordInputView.isSecureTextEntry) {
            weak_self.passwordInputView.secureTextEntry = NO;
            [weak_self.passwordInputView setRightImage:MSResourceImage(@"ic_input_view_s")];
        } else {
            weak_self.passwordInputView.secureTextEntry = YES;
            [weak_self.passwordInputView setRightImage:MSResourceImage(@"ic_input_view")];
        }
    };
    self.passwordInputView.delegate = self;
    [self.passwordInputView setTextFieldTag:textFieldTag + 1];
    self.passwordInputView.font = self.isSmallScreen ? [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold] : [UIFont systemFontOfSize:16 weight:UIFontWeightSemibold];
    self.passwordInputView.placeholder = MSResourceString(@"register_page_enter_phrase_placeholder");
    [self.view addSubview:self.passwordInputView];
    
    self.SignInButton.backgroundColor = RGBA_HEX(0xEC1C24 ,0.3);
    self.SignInButton.enabled = NO;
    self.SignInButton.layer.cornerRadius = self.isSmallScreen ? 19 : 22;
    [self.SignInButton setTitle:MSResourceString(@"login_page_login_button") forState:UIControlStateNormal];
    [self.SignInButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.SignInButton.titleLabel.font = self.isSmallScreen ? [UIFont systemFontOfSize:14 weight:UIFontWeightMedium] : [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    [self.SignInButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.SignInButton];
    
    NSString * forgetPWDString = [NSString stringWithFormat:@"%@?",MSResourceString(@"login_page_forget_password")]; //忘记密码
    NSAttributedString *forgetpasswordButtonAttrText = [UIView attributedText:forgetPWDString color:RGB_HEX(0x999999) arrow:nil isSmallScreen:self.isSmallScreen];
    [self.forgetpasswordButton setAttributedTitle:forgetpasswordButtonAttrText forState:UIControlStateNormal];
    [self.forgetpasswordButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.forgetpasswordButton];
    
    NSAttributedString *signUpButtonAttrText = [UIView attributedText:MSResourceString(@"login_page_signup_button")
                                                              color:RGB_HEX(0xEC1C24)
                                                              arrow:nil
isSmallScreen:self.isSmallScreen];
    [self.signUpButton setAttributedTitle:signUpButtonAttrText forState:UIControlStateNormal];
    [self.signUpButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.signUpButton];
    
    
    self.selectButton.enlargeTouchAreaInsets = UIEdgeInsetsMake(5, 5, 5, 5);
    [self.selectButton setImage:MSResourceImage(@"ic_checkbox") forState:UIControlStateNormal];
    [self.selectButton setImage:MSResourceImage(@"ic_checkbox_s") forState:UIControlStateSelected];
    [self.selectButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.selectButton];
    
    self.selectLabel.numberOfLines = 0;
    [self updateAttributeString];
    [self.view addSubview:self.selectLabel];
    
    
    self.orSignInLabel.text = MSResourceString(@"login_page_thirdpart_login_other");
    self.orSignInLabel.textColor = RGB_HEX(0x999999);
    self.orSignInLabel.font = self.isSmallScreen ? [UIFont systemFontOfSize:10] : [UIFont systemFontOfSize:12];
    [self.view addSubview:self.orSignInLabel];
    
    [self.facebookButton setImage:MSResourceImage(@"login_ic_facebook") forState:UIControlStateNormal];
    [self.facebookButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    self.facebookButton.hidden = YES;
    [self.view addSubview:self.facebookButton];
    
    if (@available(iOS 13.0, *)) {
        [self.appleButton setImage:MSResourceImage(@"login_ic_apple") forState:UIControlStateNormal];
        [self.appleButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:self.appleButton];
    }
    
    UIImage * loginPageSubIcon = OEMCustomizableImage(@"login_page_sub_icon");
    if (loginPageSubIcon) {
        self.logoImageView.image = loginPageSubIcon;
    }else{
        self.logoImageView.hidden = YES;
    }
    [self.view addSubview:self.logoImageView];
    
    //导航栏已隐藏，这里需要手动添加返回按钮
    UIButton * leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.view addSubview:leftButton];
    self.leftButton = leftButton;
    [leftButton addTarget:self action:@selector(leftBarButtonClick:) forControlEvents:UIControlEventTouchUpInside];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSString *countryName = HGCurrentCountry.name;
    self.regionInputView.text = countryName;
    [self setNavButton];
    [self.navigationController setNavigationBarHidden:YES animated:animated];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.navigationController.interactivePopGestureRecognizer.enabled = YES;
    [self.navigationController.navigationBar setBackgroundImage:nil forBarMetrics:UIBarMetricsDefault];
    [self.navigationController setNavigationBarHidden:NO animated:animated];
}

#pragma mark - notification
- (void)passwordModify:(NSNotification *)notification{
    NSDictionary *userInfo = notification.userInfo;
    if ([userInfo[@"type"] isEqualToString:@"reset password"]) {  //未登录状态重置密码 "reset password"
        [self toastText:MSResourceString(@"reset_pasword_page_success_tip")];
    }
}

- (void)addAnimationBackView {
    UIImage * loginPageBgImg = OEMCustomizableImage(@"login_page_bg");
    if (loginPageBgImg) {
        self.backImageView = [HGImageView new];
        self.backImageView.image = loginPageBgImg;
        self.backImageView.contentMode = UIViewContentModeScaleAspectFill;
        [self.view addSubview:self.backImageView];
        
        [self.backImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.view.mas_top);
            make.leading.equalTo(self.view.mas_leading);
            make.trailing.equalTo(self.view.mas_trailing);
            make.bottom.equalTo(self.view.mas_bottom);
        }];
        
        return;
    }
    self.backView = [HGView new];
    [self.view addSubview:self.backView];

    self.backImageView = [HGImageView new];
    self.backImageView.image = MSResourceImage(@"signin_bg@3x.jpg");
    self.backImageView.contentMode = UIViewContentModeScaleAspectFill;
    self.backImageView.alpha = 0.0f;
    self.backImageView.alpha = 0.15f;
    [self.backView addSubview:self.backImageView];

    self.backImageView1 = [HGImageView new];
    self.backImageView1.image = MSResourceImage(@"signin_bg@3x.jpg");
    self.backImageView1.alpha = 0.0f;
    self.backImageView1.alpha = 0.15f;
    self.backImageView1.contentMode = UIViewContentModeScaleAspectFill;
    [self.backView addSubview:self.backImageView1];
    
    CGFloat imageHeight = SCREEN_HEIGHT;
    CGFloat imageWidth = imageHeight * self.backImageView.image.size.width / self.backImageView.image.size.height;
    self.backImageView.frame = CGRectMake(0, SCREEN_HEIGHT-imageHeight, imageWidth, imageHeight);
    self.backImageView1.frame = CGRectMake(self.backImageView.frame.size.width, self.backImageView.frame.origin.y, self.backImageView.frame.size.width, self.backImageView.frame.size.height);
    self.backView.frame = CGRectMake(0, 0, self.backImageView.frame.size.width*2, SCREEN_HEIGHT);
}


-(void)addBackImageViewAnimation{
//    [self.backView.layer removeAllAnimations];
    
    CABasicAnimation* animation = [CABasicAnimation animationWithKeyPath:@"position"];
    animation.fromValue = [NSValue valueWithCGPoint:CGPointMake(0, 0)];
    animation.toValue = [NSValue valueWithCGPoint:CGPointMake(-self.backImageView.frame.size.width, 0)];
    animation.duration = 40;
    animation.repeatCount = MAXFLOAT;
    animation.removedOnCompletion = NO;

    self.backView.layer.anchorPoint = CGPointMake(0, 0);
    [self.backView.layer addAnimation:animation forKey:nil];
}

- (void)makeConstraints{
   // CGFloat statusBarHeight = [UIApplication sharedApplication].statusBarFrame.size.height;
    
    BOOL isAppleSignEnable = YES;  //[MSAppInfo isAppleSignEnable];
    CGFloat leading = 30;
    CGFloat topSpace = SCREEN_SCALE_WIDTH(20);
    if (self.isSmallScreen) {
        [self.leftButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.view).offset(kSafeAreaTop + 20);
            make.leading.equalTo(self.view.mas_leading).offset(16);
        }];
        
        [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.leftButton.mas_bottom).offset(15);
            make.size.mas_equalTo(CGSizeMake(48, 48));
            make.centerX.equalTo(self.view);
        }];
        
        [self.appNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.iconImageView.mas_bottom).offset(topSpace);
            make.leading.equalTo(self.view).offset(leading);
            make.trailing.equalTo(self.view).offset(-leading);
            make.height.mas_equalTo(15);
        }];
        
        [self.regionInputView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.appNameLabel.mas_bottom).offset(topSpace);
            make.leading.equalTo(self.view).offset(leading);
            make.trailing.equalTo(self.view).offset(-leading);
            make.height.mas_equalTo(40);
        }];
        
        [self.regionButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leading.trailing.top.bottom.equalTo(self.regionInputView);
        }];
        
        [self.accountInputView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.regionInputView.mas_bottom).offset(topSpace);
            make.leading.equalTo(self.view).offset(leading);
            make.trailing.equalTo(self.view).offset(-leading);
            make.height.mas_equalTo(40);
        }];
        [self.passwordInputView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.accountInputView.mas_bottom).offset(topSpace);
            make.leading.equalTo(self.view).offset(leading);
            make.trailing.equalTo(self.view).offset(-leading);
            make.height.mas_equalTo(40);
        }];
        [self.forgetpasswordButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.passwordInputView.mas_bottom).offset(topSpace);
            make.leading.equalTo(self.SignInButton).offset(5);
            make.height.mas_equalTo(12);
        }];
        [self.signUpButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.passwordInputView.mas_bottom).offset(topSpace);
            make.trailing.equalTo(self.SignInButton);
            make.height.mas_equalTo(12);
        }];
        [self.SignInButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.forgetpasswordButton.mas_bottom).offset(topSpace);
            make.leading.equalTo(self.view).offset(26);
            make.trailing.equalTo(self.view).offset(-26);
            make.height.mas_equalTo(38);
        }];
        [self.selectButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leading.mas_equalTo(33.5);
            make.size.mas_equalTo(CGSizeMake(15, 15));
            make.top.equalTo(self.selectLabel.mas_top);
        }];
        [self.selectLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leading.equalTo(self.selectButton.mas_trailing).offset(6.9);
            make.trailing.mas_equalTo(-33.5);
            make.top.equalTo(self.SignInButton.mas_bottom).offset(topSpace);
            make.height.mas_equalTo(self.selectTextHeight);
        }];
        
        [self.orSignInLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.view.mas_bottom).offset(-kSafeAreaBottom-62.9);
            make.centerX.equalTo(self.view);
        }];
        
        
        
//        if (@available(iOS 13.0, *)) {
//            self.orSignInLabel.hidden = NO;
//            [self.appleButton mas_makeConstraints:^(MASConstraintMaker *make) {
//                make.top.equalTo(self.orSignInLabel.mas_bottom).offset(14);
//                make.height.mas_equalTo(36);
//                make.width.mas_equalTo(36);
//                make.centerX.equalTo(self.view);
//            }];
//        }else{
//            self.orSignInLabel.hidden = YES;
//        }
        
        //暂时屏蔽facebook登录
        self.facebookButton.hidden = NO;
        if (@available(iOS 13.0, *)) {
            if (isAppleSignEnable){
                NSArray *array = @[self.facebookButton, self.appleButton];
                self.appleButton.layer.cornerRadius = 18;
                self.appleButton.clipsToBounds = YES;
                self.facebookButton.layer.cornerRadius = 18;
                self.facebookButton.clipsToBounds = YES;
                CGFloat space = (SCREEN_WIDTH - 36 - 25 - 36) / 2.0;
                [array mas_distributeViewsAlongAxis:MASAxisTypeHorizontal withFixedItemLength:36 leadSpacing:space tailSpacing:space];
                [array mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.top.equalTo(self.orSignInLabel.mas_bottom).offset(14);
                    make.height.mas_equalTo(36);
                    make.width.mas_equalTo(36);
                }];
            }else{
                self.facebookButton.layer.cornerRadius = 18;
                self.facebookButton.clipsToBounds = YES;
                [self.facebookButton mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.top.equalTo(self.orSignInLabel.mas_bottom).offset(14);
                    make.height.mas_equalTo(36);
                    make.width.mas_equalTo(36);
                    make.centerX.equalTo(self.view);
                }];
            }
        } else {
            self.facebookButton.layer.cornerRadius = 18;
            self.facebookButton.clipsToBounds = YES;
            [self.facebookButton mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(self.orSignInLabel.mas_bottom).offset(14);
                make.height.mas_equalTo(36);
                make.width.mas_equalTo(36);
                make.centerX.equalTo(self.view);
            }];
        }
        
    } else {
        [self.leftButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.view).offset(kSafeAreaTop + 20);
            make.leading.equalTo(self.view.mas_leading).offset(16);
        }];
        
        [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.leftButton.mas_bottom).offset(20);
            make.size.mas_equalTo(CGSizeMake(58, 58));
            make.centerX.equalTo(self.view);
        }];
        
        [self.appNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.iconImageView.mas_bottom).offset(14);
            make.leading.equalTo(self.view).offset(leading);
            make.trailing.equalTo(self.view).offset(-leading);
            make.height.mas_equalTo(18);
        }];
        
        [self.regionInputView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.appNameLabel.mas_bottom).offset(30);
            make.leading.equalTo(self.view).offset(leading);
            make.trailing.equalTo(self.view).offset(-leading);
            make.height.mas_equalTo(48);
        }];
        
        [self.regionButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leading.trailing.top.bottom.equalTo(self.regionInputView);
        }];
        
        [self.accountInputView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.regionInputView.mas_bottom).offset(16);
            make.leading.equalTo(self.view).offset(leading);
            make.trailing.equalTo(self.view).offset(-leading);
            make.height.mas_equalTo(48);
        }];
        [self.passwordInputView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.accountInputView.mas_bottom).offset(16);
            make.leading.equalTo(self.view).offset(leading);
            make.trailing.equalTo(self.view).offset(-leading);
            make.height.mas_equalTo(48);
        }];
        [self.forgetpasswordButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.passwordInputView.mas_bottom).offset(20);
            make.leading.equalTo(self.SignInButton);
            make.height.mas_equalTo(14);
        }];
        [self.signUpButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.passwordInputView.mas_bottom).offset(20);
            make.trailing.equalTo(self.SignInButton);
            make.height.mas_equalTo(14);
        }];
        [self.SignInButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.forgetpasswordButton.mas_bottom).offset(60);
            make.leading.equalTo(self.view).offset(30);
            make.trailing.equalTo(self.view).offset(-30);
            make.height.mas_equalTo(44);
        }];
        [self.selectButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leading.mas_equalTo(40);
            make.size.mas_equalTo(CGSizeMake(16, 16));
            make.top.equalTo(self.selectLabel.mas_top);
        }];
        [self.selectLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leading.equalTo(self.selectButton.mas_trailing).offset(8);
            make.trailing.mas_equalTo(-40);
            make.top.equalTo(self.SignInButton.mas_bottom).offset(24);
            make.height.mas_equalTo(self.selectTextHeight);
        }];
        
        [self.orSignInLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.view.mas_bottom).offset(-kSafeAreaBottom-96);
            make.centerX.equalTo(self.view);
        }];
        
//        if (@available(iOS 13.0, *)) {
//            [self.appleButton mas_makeConstraints:^(MASConstraintMaker *make) {
//                make.top.equalTo(self.orSignInLabel.mas_bottom).offset(14);
//                make.height.mas_equalTo(36);
//                make.width.mas_equalTo(36);
//                make.centerX.equalTo(self.view);
//            }];
//        }
        
        //暂时屏蔽facebook登录
        self.facebookButton.hidden = NO;
        if (@available(iOS 13.0, *)) {
            if (isAppleSignEnable) {
                self.appleButton.layer.cornerRadius = 24;
                self.appleButton.clipsToBounds = YES;
                self.facebookButton.layer.cornerRadius = 24;
                self.facebookButton.clipsToBounds = YES;
                NSArray *array = @[self.facebookButton, self.appleButton];
                CGFloat space = (SCREEN_WIDTH - 48 - 30 - 48) / 2.0;
                [array mas_distributeViewsAlongAxis:MASAxisTypeHorizontal withFixedItemLength:48 leadSpacing:space tailSpacing:space];
                [array mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.top.equalTo(self.orSignInLabel.mas_bottom).offset(15);
                    make.height.mas_equalTo(48);
                    make.width.mas_equalTo(48);
                }];
            }else{
                self.facebookButton.layer.cornerRadius = 24;
                self.facebookButton.clipsToBounds = YES;
                [self.facebookButton mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.top.equalTo(self.orSignInLabel.mas_bottom).offset(15);
                    make.height.mas_equalTo(48);
                    make.width.mas_equalTo(48);
                    make.centerX.equalTo(self.view);
                }];
            }
            
        } else {
            self.facebookButton.layer.cornerRadius = 24;
            self.facebookButton.clipsToBounds = YES;
            [self.facebookButton mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(self.orSignInLabel.mas_bottom).offset(15);
                make.height.mas_equalTo(48);
                make.width.mas_equalTo(48);
                make.centerX.equalTo(self.view);
            }];
        }
    }
    
    [self.logoImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(240);
        make.height.mas_equalTo(26);
        make.centerX.equalTo(self.view);
        make.top.equalTo(self.appleButton.mas_bottom).offset(13.6);
    }];

}

#pragma mark - click button
- (void)leftBarButtonClick:(UIButton *)button{
    CATransition* transition = [CATransition animation];
    transition.duration = 0.25f;
    transition.type = kCATransitionReveal;
    transition.subtype = kCATransitionFromBottom;
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    [self.navigationController popToRootViewControllerAnimated:NO];
    
    safeCallBlock(self.clickLeftButtonBlock);
}

- (void)rightBarButtonClick:(UIButton *)button
{
    MSCountrySelectViewController *countrySelectViewController = [MSCountrySelectViewController new];
    countrySelectViewController.enterType = MSCountrySelectEnterType_Right;
    [self.navigationController pushViewController:countrySelectViewController animated:YES];
}

- (void)clickButton:(UIButton *)button {
    if (button == self.SignInButton) {
        if (self.selectButton.isSelected) {
            [self.presenter login];
        } else {
            [self selectButtonAnimation];
        }
    } else if (button == self.forgetpasswordButton) {
        [OEMRouter handleURL:MSRouterReactNativeIndex withParams:@{
            MSReactNativeModuleNameDefine : MSReactNativeInnerModule_settings,
            MSReactNativeViewProps: @{
                    @"initialRouteName" : @"ResetPassword"
            }
                                                                    
        }];
    } else if (button == self.signUpButton) {
        MSRegistMainViewController* registMainViewController = [MSRegistMainViewController new];
        registMainViewController.isDevice = self.isDevice;
        registMainViewController.isLoginExpired = self.isLoginExpired;
        [self.navigationController pushViewController:registMainViewController animated:YES];
    } else if (button == self.facebookButton) {
        [self showThirdLoginAlertView:1];
    } else if (button == self.twButton) {
        [self showThirdLoginAlertView:2];
    } else if (button == self.appleButton) {
        [self showThirdLoginAlertView:3];
    } else if (button == self.selectButton) {
        self.selectButton.selected = !self.selectButton.isSelected;
    }
}

- (void)selectButtonAnimation {
    [self toastText:MSResourceString(@"login_page_privacy_no_check_toast")];

    CGPoint selectButtonPoint = self.selectButton.center;
    CAKeyframeAnimation *selectButtonAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    selectButtonAnimation.duration = 0.4f;
    selectButtonAnimation.values = @[@(CGPointMake(selectButtonPoint.x-10, selectButtonPoint.y)), @(selectButtonPoint), @(CGPointMake(selectButtonPoint.x-10, selectButtonPoint.y)), @(selectButtonPoint)];
    
    CGPoint selectLabelPoint = self.selectLabel.center;
    CAKeyframeAnimation *selectLabelAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    selectLabelAnimation.duration = 0.4f;
    selectLabelAnimation.values = @[@(CGPointMake(selectLabelPoint.x-10, selectLabelPoint.y)), @(selectLabelPoint), @(CGPointMake(selectLabelPoint.x-10, selectLabelPoint.y)), @(selectLabelPoint)];
    
    [self.selectButton.layer addAnimation:selectButtonAnimation forKey:nil];
    [self.selectLabel.layer addAnimation:selectLabelAnimation forKey:nil];
}

#pragma mark - MSLoginInputViewDelegate

- (void)inputView:(MSInputView *)inputView didChangeText:(NSString *)text
{
    if (self.accountInputView == inputView) {
        self.presenter.account = text;
    } else if (self.passwordInputView == inputView){
        self.presenter.password = text;
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    if (textField.tag == textFieldTag) {
        [self.accountInputView setRightButtonHidden:YES];
    }
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    if (textField.tag == textFieldTag && ![self.accountInputView.text isEqualToString:@""]) {
        [self.accountInputView setRightButtonHidden:NO];
    }
}



- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    if (textField.tag == textFieldTag && ([[string disable_emoji] isEqualToString:@"&&&&****"] || [[string disable_emoji] isEqualToString:@"&&&&****&&&&****"])) {
        [textField becomeFirstResponder];
        return NO;
    }
    
    
    if (textField.tag == textFieldTag){ //限制账号输入框
        NSCharacterSet *cs;
        cs = [[NSCharacterSet characterSetWithCharactersInString:kAlphaNum] invertedSet];
        NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""]; //按cs分离出数组,数组按@""分离出字符串
        BOOL canChange = [string isEqualToString:filtered];
        if (!canChange) {
            return NO;
        }
    }
    //限制空格
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    newString = [newString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (textField.tag == textFieldTag && [newString isEqualToString:textField.text] && range.length == 0) {
        return NO;
    }else if (textField.tag == textFieldTag + 1
              && [string length] > 0
              && ![string isEqualToString:@""]
              && [newString length] > 20){
        //限制长度
        return NO;
    }else if(textField.tag == textFieldTag + 1 && textField.isSecureTextEntry ){//屏蔽密码密文输入状态状态重新编辑清除原有内容
        textField.text = newString;
        self.presenter.password = newString;
        return NO;
    }else if (textField.tag == textFieldTag && newString.length > OEMLoginAccountInputLimit){
        //限制邮箱320字符
        return NO;
    }
    
    return YES;
}



#pragma mark - MSLoginViewProtocol

-(void)presenter:(MSLoginPresenter *)presenter didEnableShowDeleteButton:(BOOL)enable{
    [self.accountInputView setRightButtonHidden:!enable];
}

-(void)presenter:(MSLoginPresenter *)presenter didEnableLogin:(BOOL)enable{
    if (enable) {
        self.SignInButton.backgroundColor = RGBA_HEX(0xEC1C24 ,1);
        self.SignInButton.enabled = YES;
        
        //self.SignInButton.layer.shadowColor = RGBA_HEX(0xEC1C24, 0.25f).CGColor;
        //self.SignInButton.layer.shadowOffset = CGSizeMake(0,2);
        //self.SignInButton.layer.shadowOpacity = 1;
        //self.SignInButton.layer.shadowRadius = self.isSmallScreen ? 9 : 10;
        //self.SignInButton.layer.shadowPath = [UIBezierPath bezierPathWithRect:self.SignInButton.bounds].CGPath;
    } else{
        self.SignInButton.backgroundColor = RGBA_HEX(0xEC1C24 ,0.3);
        self.SignInButton.enabled = NO;
        //self.SignInButton.layer.shadowOpacity = 0;
    }
}

-(void)presenter:(MSLoginPresenter *)presenter loginCompletion:(MSBusinessError *)error{
    if (error) {
        [self toastText:error.localizedDescription];
    } else {
        [self loginSuccessToJump];
    }
}

-(void)presenter:(MSLoginPresenter *)presenter thirdLoginCompletion:(MSBusinessError *)error{
    if (error) {
        if (error.code == 14007) {   //未绑定邮箱，则跳转邮箱绑定页面
            MSThirdLoginBindEmailViewController* thirdLoginBindEmailViewController = [MSThirdLoginBindEmailViewController new];
            thirdLoginBindEmailViewController.isDevice = self.isDevice;
            thirdLoginBindEmailViewController.isLoginExpired = self.isLoginExpired;
            thirdLoginBindEmailViewController.thirdType = self.presenter.thirdType;
            thirdLoginBindEmailViewController.userId = self.presenter.userId;
            thirdLoginBindEmailViewController.taccessToken = self.presenter.taccessToken;
            thirdLoginBindEmailViewController.accountInfo = self.presenter.accountInfo;
            [self.navigationController pushViewController:thirdLoginBindEmailViewController animated:YES];
       }else{
           [self toastText:error.localizedDescription];
       }
    } else {
        [self loginSuccessToJump];
   }
    
}

-(void)loginSuccessToJump{
    [MSLoginUtils postLoginInNotification];
    
    CATransition* transition = [CATransition animation];
    transition.duration = 0.25f;
    transition.type = kCATransitionReveal;
    transition.subtype = kCATransitionFromBottom;
    
    if (self.isDevice) {
        NSMutableArray* controllerArray = [self.navigationController.viewControllers mutableCopy];
        UIViewController* viewCtl = [OEMRouter objectForURL:MSRouterDeviceIndex];
        if (viewCtl && controllerArray.count > 1) {
            [controllerArray insertObject:viewCtl atIndex:1];
            viewCtl.hidesBottomBarWhenPushed = YES;
            self.navigationController.viewControllers = [controllerArray copy];
            
            [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
            [self.navigationController popToViewController:viewCtl animated:NO];
        }
    } else if (self.isLoginExpired) {
        [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
        [self.navigationController popViewControllerAnimated:NO];
    } else {
        [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
        [self.navigationController popToRootViewControllerAnimated:NO];
        if(self.viewControllerSuccessBlock){
            self.viewControllerSuccessBlock();
        }
    }
}

#pragma mark - 弹框
//type=1，Facebook   type=2， Twitter    type=3，  apple
- (void)showThirdLoginAlertView:(NSInteger)type {
     
    if (!self.selectButton.isSelected) {
        [self selectButtonAnimation];
        return;
    }
    
    switch (type) {
        case 1:{
            [self.presenter loginFacebook];
        }
            break;
            
        case 2:{
            WEAK_SELF;
            HGAlertAction* cancelAction = [HGAlertAction actionWithTitle:MSResourceString(@"login_page_thirdpart_login_cancel") style:HGAlertActionStyleCancel action:^{
                [weak_self toastText:MSResourceString(@"login_page_thirdpart_login_cancel")];
            }];
            cancelAction.font = [UIFont systemFontOfSize:17 weight:UIFontWeightRegular];
            HGAlertAction* okAction = [HGAlertAction actionWithTitle:MSResourceString(@"login_page_thirdpart_login_continue") action:^{
                [weak_self.presenter loginTwitter];
            }];
            HGAlertController* alertController = [OEMHGAlertController alertControllerWithTitle:[NSString stringWithFormat:MSResourceString(@"login_page_thirdpart_login_scheme"), [MSAppInfo appName], @"Twitter.com"] message:MSResourceString(@"login_page_thirdpart_login_allowshareinfo") actions:@[cancelAction, okAction]];
            [alertController show];
        }
            break;
            
        case 3:{
            [self.presenter loginApple];
        }
            break;
            
        default:
            break;
    }
    
}


@end


