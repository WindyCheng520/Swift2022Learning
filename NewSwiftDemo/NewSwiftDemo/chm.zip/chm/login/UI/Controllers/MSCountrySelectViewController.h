//
//  MSCountrySelectViewController.h
//  MSLogin
//
//  Created by syp on 2020/6/16.
//

#import <MSBusiness/MVPViewController.h>
#import "MSCountrySelectPresenter.h"

typedef NS_ENUM(NSInteger, MSCountrySelectEnterType) {
    MSCountrySelectEnterType_Device = 0,  //点击首页添加设备，未选择国家地区，进入
    MSCountrySelectEnterType_Login,   //点击首页登录按钮，我的页面消息中心、登录、我的设备，未登录，未选择国家地区，进入
    MSCountrySelectEnterType_Right    //点击登录、注册页面等右上角进入
};


@interface MSCountrySelectViewController : MVPViewController<MSCountrySelectPresenter *><MSCountrySelectViewProtocol>

@property (nonatomic, assign) MSCountrySelectEnterType enterType;
@property (nonatomic, copy) void(^clickLeftButtonBlock)(void);


@property (nonatomic, assign) BOOL isForAuthorize; //为了跳转授权


@end

