//
//  MSThirdLoginBindEmailViewController.m
//  MSLogin
//
//  Created by 及时行乐 on 2020/7/16.
//

#import "MSThirdLoginBindEmailViewController.h"
#import <OEMFoundation/HGInternationalization.h>
#import "MSLoginBundle.h"
#import "MSCountrySelectViewController.h"
#import "MSThirdLoginSetPasswordViewController.h"
#import "MSUIConfiguration.h"
#import <MSBusiness/MSRouterUrl.h>
#import <OEMTheme/MSInputView_Private.h>
#import "MSLoginUtils.h"
#import <OEMTheme/OEMTitleAndOneButtonAlertView.h>
#import <OEMTheme/OEMMSInputView.h>
#import "CodeNotRecvViewController.h"
#import "MSValidCodeView.h"
#import "UIView+LoginUtilities.h"
#import <MSBusiness/NSString+Toshiba.h>
#import <OEMFoundation/OEMCustomize.h>
#import "MSLoginUtils.h"

static const NSInteger textFieldTag = 1234;
static const NSInteger verifyCodeMaxErrorCount = 3100;   //验证码输错五次

#define kAlphaNum @"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-.@"

@interface MSThirdLoginBindEmailViewController ()<MSInputViewDelegate,MSInputViewDelegate>

@property (nonatomic, strong) HGScrollView *scrollContainer;

@property (nonatomic, strong) HGView * mailInputViewContainer;       //账号输入框容器（左屏）
@property (nonatomic, strong) HGView * validCodeViewContainer;       //验证码输入框容器（右屏）

@property (nonatomic, strong) HGLabel *titleLabel;           //@"绑定邮箱"
@property (nonatomic, strong) HGLabel *emailLabel;           //@"We will send you a verification code" （去掉）

@property (nonatomic, strong) MSInputView *regionInputView; //国家地区
@property (nonatomic, strong) HGButton *regionButton;       //国家地区覆盖按钮

@property (nonatomic, strong) MSInputView *emailInputView;   //邮箱输入框
@property (nonatomic, strong) HGButton *codeButton;         //获取验证码按钮
@property (nonatomic, strong) HGButton *backButton;         //返回 × 按钮


//@property (nonatomic, strong) HGLabel *confirmationCodeLabel;
@property (nonatomic, strong) MSValidCodeView *confirmationCodeInputView; //验证码输入框
@property (nonatomic, strong) HGLabel *confirmCodeTitle;                //@"输入验证码"
@property (nonatomic, strong) HGLabel *confirmCodeDesLabel;            //@"验证码已发送致邮箱"
@property (nonatomic, assign) CGFloat selectTextHeight;
@property (nonatomic, strong) HGButton *retryButton;                    //重新发送
@property (nonatomic, strong) HGButton *codeNotRecvBtn;

@property (nonatomic, strong) HGButton *nextButton;
@property (nonatomic, assign) BOOL isInputValidCodeStage;

@end

@implementation MSThirdLoginBindEmailViewController


- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.presenter = [[MSThirdLoginBindEmailPresenter alloc]initWithView:self];
        
        self.scrollContainer = [HGScrollView new];
        self.mailInputViewContainer = [HGView new];
        self.validCodeViewContainer = [HGView new];
        
        self.titleLabel = [HGLabel new];
        self.emailLabel = [HGLabel new];
        
        self.regionInputView = [OEMMSInputView new];
        self.regionButton = [HGButton new];
        
        self.emailInputView = [OEMMSInputView new];
        self.codeButton = [HGButton new];

        
     //   self.confirmationCodeLabel = [HGLabel new];
        self.confirmCodeTitle = [HGLabel new];
        self.confirmCodeDesLabel = [HGLabel new];
        self.confirmationCodeInputView = [MSValidCodeView new];
        self.retryButton = [HGButton new];
        self.codeNotRecvBtn = [HGButton new];
    }
    return self;
}

- (void)configOEMTheme{
    
    self.regionInputView.layer.borderColor = [UIColor clearColor].CGColor;
    self.regionInputView.layer.borderWidth = 0.0;
    [self.regionInputView addThemeBottomSeplineWithOffset:0];
    
    self.emailInputView.layer.borderColor = [UIColor clearColor].CGColor;
    self.emailInputView.layer.borderWidth = 0.0;
    [self.emailInputView addThemeBottomSeplineWithOffset:0];
   if ([self.emailInputView.textField isKindOfClass:[UITextField class]]) {
       self.emailInputView.textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
       if ([OEMCustomize getUIntValueWithKey:@"SupportedAccount"] == 0) {
           self.emailInputView.textField.placeholder = MSResourceString(@"login_page_thirdpart_enter_mail_email_account_only");
       }else{
           self.emailInputView.textField.placeholder = MSResourceString(@"login_page_thirdpart_enter_mail");
       }
       
    }
    

    [self.view specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIView_Background) : CommonDarkThemeForegroudColor,
    } lightModeProperties:@{
        @(OEMThemesTag_UIView_Background) : CommonLightThemeForegroudColor,
    }];
    
    
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    
    [self.titleLabel configure90TranslucentTrait];
    [self.emailLabel configure40TranslucentTrait];
    
    [self.codeButton configureThemeTag:OEMThemesTag_UIView_Main_Color];
    [self.codeButton configureThemeTag:OEMThemesTag_UIButton_Background];
    [self.codeButton configureThemeTag:OEMThemesTag_UIButton_AttributedTraitColor];
    
    [self.regionInputView.textField configureThemeTag:OEMThemesTag_UITextField_Textcolor];
    [self.emailInputView.textField configureThemeTag:OEMThemesTag_UITextField_Textcolor];
    [self.backButton configureThemeTag:OEMThemesTag_UIButton_TitleThemeColor];
    
    
    [self.confirmCodeTitle  configure90TranslucentTrait];
    [self.confirmCodeDesLabel configure40TranslucentTrait];
    [self.retryButton configureThemeTag:OEMThemesTag_UIButton_TitleThemeColor];
    
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        if (OEMThemeIsDarkMode){
            weakSelf.navigationController.navigationBar.tintColor = RGBA_HEX(0x1A1A1A, 1.0);
        }else{
            weakSelf.navigationController.navigationBar.tintColor = RGBA_HEX(0x1A1A1A, 1.0);
        }
        [weakSelf setNavButton];
    } callImmidiately:YES];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    self.hiddenKeyboardWhenTap = YES;

    [self.view addSubview:self.scrollContainer];
    [self.scrollContainer mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.scrollContainer.superview);
    }];
    self.scrollContainer.pagingEnabled = YES;
    self.scrollContainer.scrollEnabled = NO;
    self.scrollContainer.alwaysBounceVertical = NO;
    [self.scrollContainer addSubview:self.mailInputViewContainer];
    [self.scrollContainer addSubview:self.validCodeViewContainer];
    self.scrollContainer.showsVerticalScrollIndicator = NO;
    self.scrollContainer.showsHorizontalScrollIndicator = NO;
    self.scrollContainer.userInteractionEnabled = YES;
    
    [self.mailInputViewContainer mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.top.bottom.equalTo(self.mailInputViewContainer.superview);
        make.width.mas_equalTo(BHScreenWidth);
        make.height.equalTo(self.view);
    }];
    
    [self.validCodeViewContainer mas_makeConstraints:^(MASConstraintMaker *make) {
        make.trailing.top.bottom.equalTo(self.mailInputViewContainer.superview);
        make.width.mas_equalTo(BHScreenWidth);
        make.height.equalTo(self.mailInputViewContainer);
        make.leading.equalTo(self.mailInputViewContainer.mas_trailing);
    }];
    
    
    if ([OEMCustomize getUIntValueWithKey:@"SupportedAccount"] == 0) {
        self.titleLabel.text = MSResourceString(@"login_page_thirdpart_login_binding_email_account_only");
    }else{
        self.titleLabel.text = MSResourceString(@"login_page_thirdpart_login_binding");
    }
    self.titleLabel.font = [UIFont systemFontOfSize:22 weight:UIFontWeightSemibold];
    self.titleLabel.textColor = RGB_HEX(0x000000);
    [self.mailInputViewContainer addSubview:self.titleLabel];
    if ([OEMCustomize getUIntValueWithKey:@"SupportedAccount"] == 0) {
        self.emailLabel.text = MSResourceString(@"register_page_enter_mail_placeholder");
    }else{
        self.emailLabel.text = MSResourceString(@"register_page_enter_mail_placeholder_email_account_only");
    }
    
    self.emailLabel.font = [UIFont systemFontOfSize:14];
    self.emailLabel.textColor = RGB_HEX(0x999999);
  //  [self.mailInputViewContainer addSubview:self.emailLabel];
    
    
    [self.regionInputView setRightImage:MSResourceImage(@"ic_16_arrow")];
    self.regionInputView.font = [UIFont systemFontOfSize:16 weight:UIFontWeightSemibold];
    [self.mailInputViewContainer addSubview:self.regionInputView];
    
    self.regionButton.backgroundColor = [UIColor clearColor];
    [self.regionButton addTarget:self action:@selector(rightBarButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.regionInputView addSubview:self.regionButton];
    
    
    [self.emailInputView setRightImage:MSResourceImage(@"ic_Input_close")];
    [self.emailInputView setFont:[UIFont systemFontOfSize:16 weight:UIFontWeightSemibold]];
    [self.emailInputView setTextColor:RGB_HEX(0x000000)];
    @weakify(self)
    self.emailInputView.clickRightButtonBlock = ^{
        @strongify(self)
        self.emailInputView.text = nil;
        self.presenter.account = @"";
    };
    self.emailInputView.delegate = self;
    self.emailInputView.keyboardType = UIKeyboardTypeEmailAddress;
    [self.emailInputView setRightButtonHidden:YES];
    [self.emailInputView setTextFieldTag:textFieldTag];
    [self.mailInputViewContainer addSubview:self.emailInputView];
    
    self.codeButton.backgroundColor = RGBA_HEX(0xEC1C24 ,0.3);
    self.codeButton.enabled = NO;
    self.codeButton.layer.cornerRadius = 22;
    [self.codeButton setTitle:MSResourceString(@"register_page_button_get_verification_code") forState:UIControlStateNormal];
    [self.codeButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
    self.codeButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    [self.codeButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.mailInputViewContainer addSubview:self.codeButton];
    
//    self.confirmationCodeLabel.text = MSResourceString(@"register_page_enter_verivication_code");
//    self.confirmationCodeLabel.font = [UIFont systemFontOfSize:14];
//    self.confirmationCodeLabel.textColor = RGB_HEX(0x999999);
//    self.confirmationCodeLabel.hidden = YES;
//    [self.mailInputViewContainer addSubview:self.confirmationCodeLabel];

//    self.confirmationCodeInputView.delegate = self;
//    self.confirmationCodeInputView.hidden = YES;
//    [self.confirmationCodeInputView setFont:[UIFont systemFontOfSize:16 weight:UIFontWeightSemibold]];
//    [self.confirmationCodeInputView setTextColor:RGB_HEX(0x000000)];
//    self.confirmationCodeInputView.keyboardType = UIKeyboardTypeNumberPad;
//    [self.confirmationCodeInputView setRightTitle:MSResourceString(@"register_page_resend_verification_code") font:[UIFont systemFontOfSize:14 weight:UIFontWeightMedium]];
//    self.confirmationCodeInputView.clickRightButtonBlock = ^{
//        @strongify(self)
//        [self.presenter getVerifyCode];
//    };
 //   [self.mailInputViewContainer addSubview:self.confirmationCodeInputView];
    
    self.nextButton.backgroundColor = RGBA_HEX(0xEC1C24 ,0.3);
    self.nextButton.enabled = NO;
    self.nextButton.layer.cornerRadius = 22;
    [self.nextButton setTitle:MSResourceString(@"login_page_thirdpart_login_next") forState:UIControlStateNormal];
    [self.nextButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
    self.nextButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    [self.nextButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.nextButton];
    self.nextButton.hidden = YES;
    
    [self setUPCodeValidateView];
    [self makeConstraints];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillEnterForeground:) name:UIApplicationWillEnterForegroundNotification object:nil];
    [self configOEMTheme];
}


- (void)setUPCodeValidateView{
    self.confirmCodeTitle.text = MSResourceString(@"register_page_enter_verivication_code");
    self.confirmCodeTitle.font = [UIFont systemFontOfSize:22 weight:UIFontWeightBold];
    self.confirmCodeTitle.textColor = RGB_HEX(0x999999);
    [self.validCodeViewContainer addSubview:self.confirmCodeTitle];
    
    self.confirmCodeDesLabel.text = MSResourceString(@"register_page_did_sent_code");
    self.confirmCodeDesLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
    self.confirmCodeDesLabel.textColor = RGB_HEX(0x999999);
    self.confirmCodeDesLabel.numberOfLines = 0;
    [self.confirmCodeDesLabel sizeToFit];
    [self.validCodeViewContainer addSubview:self.confirmCodeDesLabel];

    WEAKSELF
    self.confirmationCodeInputView.lastCodeDidInput = ^{
        if ([weakSelf.confirmationCodeInputView.text length] == 6) {
            [weakSelf.presenter setVerifyCode:weakSelf.confirmationCodeInputView.text];
        }
    
       [weakSelf.presenter verifyCodeAuth];
       // [weakSelf.presenter getVerifyCode];
    };
    
    [self.validCodeViewContainer addSubview:self.confirmationCodeInputView];
    
    self.retryButton.enabled = YES;
    self.retryButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [self.retryButton setTitle:MSResourceString(@"register_page_resend_verification_code") forState:UIControlStateNormal];
    self.retryButton.titleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
    [self.retryButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.validCodeViewContainer addSubview:self.retryButton];
    
    NSString *forgetPWDString = [NSString stringWithFormat:@"%@?",MSResourceString(@"register_page_code_not_recvive")];
    NSAttributedString *forgetpasswordButtonAttrText = [UIView attributedText:forgetPWDString color:RGB_HEX(0x999999) arrow:nil isSmallScreen:NO];
    [self.codeNotRecvBtn setAttributedTitle:forgetpasswordButtonAttrText forState:UIControlStateNormal];
    [self.codeNotRecvBtn addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.validCodeViewContainer addSubview:self.codeNotRecvBtn];
}




-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSString *countryName = HGCurrentCountry.name;
    self.regionInputView.text = countryName;
    [self setNavButton];
}

- (void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    if (self.scrollContainer.contentSize.height != 0) {
        self.scrollContainer.contentSize = CGSizeMake(BHScreenWidth * 2, 0);
    }
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)setNavButton{
    if (OEMThemeIsDarkMode) {
        UIImage * img =  MSResourceImage(@"ic_nav_back_dm");
        NSString * title = self.isInputValidCodeStage ? @"" :HGCurrentCountry.name;
        [self createLeftButtonWithImage:img];
      //  [self createRightButtonWithTitle:title font:[UIFont boldSystemFontOfSize:14] color:CommonThemeColor];
    }else{
        UIImage * img = MSResourceImage(@"ic_nav_back_lg"); 
        NSString * title = self.isInputValidCodeStage ? @"" :HGCurrentCountry.name;
        [self createLeftButtonWithImage:img];
       // [self createRightButtonWithTitle:title font:[UIFont boldSystemFontOfSize:14] color:CommonThemeColor];
    }
}

- (void)makeConstraints{
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.titleLabel.superview).offset(30);
        make.trailing.equalTo(self.titleLabel.superview).offset(-30);
        make.top.equalTo(self.titleLabel.superview).offset(40);
    }];
    
//    [self.emailLabel mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.leading.equalTo(self.titleLabel.mas_leading);
//        make.top.equalTo(self.titleLabel.mas_bottom).offset(12);
//    }];
    
    [self.regionInputView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleLabel.mas_bottom).offset(30);
        make.leading.equalTo(self.titleLabel.mas_leading);
        make.trailing.equalTo(self.titleLabel.mas_trailing);
        make.height.mas_equalTo(48);
    }];
    
    [self.regionButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.top.bottom.equalTo(self.regionInputView);
    }];
    
    
    [self.emailInputView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.regionInputView.mas_bottom).offset(20);
        make.leading.equalTo(self.titleLabel.mas_leading);
        make.trailing.equalTo(self.titleLabel.mas_trailing);
        make.height.mas_equalTo(48);
    }];
    
    [self.codeButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.titleLabel.mas_leading);
        make.trailing.equalTo(self.titleLabel.mas_trailing);
        make.top.equalTo(self.emailInputView.mas_bottom).offset(60);
        make.height.mas_equalTo(44);
    }];

    
    //验证码区域布局
    [self.confirmCodeTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.confirmCodeTitle.superview).offset(30);
        make.leading.equalTo(self.confirmCodeTitle.superview).offset(30);
    }];
    
    [self.confirmCodeDesLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.confirmCodeTitle.mas_leading);
        make.trailing.equalTo(self.confirmCodeTitle.superview).offset(-30);
        make.top.equalTo(self.confirmCodeTitle.mas_bottom).offset(5);
    }];

    [self.confirmationCodeInputView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.confirmationCodeInputView.superview).offset(30);
        make.trailing.equalTo(self.confirmationCodeInputView.superview).offset(-30);
        make.top.equalTo(self.confirmCodeDesLabel.mas_bottom).offset(43);
        make.height.mas_equalTo(40);
    }];

    [self.retryButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.retryButton.superview).offset(30);
        make.top.equalTo(self.confirmationCodeInputView.mas_bottom).offset(20);
        make.size.mas_equalTo(CGSizeMake(120, 30));
    }];
    
    [self.codeNotRecvBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.confirmationCodeInputView.mas_bottom).offset(158);
        make.centerX.equalTo(self.codeNotRecvBtn.superview);
    }];
    
}

#pragma mark - click event

- (void)clickButton:(UIButton*)sender
{
    if (sender == self.codeButton || sender == self.retryButton) {
        //发送验证码，开始倒计时
        self.presenter.channel = self.thirdType;
        [self.presenter getVerifyCode];
    }else if (sender == self.codeNotRecvBtn){
        CodeNotRecvViewController * vc = [[CodeNotRecvViewController alloc] init];
        [self.navigationController pushViewController:vc animated:true];
    }
}

- (void)leftBarButtonClick:(UIButton *)button{
    if (self.isInputValidCodeStage) {
        [self shouldMoveToValidationCodeInputState:NO];
        [self.confirmationCodeInputView cleanInputWithFocusFirstInput:NO];
        return;
    }
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)rightBarButtonClick:(UIButton *)button
{
    MSCountrySelectViewController *countrySelectViewController = [MSCountrySelectViewController new];
    countrySelectViewController.enterType = MSCountrySelectEnterType_Right;
    [self.navigationController pushViewController:countrySelectViewController animated:YES];
}


- (void)applicationWillEnterForeground:(NSNotification *)notification {
    [self.presenter applicationWillEnterForeground:notification];
}

#pragma mark -MSLoginInputViewDelegate

- (void)inputView:(MSInputView *)inputView didChangeText:(NSString *)text
{
    text = [text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if (inputView == self.emailInputView) {
        self.presenter.account = text;
        self.account = text;
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    if (textField.tag == textFieldTag) {
        [self.emailInputView setRightButtonHidden:YES];
    }
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    if (textField.tag == textFieldTag && ![self.emailInputView.text isEqualToString:@""]) {
        [self.emailInputView setRightButtonHidden:NO];
    }
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {

    if ([[string disable_emoji] isEqualToString:@"&&&&****"] || [[string disable_emoji] isEqualToString:@"&&&&****&&&&****"]) {
        [textField becomeFirstResponder];
        return NO;
    }
    
    //限制空格
    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    newString = [newString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if ([newString isEqualToString:textField.text] && range.length == 0) {
        return NO;
    }
    
    NSCharacterSet *cs;
    cs = [[NSCharacterSet characterSetWithCharactersInString:kAlphaNum] invertedSet];
    NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""]; //按cs分离出数组,数组按@""分离出字符串
    BOOL canChange = [string isEqualToString:filtered];
    if (!canChange) {
        return NO;
    }
    
    return YES;
}


#pragma mark - MSRegistViewProtocol

- (void)presenterDidEnableGetVerifyCode:(MSThirdLoginBindEmailPresenter *)presenter
{
    if (presenter.enableGetVerifyCode) {
        self.codeButton.backgroundColor = RGBA_HEX(0xEC1C24 ,1);
        self.codeButton.enabled = YES;
        [self.emailInputView setRightButtonHidden:NO];
        
//        self.codeButton.layer.shadowColor = RGBA_HEX(0xEC1C24, 0.25f).CGColor;
//        self.codeButton.layer.shadowOffset = CGSizeMake(0,2);
//        self.codeButton.layer.shadowOpacity = 1;
//        self.codeButton.layer.shadowRadius = 10;
//        self.codeButton.layer.shadowPath = [UIBezierPath bezierPathWithRect:self.codeButton.bounds].CGPath;
    } else {
        self.codeButton.backgroundColor = RGBA_HEX(0xEC1C24 ,0.3);
        self.codeButton.enabled = NO;
        [self.emailInputView setRightButtonHidden:YES];
        self.codeButton.layer.shadowOpacity = 0;
    }
}

- (void)presenter:(MSThirdLoginBindEmailPresenter *)presenter updateGetVerifyCodeCountDown:(NSUInteger)count
{
    if (count == 0) {
        NSString * timeDes = [NSString stringWithFormat:@"%@", MSResourceString(@"register_page_resend_verification_code")];
        [self.retryButton setTitle:timeDes forState:UIControlStateNormal];
        self.retryButton.enabled = YES;
        
    }else{
        NSString * timeDes = [NSString stringWithFormat:@"%@(%lus)", MSResourceString(@"register_page_resend_verification_code"), (unsigned long)count];
        [self.retryButton setTitle:timeDes forState:UIControlStateNormal];
        self.retryButton.enabled = NO;
    }
}

- (void)presenterDidEnableVerifyCodeAuth:(MSThirdLoginBindEmailPresenter *)presenter
{
    
    self.retryButton.enabled = presenter.enableVerifyCodeAuth;
    
//    if (presenter.enableVerifyCodeAuth) {
//        self.nextButton.backgroundColor = RGBA_HEX(0xEC1C24 ,1);
//        self.nextButton.enabled = YES;
//        self.nextButton.layer.shadowColor = RGBA_HEX(0xEC1C24, 0.25f).CGColor;
//        self.nextButton.layer.shadowOffset = CGSizeMake(0,2);
//        self.nextButton.layer.shadowOpacity = 1;
//        self.nextButton.layer.shadowRadius = 10;
//        self.nextButton.layer.shadowPath = [UIBezierPath bezierPathWithRect:self.nextButton.bounds].CGPath;
//    } else {
//        self.nextButton.backgroundColor = RGBA_HEX(0xEC1C24 ,0.3);
//        self.nextButton.enabled = NO;
//        self.nextButton.layer.shadowOpacity = 0;
//    }
}

- (void)presenter:(MSThirdLoginBindEmailPresenter *)presenter getVerifyCodeCompletion:(NSError *)error
{
    if (error) {
        if (error.code == 14003) {
            [self shouldMoveToValidationCodeInputState:YES];
            [self.confirmationCodeInputView becomResponder];
            [self.confirmationCodeInputView cleanInputWithFocusFirstInput:YES];
        }else{
            [self toastText:error.localizedDescription];
            [self.confirmationCodeInputView resignFirstResponder];
        }
       
        return;
    } else {
        [self shouldMoveToValidationCodeInputState:YES];
        [self.confirmationCodeInputView becomResponder];
    }
}

- (void)presenter:(MSThirdLoginBindEmailPresenter *)presenter verifyCodeAuthCompletion:(NSError *)error{
    if (error) {
        if (error.code == verifyCodeMaxErrorCount) {
            OEMTitleAndOneButtonAlertView *alertView = [[OEMTitleAndOneButtonAlertView alloc]initWithTitle:MSResourceString(@"register_page_verifycode_maxcount_error") confirmButtonName:MSResourceString(@"register_page_button_confirm")];
            [alertView showWithSuperview:self.view.window];
            @weakify(self)
            alertView.clickConfirmBlock = ^{
                @strongify(self)
                [self showOrHiddenNextView:YES];
               // self.confirmationCodeInputView.text = nil;
                self.presenter.verifyCode = nil;
            };

        } else {
            [self toastText:error.localizedDescription];
            [self.confirmationCodeInputView cleanInputWithFocusFirstInput:NO];
        }
    }else{
        
        
        if (self.presenter.isAccountExist) {
            [self.presenter thirdLoginWithToken:self.taccessToken
                                         userId:self.userId
                                        channel:self.thirdType
                                       verifyId:self.presenter.verifyCode
                                        account:self.presenter.account
                                    accountInfo:self.accountInfo];
        }else{
            
            NSLog(@"验证正确------------------------------%@", self.presenter.verifyCode);
            MSThirdLoginSetPasswordViewController *setPasswordViewController = [MSThirdLoginSetPasswordViewController new];
            setPasswordViewController.isDevice = self.isDevice;
            setPasswordViewController.isLoginExpired = self.isLoginExpired;
            setPasswordViewController.userId = self.userId;
            setPasswordViewController.thirdType = self.thirdType;
            setPasswordViewController.taccessToken = self.taccessToken;
            setPasswordViewController.verifyCode = self.presenter.verifyCode;
            setPasswordViewController.account = self.presenter.account;
            setPasswordViewController.accountInfo = self.accountInfo;
            [self.confirmationCodeInputView cleanInputWithFocusFirstInput:NO];
            [self.navigationController pushViewController:setPasswordViewController animated:YES];
            
        }
        
    }
}

-(void)presenter:(MSThirdLoginBindEmailPresenter *)presenter thirdLoginBindCompletion:(MSBusinessError *)error emailExist:(BOOL)emailExist{
    if (emailExist) {
        if (error) {
            [self toastText:error.localizedDescription];
        }
    }else{
        MSThirdLoginSetPasswordViewController* setPasswordViewController = [MSThirdLoginSetPasswordViewController new];
        setPasswordViewController.isDevice = self.isDevice;
        setPasswordViewController.isLoginExpired = self.isLoginExpired;
        setPasswordViewController.userId = self.userId;
        setPasswordViewController.thirdType = self.thirdType;
        setPasswordViewController.taccessToken = self.taccessToken;
        setPasswordViewController.email = self.presenter.email;
        setPasswordViewController.accountInfo = self.accountInfo;
        [self.navigationController pushViewController:setPasswordViewController animated:YES];
    }
    
}


-(void)presenter:(MSThirdLoginBindEmailPresenter *)presenter thirdLoginCompletion:(MSBusinessError *)error{
    if (error) {
        if (error.code == 999999 || error.code == -1009) {
            [self toastText:error.localizedDescription];
            return;
        }
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self toastText:error.localizedDescription];
        });
        
        [self popToLoginViewController];
       
    } else {
        [MSLoginUtils postLoginInNotification];

        CATransition* transition = [CATransition animation];
        transition.duration = 0.25f;
        transition.type = kCATransitionReveal;
        transition.subtype = kCATransitionFromBottom;
        
        if (self.isDevice) {
            NSMutableArray* controllerArray = [self.navigationController.viewControllers mutableCopy];
            UIViewController* viewCtl = [OEMRouter objectForURL:MSRouterDeviceIndex];
            if (viewCtl && controllerArray.count > 1) {
                [controllerArray insertObject:viewCtl atIndex:1];
                viewCtl.hidesBottomBarWhenPushed = YES;
                self.navigationController.viewControllers = [controllerArray copy];
                
                [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
                [self.navigationController popToViewController:viewCtl animated:NO];
            }
        } else if (self.isLoginExpired) {
            for (UIViewController *viewController in self.navigationController.viewControllers) {
                if ([NSStringFromClass(viewController.class) isEqualToString:@"MSLoginMainViewController"]) {
                    NSInteger index = [self.navigationController.viewControllers indexOfObject:viewController];
                    UIViewController *popViewController = [self.navigationController.viewControllers objectAtIndex:index-1];
                    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
                    [self.navigationController popToViewController:popViewController animated:NO];
                    break;
                }
            }
            
        } else {
            [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
            [self.navigationController popToRootViewControllerAnimated:NO];
        }
        
    }
}


- (void)shouldMoveToValidationCodeInputState:(BOOL)inputValidCodeStage{
    self.isInputValidCodeStage = inputValidCodeStage;
    [self.scrollContainer setContentOffset:CGPointMake(inputValidCodeStage ? SCREEN_WIDTH : 0, 0) animated:YES];
    
    if (inputValidCodeStage) {
        BOOL isEmail = [MSLoginUtils isValidEmail:self.account]; //是否邮箱
        if (isEmail) {
            self.confirmCodeDesLabel.text = [NSString stringWithFormat:@"%@ %@", MSResourceString(@"register_page_did_sent_code"), self.account];
        }else{
            self.confirmCodeDesLabel.text = [NSString stringWithFormat:@"%@ +00%@ %@", MSResourceString(@"register_page_did_sent_code"),HGCurrentCountry.phoneCode,self.account];
        }
    }
    
    [self setNavButton];
}

//隐藏或显示下一步相关的视图
- (void)showOrHiddenNextView:(BOOL)hidden {
    if (hidden) {
        self.codeButton.hidden = NO;
        self.confirmCodeTitle.hidden = NO;
        self.confirmationCodeInputView.hidden = NO;
    } else {
        self.codeButton.hidden = NO;
        self.confirmCodeTitle.hidden = NO;
        self.confirmationCodeInputView.hidden = NO;
    }
}


- (void)popToLoginViewController{
    NSMutableArray *mvcvs = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
    __block UIViewController *tempViewController = nil;
    [mvcvs enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        UIViewController *viewController =   (UIViewController *)obj;
        if ([viewController isKindOfClass:NSClassFromString(@"MSLoginMainViewController")]) {
            tempViewController = viewController;
            *stop = YES;
        }
    }];
    if (tempViewController){
        [self.navigationController popToViewController:tempViewController animated:YES];
    }
}

@end
