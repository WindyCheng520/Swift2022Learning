//
//  MSSetPasswordViewController.h
//  MSLogin
//
//  Created by 及时行乐 on 2020/6/21.
//

#import <MSBusiness/MVPViewController.h>
#import "MSSetPasswordPresenter.h"


@interface MSSetPasswordViewController : MVPViewController<MSSetPasswordPresenter *> <MSSetPasswordViewProtocol>

@property (nonatomic, assign) BOOL isDevice;          //如果是点击添加设备进来，登录成功要跳转配网的指南页面
@property (nonatomic, assign) BOOL isLoginExpired;   //如果是登录过期进来，登录成功返回之前的页面

@property (nonatomic, copy) NSString *account;        //账号

@property (nonatomic, copy) NSString *verifyCode;


@end

