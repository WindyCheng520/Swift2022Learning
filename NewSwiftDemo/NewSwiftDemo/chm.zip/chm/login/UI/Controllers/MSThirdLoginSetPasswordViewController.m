//
//  MSThirdLoginSetPasswordViewController.m
//  MSLogin
//
//  Created by 及时行乐 on 2020/7/16.
//

#import "MSThirdLoginSetPasswordViewController.h"
#import "MSCountrySelectViewController.h"
#import "MSLoginBundle.h"
#import <OEMFoundation/HGInternationalization.h>
#import <MSBusiness/MSRouterUrl.h>
#import "MSLoginMainViewController.h"
#import "MSLoginUtils.h"
#import <OEMTheme/MSInputView_Private.h>

static NSInteger const MSTextFieldTag = 1234;

#define kAlphaNum @"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"


@interface MSThirdLoginSetPasswordViewController ()<MSInputViewDelegate>

@property (nonatomic, strong) HGLabel *titleLabel;  //标题

@property (nonatomic, strong) MSInputView *passwordInputView; //密码输入框

@property (nonatomic, strong) MSInputView *confirmInputView;
@property (nonatomic, strong) HGButton *submitButton;

@property (nonatomic, strong) HGLabel *ruleLabel;       //密码规则label

@property (nonatomic, assign) BOOL isConfirmEnter;   //记录确认框有没有输入过

@end

@implementation MSThirdLoginSetPasswordViewController

-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        self.presenter = [[MSThirdLoginSetPasswordPresenter alloc]initWithView:self];
        
        self.titleLabel = [HGLabel new];
        self.passwordInputView = [MSInputView new];
        self.confirmInputView = [MSInputView new];
        self.submitButton = [HGButton new];
        self.ruleLabel = [HGLabel new];
    }
    return self;
}

- (void)configureOEMTheme{
    
    self.passwordInputView.layer.borderColor = [UIColor clearColor].CGColor;
    [self.passwordInputView addThemeBottomSeplineWithOffset:23];
    self.passwordInputView.layer.borderWidth = 0.0;
    
    self.confirmInputView.layer.borderColor = [UIColor clearColor].CGColor;
    self.confirmInputView.layer.borderWidth = 0.0;
    [self.confirmInputView addThemeBottomSeplineWithOffset:23];
    
    [self.view configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.view specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIView_Foreground) : CommonDarkThemeForegroudColor,
    } lightModeProperties:@{}];
    
    [self.submitButton configureThemeTag:OEMThemesTag_UIView_Main_Color];
    [self.submitButton configureThemeTag:OEMThemesTag_UIButton_Background];
    [self.submitButton configureThemeTag:OEMThemesTag_UIButton_AttributedTraitColor];
    [self.titleLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];

    [self.ruleLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    [self.passwordInputView.textField configureThemeTag:OEMThemesTag_UITextField_Textcolor];
    [self.confirmInputView.textField configureThemeTag:OEMThemesTag_UITextField_Textcolor];
    
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        [weakSelf setNavButton];
    } callImmidiately:YES];
}

- (void)setNavButton{
    if (OEMThemeIsDarkMode) {
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_dm")];
    }else{
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_lg")];
    }
}

- (void)viewDidLoad{
    [super viewDidLoad];
    self.hiddenKeyboardWhenTap = YES;
    
    self.titleLabel.text = MSResourceString(@"set_password_page_set_password");
    self.titleLabel.font = [UIFont boldSystemFontOfSize:22];
    self.titleLabel.textColor = RGB_HEX(0x000000);
    [self.view addSubview:self.titleLabel];
    
    
    self.passwordInputView.placeholder = MSResourceString(@"register_page_enter_phrase_placeholder");
    [self.passwordInputView setRightImage:MSResourceImage(@"ic_input_view")];
    [self.passwordInputView setFont:[UIFont systemFontOfSize:16 weight:UIFontWeightSemibold]];
    [self.passwordInputView setTextColor:RGB_HEX(0x000000)];
    self.passwordInputView.secureTextEntry = YES;
    self.passwordInputView.keyboardType = UIKeyboardTypeASCIICapable;
    @weakify(self)
    self.passwordInputView.clickRightButtonBlock = ^{
        @strongify(self)
        if (self.passwordInputView.isSecureTextEntry) {
            self.passwordInputView.secureTextEntry = NO;
            [self.passwordInputView setRightImage:MSResourceImage(@"ic_input_view_s")];
        } else {
            self.passwordInputView.secureTextEntry = YES;
            [self.passwordInputView setRightImage:MSResourceImage(@"ic_input_view")];
        }
    };
    self.passwordInputView.delegate = self;
    [self.view addSubview:self.passwordInputView];
    [self.passwordInputView setTextFieldTag:MSTextFieldTag+1];
    

    self.confirmInputView.placeholder = MSResourceString(@"set_password_page_reenter_password");
    [self.confirmInputView setRightImage:MSResourceImage(@"ic_input_view")];
    [self.confirmInputView setFont:[UIFont systemFontOfSize:16 weight:UIFontWeightSemibold]];
    [self.confirmInputView setTextColor:RGB_HEX(0x000000)];
    self.confirmInputView.secureTextEntry = YES;
    self.confirmInputView.keyboardType = UIKeyboardTypeASCIICapable;
    self.confirmInputView.clickRightButtonBlock = ^{
        @strongify(self)
       if (self.confirmInputView.isSecureTextEntry) {
           self.confirmInputView.secureTextEntry = NO;
           [self.confirmInputView setRightImage:MSResourceImage(@"ic_input_view_s")];
       } else {
           self.confirmInputView.secureTextEntry = YES;
           [self.confirmInputView setRightImage:MSResourceImage(@"ic_input_view")];
       }
    };
    self.confirmInputView.delegate = self;
    [self.view addSubview:self.confirmInputView];
    [self.confirmInputView setTextFieldTag:MSTextFieldTag+2];
    
    self.submitButton.backgroundColor = RGBA_HEX(0xEC1C24, 0.3);
    self.submitButton.enabled = NO;
    self.submitButton.layer.cornerRadius = 22;
    [self.submitButton setTitle:MSResourceString(@"set_password_page_submit") forState:UIControlStateNormal];
    [self.submitButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
    self.submitButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    [self.submitButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.submitButton];
    
    
    self.ruleLabel.text = MSResourceString(@"set_password_page_password_num_alphabet_require");
    self.ruleLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightRegular];
    self.ruleLabel.textColor = RGB_HEX(0x999999);
    self.ruleLabel.numberOfLines = 0;
    [self.ruleLabel sizeToFit];
    [self.view addSubview:self.ruleLabel];
    
    [self makeConstraints];
    [self configureOEMTheme];
    
    self.confirmInputView.hidden = YES;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (void)makeConstraints{
    CGFloat inputOffset = 15;
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.view).offset(30);
        make.trailing.equalTo(self.view).offset(-30);
        make.top.mas_equalTo(30);
    }];

    
    [self.ruleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.titleLabel.mas_leading);
        make.trailing.equalTo(self.titleLabel.mas_trailing);
        make.top.equalTo(self.titleLabel.mas_bottom).offset(3);
    }];
    
    [self.passwordInputView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.titleLabel.mas_leading).offset(-inputOffset);
        make.trailing.equalTo(self.titleLabel.mas_trailing);
        make.top.equalTo(self.ruleLabel.mas_bottom).offset(30);
        make.height.mas_equalTo(48);
    }];


    [self.submitButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.titleLabel.mas_leading);
        make.trailing.equalTo(self.titleLabel.mas_trailing);
        make.top.equalTo(self.passwordInputView.mas_bottom).offset(91);
        make.height.mas_equalTo(44);
    }];
}


//展示错误提示
- (void)showToastifErrorExist {
    self.ruleLabel.hidden = NO;
    if (!self.submitButton.enabled) return;
    if (!self.presenter.isLengthRight) {
        [self toastText:MSResourceString(@"set_password_page_length_tip")];
    }else if(!self.presenter.isRuleRight){
        [self toastText:MSResourceString(@"set_password_page_password_num_alphabet_require")];
    }else if (!self.presenter.isConsistent){
       // [self toastText:MSResourceString(@"set_password_page_inconsistent")];
    }
    
    
}

- (void)showConsistentLabel {

}

- (void)hiddenConsistentLabel {

}

#pragma mark - click event
- (void)rightBarButtonClick:(UIButton *)button {
    MSCountrySelectViewController *countrySelectViewController = [MSCountrySelectViewController new];
    countrySelectViewController.enterType = MSCountrySelectEnterType_Right;
    [self.navigationController pushViewController:countrySelectViewController animated:YES];
}

- (void)clickButton:(UIButton*)sender {
    self.presenter.isConsistent = YES;
    [self updateConfirmInputViewUI];
    [self addAnimationForTips];
    [self showToastifErrorExist];
    if (!self.presenter.isRuleRight || !self.presenter.isLengthRight) {
        [self.passwordInputView endEditing:YES];
    } else if (!self.presenter.isConsistent) {
        [self.passwordInputView endEditing:YES];
    } else {
        NSLog(@"验证码---------%@", self.verifyCode);
        [self.presenter thirdLoginWithToken:self.taccessToken
                                     userId:self.userId
                                    channel:self.thirdType
                                   password:self.confirmInputView.text
                                   verifyId:self.verifyCode
                                    account:self.account
                                accountInfo:self.accountInfo];
    }
}

- (void)addAnimationForTips {

}

#pragma mark -MSInputViewDelegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    if (textField.tag == MSTextFieldTag+1) {
        self.presenter.isPasswordInputEditing = YES;
    } else {
        self.presenter.isConfirmInputEditing = YES;
    }
    
    return YES;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField {
    if (textField.tag == MSTextFieldTag+1) {
        self.presenter.isPasswordInputEditing = NO;
    } else {
        self.presenter.isConfirmInputEditing = NO;
    }
    
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    //限制长度
    NSString* newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    if (newString.length > 20) {
        return NO;
    }
    //限制空格
    newString = [newString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if ([newString isEqualToString:textField.text]) {
        return NO;
    }
    

    
    NSCharacterSet *cs;
    cs = [[NSCharacterSet characterSetWithCharactersInString:kAlphaNum] invertedSet];
    NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""]; //按cs分离出数组,数组按@""分离出字符串
    BOOL canChange = [string isEqualToString:filtered];
    if (!canChange) {
        return NO;
    }
    
    if(textField.isSecureTextEntry){//屏蔽密码密文输入状态状态重新编辑清除原有内容
        textField.text = newString;
        self.presenter.password = newString;
        return NO;
    }
    
    if (textField.tag == MSTextFieldTag + 1) {
        self.presenter.password = newString;
    }else{
        self.presenter.confirmPassword = newString;
    }
    
    return YES;
}

//解决密文状态下，切换输入框之后，点键盘上删除字符按键时，上面方法返回有问题，range
- (void)inputView:(MSInputView *)inputView didChangeText:(NSString *)text {
    if (inputView == self.passwordInputView) {
        if (![text isEqualToString:self.presenter.password]) {
            self.presenter.password = text;
        }
        [self.passwordInputView setBorderColor:RGB_HEX(0xCCCCCC)];
    }else{
        if (![text isEqualToString:self.presenter.confirmPassword]) {
            self.presenter.confirmPassword = text;
        }
        [self.confirmInputView setBorderColor:RGB_HEX(0xCCCCCC)];
    }
}

#pragma mark - MSSetPasswordViewProtocol
- (void)presenter:(MSThirdLoginSetPasswordPresenter *)presenter didEnableRegiste:(BOOL)enable {
    if (enable) {
        self.submitButton.backgroundColor = RGBA_HEX(0xEC1C24 ,1);
        self.submitButton.enabled = YES;
    } else{
        self.submitButton.backgroundColor = RGBA_HEX(0xEC1C24 ,0.3);
        self.submitButton.enabled = NO;
    }
}

- (void)presenter:(MSThirdLoginSetPasswordPresenter *)presenter didPasswordInputEditingChanged:(BOOL)isPasswordInputEditing {
    if (isPasswordInputEditing) {
        //[self showToastifErrorExist];
        self.isConfirmEnter = YES; //已经有输入
    } else {
       // [self showToastifErrorExist];
        [self updateConfirmInputViewUI];
    }
}

- (void)presenter:(MSThirdLoginSetPasswordPresenter *)presenter didConfirmInputEditingChanged:(BOOL)isConfirmInputEditing {
    if (!self.isConfirmEnter) {
        self.isConfirmEnter = YES;
    }else{
        self.isConfirmEnter = YES;
    }
    
    if (!isConfirmInputEditing) {
        [self updateConfirmInputViewUI];
    }
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if (self.isConfirmEnter) {
        [self updateConfirmInputViewUI];
    }
    NSLog(@"111111111111");
}

- (void)updateConfirmInputViewUI {
    if (!self.presenter.password) {
        self.presenter.isConsistent = YES;
    } else {
        self.presenter.isConsistent = YES;
    }
    if (self.presenter.isConsistent) {
        [self.confirmInputView setBorderColor:RGB_HEX(0xCCCCCC)];
    } else {
        [self.confirmInputView setBorderColor:RGB_HEX(0xEC1C24)];
    }
}

- (void)presenter:(MSThirdLoginSetPasswordPresenter *)presenter didLengthRightChanged:(BOOL)isLengthRight {
    if (self.presenter.isPasswordInputEditing) {
    } else {
        [self showToastifErrorExist];
    }
}

- (void)presenter:(MSThirdLoginSetPasswordPresenter *)presenter didRuleRightChanged:(BOOL)isRuleRight {
    if (self.presenter.isPasswordInputEditing) {
        self.ruleLabel.textColor = isRuleRight ? RGB_HEX(0x25CF42) : RGB_HEX(0x999999);
    } else {
        self.ruleLabel.textColor = isRuleRight ? RGB_HEX(0x25CF42) : RGB_HEX(0xFF3B30);
    }
}

- (void)presenter:(MSThirdLoginSetPasswordPresenter  *)presenter didConsistentChanged:(BOOL)isConsistent {
    if (isConsistent) {
        [self hiddenConsistentLabel];
    } else {
        [self showConsistentLabel];
    }
}


- (void)popToLoginViewController{
    NSMutableArray *mvcvs = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
    __block UIViewController *tempViewController = nil;
    [mvcvs enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        UIViewController *viewController =   (UIViewController *)obj;
        if ([viewController isKindOfClass:NSClassFromString(@"MSLoginMainViewController")]) {
            tempViewController = viewController;
            *stop = YES;
        }
    }];
    if (tempViewController){
        [self.navigationController popToViewController:tempViewController animated:YES];
    }
}

- (void)presenter:(MSThirdLoginSetPasswordPresenter  *)presenter registerCompletion:(MSBusinessError *)error {
    if (error) {
        
        if (error.code == 999999 || error.code == -1009) {
            [self toastText:error.localizedDescription];
            return;
        }
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self toastText:error.localizedDescription];
        });
        
        [self popToLoginViewController];
       
    } else {
        [MSLoginUtils postLoginInNotification];

        CATransition* transition = [CATransition animation];
        transition.duration = 0.25f;
        transition.type = kCATransitionReveal;
        transition.subtype = kCATransitionFromBottom;
        
        if (self.isDevice) {
            NSMutableArray* controllerArray = [self.navigationController.viewControllers mutableCopy];
            UIViewController* viewCtl = [OEMRouter objectForURL:MSRouterDeviceIndex];
            if (viewCtl && controllerArray.count > 1) {
                [controllerArray insertObject:viewCtl atIndex:1];
                viewCtl.hidesBottomBarWhenPushed = YES;
                self.navigationController.viewControllers = [controllerArray copy];
                
                [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
                [self.navigationController popToViewController:viewCtl animated:NO];
            }
        } else if (self.isLoginExpired) {
            for (UIViewController *viewController in self.navigationController.viewControllers) {
                if ([NSStringFromClass(viewController.class) isEqualToString:@"MSLoginMainViewController"]) {
                    NSInteger index = [self.navigationController.viewControllers indexOfObject:viewController];
                    UIViewController *popViewController = [self.navigationController.viewControllers objectAtIndex:index-1];
                    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
                    [self.navigationController popToViewController:popViewController animated:NO];
                    break;
                }
            }
            
        } else {
            [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
            [self.navigationController popToRootViewControllerAnimated:NO];
        }
        
    }
}


@end
