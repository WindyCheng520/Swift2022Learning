//
//  MSBottomAlertView.m
//  MSLogin
//
//  Created by pactera on 2020/8/1.
//

#import "MSBottomAlertView.h"
#import <MSLoginBundle.h>


@interface MSBottomAlertView ()

@property (nonatomic, strong) HGView *backView;
@property (nonatomic, strong) HGLabel *titleLabel;
@property (nonatomic, strong) HGButton *actionButton;
@property (nonatomic, strong) HGButton *cancleButton;
@property (nonatomic, strong) UIView *lineView;
@property (nonatomic, strong) UIView *grayView;

@property (nonatomic, assign) CGFloat contentHeight;

@end

@implementation MSBottomAlertView

-(instancetype)initWithTitle:(NSString*)title actionTitle:(NSString*)actionTitle{
    if (self = [super init]) {
        self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5f];
        self.alpha = 0;
        self.frame = [UIScreen mainScreen].bounds;
        
        self.backView = [HGView new];
        self.backView.backgroundColor = [UIColor whiteColor];
        [self addSubview:self.backView];
        
        self.titleLabel = [HGLabel new];
        self.titleLabel.textColor = RGB_HEX(0x8A8A8F);
        self.titleLabel.font = [UIFont systemFontOfSize:14];
        self.titleLabel.text = title;
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.numberOfLines = 0;
        [self.backView addSubview:self.titleLabel];
        
        self.actionButton = [HGButton new];
        [self.actionButton setTitle:actionTitle forState:UIControlStateNormal];
        [self.actionButton setTitleColor:RGB_HEX(0xEC1C24) forState:UIControlStateNormal];
        self.actionButton.titleLabel.font = [UIFont systemFontOfSize:16];
        self.actionButton.titleLabel.numberOfLines = 0;
        self.actionButton.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.actionButton.contentEdgeInsets = UIEdgeInsetsMake(0, 16, 0, 16);
        [self.actionButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
        [self.backView addSubview:self.actionButton];
        
        self.cancleButton = [HGButton new];
        [self.cancleButton setTitle:MSResourceString(@"login_page_thirdpart_login_cancel") forState:UIControlStateNormal];
        [self.cancleButton setTitleColor:RGB_HEX(0x232323) forState:UIControlStateNormal];
        self.cancleButton.titleLabel.font = [UIFont systemFontOfSize:16];
        [self.cancleButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
        [self.backView addSubview:self.cancleButton];
        
        self.lineView = [HGView new];
        self.lineView.backgroundColor = RGB_HEX(0xEBEBEB);
        [self.backView addSubview:self.lineView];
        
        self.grayView = [HGView new];
        self.grayView.backgroundColor = RGB_HEX(0xF2F2F2);
        [self.backView addSubview:self.grayView];
        
        [self makeConstraints];
        [self setViewLayerWithDirection:UIRectCornerTopLeft|UIRectCornerTopRight andLayerView:self.backView andCornerRadii:CGSizeMake(16, 16)];
        
        [self configureOEMTheme];
    }
    return self;
}

- (void)configureOEMTheme{
    [self.backView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.titleLabel configure40TranslucentTrait];
    [self.lineView configureThemeTag:OEMThemesTag_UIView_Sepline];
    [self.grayView configureThemeTag:OEMThemesTag_UIView_Background];
    
    [self.actionButton specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIButton_TitleTraitColor): HexColorAlpha(0xE54141, 1)
    } lightModeProperties:@{
        @(OEMThemesTag_UIButton_TitleTraitColor): HexColorAlpha(0xE54141, 1)
    }];
    [self.cancleButton specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIButton_TitleTraitColor): HexColorAlpha(0x267AFF, 1)
    } lightModeProperties:@{
        @(OEMThemesTag_UIButton_TitleTraitColor): HexColorAlpha(0x267AFF, 1)
    }];
}

-(void)makeConstraints{
    CGFloat titleHeight = [self.titleLabel.text boundingRectWithSize:CGSizeMake(SCREEN_WIDTH-16*2, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:self.titleLabel.font} context:nil].size.height + 16*2;
    CGFloat actionHeight = [self.actionButton.titleLabel.text boundingRectWithSize:CGSizeMake(SCREEN_WIDTH-16*2, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:self.actionButton.titleLabel.font} context:nil].size.height + 16*2;
    self.contentHeight = titleHeight+1+actionHeight+8+48+kSafeAreaBottom;
    
    [self.backView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.equalTo(self);
        make.height.mas_equalTo(self.contentHeight);
        make.bottom.equalTo(self).offset(self.contentHeight);
    }];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.backView);
        make.leading.equalTo(self.backView).offset(16);
        make.trailing.equalTo(self.backView).offset(-16);
        make.height.mas_equalTo(titleHeight);
    }];
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.equalTo(self.backView);
        make.top.equalTo(self.titleLabel.mas_bottom);
        make.height.mas_equalTo(1);
    }];
    [self.actionButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.equalTo(self.backView);
        make.top.equalTo(self.lineView.mas_bottom);
        make.height.mas_equalTo(actionHeight);
    }];
    [self.grayView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.equalTo(self.backView);
        make.top.equalTo(self.actionButton.mas_bottom);
        make.height.mas_equalTo(8);
    }];
    [self.cancleButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.equalTo(self.backView);
        make.top.equalTo(self.grayView.mas_bottom);
        make.height.mas_equalTo(48);
    }];
    
}

-(void)clickButton:(UIButton*)sender{
    if (sender == self.cancleButton) {
        [self dismiss];
        safeCallBlock(self.clickCancleBlock);
    }else{
        [self dismiss];
        safeCallBlock(self.clickActionBlock);
    }
}

-(void)show{
    UIWindow* keyWindow = [UIApplication sharedApplication].keyWindow;
    [keyWindow addSubview:self];
    [UIView animateWithDuration:0.25 animations:^{
        self.alpha = 1;
        [self.backView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self).offset(0);
        }];
    } completion:nil];
}

-(void)dismiss{
    [UIView animateWithDuration:0.25 animations:^{
        self.alpha = 0;
        [self.backView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self).offset(self.contentHeight);
        }];
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}

//为view添加圆角  cornerRadii圆角尺寸
-(void)setViewLayerWithDirection:(UIRectCorner)corner andLayerView:(UIView*)view andCornerRadii:(CGSize)cornerRadii{
    CGRect rect = CGRectMake(0, 0, SCREEN_WIDTH, self.contentHeight);
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:rect byRoundingCorners:corner cornerRadii:cornerRadii];
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = rect;
    maskLayer.path = maskPath.CGPath;
    view.layer.mask = maskLayer;
}


@end
