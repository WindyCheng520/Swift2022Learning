//
//  CodeNotRecvTableViewCell.h
//  MSLogin
//
//  Created by Neil 韦学宁 on 2021/7/14.
//

#import <OEMFoundation/HGTableViewCell.h>

NS_ASSUME_NONNULL_BEGIN

@interface CodeNotRecvTableViewCell : HGTableViewCell

@property(nonatomic, strong)UILabel * contentLabel;

@property(nonatomic, strong)UILabel * indexItemLabel;

+ (CGFloat)textHeightWithString:(NSString *)string;

- (void)setText:(NSString *)text index:(NSInteger)index;

+ (CGSize)boundingRectWithSize:(CGSize)size font:(UIFont*)font lineSpacing:(CGFloat)lineSpacing string:(NSString *)string;

@end

NS_ASSUME_NONNULL_END
