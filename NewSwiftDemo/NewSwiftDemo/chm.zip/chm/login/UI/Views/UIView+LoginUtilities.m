//
//  UIView+LoginUtilities.m
//  MSLogin
//
//  Created by Neil 韦学宁 on 2021/7/11.
//

#import "UIView+LoginUtilities.h"
#import "MSLoginBundle.h"
#import <OEMTheme/MSInputView_Private.h>
#import <OEMTheme/OEMThemesDefine.h>
#import <MSBusiness/MSNotificationConst.h>
#import <UIKit/UIKit.h>
#import <YYText/YYText.h>
#import <MSBusiness/MSRouterUrl.h>

@implementation UIView (LoginUtilities)

+ (NSMutableAttributedString *)getProtocolString:(BOOL)isSmallScreen{
    UIColor * highLightTxtColor = OEMThemeColorWithTrait(LightThemeNavigatorTextColor, DarkThemeNavigatorTextColor);
    UIColor * norTxtColor = OEMThemeColorWithTrait(LightThemeTextFieldPlaceHolder, LightThemeClearBackgroundButtonTitle);
    NSString* selectString = MSResourceString(@"login_page_privacy_check_content");
    NSRange privacyRange = [selectString rangeOfString:MSResourceString(@"login_page_privacy_link")];
    NSRange softwareRange = [selectString rangeOfString:MSResourceString(@"login_page_license_link")];
    
    NSMutableAttributedString* selectAttributedString = [[NSMutableAttributedString alloc]initWithString:selectString attributes:@{NSFontAttributeName:isSmallScreen ? [UIFont systemFontOfSize:10] : [UIFont systemFontOfSize:13], NSForegroundColorAttributeName:norTxtColor}];
    [selectAttributedString addAttribute:NSFontAttributeName value:isSmallScreen ? [UIFont systemFontOfSize:10 weight:UIFontWeightMedium] : [UIFont systemFontOfSize:13 weight:UIFontWeightMedium] range:privacyRange];
    [selectAttributedString addAttribute:NSFontAttributeName value:isSmallScreen ? [UIFont systemFontOfSize:10 weight:UIFontWeightMedium] : [UIFont systemFontOfSize:13 weight:UIFontWeightMedium] range:softwareRange];
    NSMutableParagraphStyle* paragraphStyle = [[NSMutableParagraphStyle alloc]init];
    paragraphStyle.lineSpacing = MIN(5, SCREEN_SCALE_WIDTH(5));
    [selectAttributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, selectAttributedString.length)];
    [selectAttributedString yy_setTextHighlightRange:privacyRange color:highLightTxtColor backgroundColor:[UIColor clearColor] tapAction:^(UIView * _Nonnull containerView, NSAttributedString * _Nonnull text, NSRange range, CGRect rect) {
        [OEMRouter handleURL:MSRouterHtmlIndex withParams:@{@"type" : @(1)}];
    }];
    [selectAttributedString yy_setTextHighlightRange:softwareRange color:highLightTxtColor backgroundColor:[UIColor clearColor] tapAction:^(UIView * _Nonnull containerView, NSAttributedString * _Nonnull text, NSRange range, CGRect rect) {
        [OEMRouter handleURL:MSRouterHtmlIndex withParams:@{@"type" : @(2)}];
    }];
    return selectAttributedString;
}

+ (NSAttributedString *)attributedText:(NSString *)text
                                 color:(UIColor *)color
                                 arrow:(nullable UIImage *)arrow
                         isSmallScreen:(BOOL)isSmallScreen{
    NSMutableAttributedString *tipAttributedString = [NSMutableAttributedString new];
        
    [tipAttributedString appendAttributedString:[[NSAttributedString alloc] initWithString:text]];
    NSDictionary *attributes = @{
        NSForegroundColorAttributeName : color,
        NSFontAttributeName : isSmallScreen ? [UIFont systemFontOfSize:12 weight:UIFontWeightSemibold] : [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold]
    };
    NSRange range = NSMakeRange(0, text.length);
    [tipAttributedString setAttributes:attributes range:range];
    
    if (arrow) {
        NSTextAttachment *attachment = [NSTextAttachment new];
        attachment.image = arrow;
        attachment.bounds = CGRectMake(0, -2 , 12, 12);
        [tipAttributedString appendAttributedString:[NSAttributedString attributedStringWithAttachment:attachment]];
    }
    return tipAttributedString;
}


@end
