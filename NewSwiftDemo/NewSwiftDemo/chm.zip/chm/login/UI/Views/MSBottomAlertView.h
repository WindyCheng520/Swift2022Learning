//
//  MSBottomAlertView.h
//  MSLogin
//
//  Created by pactera on 2020/8/1.
//

#import <UIKit/UIKit.h>



@interface MSBottomAlertView : UIView

- (void)show;
- (void)dismiss;
@property (nonatomic, copy) dispatch_block_t clickActionBlock;
@property (nonatomic, copy) dispatch_block_t clickCancleBlock;

- (instancetype)initWithTitle:(NSString*)title actionTitle:(NSString*)actionTitle;

@end


