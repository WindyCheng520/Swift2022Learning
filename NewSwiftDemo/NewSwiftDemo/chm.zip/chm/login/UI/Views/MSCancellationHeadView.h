//
//  MSCancellationHeadView.h
//  MSLogin
//
//  Created by WindyCheng on 2021/8/6.
//

#import <OEMFoundation/HGView.h>

NS_ASSUME_NONNULL_BEGIN

@interface MSCancellationHeadView : HGView

@end

NS_ASSUME_NONNULL_END
