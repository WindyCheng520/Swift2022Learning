//
//  MSValidCodeView.h
//  MSLogin
//
//  Created by Neil 韦学宁 on 2021/7/13.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MSValidCodeView : HGView

@property(nonatomic, assign)NSInteger currentInputIndex;

@property(nonatomic, assign)NSInteger nextInputIndex;

@property(nonatomic, strong, readonly)NSString * text;

@property(nonatomic, copy)os_block_t lastCodeDidInput;


/// 清除所有输入框
/// @param focusFirstInput 是否聚焦第一个输入光标，否则收起键盘
- (void)cleanInputWithFocusFirstInput:(BOOL)focusFirstInput;

- (void)resignResponder;

- (void)becomResponder;

@end

NS_ASSUME_NONNULL_END
