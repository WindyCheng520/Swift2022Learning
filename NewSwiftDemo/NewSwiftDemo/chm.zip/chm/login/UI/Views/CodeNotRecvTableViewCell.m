//
//  CodeNotRecvTableViewCell.m
//  MSLogin
//
//  Created by Neil 韦学宁 on 2021/7/14.
//

#import "CodeNotRecvTableViewCell.h"

#define CodeNotRecvTableViewCellFontSize (16)

@interface CodeNotRecvTableViewCell()

@end

@implementation CodeNotRecvTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self initSubViews];
    }
    return self;
}

- (void)dealloc{
    NSLog(@"%s", __func__);
}

- (void)initSubViews{
    
    self.contentLabel = [UILabel new];
    self.contentLabel.numberOfLines = 0;
    self.contentLabel.font = [UIFont systemFontOfSize:CodeNotRecvTableViewCellFontSize];
    self.contentLabel.textAlignment = NSTextAlignmentLeft;
    self.contentLabel.backgroundColor = [UIColor clearColor];
    [self.contentView addSubview:self.contentLabel];
    
    [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentLabel.superview);
        make.leading.equalTo(self.contentLabel.superview).offset(43);
        make.trailing.equalTo(self.contentLabel.superview).offset(-26);
    }];
    
    self.indexItemLabel = [UILabel new];
    self.indexItemLabel.numberOfLines = 0;
    self.indexItemLabel.font = [UIFont systemFontOfSize:12];
    self.indexItemLabel.textAlignment = NSTextAlignmentCenter;
    self.indexItemLabel.backgroundColor = [UIColor clearColor];
    self.indexItemLabel.layer.cornerRadius = 19 * 0.5;
    self.indexItemLabel.layer.borderWidth = 0.5;
    self.indexItemLabel.layer.masksToBounds = YES;
    
    [self.contentView addSubview:self.indexItemLabel];
    
    [self.indexItemLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.indexItemLabel.superview).offset(2);
        make.leading.equalTo(self.indexItemLabel.superview).offset(16);
        make.size.mas_equalTo(CGSizeMake(19, 19));
    }];
    
    [self configureOEMTheme];
    self.backgroundColor = [UIColor clearColor];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}

- (void)configureOEMTheme{
    [self.contentView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.contentLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
    [self.indexItemLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
    WEAKSELF
    [self.contentView registerTraitDidChangeCallback:^{
        if (OEMThemeIsDarkMode) {
            weakSelf.indexItemLabel.layer.borderColor = DarkThemeClearBackgroundButtonTitle.CGColor;
        }else{
            weakSelf.indexItemLabel.layer.borderColor = LightThemeClearBackgroundButtonTitle.CGColor;
        }
    } callImmidiately:YES];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

+ (CGFloat)textHeightWithString:(NSString *)string{
    UIFont * font = [UIFont systemFontOfSize:CodeNotRecvTableViewCellFontSize];
    return [self boundingRectWithSize:CGSizeMake(SCREEN_WIDTH - 43 - 16, MAXFLOAT) font:font lineSpacing:0 string:string].height + 22;
    /*
    CGSize size = [string boundingRectWithSize:CGSizeMake(SCREEN_WIDTH - 43 - 16, MAXFLOAT) font:font lineSpacing:font.lineHeight];
    return size.height;
     */
}

- (void)setText:(NSString *)text index:(NSInteger)index{
    self.contentLabel.text = text;
    self.indexItemLabel.text = [NSString stringWithFormat:@"%ld", index + 1];
}

+ (CGSize)boundingRectWithSize:(CGSize)size font:(UIFont*)font lineSpacing:(CGFloat)lineSpacing string:(NSString *)string
{
    NSMutableAttributedString *attributeString = [[NSMutableAttributedString alloc] initWithString:string];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = lineSpacing;
    [attributeString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, string.length)];
    [attributeString addAttribute:NSFontAttributeName value:font range:NSMakeRange(0, string.length)];
    NSStringDrawingOptions options = NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading;
    CGRect rect = [attributeString boundingRectWithSize:size options:options context:nil];
    return rect.size;
    
}

@end
