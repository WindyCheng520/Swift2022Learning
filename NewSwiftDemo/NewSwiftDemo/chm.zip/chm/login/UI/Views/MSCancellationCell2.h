//
//  MSCancellationCell2.h
//  MSLogin
//
//  Created by WindyCheng on 2021/8/6.
//

#import <OEMFoundation/HGTableViewCell.h>

NS_ASSUME_NONNULL_BEGIN

@interface MSCancellationCell2 : HGTableViewCell

@property(nonatomic, strong)UILabel *indexItemLabel;

@property(nonatomic, strong)UILabel *contentLabel;

//@property(nonatomic, copy)NSString *index;
//
//@property(nonatomic, copy)NSString *content;

@end

NS_ASSUME_NONNULL_END
