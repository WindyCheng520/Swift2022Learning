//
//  MSCancellationCell1.m
//  MSLogin
//
//  Created by WindyCheng on 2021/8/6.
//

#import "MSCancellationCell1.h"

@implementation MSCancellationCell1


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
       
        self.contentLabel = [UILabel new];
        self.contentLabel.font =  [UIFont systemFontOfSize:16 weight:UIFontWeightSemibold];
        self.contentLabel.textAlignment = NSTextAlignmentLeft;
        self.contentLabel.backgroundColor = [UIColor clearColor];
        self.contentLabel.numberOfLines = 0;
        [self.contentLabel sizeToFit];
        [self.contentView addSubview:self.contentLabel];
        
        [self makeConstraints];
        [self configureOEMTheme];
    }
    return self;
}


- (void)configureOEMTheme{
    [self.contentView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.contentLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
}

- (void)makeConstraints {
    [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView).offset(0);
        make.leading.equalTo(self.contentView).offset(16);
        make.trailing.equalTo(self.contentView).offset(-16);
        make.bottom.equalTo(self.contentView).offset(0);
    }];
}


@end
