//
//  UIView+LoginUtilities.h
//  MSLogin
//
//  Created by Neil 韦学宁 on 2021/7/11.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (LoginUtilities)

+ (NSMutableAttributedString *)getProtocolString:(BOOL)isSmallScreen;

+ (NSAttributedString *)attributedText:(NSString *)text
                                 color:(UIColor *)color
                                 arrow:(nullable UIImage *)arrow
                         isSmallScreen:(BOOL)isSmallScreen;

@end

NS_ASSUME_NONNULL_END
