//
//  MSCountrySelectCell.m
//  MSLogin
//
//  Created by pactera on 2020/8/14.
//

#import "MSCountrySelectCell.h"
#import "MSLoginBundle.h"

@interface MSCountrySelectCell ()

@property (nonatomic, strong) HGView *lineView;

@end

@implementation MSCountrySelectCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.tintColor = RGB_HEX(0xEC1C24);
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.titleLabel = [HGLabel new];
        self.titleLabel.textColor = RGB_HEX(0x000000);
        self.titleLabel.font = [UIFont systemFontOfSize:16];
        self.titleLabel.textAlignment = NSTextAlignmentLeft;
        [self.contentView addSubview:self.titleLabel];
        
        self.lineView = [HGView new];
        self.lineView.backgroundColor = RGB_HEX(0xEBEBEB);
        [self.contentView addSubview:self.lineView];
        
        self.checkMark = [UIImageView new];
        self.checkMark.image = MSResourceImage(@"ic_country_selected");
        [self.contentView addSubview:self.checkMark];
        
        [self makeConstraints];
        
        [self configureThemeStyle];
        
    }
    return self;
}

- (void)configureThemeStyle{
    [self.contentView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.lineView configureThemeTag:OEMThemesTag_UIView_Sepline];
    [self.titleLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
}

-(void)makeConstraints {
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(16);
        make.trailing.mas_equalTo(-16);
        make.centerY.equalTo(self.contentView);
    }];
    
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.titleLabel);
        make.trailing.equalTo(self.contentView);
        make.bottom.equalTo(self.contentView);
        make.height.mas_equalTo(0.5f);
    }];
    
    [self.checkMark mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(24, 24));
        make.centerY.equalTo(self);
        make.trailing.equalTo(self).offset(-19);
    }];
}

-(void)dealloc{
    NSLog(@"%s",__func__);
}
@end
