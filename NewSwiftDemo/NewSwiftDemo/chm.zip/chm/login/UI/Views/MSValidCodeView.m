//
//  MSValidCodeView.m
//  MSLogin
//
//  Created by Neil 韦学宁 on 2021/7/13.
//

#import "MSValidCodeView.h"

typedef void(^MSTextFieldBackwarkEvent)(UITextField * textField);

@interface MSInsetTextField : HGTextField

@property(nonatomic, assign)CGFloat leadingInset;

@property(nonatomic, copy)MSTextFieldBackwarkEvent backwarkEvent;

@end

@implementation MSInsetTextField

- (CGRect)editingRectForBounds:(CGRect)bounds{
    if (self.text.length > 0) {
        return [super editingRectForBounds:bounds];
    } else {
        CGRect inset = CGRectMake(bounds.origin.x,
                                  bounds.origin.y,
                                  bounds.size.width,
                                  bounds.size.height);
        return inset;
    }
}

- (void)deleteBackward{
    if (self.backwarkEvent) {
        self.backwarkEvent(self);
    }
}

@end


#define MSValidCodeViewCodeLength (6)

@interface MSValidCodeView()<UITextFieldDelegate>

@property (nonatomic, strong)NSArray<MSInsetTextField *> *views;

@property(nonatomic, strong)NSString * text;

@end

@implementation MSValidCodeView

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self customInit];
    }
    return self;;
}

- (void)customInit{
    self.views = [NSArray new];
    [self initTextFields];
    [self makeConstraints];
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        [weakSelf updateUITextFieldStyle];
    } callImmidiately:YES];
}

- (void)updateUITextFieldStyle{
    for (HGTextField * textField in self.views) {
        if (![textField isKindOfClass:[UITextField class]]) {
            continue;
        }
        textField.tintColor = OEMThemeIsDarkMode ? [UIColor whiteColor] : [UIColor blackColor];
    }
}

- (void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)initTextFields{
    if ([self.views count] > 0) {
        return;
    }
    NSMutableArray * newViews = [NSMutableArray new];
    for (int i = 0; i < MSValidCodeViewCodeLength; i++) {
        HGTextField * textField = [self newTextField];
        textField.tag = i;
        [newViews addObject:textField];
    }
    self.views = [NSArray arrayWithArray:newViews];
}

- (MSInsetTextField *)newTextField{
    MSInsetTextField * textField = [MSInsetTextField new];
    textField.font = [UIFont systemFontOfSize:22 weight:UIFontWeightBold];
    textField.backgroundColor = [UIColor clearColor];
    textField.delegate = self;
    textField.keyboardType = UIKeyboardTypeNumberPad;
    textField.textAlignment = NSTextAlignmentCenter;
    
    [textField configureThemeTag:OEMThemesTag_UITextField_Textcolor];
    [textField addThemeBottomSeplineWithOffset:0];
    textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textDidChangeNotification:) name:UITextFieldTextDidChangeNotification object:textField];

    WEAKSELF
    textField.backwarkEvent = ^(UITextField *textField) {
        if ([textField.text length] == 0) {
            int previousTag = (int)textField.tag - 1;
            if (previousTag >= 0 && previousTag < MSValidCodeViewCodeLength) {
                weakSelf.nextInputIndex = previousTag;
                UITextField * previousView = [weakSelf.views objectAtIndex:previousTag];
                previousView.text = @"";
                [previousView becomeFirstResponder];
            }
        }
    };
    
    return textField;
}

- (void)makeConstraints{
    HGTextField * previous = nil;
    for (HGTextField * textField in self.views) {
        if (!textField.superview) {
            [self addSubview:textField];
        }
        if (!previous) {
            [textField mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.leading.equalTo(textField.superview);
                make.top.bottom.equalTo(textField.superview);
                make.width.mas_equalTo(32);
            }];
        }else{
            [textField mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.leading.equalTo(previous.mas_trailing).offset(12);
                make.top.bottom.equalTo(textField.superview);
                make.width.mas_equalTo(32);
            }];
        }
        previous = textField;
    }
}

- (void)activateFirstResponsderWithCurrentIndex{
    
}

#pragma mark - ====== UITextFieldDelegate ======

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    
    if ([self.text length] == MSValidCodeViewCodeLength && textField.tag != (MSValidCodeViewCodeLength - 1)) {
        //都输入的情况下，最后一个TextField作为第一响应者
        [[self.views lastObject] becomeFirstResponder];
        return NO;
    }
    
    NSInteger shouldResponseTextFiledTag = [self getFistNullInputTextFiled];
    if (shouldResponseTextFiledTag != NSIntegerMax &&
        shouldResponseTextFiledTag != textField.tag &&
        shouldResponseTextFiledTag < MSValidCodeViewCodeLength) {
        //如果任意点击一个UITextField，first Responder必须是文字为空的第一个TextField
        [self.views[shouldResponseTextFiledTag] becomeFirstResponder];
        return NO;
    }
    
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    self.currentInputIndex = textField.tag;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    
    if (self.nextInputIndex == textField.tag - 1 ||
        self.nextInputIndex == textField.tag + 1 ||
        self.nextInputIndex == NSIntegerMax ||
        self.currentInputIndex == NSIntegerMax) {
        return YES;
    }
    return NO;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    if ([self.text length] == MSValidCodeViewCodeLength && textField.tag == MSValidCodeViewCodeLength - 1) {
        if (self.lastCodeDidInput) {
            self.lastCodeDidInput();
        }
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{

    return YES;
}

#pragma mark - ====== APIs ======

- (NSInteger)getFistNullInputTextFiled{
    __block NSInteger index = NSIntegerMax;
    [self.views enumerateObjectsUsingBlock:^(MSInsetTextField * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj.text length] == 0) {
            index = idx;
            *stop = YES;
        }
    }];
    return index;
}

- (NSString *)text{
    NSMutableString * string = [NSMutableString new];
    [self.views enumerateObjectsUsingBlock:^(MSInsetTextField * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj.text length] > 0) {
            [string appendString:obj.text];
        }
    }];
    return [NSString stringWithString:string];
}

- (void)cleanInputWithFocusFirstInput:(BOOL)focusFirstInput{
    [self.views enumerateObjectsUsingBlock:^(MSInsetTextField * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        obj.text = @"";
    }];
    if (focusFirstInput) {
        [self.views.firstObject becomeFirstResponder];
    }else{
        [self endEditing:YES];
        self.nextInputIndex = NSIntegerMax;
        self.currentInputIndex = NSIntegerMax;
    }
}

- (void)resignResponder{
    __block UITextField * textField = nil;
    [self.views enumerateObjectsUsingBlock:^(MSInsetTextField * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([obj isFirstResponder]) {
                textField = obj;
            }
    }];
    if (textField) {
        [textField resignFirstResponder];
        self.nextInputIndex = NSIntegerMax;
        self.currentInputIndex = NSIntegerMax;
    }
}

- (void)becomResponder{
    [self.views.firstObject becomeFirstResponder];
    self.nextInputIndex = 1;
    self.currentInputIndex = 0;
}

#pragma mark - ====== Notification ======

- (void)textDidChangeNotification:(NSNotification *)notification{
    if (![notification.object isKindOfClass:[UITextField class]]) {
        return;
    }
    
    UITextField * textField = notification.object;
    NSInteger nextResponder = textField.tag + 1;
    self.nextInputIndex = nextResponder;
    if (nextResponder < [self.views count]) {
        [[self.views objectAtIndex:nextResponder] becomeFirstResponder];
    }else{
        [textField resignFirstResponder];
    }
}


@end
