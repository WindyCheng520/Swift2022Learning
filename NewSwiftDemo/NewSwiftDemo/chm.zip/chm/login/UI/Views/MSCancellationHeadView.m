//
//  MSCancellationHeadView.m
//  MSLogin
//
//  Created by WindyCheng on 2021/8/6.
//

#import "MSCancellationHeadView.h"
#import <MSLoginBundle.h>


@interface MSCancellationHeadView ()

@property (nonatomic, strong) HGImageView *warnView;
@property (nonatomic, strong) HGLabel *titleLabel;

@end

@implementation MSCancellationHeadView


- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.warnView = [HGImageView new];
        self.warnView.layer.cornerRadius = 24;
        self.warnView.layer.masksToBounds = YES;
        self.warnView.clipsToBounds = YES;
        self.warnView.image = MSResourceImage(@"ic_other_caution");
        self.warnView.backgroundColor = CommonThemeWarningColor;
        [self addSubview:self.warnView];
        self.titleLabel = [HGLabel new];
        self.titleLabel.text = MSResourceString(@"account_cancellation_page_title");
        self.titleLabel.font = [UIFont systemFontOfSize:22 weight:UIFontWeightSemibold];
        self.titleLabel.textColor = [UIColor clearColor];
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.titleLabel];
        [self makeContstraints];
        [self configureOEMTheme];
    }
    return self;
}

- (void)configureOEMTheme{
    [self configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.titleLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
}

- (void)makeContstraints {

    [self.warnView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).offset(16);
        make.centerX.equalTo(self);
        make.size.mas_equalTo(CGSizeMake(48, 48));
    }];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.warnView.mas_bottom).offset(5);
        make.height.mas_equalTo(26);
        make.width.mas_equalTo(self.frame.size.width);
    }];
}





@end
