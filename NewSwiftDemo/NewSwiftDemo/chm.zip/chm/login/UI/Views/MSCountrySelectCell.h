//
//  MSCountrySelectCell.h
//  MSLogin
//
//  Created by pactera on 2020/8/14.
//

#import <OEMFoundation/HGTableViewCell.h>

NS_ASSUME_NONNULL_BEGIN

@interface MSCountrySelectCell : HGTableViewCell

@property (nonatomic, strong) HGLabel *titleLabel;

@property (nonatomic, strong) UIImageView *checkMark;

@end

NS_ASSUME_NONNULL_END
