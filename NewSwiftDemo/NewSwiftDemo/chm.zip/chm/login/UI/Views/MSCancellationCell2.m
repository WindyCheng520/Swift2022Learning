//
//  MSCancellationCell2.m
//  MSLogin
//
//  Created by WindyCheng on 2021/8/6.
//

#import "MSCancellationCell2.h"

@implementation MSCancellationCell2


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.indexItemLabel = [UILabel new];
        self.indexItemLabel.numberOfLines = 1;
        self.indexItemLabel.font =  [UIFont systemFontOfSize:12 weight:UIFontWeightMedium];
        self.indexItemLabel.textAlignment = NSTextAlignmentCenter;
        self.indexItemLabel.backgroundColor = [UIColor clearColor];
        self.indexItemLabel.layer.cornerRadius = 13.5 * 0.5;
        self.indexItemLabel.layer.borderWidth = 0.5;
        self.indexItemLabel.layer.masksToBounds = YES;
        [self.contentView addSubview:self.indexItemLabel];
       
        self.contentLabel = [UILabel new];
        self.contentLabel.numberOfLines = 0;
        self.contentLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightRegular];
        self.contentLabel.textAlignment = NSTextAlignmentLeft;
        self.contentLabel.backgroundColor = [UIColor clearColor];
        [self.contentLabel sizeToFit];
        [self.contentView addSubview:self.contentLabel];
        
        [self makeConstraints];
        [self configureOEMTheme];
    }
    return self;
}

- (void)configureOEMTheme{
    [self.contentView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.contentLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
    [self.indexItemLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
    WEAKSELF
    [self.contentView registerTraitDidChangeCallback:^{
        if (OEMThemeIsDarkMode) {
            weakSelf.indexItemLabel.layer.borderColor = DarkThemeClearBackgroundButtonTitle.CGColor;
        }else{
            weakSelf.indexItemLabel.layer.borderColor = LightThemeClearBackgroundButtonTitle.CGColor;
        }
    } callImmidiately:YES];
}

- (void)makeConstraints {
    
    [self.indexItemLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView).offset(2.5);
        make.leading.equalTo(self.contentView).offset(18.75);
        make.size.mas_equalTo(CGSizeMake(13.5, 13.5));
    }];
    
    [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView).offset(0);
        make.leading.mas_equalTo(self.indexItemLabel.mas_trailing).offset(10.75);
        make.trailing.equalTo(self.contentView).offset(-16);
        make.bottom.equalTo(self.contentView).offset(0);
    }];

}

@end
