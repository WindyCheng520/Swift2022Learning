//
//  MSCancellationCell1.h
//  MSLogin
//
//  Created by WindyCheng on 2021/8/6.
//

#import <OEMFoundation/HGTableViewCell.h>

NS_ASSUME_NONNULL_BEGIN

@interface MSCancellationCell1 : HGTableViewCell

@property(nonatomic, strong)UILabel *contentLabel;

@property(nonatomic, copy)NSString *content;

@end

NS_ASSUME_NONNULL_END
