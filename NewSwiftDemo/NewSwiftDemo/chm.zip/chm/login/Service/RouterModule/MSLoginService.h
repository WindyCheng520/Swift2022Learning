//
//  MSLoginService.h
//  MSLogin
//
//  Created by 及时行乐 on 2020/7/11.
//

#import <Foundation/Foundation.h>
#import <MSBusiness/MSLoginProtocol.h>

@interface MSLoginService : OEMRouterBaseService<MSLoginProtocol>




@end

