//
//  MSLoginService.m
//  MSLogin
//
//  Created by 及时行乐 on 2020/7/11.
//

#import "MSLoginService.h"
#import <MSBusiness/MSUserDefaultTools.h>
#import "MSLoginModel.h"
#import "MSLoginBundle.h"
#import <DolphinRouter/OEMRouter.h>
#import <MSBusiness/MSRouterUrl.h>
#import "MSLoginUtils.h"
#import <MSBusiness/BusinessRequestManager.h>
#import "MSLoginUtils.h"
#import "MSCountrySelectModel.h"
#import <OEMFoundation/HGInternationalization.h>
#import <MSBusiness/MSNotificationConst.h>
#import <MSBusiness/MSUserInfoManager.h>
#import <MSBusiness/MSBusinessError.h>

#import "MSLoginAndRegistRepository.h"
#import <MSBusiness/MSUIConfiguration.h>

#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import "MSLoginError.h"
#import "MSRegistPresenter.h"
//#import <TwitterKit/TWTRKit.h>
#import <AuthenticationServices/AuthenticationServices.h>
#import <MSBusiness/MSBusiness-Swift.h>

@DOFService(MSLoginProtocol, MSLoginService)

@interface MSLoginService ()<ASAuthorizationControllerDelegate,ASAuthorizationControllerPresentationContextProviding>

@property (nonatomic, strong) MSLoginModel *loginModel;
@property (nonatomic, strong) MSCountrySelectModel *countryModel;

@property (nonatomic, assign) BOOL isRefreshToken;  //是否正在刷新token
@property (nonatomic, strong) NSMutableArray *refreshBlockArray;

@property (nonatomic, copy) void (^completion)(BOOL success,NSString *accountInfo);

@property (nonatomic, copy)NSString *accountInfo;


@property (nonatomic, copy)NSString *token;   //第三方token
@property (nonatomic, copy)NSString *userId;  //第三方userId

@end

@implementation MSLoginService

+ (BOOL)singleton {
    return YES;
}

+ (id)shareInstance {
    static id instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[MSLoginService alloc] init];
    });
    return instance;
}

- (NSMutableArray *)refreshBlockArray {
    if (!_refreshBlockArray) {
        _refreshBlockArray = [NSMutableArray array];
    }
    return _refreshBlockArray;
}

- (MSLoginModel *)loginModel {
    if (!_loginModel) {
        _loginModel = [MSLoginModel new];
    }
    return _loginModel;
}

- (MSCountrySelectModel *)countryModel {
    if (!_countryModel) {
        _countryModel = [MSCountrySelectModel new];
    }
    return _countryModel;
}

//- (BOOL)isLogined {
//    if (![[MSUserDefaultTools getMasAccessToken] isEqualToString:@""] && ![[MSUserDefaultTools getMasTokenPwd] isEqualToString:@""] && ![[MSUserDefaultTools getMideaCloudRandomData] isEqualToString:@""] && ![[MSUserDefaultTools getMideaCloudAccessToken] isEqualToString:@""]) {
//        return YES;
//    }
//    return NO;
//}

- (void)autoLoginWithCompletion:(dispatch_block_t)completionBlock {
    [self.refreshBlockArray addObject:completionBlock];
    if (self.isRefreshToken) {
        return;
    }
    
    self.isRefreshToken = YES;
    [self.loginModel userAutoLoginWithRule:@"1" success:^(MSAutoLoginResult *result) {
        [[MSUserInfoManager shareManager] updateLoginInfoMasAccessTokenWithAccessToken:result.accessToken];
        [MSLoginUtils postLoginInNotification];
        
        for (dispatch_block_t requestBlock in self.refreshBlockArray) {
            safeCallBlock(requestBlock);
        }
        [self.refreshBlockArray removeAllObjects];
        self.isRefreshToken = NO;

    } failure:^(MSBusinessError *error) {
        [[NSNotificationCenter defaultCenter] postNotificationName:kMideaQuitLoginNotification object:nil userInfo:@{@"isLoginExpired":@"1"}];
        
        UIViewController *currentVC = [OEMRouterHandler getCurrentViewController];
        NSString *previousPageName = @"";
        if ([currentVC isKindOfClass:NSClassFromString(@"MSHomeViewController")]) {
            previousPageName = @"toshibaHomePage";
        } else if ([currentVC isKindOfClass:NSClassFromString(@"MSMineViewController")]) {
            previousPageName = @"personalPage";
        }
        if (![NSStringFromClass(currentVC.class) isEqualToString:@"MSLoginMainViewController"]) {
            [OEMRouter handleURL:MSRouterLoginIndex withParams:@{@"previousPageName":previousPageName, @"isLoginExpired":@YES} sourceController:currentVC andCompletion:nil];
        }
        
        for (dispatch_block_t requestBlock in self.refreshBlockArray) {
            safeCallBlock(requestBlock);
        }
        [self.refreshBlockArray removeAllObjects];
        self.isRefreshToken = NO;
        
    }];
    
}

- (void)updateCountryNameAfterChangeLanguage {
    [self.countryModel userGetCountryDataSuccess:^(NSArray<MSCountryGetResult *> *result) {
        
        for (MSCountryGetResult *item in result) {
            if ([item.countryCode isEqualToString:HGCurrentCountry.code]) {
                HGCountry *country = [HGCountry new];
                country.code = item.countryCode?:@"";
                country.name = item.area?:@"";
                country.url = item.url?:@"";
                country.phoneCode = item.phoneCode?:@"";
                country.mqttBroker = item.mqttBroker?:@"";
                
                HGCurrentCountry = country;
                break;
            }
        }
        
    } failure:^(MSBusinessError *error) {
        
    }];
}

- (void)performSettingLanguage:(NSString *)languageCode completion:(void (^)(BOOL))completion{
    if (!ISLOGIN) {
        //未登录，直接认为成功
        safeCallBlock(completion, true);
        return;
    }
    [MSLoginAndRegistRepository setLanguageWithParas:@{ @"language" : languageCode ?: @"" } success:^{
        safeCallBlock(completion, true);
    } failure:^(MSBusinessError *error) {
        safeCallBlock(completion, false);
    }];
}


-(void)thirdLoginWithChannel:(NSString *_Nonnull)channel
                  completion:(void (^_Nonnull)(BOOL success, NSString *accountInfo))completion{
    self.completion = completion;
    if([channel isEqualToString:@"89"]){
        //[self loginTwitter];
    }else if ([channel isEqualToString:@"79"]){
        [self loginApple];
    }else{
        [self loginFacebook];
    }
   
}


//苹果登录
- (void)loginApple {
    UIViewController *view = [OEMRouterHandler getCurrentViewController];
    if ([BusinessNetWorkTools isNetworkUnreachable]) {
        [MSUIConfiguration sh_showBlackToastHudToView:view.view text:[MSBusinessError networkDisconnectTips]];
        if (self.completion){
            self.completion(NO,@"");
        }
        return;
    }
    if (@available(iOS 13.0, *)) {
        ASAuthorizationAppleIDProvider *appleIDProvider = [[ASAuthorizationAppleIDProvider alloc] init];
        ASAuthorizationAppleIDRequest *appleIDRequest = [appleIDProvider createRequest];
        appleIDRequest.requestedScopes = @[ASAuthorizationScopeFullName, ASAuthorizationScopeEmail];
        ASAuthorizationController *authorizationController = [[ASAuthorizationController alloc] initWithAuthorizationRequests:@[appleIDRequest]];
        authorizationController.delegate = self;
        authorizationController.presentationContextProvider = self;
        [authorizationController performRequests];
    }
}

//苹果授权成功回调
- (void)authorizationController:(ASAuthorizationController *)controller didCompleteWithAuthorization:(ASAuthorization *)authorization  API_AVAILABLE(ios(13.0)){
    
    if ([authorization.credential isKindOfClass:[ASAuthorizationAppleIDCredential class]]) {
        ASAuthorizationAppleIDCredential *appleIDCredential = authorization.credential;
        // 基本信息
        NSString *user = appleIDCredential.user;
        NSData *identityToken = appleIDCredential.identityToken;
        NSString *identityTokenStr = [[NSString alloc] initWithData:identityToken encoding:NSUTF8StringEncoding];
        NSString *email = appleIDCredential.email; //用户有可能没授权
        self.accountInfo = email?email:user;
        [self thirdLoginWithToken:identityTokenStr userId:user thirdType:@"79" extraInfo:email?:@"" context:nil];
    } else {
//        if([self.view respondsToSelector:@selector(presenter:thirdLoginCompletion:)]) {
//            [self.view presenter:self thirdLoginCompletion:[MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeThirdLoginError]];
//        }
        UIViewController *view = [OEMRouterHandler getCurrentViewController];
        MSBusinessError *errors = [MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeThirdLoginError];
        [MSUIConfiguration sh_showBlackToastHudToView:view.view text:errors.localizedDescription];
        if (self.completion){
            self.completion(NO,@"");
        }
    }

}

//苹果授权失败
- (void)authorizationController:(ASAuthorizationController *)controller didCompleteWithError:(NSError *)error  API_AVAILABLE(ios(13.0)){
    UIViewController *view = [OEMRouterHandler getCurrentViewController];
    if (error.code == ASAuthorizationErrorCanceled) {
//        if([self.view respondsToSelector:@selector(presenter:thirdLoginCompletion:)]) {
//            [self.view presenter:self thirdLoginCompletion:[MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeThirdLoginCancel]];
//        }
        MSBusinessError *errors = [MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeThirdLoginCancel];
        [MSUIConfiguration sh_showBlackToastHudToView:view.view text:errors.localizedDescription];
        if (self.completion){
            self.completion(NO,@"");
        }
    } else {
//        if([self.view respondsToSelector:@selector(presenter:thirdLoginCompletion:)]) {
//            [self.view presenter:self thirdLoginCompletion:[MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeThirdLoginError]];
//        }
        MSBusinessError *errors = [MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeThirdLoginError];
        [MSUIConfiguration sh_showBlackToastHudToView:view.view text:errors.localizedDescription];
        if (self.completion){
            self.completion(NO,@"");
        }
    }
}

// apple告诉delegate应该在哪个window展示内容给用户
- (ASPresentationAnchor)presentationAnchorForAuthorizationController:(ASAuthorizationController *)controller  API_AVAILABLE(ios(13.0)){
    return [UIApplication sharedApplication].windows.lastObject;
}




#pragma mark - FaceBook登录
- (void)loginFacebook {
    WEAKSELF
    FBSDKLoginManager *loginManager = [FBSDKLoginManager new];
    [loginManager logOut];
    [FBSDKProfile enableUpdatesOnAccessTokenChange:YES];
    UIViewController *view = [OEMRouterHandler getCurrentViewController];
    WEAKIFY_OBJECT(view);
    [loginManager logInWithPermissions:@[@"public_profile", @"email"] fromViewController:view handler:^(FBSDKLoginManagerLoginResult * _Nullable result, NSError * _Nullable error) {
        DDLogLoginInfo(@"facebook 登录回调：%@, %@", error.localizedDescription, error.userInfo);
        if (error) {
            MSBusinessError *errors = [MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeThirdLoginError];
            [MSUIConfiguration sh_showBlackToastHudToView:weakview.view text:errors.localizedDescription];
            if (weakSelf.completion){
                weakSelf.completion(NO,@"");
            }
        }else if (result.isCancelled){
            if (weakSelf.completion){
                weakSelf.completion(NO,@"");
            }
            MSBusinessError *errors = [MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeThirdLoginCancel];
            [MSUIConfiguration sh_showBlackToastHudToView:weakview.view text:errors.localizedDescription];
        }else{
            weakSelf.token = result.token.tokenString?:@"";
            weakSelf.userId = result.token.userID?:@"";
            //[weakSelf thirdLoginWithToken:token userId:userId thirdType:@"32" extraInfo:@""];
            [weakSelf getUserInfoWithResult:result];
        }
    }];
}



//获取用户信息 picture用户头像
- (void)getUserInfoWithResult:(FBSDKLoginManagerLoginResult *)result{
    NSDictionary *params= @{@"fields":@"id,name,email,age_range,first_name,last_name,link,gender,locale,picture,timezone,updated_time,verified"};
    WEAKSELF
    FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc] initWithGraphPath:result.token.userID
                                                                   parameters:params
                                                                   HTTPMethod:@"GET"];
    [request startWithCompletion:^(id<FBSDKGraphRequestConnecting>  _Nullable connection, id  _Nullable result, NSError * _Nullable error) {
        NSLog(@"faceBook 详细信息%@-----------------",result);
//        {
//            email = "windycheng@aliyun.com";
//            "first_name" = "\U8f69\U8f0a";
//            id = 112054541148072;
//            "last_name" = "\U7a0b";
//            name = "\U7a0b\U8f69\U8f0a";
//            picture =     {
//                data =         {
//                    height = 50;
//                    "is_silhouette" = 0;
//                    url = "https://platform-lookaside.fbsbx.com/platform/profilepic/?asid=112054541148072&height=50&width=50&ext=1639217835&hash=AeSBg0gl7v_QLZ_T3cg";
//                    width = 50;
//                };
//            };
        if (error) {
            [weakSelf thirdLoginWithToken:weakSelf.token userId:weakSelf.userId thirdType:@"32" extraInfo:@"" context:nil];
        }else{
            NSDictionary *dict = (NSDictionary *)result;
            if ([dict isKindOfClass:[NSDictionary class]] && dict && [dict.allKeys containsObject:@"email"]) {
                weakSelf.accountInfo = dict[@"email"];
                [weakSelf thirdLoginWithToken:weakSelf.token userId:weakSelf.userId thirdType:@"32" extraInfo:dict[@"email"] context:nil];
            }else{
                weakSelf.accountInfo = weakSelf.userId;
                [weakSelf thirdLoginWithToken:weakSelf.token userId:weakSelf.userId thirdType:@"32" extraInfo:@"" context:nil];
            }
        }
    }];
  
//    [request startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
//                        NSLog(@"%@",result);
//        /*
//         {
//         "age_range" =     {
//         min = 21;
//         };
//         "first_name" = "\U6dd1\U5a1f";
//         gender = female;
//         id = 320561731689112;
//         "last_name" = "\U6f58";
//         link = "https://www.facebook.com/app_scoped_user_id/320561731689112/";
//         locale = "zh_CN";
//         name = "\U6f58\U6dd1\U5a1f";
//         picture =     {
//         data =         {
//         "is_silhouette" = 0;
//         url = "https://fb-s-c-a.akamaihd.net/h-ak-fbx/v/t1.0-1/p50x50/18157158_290358084709477_3057447496862917877_n.jpg?oh=01ba6b3a5190122f3959a3f4ed553ae8&oe=5A0ADBF5&__gda__=1509731522_7a226b0977470e13b2611f970b6e2719";
//         };
//         };
//         timezone = 8;
//         "updated_time" = "2017-04-29T07:54:31+0000";
//         verified = 1;
//         }
//         */
//    }];

}


/*
- (void)loginTwitter {
    WEAKSELF;
   // [MSUIConfiguration sh_showBlackLoadingHudToView:view.view];
    UIViewController *view = [OEMRouterHandler getCurrentViewController];
    WEAKIFY_OBJECT(view);
    [[Twitter sharedInstance] logInWithViewController:view completion:^(TWTRSession * _Nullable session, NSError * _Nullable error) {
        if (session) {
            NSString *token = session.authToken?:@"";
            NSString *userId = session.userID?:@"";
            NSString *tokenSecret = session.authTokenSecret?:@"";
            
           TWTRAPIClient *client = [[TWTRAPIClient alloc] initWithUserID:userId];
//            [client loadUserWithID:userId completion:^(TWTRUser * _Nullable user, NSError * _Nullable error) {
//                block(userId,user.profileURL.absoluteString);
//            }];
       
           
            [client requestEmailForCurrentUser:^(NSString * _Nullable email, NSError * _Nullable error) {
                NSLog(@"推特邮箱:%@",email);
            }];
            
            
            [weakSelf thirdLoginWithToken:token userId:[NSString stringWithFormat:@"%@&%@",userId,tokenSecret] thirdType:@"89" extraInfo:@"" context:nil];
        } else {
            if (error.code == 1) {
               // thirdLoginCompletion([MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeThirdLoginCancel]);
                MSBusinessError *errors = [MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeThirdLoginCancel];
                [MSUIConfiguration sh_showBlackToastHudToView:weakview.view text:errors.localizedDescription];
                if (weakSelf.completion){
                    weakSelf.completion(NO,@"");
                }
            }else{
               // thirdLoginCompletion([MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeThirdLoginError]);
                MSBusinessError *errors = [MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeThirdLoginError];
                [MSUIConfiguration sh_showBlackToastHudToView:weakview.view text:errors.localizedDescription];
                if (weakSelf.completion){
                    weakSelf.completion(NO,@"");
                }
            }
        }
    }];
}
 */


//thirdType用于区分登录平台，facebook是32 Twitter是89 apple是79
- (void)thirdLoginWithToken:(NSString *)accessToken
                     userId:(NSString *)userId
                  thirdType:(NSString *)thirdType
                  extraInfo:(NSString *)extraInfo
                    context:(NSDictionary *)context{
    WEAKSELF
    UIViewController *view = [OEMRouterHandler getCurrentViewController];
    [MSUIConfiguration sh_showBlackLoadingHudToView:view.view];
    WEAKIFY_OBJECT(view);
    
    [self.loginModel userThirdBindWithToken:accessToken
                                     userId:userId
                                  thirdType:thirdType
                                  extraInfo:extraInfo
                                    context:context
                                    success:^{
        [MSUIConfiguration sh_hideAllHudForView:weakview.view animated:YES];
     if (weakSelf.completion){
         weakSelf.completion(YES, weakSelf.accountInfo);
     }
        
    }
                                    failure:^(MSBusinessError *error) {
        [MSUIConfiguration sh_hideAllHudForView:weakview.view animated:YES];
        [MSUIConfiguration sh_showBlackToastHudToView:weakview.view text:error.localizedDescription];
        if (weakSelf.completion){
            weakSelf.completion(NO,@"");
        }
    }];
    
}




@end
