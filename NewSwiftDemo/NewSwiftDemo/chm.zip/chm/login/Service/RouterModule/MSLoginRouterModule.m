//
//  MSLoginRouterModule.m
//  MSLogin
//
//  Created by syp on 2020/6/11.
//

#import "MSLoginRouterModule.h"
#import <DolphinRouter/OEMRouter.h>
#import <MSBusiness/MSRouterUrl.h>
#import "MSLoginMainViewController.h"
#import "MSRegistMainViewController.h"
#import "MSCountrySelectViewController.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>
//#import <TwitterKit/TWTRKit.h>
#import <MSBusiness/MSAppInfo.h>
#import <MSBusiness/MSNotificationConst.h>
#import "MSLoginUtils.h"
#import "MSLoginService.h"

@DOFModule(MSLoginRouterModule)
@interface MSLoginRouterModule()<OEMModuleProtocol>

@end

@implementation MSLoginRouterModule

- (NSInteger)modulePriority {
    return 2;
}

- (void)modInit:(OEMContext *)context {
    [OEMRouter registerWithURL:MSRouterCountryIndex toClass:@"MSCountrySelectViewController"];
    [OEMRouter registerWithURL:MSRouterLoginIndex toClass:@"MSLoginMainViewController"];
    [OEMRouter registerWithURL:MSRouterRegistIndex toClass:@"MSRegistMainViewController"];
    
    
    [OEMRouter registerWithURL:MSRouterRegistIndex toHandler:^(UIViewController *sourceCtl, NSDictionary *routerParameters) {
        BOOL isFromRN = NO;
        NSString *email = @"";
        if (routerParameters && [routerParameters isKindOfClass:[NSDictionary class]]) {
            if (routerParameters[@"isFromRN"]) {
                isFromRN = [routerParameters[@"isFromRN"] boolValue];
            }
            
            if (routerParameters[@"email"]) {
                email = routerParameters[@"email"];
            }
        }
        if (sourceCtl.navigationController) {
            MSRegistMainViewController *dest = [MSRegistMainViewController new];
            dest.isFromRN = isFromRN;
            dest.email = email;
            [sourceCtl.navigationController pushViewController:dest animated:YES];
        }
    }];
    
    
    

    [OEMRouter registerWithURL:MSRouterCountryIndex toHandler:^(UIViewController *sourceCtl, NSDictionary *routerParameters) {
        NSInteger enterType = 1;
        BOOL isForAuthorize = NO;
        void(^clickLeftButtonBlock)(void) = nil;
        if (routerParameters && [routerParameters isKindOfClass:[NSDictionary class]]) {
            if (routerParameters[@"enterType"]) {
                enterType = [routerParameters[@"enterType"] integerValue];
            }
            if (routerParameters[@"clickLeftButtonBlock"]) {
                clickLeftButtonBlock = routerParameters[@"clickLeftButtonBlock"];
            }
            if (routerParameters[@"isForAuthorize"]) {
                isForAuthorize = [routerParameters[@"isForAuthorize"] boolValue];
            }
        }
        if (sourceCtl.navigationController) {
            MSCountrySelectViewController* countryController = [MSCountrySelectViewController new];
            countryController.enterType = enterType;
            countryController.clickLeftButtonBlock = clickLeftButtonBlock;
            countryController.isForAuthorize = isForAuthorize;
            [sourceCtl.navigationController pushViewController:countryController animated:YES];
        }
        
    }];
    
    [OEMRouter registerWithURL:MSRouterLoginIndex toHandler:^(UIViewController *sourceCtl, NSDictionary *routerParameters) {
        
        BOOL isDevice = NO;
        NSString *previousPageName = nil;
        BOOL isLoginExpired = NO;
        BOOL isForAuthorize = NO;
        void(^clickLeftButtonBlock)(void) = nil;
        void(^viewControllerSuccessBlock)(void) = nil;
        if (routerParameters && [routerParameters isKindOfClass:[NSDictionary class]]) {
            if (routerParameters[@"isDevice"]) {
                isDevice = [routerParameters[@"isDevice"] boolValue];
            }
            if (routerParameters[@"previousPageName"]) {
                previousPageName = routerParameters[@"previousPageName"];
            }
            if (routerParameters[@"isLoginExpired"]) {
                isLoginExpired = [routerParameters[@"isLoginExpired"] boolValue];
            }
            if (routerParameters[@"clickLeftButtonBlock"]) {
                clickLeftButtonBlock = routerParameters[@"clickLeftButtonBlock"];
            }
            
            if (routerParameters[@"viewControllerSuccessBlock"]) {
                viewControllerSuccessBlock = routerParameters[@"viewControllerSuccessBlock"];
            }
            
            if (routerParameters[@"isForAuthorize"]) {
                isForAuthorize = [routerParameters[@"isForAuthorize"] boolValue];
            }
        }
        if (!sourceCtl) {
            sourceCtl = [OEMRouterHandler getCurrentViewController];
        }
        if (sourceCtl.navigationController) {
            CATransition* transition = [CATransition animation];
            transition.duration = 0.25f;
            transition.type = kCATransitionMoveIn;
            transition.subtype = kCATransitionFromTop;
            
            MSLoginMainViewController* loginController = [MSLoginMainViewController new];
            loginController.isDevice = isDevice;
            loginController.previousPageName = previousPageName;
            loginController.isLoginExpired = isLoginExpired;
            loginController.clickLeftButtonBlock = clickLeftButtonBlock;
            loginController.viewControllerSuccessBlock = viewControllerSuccessBlock;
            loginController.isForAuthorize = isForAuthorize;
//            loginController.hidesBottomBarWhenPushed = YES;
            [sourceCtl.navigationController.view.layer addAnimation:transition forKey:kCATransition];
            [sourceCtl.navigationController pushViewController:loginController animated:NO];
        }        
    }];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        //1.1.1暂时屏蔽Facebook login，后续打开时，需要在同意隐私确认后，才进行初始化
        //[[FBSDKApplicationDelegate sharedInstance] application:context.application didFinishLaunchingWithOptions:context.launchOptions];
    });
    
  //  [[Twitter sharedInstance] startWithConsumerKey:[MSAppInfo getTwitterConsumerKey] consumerSecret:[MSAppInfo getTwitterConsumerSecret]];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [[FBSDKApplicationDelegate sharedInstance] application:context.application didFinishLaunchingWithOptions:context.launchOptions];
        });
        [self refreshCountryName];
    });
#if AppStore_ENV==0
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onInnerToolsLanguageUpdate:) name:@"InnerToolsLanguagePluginUpdateLanguageNotification" object:nil];
#endif
}

#if AppStore_ENV==0
- (void)onInnerToolsLanguageUpdate:(NSNotification *)notification{
    HGLanguage *language = [HGLanguage new];
    language.name = [notification.object objectForKey:@"language"];
    NSString *code = [notification.object objectForKey:@"language"];
    code = [[HGInternationalization sharedInstance] convertUnifyLanguangeCodeToSystemLanguangeCode:code];
    language.code = code;
    id<MSLoginProtocol> loginService = [OEMRouter getServiceInstance:@protocol(MSLoginProtocol)];
    HGCurrentLanguage = language;
    return;
    [loginService performSettingLanguage:language.name completion:^(BOOL success) {
        
        if (success) {
            
        }else{
            
        }
    }];
}
#endif

//防止更改了手机系统的语言，但是App内的国家还没更新
- (void)refreshCountryName {
    [[MSLoginService new] updateCountryNameAfterChangeLanguage];
}

//- (void)modSplash:(DOFContext *)context {
//    [[FBSDKApplicationDelegate sharedInstance] application:context.application didFinishLaunchingWithOptions:context.launchOptions];
////    [[Twitter sharedInstance] startWithConsumerKey:[MSAppInfo getTwitterConsumerKey] consumerSecret:[MSAppInfo getTwitterConsumerSecret]];
//}

- (id)modOpenURL:(OEMContext *)context {
    return @([[FBSDKApplicationDelegate sharedInstance] application:context.application openURL:context.openURLItem.openURL sourceApplication:context.openURLItem.sourceApplication annotation:context.openURLItem.annotation]);

//    if ([context.openURLItem.openURL.absoluteString hasPrefix:@"twitterkit"]) {
//        return @([[Twitter sharedInstance] application:context.application openURL:context.openURLItem.openURL options:context.openURLItem.options]);
//    }else{
//        return @([[FBSDKApplicationDelegate sharedInstance] application:context.application openURL:context.openURLItem.openURL sourceApplication:context.openURLItem.sourceApplication annotation:context.openURLItem.annotation]);
//    }
}

@end




 
