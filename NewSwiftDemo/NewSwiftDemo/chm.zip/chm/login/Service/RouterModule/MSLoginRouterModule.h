//
//  MSLoginRouterModule.h
//  MSLogin
//
//  Created by syp on 2020/6/11.
//

#import <Foundation/Foundation.h>


@interface MSLoginRouterModule : NSObject

@end

