//
//  MSLoginPresenter.h
//  MSLogin
//
//  Created by syp on 2020/6/13.
//

#import <MSBusiness/MVPPresenter.h>
#import <MSBusiness/MSBusinessError.h>

@class MSLoginPresenter;
@protocol MSLoginViewProtocol <MVPViewProtocol>

- (void)presenter:(MSLoginPresenter *)presenter didEnableShowDeleteButton:(BOOL)enable;
- (void)presenter:(MSLoginPresenter *)presenter didEnableLogin:(BOOL)enable;
- (void)presenter:(MSLoginPresenter *)presenter loginCompletion:(MSBusinessError *)error;
- (void)presenter:(MSLoginPresenter *)presenter thirdLoginCompletion:(MSBusinessError *)error;

@end


@interface MSLoginPresenter : MVPPresenter<id<MSLoginViewProtocol>>

@property (nonatomic, strong) NSString *email;   //登录的邮箱

@property (nonatomic, strong) NSString *account;   //登录的账号
@property (nonatomic, strong) NSString *password;   //登录的密码


@property (nonatomic, readonly) NSString *userId;   //第三方登录获取的userId
@property (nonatomic, readonly) NSString *thirdType;      //接口需要用于区分第三方登录平台  facebook是32 Twitter是89
@property (nonatomic, readonly) NSString *taccessToken;   //第三方登录获取的token

@property (nonatomic, readonly)NSString *accountInfo;    //第三方登录额外信息，邮箱或userId


- (void)login;

- (void)loginFacebook;
- (void)loginTwitter;
- (void)loginApple;

@end

