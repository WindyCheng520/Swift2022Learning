//
//  MSRegistPresenter.m
//  MSLogin
//
//  Created by syp on 2020/6/25.
//

#import "MSRegistPresenter.h"
#import "MSRegistModel.h"
#import "MSLoginBundle.h"
#import "MSLoginError.h"
#import "MSLoginUtils.h"
#import <OEMFoundation/OEMGCDTimer.h>
#import "MSSetPasswordPresenter.h"
#import <OEMFoundation/HGInternationalization.h>
#import "MSLoginUtils.h"

static const NSInteger totalTimer = 60;


@interface MSRegistPresenter ()

@property (nonatomic, strong) MSRegistModel *registModel;

@property (nonatomic, assign) BOOL enableGetVerifyCode;
@property (nonatomic, assign) BOOL enableVerifyCodeAuth;

@property (nonatomic, strong) OEMGCDTimer *countDownTimer;
@property (nonatomic, assign) NSInteger currentCount;
@property (nonatomic, copy) NSString *startTime;

@end

@implementation MSRegistPresenter

- (MSRegistModel *)registModel {
    if (!_registModel) {
        _registModel = [MSRegistModel new];
    }
    return _registModel;
}

- (void)getVerifyCode {
    
    if(!self.isNeedVerifyAccount){
        [self sendVerifyCode];
        return;
    }
    @weakify(self)
    void(^getVerifyCodeCompletion)(MSBusinessError *error) = ^(MSBusinessError *error) {
        @strongify(self)
        if([self.view respondsToSelector:@selector(presenter:getVerifyCodeCompletion:)]) {
            [self.view presenter:self getVerifyCodeCompletion:error];
        }
    };
    
    BOOL isEmail = [MSLoginUtils isValidEmail:self.account]; //是否邮箱
    BOOL isNumber = [MSLoginUtils checkInputShouldNumber:self.account];
    if (!isEmail && !isNumber){ //非邮箱非电话号码
        MSBusinessError *error = [MSLoginUtils checkEmail:self.account];
        if (error) {
            getVerifyCodeCompletion(error);
            return;
        }
    }
    [self.view showLoading];
    NSString *account = isEmail?self.account:[NSString stringWithFormat:@"%@%@", HGCurrentCountry.phoneCode, self.account];
    
    //先验证账号是否存在
    [self.registModel userAuthExistWithAccount:account success:^{
        @strongify(self)
        [self sendVerifyCode];
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        [self.view hideLoading];
        getVerifyCodeCompletion(error);
    }];
    
}

//发送验证码
- (void)sendVerifyCode {
    @weakify(self)
    void(^getVerifyCodeCompletion)(MSBusinessError *error) = ^(MSBusinessError *error) {
        @strongify(self)
        if([self.view respondsToSelector:@selector(presenter:getVerifyCodeCompletion:)]) {
            [self.view presenter:self getVerifyCodeCompletion:error];
        }
    };
    NSString *type = self.isNeedVerifyAccount?@"1":@"5";  //1. 注册    5.注销账号
    if(!self.isNeedVerifyAccount){
        [self.view showLoading];
    }
    
    BOOL isEmail = [MSLoginUtils isValidEmail:self.account]; //是否邮箱
    NSString *userFlag = isEmail?@"0":@"1";      //0:邮箱   1：手机号
    NSString *receiver = isEmail?self.account:[NSString stringWithFormat:@"%@%@", HGCurrentCountry.phoneCode, self.account];
    [self.registModel userVerifyCodeGetWithVerifyIdReceiver:receiver type:type userFlag:userFlag success:^{
        @strongify(self)
        [self.view hideLoading];
        getVerifyCodeCompletion(nil);
        [self startGetVerifyCodeCountDown];
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        [self.view hideLoading];
        getVerifyCodeCompletion(error);
    }];
    
}

- (void)startGetVerifyCodeCountDown {
    self.currentCount = totalTimer;
    self.startTime = [MSLoginUtils getCurrentSystemTime];
    @weakify(self)
    void(^updateGetVerifyCodeCountDown)(void) = ^() {
        @strongify(self)
        if ([self.view respondsToSelector:@selector(presenter:updateGetVerifyCodeCountDown:)]) {
            [self.view presenter:self updateGetVerifyCodeCountDown:self.currentCount];
        }
    };
    
    updateGetVerifyCodeCountDown();
    self.countDownTimer = [OEMGCDTimer scheduleTimer:1 actionBlock:^{
        @strongify(self)
        self.currentCount -= 1;
        updateGetVerifyCodeCountDown();
        if (self.currentCount == 0) {
            [self.countDownTimer stop];
            self.countDownTimer = nil;
        }
    } willRepeat:YES];
}

- (void)verifyCodeAuth {
    @weakify(self)
    void(^verifyCodeAuthCompletion)(MSBusinessError *error) = ^(MSBusinessError *error) {
        @strongify(self)
        if([self.view respondsToSelector:@selector(presenter:verifyCodeAuthCompletion:)]) {
            [self.view presenter:self verifyCodeAuthCompletion:error];
        }
    };
    
    BOOL isEmail = [MSLoginUtils isValidEmail:self.account]; //是否邮箱
    NSString *receiver = isEmail?self.account:[NSString stringWithFormat:@"%@%@", HGCurrentCountry.phoneCode, self.account];
    
    BOOL isNumber = [MSLoginUtils checkInputShouldNumber:self.account];
    if (!isEmail && !isNumber){ //非邮箱非电话号码
        MSBusinessError *emailError = [MSLoginUtils checkEmail:self.account];
        if (emailError) {
            verifyCodeAuthCompletion(emailError);
            return;
        }
    }
 
    MSBusinessError *codeError = [MSLoginUtils checkVerifyCode:self.verifyCode];
    if (codeError) {
        verifyCodeAuthCompletion(codeError);
        return;
    }
    
    [self.view showLoading];
    [self.registModel userVerifyCodeAuthWithverifyIdReceiver:receiver verifyCode:self.verifyCode success:^(MSVerifyCodeAuthResult *result) {
        @strongify(self)
        [self.view hideLoading];
        self.verifyId = result.verifyId;
        verifyCodeAuthCompletion(nil);
        
        //邮箱验证成功，重置计时器
//        [self resetTimer];
        
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        [self.view hideLoading];
        verifyCodeAuthCompletion(error);
    }];
}


- (void)userUnregister{
    @weakify(self)
    void(^userUnregisterCompletion)(MSBusinessError *error) = ^(MSBusinessError *error) {
        @strongify(self)
        if([self.view respondsToSelector:@selector(presenter:userUnregisterCompletion:)]) {
            [self.view presenter:self userUnregisterCompletion:error];
        }
    };
    
    BOOL isEmail = [MSLoginUtils isValidEmail:self.account]; //是否邮箱
    NSString *receiver = isEmail?self.account:[NSString stringWithFormat:@"%@%@", HGCurrentCountry.phoneCode, self.account];
    
    [self.view showLoading];
    [self.registModel userUnRegisterWithVerifyIdReceiver:receiver
                                              verifyCode:self.verifyCode
                                                 success:^{
        @strongify(self)
        [self.view hideLoading];
        userUnregisterCompletion(nil);
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        [self.view hideLoading];
        userUnregisterCompletion(error);
    }];
}


- (void)resetTimer {
    [self.countDownTimer stop];
    self.countDownTimer = nil;
    if ([self.view respondsToSelector:@selector(presenter:updateGetVerifyCodeCountDown:)]) {
        [self.view presenter:self updateGetVerifyCodeCountDown:0];
    }
}

- (void)applicationWillEnterForeground:(NSNotification *)notification {
    if (self.countDownTimer.isValid && self.startTime) {
        NSString *currentTimeStr = [MSLoginUtils getCurrentSystemTime];
        self.currentCount = totalTimer - (currentTimeStr.integerValue - self.startTime.integerValue);
        if (self.currentCount <= 0) {
           self.currentCount = 0;
           [self.countDownTimer stop];
           self.countDownTimer = nil;
        }
        if ([self.view respondsToSelector:@selector(presenter:updateGetVerifyCodeCountDown:)]) {
           [self.view presenter:self updateGetVerifyCodeCountDown:self.currentCount];
        }
    }
}


-(void)setAccount:(NSString *)account{
    _account = account;
    self.enableGetVerifyCode = self.account.length > 0;
    self.enableVerifyCodeAuth = self.account.length > 0 && self.verifyCode.length > 0;
}

//- (void)setEmail:(NSString *)email {
//    _email = email;
//
//    self.enableGetVerifyCode = self.email.length > 0;
//    self.enableVerifyCodeAuth = self.email.length > 0 && self.verifyCode.length > 0;
//}

- (void)setVerifyCode:(NSString *)verifyCode {
    _verifyCode = verifyCode;
    self.enableVerifyCodeAuth = self.account.length > 0 && self.verifyCode.length > 0;
}

- (void)setEnableGetVerifyCode:(BOOL)enableGetVerifyCode {
    if (_enableGetVerifyCode == enableGetVerifyCode) {
        return;
    }

    _enableGetVerifyCode = enableGetVerifyCode;

    if ([self.view respondsToSelector:@selector(presenterDidEnableGetVerifyCode:)]) {
        [self.view presenterDidEnableGetVerifyCode:self];
    }
}

- (void)setEnableVerifyCodeAuth:(BOOL)enableVerifyCodeAuth {
    if (_enableVerifyCodeAuth == enableVerifyCodeAuth) {
        return;
    }
    
    _enableVerifyCodeAuth = enableVerifyCodeAuth;
    
    if ([self.view respondsToSelector:@selector(presenterDidEnableVerifyCodeAuth:)]) {
        [self.view presenterDidEnableVerifyCodeAuth:self];
    }
}

@end
