//
//  MSRegistPresenter.h
//  MSLogin
//
//  Created by syp on 2020/6/25.
//

#import <MSBusiness/MVPPresenter.h>
#import <MSBusiness/MSBusinessError.h>


@class MSRegistPresenter;
@class MSSetPasswordPresenter;
@protocol MSRegistViewProtocol <MVPViewProtocol>

- (void)presenterDidEnableGetVerifyCode:(MSRegistPresenter *)presenter;
- (void)presenter:(MSRegistPresenter *)presenter updateGetVerifyCodeCountDown:(NSUInteger)count;
- (void)presenterDidEnableVerifyCodeAuth:(MSRegistPresenter *)presenter;

- (void)presenter:(MSRegistPresenter *)presenter verifyCodeAuthCompletion:(MSBusinessError *)error;
- (void)presenter:(MSRegistPresenter *)presenter getVerifyCodeCompletion:(MSBusinessError *)error;

- (void)presenter:(MSRegistPresenter *)presenter userUnregisterCompletion:(MSBusinessError *)error;

@end

@interface MSRegistPresenter : MVPPresenter<id<MSRegistViewProtocol>>

@property (nonatomic, strong) NSString *account;       //账号（邮箱或手机号）


//@property (nonatomic, strong) NSString *email;
@property (nonatomic, strong) NSString *verifyCode;       //首次获取的验证码
@property (nonatomic, strong) NSString *verifyId;         //注册用新验证码
@property (nonatomic, assign) BOOL isNeedVerifyAccount;    //是否需要校验账号存在

@property (nonatomic, readonly) BOOL enableGetVerifyCode;
@property (nonatomic, readonly) BOOL enableVerifyCodeAuth;

//获取账号验证码
- (void)getVerifyCode;

- (void)verifyCodeAuth;

- (void)applicationWillEnterForeground:(NSNotification *)notification;

- (void)resetTimer;

- (void)userUnregister;

@end

