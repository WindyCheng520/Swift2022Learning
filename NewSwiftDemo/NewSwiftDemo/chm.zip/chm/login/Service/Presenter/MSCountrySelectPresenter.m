//
//  MSCountrySelectPresenter.m
//  MSLogin
//
//  Created by 及时行乐 on 2020/7/10.
//

#import "MSCountrySelectPresenter.h"
#import <OEMFoundation/HGInternationalization.h>
#import <MSBusiness/MSDeviceProtocol.h>
#import <MSBusiness/MSUserInfoManager.h>

@interface MSCountrySelectPresenter ()

@property (nonatomic, strong) MSCountrySelectModel *countrySelectModel;
@property (nonatomic, strong) NSArray<MSCountryGetResult *> *countryArray;
@property (nonatomic, strong) NSArray *showDataArray;
@property (nonatomic, strong) MSCountryGetResult *selectCountry;

@end

@implementation MSCountrySelectPresenter

- (MSCountrySelectModel *)countrySelectModel {
    if (!_countrySelectModel) {
        _countrySelectModel = [MSCountrySelectModel new];
    }
    return _countrySelectModel;
}

- (void)getCountryData {
    if (HGCurrentCountry) {
        self.selectCountry = [MSCountryGetResult new];
        self.selectCountry.countryCode = HGCurrentCountry.code;
        self.selectCountry.area = HGCurrentCountry.name;
    }
    
    WEAK_SELF;
    void(^getCountryCompletion)(MSBusinessError *error) = ^(MSBusinessError *error) {
        if([weak_self.view respondsToSelector:@selector(presenter:getCountryCompletion:)]) {
            [weak_self.view presenter:weak_self getCountryCompletion:error];
        }
    };
    
    [self.view showLoading];
    
    [self.countrySelectModel userGetCountryDataSuccess:^(NSArray<MSCountryGetResult *> *result) {
        [self.view hideLoading];
        self.countryArray = result;
        self.showDataArray = result;
        getCountryCompletion(nil);
    } failure:^(MSBusinessError *error) {
        [self.view hideLoading];
        getCountryCompletion(error);
    }];
    
}

- (void)setCountryData:(MSCountryGetResult *)country {
    self.selectCountry = country;
    
    HGCountry *currentCountry = [HGCountry new];
    currentCountry.code = country.countryCode?:@"";
    currentCountry.name = country.area?:@"";
    currentCountry.url = country.url?:@"";
    currentCountry.phoneCode = country.phoneCode?:@"";
    currentCountry.mqttBroker = country.mqttBroker?:@"";
    [HGInternationalization sharedInstance].currentCountry = currentCountry;
    
    if(ISLOGIN){
        NSDictionary *dict = @{@"countryCode": country.countryCode};
        [[NSNotificationCenter defaultCenter] postNotificationName:MSInternationalizationDidUpdateCountryNotification object:dict];
    }
    
//    //这里添加刷新信道
//    id<MSDeviceProtocol> service = [DOFRouter getServiceInstance:@protocol(MSDeviceProtocol)];
//    if ([service respondsToSelector:@selector(refreshCountryChannelRetrieveSuccess:failure:)]) {
//        [service refreshCountryChannelRetrieveSuccess:^{
//            //刷新信道成功
//        } failure:^(MSBusinessError *error) {
//            //刷新信道失败
//        }];
//    }
    
//    WEAK_SELF;
//    void(^setCountryCompletion)(MSBusinessError *error) = ^(MSBusinessError *error) {
//        if([weak_self.view respondsToSelector:@selector(presenter:setCountryCompletion:)]) {
//            [weak_self.view presenter:weak_self setCountryCompletion:error];
//        }
//    };
//    
//    [self.view showLoading];
//    [self.countrySelectModel userSetCountryDataWithCountryCode:country.code success:^{
//        [self.view hideLoading];
//        setCountryCompletion(nil);
//    } failure:^(MSBusinessError *error) {
//        [self.view hideLoading];
//        setCountryCompletion(error);
//    }];
    
}

- (void)searchCountryDataWithText:(NSString *)text {
    if (!text || [text isEqualToString:@""]) {
        self.showDataArray = self.countryArray;
    }else{
        NSMutableArray *resultArray = [NSMutableArray array];
        for (MSCountryGetResult *item in self.countryArray) {
            if ([item.area containsString:text]) {
                [resultArray addObject:item];
            }
        }
        self.showDataArray = [resultArray copy];
    }
    
    if ([self.view respondsToSelector:@selector(presenterDidSearchCountryData:)]) {
        [self.view presenterDidSearchCountryData:self];
    }
}


@end
