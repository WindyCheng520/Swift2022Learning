//
//  MSThirdLoginSetPasswordPresenter.h
//  MSLogin
//
//  Created by 及时行乐 on 2020/7/16.
//

#import <MSBusiness/MVPPresenter.h>
#import <MSBusiness/MSBusinessError.h>

@class MSThirdLoginSetPasswordPresenter;
@protocol MSThirdLoginSetPasswordViewProtocol <MVPViewProtocol>

- (void)presenter:(MSThirdLoginSetPasswordPresenter *)presenter registerCompletion:(MSBusinessError *)error;
- (void)presenter:(MSThirdLoginSetPasswordPresenter *)presenter didEnableRegiste:(BOOL)enable;
- (void)presenter:(MSThirdLoginSetPasswordPresenter *)presenter didPasswordInputEditingChanged:(BOOL)isPasswordInputEditing;
- (void)presenter:(MSThirdLoginSetPasswordPresenter *)presenter didConfirmInputEditingChanged:(BOOL)isConfirmInputEditing;
- (void)presenter:(MSThirdLoginSetPasswordPresenter *)presenter didLengthRightChanged:(BOOL)isLengthRight;
- (void)presenter:(MSThirdLoginSetPasswordPresenter *)presenter didRuleRightChanged:(BOOL)isRuleRight;
- (void)presenter:(MSThirdLoginSetPasswordPresenter *)presenter didConsistentChanged:(BOOL)isConsistent;

@end

@interface MSThirdLoginSetPasswordPresenter : MVPPresenter<id<MSThirdLoginSetPasswordViewProtocol>>

@property (nonatomic, strong) NSString *password;
@property (nonatomic, strong) NSString *confirmPassword;

@property (nonatomic, readonly) BOOL enableRegist;
@property (nonatomic, assign) BOOL isPasswordInputEditing;
@property (nonatomic, assign) BOOL isConfirmInputEditing;
@property (nonatomic, assign) BOOL isLengthRight;
@property (nonatomic, assign) BOOL isRuleRight;
@property (nonatomic, assign) BOOL isConsistent;

- (void)thirdLoginWithToken:(NSString *)accessToken
                     userId:(NSString *)userId
                    channel:(NSString *)channel
                   password:(NSString *)password
                   verifyId:(NSString *)verifyId
                    account:(NSString *)account
                accountInfo:(NSString *)accountInfo;


@end

