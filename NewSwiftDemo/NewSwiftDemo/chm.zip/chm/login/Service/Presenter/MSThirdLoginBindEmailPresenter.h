//
//  MSThirdLoginBindEmailPresenter.h
//  MSLogin
//
//  Created by 及时行乐 on 2020/7/16.
//

#import <MSBusiness/MVPPresenter.h>
#import <MSBusiness/MSBusinessError.h>

@class MSThirdLoginBindEmailPresenter;
@protocol MSThirdLoginBindEmailViewProtocol <MVPViewProtocol>

- (void)presenterDidEnableGetVerifyCode:(MSThirdLoginBindEmailPresenter *)presenter;
- (void)presenter:(MSThirdLoginBindEmailPresenter *)presenter updateGetVerifyCodeCountDown:(NSUInteger)count;
- (void)presenterDidEnableVerifyCodeAuth:(MSThirdLoginBindEmailPresenter *)presenter;

- (void)presenter:(MSThirdLoginBindEmailPresenter *)presenter verifyCodeAuthCompletion:(MSBusinessError *)error;
- (void)presenter:(MSThirdLoginBindEmailPresenter *)presenter getVerifyCodeCompletion:(MSBusinessError *)error;
- (void)presenter:(MSThirdLoginBindEmailPresenter *)presenter thirdLoginBindCompletion:(MSBusinessError *)error emailExist:(BOOL)emailExist;
- (void)presenter:(MSThirdLoginBindEmailPresenter *)presenter thirdLoginCompletion:(MSBusinessError *)error;

@end

@interface MSThirdLoginBindEmailPresenter : MVPPresenter<id<MSThirdLoginBindEmailViewProtocol>>

@property (nonatomic, strong) NSString *email;
@property (nonatomic, strong) NSString *account;  //账号
@property (nonatomic, strong) NSString *verifyCode;
@property (nonatomic, assign) BOOL isAccountExist;  //记录账号是否存在

@property (nonatomic, copy) NSString *channel;     //通道：

@property (nonatomic, copy) NSString *randomCode;   //验证验证码成功后返回，用于绑定邮箱接口参数


@property (nonatomic, readonly) BOOL enableGetVerifyCode;
@property (nonatomic, readonly) BOOL enableVerifyCodeAuth;

- (void)getVerifyCode;

- (void)verifyCodeAuth;


- (void)thirdLoginWithToken:(NSString *)accessToken
                     userId:(NSString *)userId
                    channel:(NSString *)channel
                   verifyId:(NSString *)verifyId
                    account:(NSString *)account
                accountInfo:(NSString *)accountInfo;

- (void)thirdLoginBindEmailWithUserId:(NSString*)userId thirdType:(NSString*)thirdType accessToken:(NSString *)accessToken;

- (void)applicationWillEnterForeground:(NSNotification *)notification;

- (void)resetTimer;


@end

