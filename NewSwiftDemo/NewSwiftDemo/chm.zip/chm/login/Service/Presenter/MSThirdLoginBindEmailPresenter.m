//
//  MSThirdLoginBindEmailPresenter.m
//  MSLogin
//
//  Created by 及时行乐 on 2020/7/16.
//

#import "MSThirdLoginBindEmailPresenter.h"
#import "MSThirdLoginModel.h"
#import "MSLoginBundle.h"
#import "MSLoginError.h"
#import "MSLoginUtils.h"
#import <OEMFoundation/OEMGCDTimer.h>
#import <OEMFoundation/OEMMacros.h>
#import <OEMFoundation/HGInternationalization.h>

static const NSInteger totalTimer = 60;

@interface MSThirdLoginBindEmailPresenter ()

@property (nonatomic, strong) MSThirdLoginModel *thirdLoginModel;
@property (nonatomic, assign) BOOL enableGetVerifyCode;
@property (nonatomic, assign) BOOL enableVerifyCodeAuth;


@property (nonatomic, strong) OEMGCDTimer *countDownTimer;
@property (nonatomic, assign) NSInteger currentCount;
@property (nonatomic, copy) NSString *startTime;

@end


@implementation MSThirdLoginBindEmailPresenter

-(MSThirdLoginModel *)thirdLoginModel{
    if (!_thirdLoginModel) {
        _thirdLoginModel = [MSThirdLoginModel new];
    }
    return _thirdLoginModel;
}

- (void)getVerifyCode{
    @weakify(self)
    
    BOOL isEmail = [MSLoginUtils isValidEmail:self.account]; //是否邮箱
    BOOL isNumber = [MSLoginUtils checkInputShouldNumber:self.account];
    if (!isEmail && !isNumber){ //非邮箱非电话号码
        MSBusinessError *error = [MSLoginUtils checkEmail:self.account];
        if (error) {
            if ([self.view respondsToSelector:@selector(presenter:getVerifyCodeCompletion:)]) {
                [self.view presenter:self getVerifyCodeCompletion:error];
            }
            return;
        }
    }
    [self.view showLoading];
    NSString *account = isEmail?self.account:[NSString stringWithFormat:@"%@%@", HGCurrentCountry.phoneCode, self.account];
    //先验证账号是否存在/不存在则发送验证码
    [self.thirdLoginModel userAuthExistWithAccount:account success:^{
        @strongify(self)
        [self sendEmailVerifyCode];
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        if (error.code == 14003) {   //已存在(邮箱已注册，也可以进行绑定）
            self.isAccountExist = YES;
            [self sendEmailVerifyCode];
        }else{
            self.isAccountExist = NO;
            [self sendEmailVerifyCode];
//            [self.view hideLoading];
//            if ([self.view respondsToSelector:@selector(presenter:getVerifyCodeCompletion:)]) {
//                [self.view presenter:self getVerifyCodeCompletion:error];
//            }
        }
    }];
    
}


//发送验证码(第三方账号登录绑定）
- (void)sendEmailVerifyCode{
    @weakify(self)
    
    BOOL isEmail = [MSLoginUtils isValidEmail:self.account]; //是否邮箱
    NSString *userFlag = isEmail?@"0":@"1";      //0:邮箱   1：手机号
    NSString *receiver = isEmail?self.account:[NSString stringWithFormat:@"%@%@", HGCurrentCountry.phoneCode, self.account];
    NSString *type = self.isAccountExist?@"4":@"1";
    [self.thirdLoginModel userVerifyCodeGetWithVerifyIdReceiver:receiver type:type userFlag:userFlag channel:self.channel success:^{
        @strongify(self)
        [self.view hideLoading];
        [self startGetVerifyCodeCountDown];
        if ([self.view respondsToSelector:@selector(presenter:getVerifyCodeCompletion:)]) {
            [self.view presenter:self getVerifyCodeCompletion:nil];
        }
    } failure:^(MSBusinessError *error) {
        [self.view hideLoading];
        if ([self.view respondsToSelector:@selector(presenter:getVerifyCodeCompletion:)]) {
            [self.view presenter:self getVerifyCodeCompletion:error];
        }
    }];
    
}


- (void)verifyCodeAuth {
    @weakify(self)
    void(^verifyCodeAuthCompletion)(MSBusinessError *error) = ^(MSBusinessError *error) {
        @strongify(self)
        if([self.view respondsToSelector:@selector(presenter:verifyCodeAuthCompletion:)]) {
            [self.view presenter:self verifyCodeAuthCompletion:error];
        }
    };
    
    BOOL isEmail = [MSLoginUtils isValidEmail:self.account]; //是否邮箱
    NSString *receiver = isEmail?self.account:[NSString stringWithFormat:@"%@%@", HGCurrentCountry.phoneCode, self.account];
    BOOL isNumber = [MSLoginUtils checkInputShouldNumber:self.account];
    if (!isEmail && !isNumber) { //非邮箱非电话号码
        
        MSBusinessError *emailError = [MSLoginUtils checkEmail:self.email];
        if (emailError) {
            verifyCodeAuthCompletion(emailError);
            return;
        }
    }
    MSBusinessError *codeError = [MSLoginUtils checkVerifyCode:self.verifyCode];
    if (codeError) {
        verifyCodeAuthCompletion(codeError);
        return;
    }
    
    [self.view showLoading];
    [self.thirdLoginModel userVerifyCodeAuthWithverifyIdReceiver:receiver verifyCode:self.verifyCode success:^(MSVerifyCodeAuthResult *result) {
        @strongify(self)
        [self.view hideLoading];
        self.verifyCode = result.verifyId;
        verifyCodeAuthCompletion(nil);
        
        //邮箱验证成功，重置计时器
//        [self resetTimer];
        
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        [self.view hideLoading];
        verifyCodeAuthCompletion(error);
    }];
}

- (void)thirdLoginWithToken:(NSString *)accessToken
                     userId:(NSString *)userId
                    channel:(NSString *)channel
                   verifyId:(NSString *)verifyId
                    account:(NSString *)account
                accountInfo:(NSString *)accountInfo{
    @weakify(self)
    void(^thirdLoginCompletion)(MSBusinessError *error) = ^(MSBusinessError *error) {
        @strongify(self)
        if([self.view respondsToSelector:@selector(presenter:thirdLoginCompletion:)]) {
            [self.view presenter:self thirdLoginCompletion:error];
        }
    };
    
//    MSBusinessError *error = [MSLoginUtils checkPassword:self.password confirmPassword:self.confirmPassword];
//    if (error) {
//        thirdLoginBindCompletion(error);
//        return;
//    }
    
    BOOL isEmail = [MSLoginUtils isValidEmail:account]; //是否邮箱
    NSString *countryCode = [HGInternationalization sharedInstance].currentCountry.code;
    NSString *phoneCode = [HGInternationalization sharedInstance].currentCountry.phoneCode;
    NSString *receiver = isEmail?account:[NSString stringWithFormat:@"%@%@", phoneCode, account];
    
   [self.view showLoading];
   [self.thirdLoginModel userThirdLoginWithToken:accessToken
                                           userId:userId
                                          channel:channel
                                         password:@""
                                         verifyId:verifyId
                                            email:isEmail?account:@""
                                    phoneAreacode:isEmail?@"":phoneCode
                                         userFlag:isEmail?@"0":@"1"
                                 verifyIdReceiver:receiver
                                           mobile:isEmail?@"":account
                                      countryCode:countryCode
                                        extraInfo:accountInfo
                                          success:^(MSLoginInfo *result) {
        @strongify(self)
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            // 需要延迟执行的代码
            [self.view hideLoading];
            thirdLoginCompletion(nil);
        });
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        [self.view hideLoading];
        thirdLoginCompletion(error);
    }];
    
}




- (void)startGetVerifyCodeCountDown{
    self.currentCount = totalTimer;
    self.startTime = [MSLoginUtils getCurrentSystemTime];
    if ([self.view respondsToSelector:@selector(presenter:updateGetVerifyCodeCountDown:)]) {
        [self.view presenter:self updateGetVerifyCodeCountDown:self.currentCount];
    }

    @weakify(self)
    self.countDownTimer = [OEMGCDTimer scheduleTimer:1 actionBlock:^{
        @strongify(self)
        self.currentCount -= 1;
        if ([self.view respondsToSelector:@selector(presenter:updateGetVerifyCodeCountDown:)]) {
            [self.view presenter:self updateGetVerifyCodeCountDown:self.currentCount];
        }
        if (self.currentCount == 0) {
            [self.countDownTimer stop];
            self.countDownTimer = nil;
        }
    } willRepeat:YES];
}



- (void)resetTimer {
    [self.countDownTimer stop];
    self.countDownTimer = nil;
    if ([self.view respondsToSelector:@selector(presenter:updateGetVerifyCodeCountDown:)]) {
        [self.view presenter:self updateGetVerifyCodeCountDown:0];
    }
}

- (void)applicationWillEnterForeground:(NSNotification *)notification {
    if (self.countDownTimer.isValid && self.startTime) {
        NSString *currentTimeStr = [MSLoginUtils getCurrentSystemTime];
        self.currentCount = totalTimer - (currentTimeStr.integerValue - self.startTime.integerValue);
        if (self.currentCount <= 0) {
           self.currentCount = 0;
           [self.countDownTimer stop];
           self.countDownTimer = nil;
        }
        if ([self.view respondsToSelector:@selector(presenter:updateGetVerifyCodeCountDown:)]) {
            [self.view presenter:self updateGetVerifyCodeCountDown:self.currentCount];
        }
    }
    
}

-(void)setAccount:(NSString *)account{
    _account = account;
    self.enableGetVerifyCode = self.account.length > 0;
    self.enableVerifyCodeAuth = self.account.length > 0 && self.verifyCode.length > 0;
}

//- (void)setEmail:(NSString *)email{
//    _email = email;
//
//    self.enableGetVerifyCode = self.email.length > 0;
//    self.enableVerifyCodeAuth = self.email.length > 0 && self.verifyCode.length > 0;
//}

- (void)setVerifyCode:(NSString *)verifyCode
{
    _verifyCode = verifyCode;
    
    self.enableVerifyCodeAuth = self.account.length > 0 && self.verifyCode.length > 0;
}

- (void)setEnableGetVerifyCode:(BOOL)enableGetVerifyCode
{
    if (_enableGetVerifyCode == enableGetVerifyCode) {
        return;
    }

    _enableGetVerifyCode = enableGetVerifyCode;

    if ([self.view respondsToSelector:@selector(presenterDidEnableGetVerifyCode:)]) {
        [self.view presenterDidEnableGetVerifyCode:self];
    }
}

- (void)setEnableVerifyCodeAuth:(BOOL)enableVerifyCodeAuth
{
    if (_enableVerifyCodeAuth == enableVerifyCodeAuth) {
        return;
    }
    
    _enableVerifyCodeAuth = enableVerifyCodeAuth;
    
    if ([self.view respondsToSelector:@selector(presenterDidEnableVerifyCodeAuth:)]) {
        [self.view presenterDidEnableVerifyCodeAuth:self];
    }
}

@end
