//
//  MSCountrySelectPresenter.h
//  MSLogin
//
//  Created by 及时行乐 on 2020/7/10.
//

#import <MSBusiness/MVPPresenter.h>
#import <MSBusiness/MSBusinessError.h>
#import "MSCountrySelectModel.h"


@class MSCountrySelectPresenter;
@protocol MSCountrySelectViewProtocol <MVPViewProtocol>

- (void)presenter:(MSCountrySelectPresenter *)presenter getCountryCompletion:(MSBusinessError *)error;
- (void)presenter:(MSCountrySelectPresenter *)presenter setCountryCompletion:(MSBusinessError *)error;
- (void)presenterDidSearchCountryData:(MSCountrySelectPresenter *)presenter;

@end

@interface MSCountrySelectPresenter : MVPPresenter<id<MSCountrySelectViewProtocol>>

@property (nonatomic, readonly) NSArray<MSCountryGetResult *> *countryArray;
@property (nonatomic, readonly) MSCountryGetResult *selectCountry;
@property (nonatomic, readonly) NSArray *showDataArray;


- (void)getCountryData;
- (void)setCountryData:(MSCountryGetResult *)country;
- (void)searchCountryDataWithText:(NSString *)text;

@end

