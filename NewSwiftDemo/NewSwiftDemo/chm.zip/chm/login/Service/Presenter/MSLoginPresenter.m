//
//  MSLoginPresenter.m
//  MSLogin
//
//  Created by syp on 2020/6/13.
//

#import "MSLoginPresenter.h"
#import "MSLoginModel.h"
#import "MSLoginUtils.h"
#import "MSLoginBundle.h"
#import <MSBusiness/MSUserDefaultTools.h>
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import "MSLoginError.h"
#import "MSRegistPresenter.h"
//#import <TwitterKit/TWTRKit.h>
#import <AuthenticationServices/AuthenticationServices.h>
#import <MJExtension/MJExtension.h>
#import <MSBusiness/MSUserInfoManager.h>
#import "MSLoginUtils.h"
#import <MSBusiness/MSBusiness-Swift.h>

@interface MSLoginPresenter ()<ASAuthorizationControllerDelegate,ASAuthorizationControllerPresentationContextProviding>

@property (nonatomic, strong) MSLoginModel *loginModel;
@property (nonatomic, assign) BOOL enableLogin;

@property (nonatomic, copy) NSString *userId;
@property (nonatomic, copy) NSString *thirdType;
@property (nonatomic, copy) NSString *taccessToken;

@property (nonatomic, copy)NSString *accountInfo;


@end

@implementation MSLoginPresenter

- (MSLoginModel *)loginModel {
    if (!_loginModel) {
        _loginModel = [MSLoginModel new];
    }
    return _loginModel;
}

#pragma mark - 账号密码登录
- (void)login{
    
    WEAK_SELF;
    void(^loginCompletion)(MSBusinessError *error) = ^(MSBusinessError *error) {
        if([weak_self.view respondsToSelector:@selector(presenter:loginCompletion:)]) {
            [weak_self.view presenter:weak_self loginCompletion:error];
        }
    };
    
   
    BOOL isEmail = [MSLoginUtils isValidEmail:self.account]; //是否邮箱
    //NSString *userFlag = isEmail?@"0":@"1";      //0:邮箱   1：手机号
  //  NSString *receiver = isEmail?self.account:[NSString stringWithFormat:@"%@%@", HGCurrentCountry.phoneCode, self.account];
    
    BOOL isNumber = [MSLoginUtils checkInputShouldNumber:self.account];
    if (!isEmail && !isNumber) { //非邮箱非电话号码
        MSBusinessError *error = [MSLoginUtils checkEmail:self.account];
        if (error) {
            loginCompletion(error);
            return;
        }
    }
    
    [self.view showLoading];
    [self.loginModel userLoginWithAccount:self.account
                                 password:self.password
                                  success:^(MSLoginInfo *result) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            // 需要延迟执行的代码
            [weak_self.view hideLoading];
            loginCompletion(nil);
        });
       
    }
                                  failure:^(MSBusinessError *error) {
        [weak_self.view hideLoading];
        loginCompletion(error);
    }];

}

#pragma mark - 第三方登录
- (void)loginFacebook {
    WEAK_SELF;
    void(^thirdLoginCompletion)(MSBusinessError *error) = ^(MSBusinessError *error) {
        if([weak_self.view respondsToSelector:@selector(presenter:thirdLoginCompletion:)]) {
            [weak_self.view presenter:weak_self thirdLoginCompletion:error];
        }
    };

    FBSDKLoginManager* loginManager = [FBSDKLoginManager new];
    [loginManager logOut];
    [FBSDKProfile enableUpdatesOnAccessTokenChange:YES];
    [loginManager logInWithPermissions:@[@"public_profile",@"email"] fromViewController:self.view handler:^(FBSDKLoginManagerLoginResult * _Nullable result, NSError * _Nullable error) {
        DDLogLoginInfo(@"facebook 登录回调：%@, %@", error.localizedDescription, error.userInfo);
        if (error) {
            thirdLoginCompletion([MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeThirdLoginError]);
        }else if (result.isCancelled){
            thirdLoginCompletion([MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeThirdLoginCancel]);
        }else{
            weak_self.taccessToken = result.token.tokenString?:@"";
            weak_self.userId = result.token.userID?:@"";
            [weak_self getUserInfoWithResult:result];
        }
    }];
}



//获取用户信息 picture用户头像
- (void)getUserInfoWithResult:(FBSDKLoginManagerLoginResult *)result{
    NSDictionary *params= @{@"fields":@"id,name,email,age_range,first_name,last_name,link,gender,locale,picture,timezone,updated_time,verified"};
    WEAKSELF
    FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc] initWithGraphPath:result.token.userID
                                                                   parameters:params
                                                                   HTTPMethod:@"GET"];
    [request startWithCompletion:^(id<FBSDKGraphRequestConnecting>  _Nullable connection, id  _Nullable result, NSError * _Nullable error) {
        NSLog(@"faceBook 详细信息%@-----------------",result);
//        {
//            email = "windycheng@aliyun.com";
//            "first_name" = "\U8f69\U8f0a";
//            id = 112054541148072;
//            "last_name" = "\U7a0b";
//            name = "\U7a0b\U8f69\U8f0a";
//            picture =     {
//                data =         {
//                    height = 50;
//                    "is_silhouette" = 0;
//                    url = "https://platform-lookaside.fbsbx.com/platform/profilepic/?asid=112054541148072&height=50&width=50&ext=1639217835&hash=AeSBg0gl7v_QLZ_T3cg";
//                    width = 50;
//                };
//            };
        if (error) {
           [weakSelf thirdLoginWithToken:weakSelf.taccessToken userId:weakSelf.userId thirdType:@"32" extraInfo:@"" context:nil];
        }else{
            NSDictionary *dict = (NSDictionary *)result;
            if ([dict isKindOfClass:[NSDictionary class]] && dict && [dict.allKeys containsObject:@"email"]) {
                weakSelf.accountInfo = dict[@"email"];
                [weakSelf thirdLoginWithToken:weakSelf.taccessToken userId:weakSelf.userId thirdType:@"32" extraInfo:dict[@"email"] context:nil];
            }else{
                weakSelf.accountInfo = weakSelf.userId;
                [weakSelf thirdLoginWithToken:weakSelf.taccessToken userId:weakSelf.userId thirdType:@"32" extraInfo:@"" context:nil];
            }
        }
    }];

}




- (void)loginTwitter {
//    WEAK_SELF;
//    void(^thirdLoginCompletion)(MSBusinessError *error) = ^(MSBusinessError *error) {
//        if([weak_self.view respondsToSelector:@selector(presenter:thirdLoginCompletion:)]) {
//            [weak_self.view presenter:weak_self thirdLoginCompletion:error];
//        }
//    };
//
//    [[Twitter sharedInstance] logInWithViewController:self.view completion:^(TWTRSession * _Nullable session, NSError * _Nullable error) {
//        if (session) {
//            NSString* token = session.authToken?:@"";
//            NSString* userId = session.userID?:@"";
//            NSString* tokenSecret = session.authTokenSecret?:@"";
//           [weak_self thirdLoginWithToken:token userId:[NSString stringWithFormat:@"%@&%@",userId,tokenSecret] thirdType:@"89"];
//        } else {
//            if (error.code == 1) {
//                thirdLoginCompletion([MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeThirdLoginCancel]);
//            }else{
//                thirdLoginCompletion([MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeThirdLoginError]);
//            }
//        }
//    }];
    
}

- (void)loginApple {
    if ([BusinessNetWorkTools isNetworkUnreachable]) {
        [self.view toastText:[MSBusinessError networkDisconnectTips]];
        return;
    }
    if (@available(iOS 13.0, *)) {
        ASAuthorizationAppleIDProvider *appleIDProvider = [[ASAuthorizationAppleIDProvider alloc] init];
        ASAuthorizationAppleIDRequest *appleIDRequest = [appleIDProvider createRequest];
        appleIDRequest.requestedScopes = @[ASAuthorizationScopeFullName, ASAuthorizationScopeEmail];
        ASAuthorizationController *authorizationController = [[ASAuthorizationController alloc] initWithAuthorizationRequests:@[appleIDRequest]];
        authorizationController.delegate = self;
        authorizationController.presentationContextProvider = self;
        [authorizationController performRequests];
    }
}

//苹果授权成功回调
- (void)authorizationController:(ASAuthorizationController *)controller didCompleteWithAuthorization:(ASAuthorization *)authorization  API_AVAILABLE(ios(13.0)){
    
    if ([authorization.credential isKindOfClass:[ASAuthorizationAppleIDCredential class]]) {
        ASAuthorizationAppleIDCredential *appleIDCredential = authorization.credential;
        // 基本信息
        NSString *user = appleIDCredential.user;
        NSData *identityToken = appleIDCredential.identityToken;
        NSString *identityTokenStr = [[NSString alloc] initWithData:identityToken encoding:NSUTF8StringEncoding];
        NSString *email = appleIDCredential.email; //用户有可能没授权
        self.accountInfo = email?email:user;
        NSDictionary * context = nil;
        if (appleIDCredential.email && appleIDCredential.email.length > 0) {
            context = @{@"email": appleIDCredential.email};
        }
        [self thirdLoginWithToken:identityTokenStr userId:user thirdType:@"79" extraInfo:email?:@"" context:context];
    } else {
        if([self.view respondsToSelector:@selector(presenter:thirdLoginCompletion:)]) {
            [self.view presenter:self thirdLoginCompletion:[MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeThirdLoginError]];
        }
    }

}

//苹果授权失败
- (void)authorizationController:(ASAuthorizationController *)controller didCompleteWithError:(NSError *)error  API_AVAILABLE(ios(13.0)){
    if (error.code == ASAuthorizationErrorCanceled) {
        if([self.view respondsToSelector:@selector(presenter:thirdLoginCompletion:)]) {
            [self.view presenter:self thirdLoginCompletion:[MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeThirdLoginCancel]];
        }
    } else {
        if([self.view respondsToSelector:@selector(presenter:thirdLoginCompletion:)]) {
            [self.view presenter:self thirdLoginCompletion:[MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeThirdLoginError]];
        }
    }
}

// apple告诉delegate应该在哪个window展示内容给用户
- (ASPresentationAnchor)presentationAnchorForAuthorizationController:(ASAuthorizationController *)controller  API_AVAILABLE(ios(13.0)){
    return [UIApplication sharedApplication].windows.lastObject;
}

//thirdType用于区分登录平台，facebook是32 Twitter是89 apple是79
- (void)thirdLoginWithToken:(NSString*)accessToken
                     userId:(NSString*)userId
                  thirdType:(NSString*)thirdType
                  extraInfo:(NSString *)extraInfo
                    context:(NSDictionary *)context {
    self.thirdType = thirdType;
    self.userId = userId;
    self.taccessToken = accessToken;
    self.accountInfo = extraInfo;
    WEAK_SELF;
    void(^thirdLoginCompletion)(MSBusinessError *error) = ^(MSBusinessError *error) {
        if([weak_self.view respondsToSelector:@selector(presenter:thirdLoginCompletion:)]) {
            [weak_self.view presenter:weak_self thirdLoginCompletion:error];
        }
    };
    
    [self.view showLoading];
    [self.loginModel userThirdLoginWithToken:accessToken
                                      userId:userId
                                   thirdType:thirdType
                                     context:context
                                     success:^(MSLoginInfo *result) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            // 需要延迟执行的代码
            [weak_self.view hideLoading];
            if ([thirdType isEqualToString:@"79"] && [result.userFlag isEqualToString:@"79"]) { //userFlag == 79 代表此apple id 没绑定过邮箱或手机号
                NSDictionary * appleSignInInfo = @{
                    @"uid": userId ?: @"",
                    @"email": [context objectForKey:@"email"] ?: @""
                };
                [[MSUserInfoManager shareManager] saveAppleSignInTagAndContext:appleSignInInfo];
            }

            thirdLoginCompletion(nil);
        });
        
    } failure:^(MSBusinessError *error) {
        [weak_self.view hideLoading];
        thirdLoginCompletion(error);
    }];
    
}

#pragma mark - 输入状态
- (void)setEnableLogin:(BOOL)enableLogin {
    if (_enableLogin == enableLogin) {
        return;
    }
    
    _enableLogin = enableLogin;
    if ([self.view respondsToSelector:@selector(presenter:didEnableLogin:)]) {
        [self.view presenter:self didEnableLogin:enableLogin];
    }
}

- (void)setEmail:(NSString *)email {
    _email = email;
    self.enableLogin = self.email.length > 0 && self.password.length > 0;
    if ([self.view respondsToSelector:@selector(presenter:didEnableShowDeleteButton:)]) {
        [self.view presenter:self didEnableShowDeleteButton:email.length > 0];
    }
}


- (void)setAccount:(NSString *)account{
    _account = account;
    self.enableLogin = self.account.length > 0 && self.password.length > 0;
    if ([self.view respondsToSelector:@selector(presenter:didEnableShowDeleteButton:)]) {
        [self.view presenter:self didEnableShowDeleteButton:self.account.length > 0];
    }
}


- (void)setPassword:(NSString *)password {
    _password = password;
    self.enableLogin = self.account.length > 0 && self.password.length > 0;
}



@end
