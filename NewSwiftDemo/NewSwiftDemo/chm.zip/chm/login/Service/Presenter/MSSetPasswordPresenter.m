//
//  MSSetPasswordPresenter.m
//  MSLogin
//
//  Created by syp on 2020/6/30.
//

#import "MSSetPasswordPresenter.h"
#import "MSRegistModel.h"
#import "MSLoginUtils.h"
#import <OEMFoundation/HGInternationalization.h>

@interface MSSetPasswordPresenter ()

@property (nonatomic, strong) MSRegistModel *registModel;
@property (nonatomic, assign) BOOL enableRegist;

@end
@implementation MSSetPasswordPresenter

- (MSRegistModel *)registModel {
    if (!_registModel) {
        _registModel = [MSRegistModel new];
    }
    return _registModel;
}


- (void)userRegisterWithAccount:(NSString *)account
                     verifyCode:(NSString *)verifyCode{
    @weakify(self)
    void(^registCompletion)(MSBusinessError *error) = ^(MSBusinessError *error) {
        @strongify(self)
        if([self.view respondsToSelector:@selector(presenter:registerCompletion:)]) {
            [self.view presenter:self registerCompletion:error];
        }
    };
    
//    MSBusinessError *error = [MSLoginUtils checkPassword:self.password confirmPassword:self.confirmPassword];
//    if (error) {
//        registCompletion(error);
//        return;
//    }
    BOOL isEmail = [MSLoginUtils isValidEmail:account]; //是否邮箱
    NSString *countryCode = [HGInternationalization sharedInstance].currentCountry.code;
    NSString *phoneCode = [HGInternationalization sharedInstance].currentCountry.phoneCode;
    NSString *receiver = isEmail?account:[NSString stringWithFormat:@"%@%@", phoneCode, account];
    [self.view showLoading];
    [self.registModel userRegisterWithEmail:isEmail?account:@""
                                   password:self.password
                                 verifyCode:verifyCode
                              phoneAreacode:isEmail?@"":phoneCode
                                   userFlag:isEmail?@"0":@"1"
                           verifyIdReceiver:receiver
                                     mobile:isEmail?@"":account
                                countryCode:countryCode
                                    success:^(MSLoginInfo *result) {
        @strongify(self)
        [self.view hideLoading];
        registCompletion(nil);
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        [self.view hideLoading];
        registCompletion(error);
    }];
    
}





- (void)setPassword:(NSString *)password {
    _password = password;
    
   /// self.enableRegist = self.password.length > 0;    //&& self.confirmPassword.length > 0;
    self.isLengthRight = self.password.length >= 6 && self.password.length <= 20;
    self.isRuleRight = [MSLoginUtils checkPasswordRule:self.password];
    self.enableRegist  = self.isLengthRight; //可注册，提交按钮可点击
}

- (void)setConfirmPassword:(NSString *)confirmPassword {
    _confirmPassword = confirmPassword;
    
    self.enableRegist = self.password.length > 0 && self.confirmPassword.length > 0;
    if (self.confirmPassword.length == 0) {
        self.isConsistent = YES;
    } else if (self.confirmPassword.length <= self.password.length) {
        self.isConsistent = [self.password hasPrefix:self.confirmPassword];
    } else {
        self.isConsistent = NO;
    }
}

- (void)setEnableRegist:(BOOL)enableRegist {
    if (_enableRegist == enableRegist) {
        return;
    }
    _enableRegist = enableRegist;
    if ([self.view respondsToSelector:@selector(presenter:didEnableRegiste:)]) {
        [self.view presenter:self didEnableRegiste:enableRegist];
    }
}

- (void)setIsPasswordInputEditing:(BOOL)isPasswordInputEditing {
    _isPasswordInputEditing = isPasswordInputEditing;
    
    if ([self.view respondsToSelector:@selector(presenter:didPasswordInputEditingChanged:)]) {
        [self.view presenter:self didPasswordInputEditingChanged:isPasswordInputEditing];
    }
}

- (void)setIsConfirmInputEditing:(BOOL)isConfirmInputEditing {
    _isConfirmInputEditing = isConfirmInputEditing;
    
    if ([self.view respondsToSelector:@selector(presenter:didConfirmInputEditingChanged:)]) {
        [self.view presenter:self didConfirmInputEditingChanged:isConfirmInputEditing];
    }
}

- (void)setIsLengthRight:(BOOL)isLengthRight {
    _isLengthRight = isLengthRight;
    
    if ([self.view respondsToSelector:@selector(presenter:didLengthRightChanged:)]) {
        [self.view presenter:self didLengthRightChanged:isLengthRight];
    }
}

- (void)setIsRuleRight:(BOOL)isRuleRight {
    _isRuleRight = isRuleRight;
    
    if ([self.view respondsToSelector:@selector(presenter:didRuleRightChanged:)]) {
        [self.view presenter:self didRuleRightChanged:isRuleRight];
    }
}

- (void)setIsConsistent:(BOOL)isConsistent {
    _isConsistent = isConsistent;
    
    if ([self.view respondsToSelector:@selector(presenter:didConsistentChanged:)]) {
        [self.view presenter:self didConsistentChanged:isConsistent];
    }
}



@end
