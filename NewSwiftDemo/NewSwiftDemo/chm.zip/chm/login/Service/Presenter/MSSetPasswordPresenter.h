//
//  MSSetPasswordPresenter.h
//  MSLogin
//
//  Created by syp on 2020/6/30.
//

#import <MSBusiness/MVPPresenter.h>
#import <MSBusiness/MSBusinessError.h>


@class MSRegistModel;
@class MSSetPasswordPresenter;

@protocol MSSetPasswordViewProtocol <MVPViewProtocol>

- (void)presenter:(MSSetPasswordPresenter *)presenter registerCompletion:(MSBusinessError *)error;
- (void)presenter:(MSSetPasswordPresenter *)presenter didEnableRegiste:(BOOL)enable;
- (void)presenter:(MSSetPasswordPresenter *)presenter didPasswordInputEditingChanged:(BOOL)isPasswordInputEditing;
- (void)presenter:(MSSetPasswordPresenter *)presenter didConfirmInputEditingChanged:(BOOL)isConfirmInputEditing;
- (void)presenter:(MSSetPasswordPresenter *)presenter didLengthRightChanged:(BOOL)isLengthRight;
- (void)presenter:(MSSetPasswordPresenter *)presenter didRuleRightChanged:(BOOL)isRuleRight;
- (void)presenter:(MSSetPasswordPresenter *)presenter didConsistentChanged:(BOOL)isConsistent;

@end

@interface MSSetPasswordPresenter : MVPPresenter<id<MSSetPasswordViewProtocol>>

@property (nonatomic, strong) NSString *password;
@property (nonatomic, strong) NSString *confirmPassword;

@property (nonatomic, readonly) BOOL enableRegist;
@property (nonatomic, assign) BOOL isPasswordInputEditing;
@property (nonatomic, assign) BOOL isConfirmInputEditing;
@property (nonatomic, assign) BOOL isLengthRight;
@property (nonatomic, assign) BOOL isRuleRight;
@property (nonatomic, assign) BOOL isConsistent;



//新加
- (void)userRegisterWithAccount:(NSString *)account
                     verifyCode:(NSString *)verifyCode;


@end
