//
//  MSCountryGetResult.h
//  MSLogin
//
//  Created by pactera on 2020/7/21.
//

#import <Foundation/Foundation.h>

@interface MSCountryGetResult : NSObject

@property (nonatomic, copy) NSString *countryCode;
@property (nonatomic, copy) NSString *appId;
@property (nonatomic, copy) NSString *area;
@property (nonatomic, copy) NSString *countryId;
@property (nonatomic, copy) NSString *url;

@property (nonatomic, copy) NSString *phoneCode;  //国家电话码

@property (nonatomic, copy) NSString *mqttBroker;  //aws 节点



@end
