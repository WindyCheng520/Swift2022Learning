//
//  MSCountryGetResult.m
//  MSLogin
//
//  Created by pactera on 2020/7/21.
//

#import "MSCountryGetResult.h"
#import <MJExtension/MJExtension.h>

@implementation MSCountryGetResult

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{
             @"countryId" : @"id"
             };
}

@end
