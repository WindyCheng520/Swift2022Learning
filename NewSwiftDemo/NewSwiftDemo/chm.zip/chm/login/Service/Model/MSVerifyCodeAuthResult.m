

//
//  MSVerifyCodeAuthResult.m
//  MSLogin
//
//  Created by pactera on 2020/7/21.
//

#import "MSVerifyCodeAuthResult.h"

@implementation MSVerifyCodeAuthResult

@end
