//
//  MSLoginAndRegistTypes.h
//  MSLogin
//
//  Created by syp on 2020/6/22.
//

#import <MSBusiness/MSBusinessError.h>
#import <OEMFoundation/HGInternationalization.h>
#import "MSVerifyCodeAuthResult.h"
#import "MSCountryGetResult.h"
#import "MSAutoLoginResult.h"

FOUNDATION_EXPORT NSErrorDomain const MSLoginAndRegistErrorDomain;




