//
//  MSAutoLoginResult.h
//  MSLogin
//
//  Created by pactera on 2020/7/21.
//

#import <Foundation/Foundation.h>

@interface MSAutoLoginResult : NSObject

@property (nonatomic, copy)NSString *accessToken;
@property (nonatomic, copy)NSString *tokenPwd;

@end


