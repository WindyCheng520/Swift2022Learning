//
//  MSAutoLoginResult.m
//  MSLogin
//
//  Created by pactera on 2020/7/21.
//

#import "MSAutoLoginResult.h"

@implementation MSAutoLoginResult

@end
