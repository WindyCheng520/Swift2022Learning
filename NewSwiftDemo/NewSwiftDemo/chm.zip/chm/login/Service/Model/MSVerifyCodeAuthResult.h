//
//  MSVerifyCodeAuthResult.h
//  MSLogin
//
//  Created by pactera on 2020/7/21.
//

#import <Foundation/Foundation.h>

@interface MSVerifyCodeAuthResult : NSObject

@property (nonatomic, copy) NSString *randomCode;

@property (nonatomic, copy) NSString *verifyId;



@end

