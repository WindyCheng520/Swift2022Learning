//
//  MSLoginAndRegistTypes.m
//  MSLogin
//
//  Created by syp on 2020/6/22.
//

#import "MSLoginAndRegistTypes.h"

NSString *const MSLoginAndRegistErrorDomain = @"MSLoginAndRegistErrorDomain";


