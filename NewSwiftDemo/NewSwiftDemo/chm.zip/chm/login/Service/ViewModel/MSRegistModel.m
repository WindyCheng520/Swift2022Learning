//
//  MSRegistModel.m
//  MSLogin
//
//  Created by syp on 2020/6/25.
//

#import "MSRegistModel.h"
#import <MSBusiness/MSAppInfo.h>
#import "MSLoginUtils.h"
#import <MSBusiness/MSUserInfoManager.h>
#import <MSBusiness/MSUserDefaultTools.h>

@interface MSRegistModel ()

@end


@implementation MSRegistModel

- (void)userAuthExistWithAccount:(NSString *)account
                         success:(MSLoginRepositorySuccessBlock)success
                         failure:(MSLoginRepositoryFailureBlock)failure{
    NSMutableDictionary *iotData = @{}.mutableCopy;
    [iotData setValue:account forKey:@"account"];
    NSDictionary* paras = [iotData copy];
    [MSLoginAndRegistRepository verifyUserExistWithParas:paras success:success failure:failure];
}


//type:1 注册验证码校验（原生页面）    2：忘记密码验证码校验    3：修改密码验证码校验  4:第三方登录 5:账号注销   默认为1
//userFlag: 验证码接收方式，0：邮箱、1：手机，如果不送，默认为0
- (void)userVerifyCodeGetWithVerifyIdReceiver:(NSString *)receiver
                                         type:(NSString *)type
                                     userFlag:(NSString *)userFlag
                                      success:(MSLoginRepositorySuccessBlock)success
                                      failure:(MSLoginRepositoryFailureBlock)failure{
    NSDictionary *paras = @{@"verifyIdReceiver": receiver,
                            @"type": type,
                            @"userFlag": userFlag};
    [MSLoginAndRegistRepository sendVerifyCodeWithParas:paras success:success failure:failure];
}

//1.1.2-校验验证码
- (void)userVerifyCodeAuthWithverifyIdReceiver:(NSString *)receiver
                                    verifyCode:(NSString *)verifyCode
                                       success:(MSLoginRepositoryUserVerifyCodeAuthSuccess)success
                                       failure:(MSLoginRepositoryFailureBlock)failure{
    NSMutableDictionary *iotData = @{}.mutableCopy;
    [iotData setValue:receiver forKey:@"verifyIdReceiver"];
    verifyCode = [MSLoginUtils encryptVerifyCode:verifyCode];
    [iotData setValue:verifyCode forKey:@"verifyId"];
    NSDictionary *paras = [iotData copy];
    [MSLoginAndRegistRepository authVerifyIdWithParas:paras success:success failure:failure];
}




- (void)userRegisterWithEmail:(NSString *)email
                     password:(NSString *)password
                   verifyCode:(NSString *)verifyCode
                phoneAreacode:(NSString *)phoneAreacode
                     userFlag:(NSString *)userFlag
             verifyIdReceiver:(NSString *)receiver
                       mobile:(NSString *)mobile
                  countryCode:(NSString *)countryCode
                      success:(MSLoginRepositoryUserRegisterSuccess)success
                      failure:(MSLoginRepositoryFailureBlock)failure{
    
    password = [MSLoginUtils encryptRegisterPassword:password];
    verifyCode = [MSLoginUtils encryptVerifyCode:verifyCode];
    NSDictionary *paras;
    NSString *saveAccount = @"";
    if(email.length > 0){ //邮箱
        paras = @{@"email" : email,
                  @"password": password,
                  @"verifyId": verifyCode,
                  @"userFlag": userFlag,
                  @"verifyIdReceiver": receiver,
                  @"countryCode": countryCode
                  /*@"privateVersion":@"1.0"*/};
        saveAccount = email;
        
    }else{ //手机号
        paras = @{
            @"password": password,
            @"verifyId": verifyCode,
            @"phoneAreacode": phoneAreacode,
            @"userFlag": userFlag,
            @"verifyIdReceiver": receiver,
            @"mobile" : mobile,
            @"countryCode": countryCode
            /*@"privateVersion":@"1.0"*/};
        saveAccount = mobile;
    }

    [MSLoginAndRegistRepository registerWithParas:paras success:^(MSLoginInfo *result) {
        [[MSUserInfoManager shareManager] saveLoginInfoDataWithModel:result];
        [MSUserDefaultTools saveLastLoginAccount:saveAccount];
        safeCallBlock(success, result);
    } failure:^(MSBusinessError *error) {
        safeCallBlock(failure, error);
    }];
}


- (void)userUnRegisterWithVerifyIdReceiver:(NSString *)verifyIdReceiver
                                verifyCode:(NSString *)verifyCode
                                   success:(MSLoginRepositoryUserUnregisterSuccessBlock)success
                                   failure:(MSLoginRepositoryFailureBlock)failure{
    verifyCode = [MSLoginUtils encryptVerifyCode:verifyCode];
    NSDictionary *paras = @{@"verifyIdReceiver" : verifyIdReceiver,
                            @"verifyId":verifyCode
    };
    [MSLoginAndRegistRepository unresigerWithParas:paras
                                       success:success
                                       failure:failure];
}


@end
