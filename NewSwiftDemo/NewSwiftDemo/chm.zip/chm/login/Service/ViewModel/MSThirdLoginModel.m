//
//  MSThirdLoginModel.m
//  MSLogin
//
//  Created by 及时行乐 on 2020/7/16.
//

#import "MSThirdLoginModel.h"
#import <MSBusiness/MSAppInfo.h>
#import "MSLoginUtils.h"
#import <MSBusiness/MSUserInfoManager.h>
#import <MSBusiness/MSUserDefaultTools.h>

@implementation MSThirdLoginModel



- (void)userAuthExistWithAccount:(NSString *)account
                         success:(MSLoginRepositorySuccessBlock)success
                         failure:(MSLoginRepositoryFailureBlock)failure{
    NSMutableDictionary *iotData = @{}.mutableCopy;
    [iotData setValue:account forKey:@"account"];
    NSDictionary* paras = [iotData copy];
    [MSLoginAndRegistRepository verifyUserExistWithParas:paras success:success failure:failure];
}


//1.1.2--获取验证码
//type:1 注册验证码校验（原生页面）    2：忘记密码验证码校验    3：修改密码验证码校验  4:第三方登录 5:账号注销   默认为1
//userFlag: 验证码接收方式，0：邮箱、1：手机，如果不送，默认为0
- (void)userVerifyCodeGetWithVerifyIdReceiver:(NSString *)receiver
                                         type:(NSString *)type
                                     userFlag:(NSString *)userFlag
                                      channel:(NSString *)channel
                                      success:(MSLoginRepositorySuccessBlock)success
                                      failure:(MSLoginRepositoryFailureBlock)failure{
    NSDictionary *paras = @{@"verifyIdReceiver": receiver,
                            @"type": type,
                            @"userFlag": userFlag,
                            @"channel": channel
    };
    [MSLoginAndRegistRepository sendVerifyCodeWithParas:paras success:success failure:failure];
}


//1.1.2-校验验证码
- (void)userVerifyCodeAuthWithverifyIdReceiver:(NSString *)receiver
                                    verifyCode:(NSString *)verifyCode
                                       success:(MSLoginRepositoryUserVerifyCodeAuthSuccess)success
                                       failure:(MSLoginRepositoryFailureBlock)failure{
    NSMutableDictionary *iotData = @{}.mutableCopy;
    [iotData setValue:receiver forKey:@"verifyIdReceiver"];
    verifyCode = [MSLoginUtils encryptVerifyCode:verifyCode];
    [iotData setValue:verifyCode forKey:@"verifyId"];
    NSDictionary *paras = [iotData copy];
    [MSLoginAndRegistRepository authVerifyIdWithParas:paras success:success failure:failure];
}



////第三方账号登录(绑定）
//- (void)userThirdLoginWithToken:(NSString*)accessToken
//                         userId:(NSString*)userId
//                        channel:(NSString*)channel
//                       password:(NSString*)password
//                       verifyId:(NSString *)verifyId
//                          email:(NSString *)email
//                        success:(MSLoginRepositoryUserThirdLoginSuccess)success
//                        failure:(MSLoginRepositoryFailureBlock)failure{
//    userId = [MSLoginUtils encryptVerifyCode:userId];
//    verifyId = [MSLoginUtils encryptVerifyCode:verifyId];
//    password = [MSLoginUtils encryptRegisterPassword:password];
//    NSMutableDictionary *paras = [NSMutableDictionary dictionary];
//    [paras setValue:accessToken forKey:@"token"];
//    [paras setValue:userId forKey:@"thirdUID"];
//    [paras setValue:channel forKey:@"channel"];
//    [paras setValue:password forKey:@"password"];
//    [paras setValue:channel forKey:@"channel"];
//    [paras setValue:email forKey:@"email"];
//    [paras setValue:verifyId forKey:@"verifyId"];
//    [MSLoginAndRegistRepository userThirdLoginWithParas:paras success:^(MSLoginInfo *result) {
//        [[MSUserInfoManager shareManager] saveLoginInfoDataWithModel:result];
//        [MSUserDefaultTools saveLastLoginAccount:result.email];
//        safeCallBlock(success, result);
//    } failure:^(MSBusinessError *error) {
//        safeCallBlock(failure, error);
//    }];
//}



//第三方账号绑定(未登录）
- (void)userThirdLoginWithToken:(NSString *)accessToken
                         userId:(NSString *)userId
                        channel:(NSString *)channel
                       password:(NSString *)password
                       verifyId:(NSString *)verifyId
                          email:(NSString *)email
                  phoneAreacode:(NSString *)phoneAreacode
                       userFlag:(NSString *)userFlag
               verifyIdReceiver:(NSString *)receiver
                         mobile:(NSString *)mobile
                    countryCode:(NSString *)countryCode
                      extraInfo:(NSString *)extraInfo
                        success:(MSLoginRepositoryUserThirdLoginSuccess)success
                        failure:(MSLoginRepositoryFailureBlock)failure{
    userId = [MSLoginUtils encryptVerifyCode:userId];
    verifyId = [MSLoginUtils encryptVerifyCode:verifyId];
    password = [MSLoginUtils encryptRegisterPassword:password];
    NSMutableDictionary *paras = [NSMutableDictionary dictionary];
    [paras setValue:accessToken forKey:@"token"];
    [paras setValue:userId forKey:@"thirdUID"];
    [paras setValue:channel forKey:@"channel"];
    if (password.length > 0){
      [paras setValue:password forKey:@"password"];
    }
    [paras setValue:channel forKey:@"channel"];
    [paras setValue:verifyId forKey:@"verifyId"];
    [paras setValue:extraInfo?:@"" forKey:@"extraInfo"];
    
    NSDictionary *dict;
    NSString *saveAccount = @"";
    if(email.length > 0){ //邮箱
        dict = @{@"email" : email,
                  @"userFlag": userFlag,
                  @"verifyIdReceiver": receiver,
                 @"countryCode": countryCode};
        saveAccount = email;
        
    }else{ //手机号
        dict = @{
            @"phoneAreacode": phoneAreacode,
            @"userFlag": userFlag,
            @"verifyIdReceiver": receiver,
            @"mobile" : mobile,
            @"countryCode": countryCode
        };
        saveAccount = mobile;
    }
    
    [paras addEntriesFromDictionary:dict];
    [MSLoginAndRegistRepository thirdLoginWithParas:paras success:^(MSLoginInfo *result) {
        [[MSUserInfoManager shareManager] saveLoginInfoDataWithModel:result];
        [MSUserDefaultTools saveLastLoginAccount:saveAccount];
        safeCallBlock(success, result);
    } failure:^(MSBusinessError *error) {
        safeCallBlock(failure, error);
    }];
    
}






@end
