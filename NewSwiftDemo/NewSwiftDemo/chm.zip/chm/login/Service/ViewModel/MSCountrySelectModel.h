//
//  MSCountrySelectModel.h
//  MSLogin
//
//  Created by 及时行乐 on 2020/7/10.
//

#import <MSBusiness/MVPModel.h>
#import "MSLoginAndRegistRepository.h"


@interface MSCountrySelectModel : MVPModel

- (void)userGetCountryDataSuccess:(MSLoginRepositoryUserGetCountrySuccess)success failure:(MSLoginRepositoryFailureBlock)failure;



@end

