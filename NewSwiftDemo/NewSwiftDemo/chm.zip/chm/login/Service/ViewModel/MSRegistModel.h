//
//  MSRegistModel.h
//  MSLogin
//
//  Created by syp on 2020/6/25.
//

#import <MSBusiness/MVPModel.h>
#import "MSLoginAndRegistRepository.h"


@interface MSRegistModel : MVPModel


//1.1.2-- 验证账号（邮箱或手机号码)是否存在
- (void)userAuthExistWithAccount:(NSString *)account
                         success:(MSLoginRepositorySuccessBlock)success
                         failure:(MSLoginRepositoryFailureBlock)failure;

//1.1.2--获取验证码
- (void)userVerifyCodeGetWithVerifyIdReceiver:(NSString *)receiver
                                         type:(NSString *)type
                                     userFlag:(NSString *)userFlag
                                      success:(MSLoginRepositorySuccessBlock)success
                                      failure:(MSLoginRepositoryFailureBlock)failure;
//1.1.2-校验验证码
- (void)userVerifyCodeAuthWithverifyIdReceiver:(NSString *)receiver
                                    verifyCode:(NSString *)verifyCode
                                       success:(MSLoginRepositoryUserVerifyCodeAuthSuccess)success
                                       failure:(MSLoginRepositoryFailureBlock)failure;


//1.1.2-账号注册
- (void)userRegisterWithEmail:(NSString *)email
                     password:(NSString *)password
                   verifyCode:(NSString *)verifyCode
                phoneAreacode:(NSString *)phoneAreacode
                     userFlag:(NSString *)userFlag
             verifyIdReceiver:(NSString *)receiver
                       mobile:(NSString *)mobile
                  countryCode:(NSString *)countryCode
                      success:(MSLoginRepositoryUserRegisterSuccess)success
                      failure:(MSLoginRepositoryFailureBlock)failure;

//1.1.2-账号注销
- (void)userUnRegisterWithVerifyIdReceiver:(NSString *)verifyIdReceiver
                                verifyCode:(NSString *)verifyCode
                                   success:(MSLoginRepositoryUserUnregisterSuccessBlock)success
                                   failure:(MSLoginRepositoryFailureBlock)failure;

@end

