//
//  MSCountrySelectModel.m
//  MSLogin
//
//  Created by 及时行乐 on 2020/7/10.
//

#import "MSCountrySelectModel.h"
#import <MSBusiness/MSAppInfo.h>

@implementation MSCountrySelectModel

-(void)userGetCountryDataSuccess:(MSLoginRepositoryUserGetCountrySuccess)success failure:(MSLoginRepositoryFailureBlock)failure{
    [MSLoginAndRegistRepository getArea:nil success:success failure:failure];
}




@end
