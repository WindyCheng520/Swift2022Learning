//
//  MSLoginModel.h
//  MSLogin
//
//  Created by syp on 2020/6/24.
//

#import <Foundation/Foundation.h>
#import <MSBusiness/MVPModel.h>
#import "MSLoginAndRegistRepository.h"


@interface MSLoginModel : MVPModel

- (void)userLoginWithAccount:(NSString *)account
                    password:(NSString *)password
                     success:(MSLoginRepositoryUserLoginSuccess)success
                     failure:(MSLoginRepositoryFailureBlock)failure;


//第三方账号登录(未登录状态）
- (void)userThirdLoginWithToken:(NSString*)accessToken
                         userId:(NSString*)userId
                      thirdType:(NSString*)thirdType
                        context:(NSDictionary *)context
                        success:(MSLoginRepositoryUserThirdLoginSuccess)success
                        failure:(MSLoginRepositoryFailureBlock)failure;

//第三方账号绑定(已登录状态）
- (void)userThirdBindWithToken:(NSString *)accessToken
                        userId:(NSString *)userId
                     thirdType:(NSString *)thirdType
                     extraInfo:(NSString *)extraInfo
                       context:(NSDictionary *)context
                       success:(MSLoginRepositoryUserThirdLoginBindSuccess)success
                       failure:(MSLoginRepositoryFailureBlock)failure;

//自动登录
- (void)userAutoLoginWithRule:(NSString *)rule
                      success:(MSLoginRepositoryUserAutoLoginSuccess)success
                      failure:(MSLoginRepositoryFailureBlock)failure;



@end

