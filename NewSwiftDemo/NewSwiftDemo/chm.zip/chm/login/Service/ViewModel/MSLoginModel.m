//
//  MSLoginModel.m
//  MSLogin
//
//  Created by syp on 2020/6/24.
//

#import "MSLoginModel.h"
#import "MSLoginAndRegistRepository.h"
#import <MSBusiness/MSAppInfo.h>
#import "MSLoginUtils.h"
#import <MSBusiness/MSUserDefaultTools.h>
#import <MSBusiness/MSUserInfoManager.h>
#import <MSBusiness/MSUserInfoManager.h>
#import "MSLoginUtils.h"
#import <OEMFoundation/UIDevice+Category.h>

@implementation MSLoginModel



- (void)userLoginWithAccount:(NSString *)account
                    password:(NSString *)password
                     success:(MSLoginRepositoryUserLoginSuccess)success
                     failure:(MSLoginRepositoryFailureBlock)failure{
    password = [MSLoginUtils encryptRegisterPassword:password];
    
    BOOL isEmail = [MSLoginUtils isValidEmail:account]; //是否邮箱
    NSString *receiver = isEmail?account:[NSString stringWithFormat:@"%@%@", HGCurrentCountry.phoneCode, account];
    NSString *token = [[NSUserDefaults standardUserDefaults] objectForKey:@"MSDeviceTokenKey"];
    NSDictionary *paras = @{@"loginAccount" : receiver,
                            @"password": password,
                            @"phoneModel" : [UIDevice machineType],
                            @"phoneSysVNum" : [[UIDevice currentDevice] systemVersion],
                            @"encryptVersion": @"1",
                            @"pushToken":token?:@""
    };
    
    [MSLoginAndRegistRepository loginWithParas:paras
                                           success:^(MSLoginInfo *result) {
        [[MSUserInfoManager shareManager] saveLoginInfoDataWithModel:result];
        [MSUserDefaultTools saveLastLoginAccount:account];
        safeCallBlock(success, result);
    }
                                           failure:^(MSBusinessError *error) {
        safeCallBlock(failure, error);
    }];
}


/*{
   accessToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI2MTQiLCJleHAiOjE2NDE0NjM3MTMsImlhdCI6MTY0MTM3NzMxM30.e5hW-tGVtKicDH4qZAhXkE18DmUse1awsg4xHTsHCc4";
   email = "";
   headPhoto = "";
   mobile = 3234166663;
   nickName = 3234166663;
   phoneAreacode = 1;
   uid = 614;
   userFlag = 1;
   userName = 13234166663;
   versionCode = "1.0";
};
*/

//第三方登录---1.1.2
-(void)userThirdLoginWithToken:(NSString *)accessToken
                        userId:(NSString *)userId
                     thirdType:(NSString*)thirdType
                       context:(NSDictionary *)context
                       success:(MSLoginRepositoryUserThirdLoginSuccess)success
                       failure:(MSLoginRepositoryFailureBlock)failure{
    userId = [MSLoginUtils encryptVerifyCode:userId];
    NSString *token = [[NSUserDefaults standardUserDefaults] objectForKey:@"MSDeviceTokenKey"];
    NSMutableDictionary *paras = [NSMutableDictionary dictionary];
    [paras setValue:accessToken forKey:@"token"];
    [paras setValue:userId forKey:@"thirdUID"];
    [paras setValue:thirdType forKey:@"channel"];
    [paras setValue:token?:@"" forKey:@"pushToken"];
    if (context && [thirdType isEqualToString:@"79"]) {
        //苹果登录，默认加上邮箱，不需要绑定邮箱的流程
        NSString * email = [context objectForKey:@"email"];
        if ([email isKindOfClass:[NSString class]] && email.length > 0) {
            [paras setValue:email forKey:@"email"];
        }
    }
    [MSLoginAndRegistRepository thirdLoginWithParas:paras
                                            success:^(MSLoginInfo *result) {
        [[MSUserInfoManager shareManager] saveLoginInfoDataWithModel:result];
        if(result.email.length > 0 || result.mobile.length > 0){
            [MSUserDefaultTools saveLastLoginAccount:result.email.length > 0? result.email : result.mobile];
        }else{
            [MSUserDefaultTools saveLastLoginAccount:result.nickname];
        }
        safeCallBlock(success, result);
    }
                                                failure:^(MSBusinessError *error) {
        safeCallBlock(failure, error);
    }];
}

//第三方账号绑定(已登录状态）
- (void)userThirdBindWithToken:(NSString *)accessToken
                        userId:(NSString *)userId
                     thirdType:(NSString *)thirdType
                     extraInfo:(NSString *)extraInfo
                       context:(NSDictionary *)context
                       success:(MSLoginRepositoryUserThirdLoginBindSuccess)success
                       failure:(MSLoginRepositoryFailureBlock)failure{
    userId = [MSLoginUtils encryptVerifyCode:userId];
    NSMutableDictionary *paras = [NSMutableDictionary dictionary];
    [paras setValue:accessToken forKey:@"token"];
    [paras setValue:userId forKey:@"thirdUID"];
    [paras setValue:thirdType forKey:@"channel"];
    [paras setValue:extraInfo forKey:@"extraInfo"];
    [MSLoginAndRegistRepository thirdBindWithParas:paras
                                                    success:^{
        if (success) {
            success();
        }
    }
                                                    failure:^(MSBusinessError *error) {
        if (failure) {
            failure(error);
        }
    }];
}



//续签token
- (void)userAutoLoginWithRule:(NSString *)rule
                      success:(MSLoginRepositoryUserAutoLoginSuccess)success
                      failure:(MSLoginRepositoryFailureBlock)failure {
    NSDictionary *paras = @{};
    [MSLoginAndRegistRepository tokenExtendWithParas:paras
                                             success:success
                                            failure:failure];
}

@end
