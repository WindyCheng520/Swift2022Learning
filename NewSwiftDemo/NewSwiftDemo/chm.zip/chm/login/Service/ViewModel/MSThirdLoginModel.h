//
//  MSThirdLoginModel.h
//  MSLogin
//
//  Created by 及时行乐 on 2020/7/16.
//

#import <MSBusiness/MVPModel.h>
#import "MSLoginAndRegistRepository.h"

@interface MSThirdLoginModel : MVPModel


//1.1.2-- 验证账号（邮箱或手机号码)是否存在
- (void)userAuthExistWithAccount:(NSString *)account
                         success:(MSLoginRepositorySuccessBlock)success
                         failure:(MSLoginRepositoryFailureBlock)failure;

//1.1.2--获取验证码
- (void)userVerifyCodeGetWithVerifyIdReceiver:(NSString *)receiver
                                         type:(NSString *)type
                                     userFlag:(NSString *)type
                                      channel:(NSString *)channel
                                      success:(MSLoginRepositorySuccessBlock)success
                                      failure:(MSLoginRepositoryFailureBlock)failure;

//1.1.2-校验验证码
- (void)userVerifyCodeAuthWithverifyIdReceiver:(NSString *)receiver
                                    verifyCode:(NSString *)verifyCode
                                       success:(MSLoginRepositoryUserVerifyCodeAuthSuccess)success
                                       failure:(MSLoginRepositoryFailureBlock)failure;


//1.1.2-第三方账号绑定(未登录）
- (void)userThirdLoginWithToken:(NSString *)accessToken
                         userId:(NSString *)userId
                        channel:(NSString *)channel
                       password:(NSString *)password
                       verifyId:(NSString *)verifyId
                          email:(NSString *)email
                  phoneAreacode:(NSString *)phoneAreacode
                       userFlag:(NSString *)userFlag
               verifyIdReceiver:(NSString *)receiver
                         mobile:(NSString *)mobile
                    countryCode:(NSString *)countryCode
                      extraInfo:(NSString *)extraInfo
                        success:(MSLoginRepositoryUserThirdLoginSuccess)success
                        failure:(MSLoginRepositoryFailureBlock)failure;


@end

