//
//  MSLoginBundle.m
//  MSLogin
//
//  Created by syp on 2020/6/17.
//

#import "MSLoginBundle.h"

@implementation MSLoginBundle

+(NSBundle *)strBundle{
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *bundlePath = [bundle.resourcePath stringByAppendingPathComponent:@"MSBusiness.bundle"];
    return [NSBundle bundleWithPath:bundlePath];
}

+ (NSBundle *)currentBundle {
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *bundlePath = [bundle.resourcePath stringByAppendingPathComponent:@"MSLogin.bundle"];
    return [NSBundle bundleWithPath:bundlePath];
}

@end
