//
//  MSLoginError.h
//  MSLogin
//
//  Created by syp on 2020/6/28.
//

#import <MSBusiness/MSBusinessError.h>

FOUNDATION_EXPORT NSErrorDomain const MSLoginPresenterErrorDomain;

typedef enum : NSUInteger {
    MSLoginErrorCodeInvalidEmail,
    MSLoginErrorCodePasswordNotSame,
    MSLoginErrorCodePasswordLengthError,
    MSLoginErrorCodeThirdLoginError,
    MSLoginErrorCodeThirdLoginCancel,
    MSLoginErrorCodeVerifyCodeError
    
} MSLoginErrorCode;


@interface MSLoginError : MSBusinessError

+ (instancetype)errorWithLoginErrorCode:(MSLoginErrorCode)code;

@end


