//
//  MSLoginUtils.h
//  MSLogin
//
//  Created by syp on 2020/6/28.
//

#import <Foundation/Foundation.h>
#import <MSBusiness/MSBusinessError.h>
#import <MSBusiness/MideaSecurity.h>
#import "MSLoginAndRegistTypes.h"

@interface MSLoginUtils : NSObject


+ (BOOL)isValidEmail:(NSString *)email;
//是否纯数字(电话号码）
+(BOOL)checkInputShouldNumber:(NSString *)number;

+ (MSBusinessError *)checkEmail:(NSString *)email;
+ (MSBusinessError *)checkVerifyCode:(NSString *)verifyCode;
+ (MSBusinessError *)checkPassword:(NSString *)password confirmPassword:(NSString *)confirmPassword;
+ (BOOL)checkPasswordRule:(NSString *)password;

+ (NSString *)encryptRegisterPassword:(NSString *)password;
+ (NSString *)encryptLoginPassword:(NSString *)password loginId:(NSString*)loginId;
+ (NSString *)encryptThirdLoginUserId:(NSString *)userId;

//AES加密验证码
+ (NSString *)encryptVerifyCode:(NSString *)VerifyCode;

////存储和清除登录、注册成功相关信息
//+ (void)saveLoginOrRegisterData:(MSUserLoginResult*)result;
//+ (void)clearLoginOrRegisterData;

+ (void)postLoginInNotification;
+ (void)postLoginOutNotification;
+ (NSString*)getCurrentSystemTime;
+ (NSInteger)convertThirdTypeToUploadType:(NSString *)thirdType;

@end


