//
//  MSLoginUtils.m
//  MSLogin
//
//  Created by syp on 2020/6/28.
//

#import "MSLoginUtils.h"
#import "MSLoginBundle.h"
#import "MSLoginError.h"
#import <MSBusiness/MSAppInfo.h>
#import <MSBusiness/MSUserDefaultTools.h>
#import <MSBusiness/MSNotificationConst.h>

@implementation MSLoginUtils


+ (BOOL)isValidEmail:(NSString *)email{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{1,20}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    if (![emailTest evaluateWithObject:email]) {
        return NO;
    }
    return YES;
}


+(BOOL)checkInputShouldNumber:(NSString *)number{
    NSString *regex =@"[0-9]*";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    if ([pred evaluateWithObject:number]) {
        return YES;
    }
    return NO;
}

+ (MSBusinessError *)checkEmail:(NSString *)email
{
    if (![self isValidEmail:email]) {
        return [MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeInvalidEmail];
    }
    return nil;
}

+ (MSBusinessError *)checkVerifyCode:(NSString *)verifyCode {
    if (verifyCode.length < 6) {
        return [MSLoginError errorWithLoginErrorCode:MSLoginErrorCodeVerifyCodeError];
    }
    return nil;
}

+ (MSBusinessError *)checkPassword:(NSString *)password confirmPassword:(NSString *)confirmPassword
{
    if (![password isEqualToString:confirmPassword]) {
        return [MSLoginError errorWithLoginErrorCode:MSLoginErrorCodePasswordNotSame];
    }else if (password.length < 6 || confirmPassword.length < 6){
        return [MSLoginError errorWithLoginErrorCode:MSLoginErrorCodePasswordLengthError];
    }
    
    return nil;
}

//密码规则必须包含数字和字母
+ (BOOL)checkPasswordRule:(NSString *)password {
    NSString * regex = @"^(?![^0-9]+$)(?![^a-zA-Z]+$)[\\s\\S]{1,20}$";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    BOOL result = [pred evaluateWithObject:password];
    return result;
}

//注册时密码加密、第三方登录绑定邮箱时密码加密 AESCBC（sha256(password),sha256(appkey)前16位，sha256(appkey)紧接着的16位）
+ (NSString *)encryptRegisterPassword:(NSString *)password
{
    password = [MideaSecurity getSha256String:password];
    NSString* appKey = [MSAppInfo appKey];
    appKey = [MideaSecurity getSha256String:appKey];
    
    if (appKey.length < 32) {
        return nil;
    }
    NSString *key = [appKey substringWithRange:NSMakeRange(0, 16)];
    NSString *iv = [appKey substringWithRange:NSMakeRange(16, 16)];

    NSString *result = [[MideaSecurity AESCBCEncrypt:password key:key iv:iv] lowercaseString];

    return result;
}

//AES加密验证码
+ (NSString *)encryptVerifyCode:(NSString *)VerifyCode{
    
    NSString *appKey = [MSAppInfo verifyAESKey];
    appKey = [MideaSecurity getSha256String:appKey];
    
    if (appKey.length < 32) {
        return nil;
    }
    NSString *key = [appKey substringWithRange:NSMakeRange(0, 16)];
    NSString *iv = [appKey substringWithRange:NSMakeRange(16, 16)];

    NSString *result = [[MideaSecurity AESCBCEncrypt:VerifyCode key:key iv:iv] lowercaseString];
    return result;
    
}



//第三方登录userId加密 AESCBC（userId,sha256(appkey)前16位，sha256(appkey)紧接着的16位）
+ (NSString *)encryptThirdLoginUserId:(NSString *)userId{
    NSString* appKey = [MSAppInfo appKey];
    appKey = [MideaSecurity getSha256String:appKey];
    
    if (appKey.length < 32) {
        return nil;
    }
    NSString *key = [appKey substringWithRange:NSMakeRange(0, 16)];
    NSString *iv = [appKey substringWithRange:NSMakeRange(16, 16)];

    NSString *result = [[MideaSecurity AESCBCEncrypt:userId key:key iv:iv] lowercaseString];

    return result;
}

//登录时加密：sha256(loginId+sha256(password)+appkey)
+ (NSString *)encryptLoginPassword:(NSString *)password loginId:(NSString*)loginId{
    password = [MideaSecurity getSha256String:password];
    NSString* appKey = [MSAppInfo appKey];

    NSString *result = [MideaSecurity getSha256String:[NSString stringWithFormat:@"%@%@%@", loginId,password,appKey]];
    
    return result;
}

//+(void)saveLoginOrRegisterData:(MSUserLoginResult *)result{
//    [MSUserDefaultTools saveUserAccount:result.email?:@""];
//    [MSUserDefaultTools saveMideaCloudRandomData:result.randomData?:@""];
//    [MSUserDefaultTools saveMideaCloudAccessToken:result.accessToken?:@""];
//    [MSUserDefaultTools saveUserUid:result.uid?:@""];
//    [MSUserDefaultTools saveUserNickname:result.nickname?:@""];
//    
//    if (result.mdata && [result.mdata isKindOfClass:[NSDictionary class]]) {
//        NSDictionary* mdata = result.mdata;
//        if (mdata[@"accessToken"] && [mdata[@"accessToken"] isKindOfClass:[NSString class]]) {
//            NSString* mAccessToken = mdata[@"accessToken"];
//            [MSUserDefaultTools saveMasAccessToken:mAccessToken?:@""];
//        }else{
//            [MSUserDefaultTools saveMasAccessToken:@""];
//        }
//        
//        if (mdata[@"tokenPwdInfo"] && [mdata[@"tokenPwdInfo"] isKindOfClass:[NSDictionary class]]) {
//            NSDictionary* tokenPwdInfo = mdata[@"tokenPwdInfo"];
//            if (tokenPwdInfo[@"tokenPwd"] && [tokenPwdInfo[@"tokenPwd"] isKindOfClass:[NSString class]]) {
//                NSString* tokenPwd = tokenPwdInfo[@"tokenPwd"];
//                [MSUserDefaultTools saveMasTokenPwd:tokenPwd?:@""];
//            }else{
//                [MSUserDefaultTools saveMasTokenPwd:@""];
//            }
//        }else{
//            [MSUserDefaultTools saveMasTokenPwd:@""];
//        }
//    }else{
//        [MSUserDefaultTools saveMasAccessToken:@""];
//        [MSUserDefaultTools saveMasTokenPwd:@""];
//    }
//    
//}
//
//+ (void)clearLoginOrRegisterData {
//    [MSUserDefaultTools clearUserLoginOrRegisterData];
//}

+ (void)postLoginInNotification {
    [[NSNotificationCenter defaultCenter] postNotificationName:kMideaLoginSuccessNotification object:nil userInfo:nil];
}

+ (void)postLoginOutNotification {
    [[NSNotificationCenter defaultCenter] postNotificationName:kMideaQuitLoginNotification object:nil userInfo:nil];
}

//当前时间戳
+ (NSString*)getCurrentSystemTime {
    NSDate* date = [NSDate dateWithTimeIntervalSinceNow:0];
    NSTimeInterval a = [date timeIntervalSince1970];
    NSString *timeString = [NSString stringWithFormat:@"%.0f", a];
    return timeString;
}

//第三方登录的thirdType转换为埋点上报的type  facebook是32 Twitter是89 apple是79
+ (NSInteger)convertThirdTypeToUploadType:(NSString *)thirdType {
    NSInteger uploadType = 1;
    if ([thirdType isEqualToString:@"32"]) {
        uploadType = 1;
    } else if ([thirdType isEqualToString:@"89"]) {
        uploadType = 2;
    } else if ([thirdType isEqualToString:@"79"]) {
        uploadType = 3;
    }
    return uploadType;
}

@end
