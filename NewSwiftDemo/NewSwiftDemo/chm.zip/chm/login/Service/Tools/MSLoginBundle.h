//
//  MSLoginBundle.h
//  MSLogin
//
//  Created by syp on 2020/6/17.
//


#import <OEMFoundation/OEMBundle.h>
#import <OEMFoundation/HGLocalizationResource.h>

#define MSCurrentBundle [MSLoginBundle currentBundle]
#define OEMStringBundle [MSLoginBundle strBundle]

#define MSResourceString(key) [HGLocalizationResource localizedStringForKey:key table:nil inBundle:OEMStringBundle]
#define MSResourceImage(imageName) [HGLocalizationResource localizedImageForImageName:imageName inBundle:MSCurrentBundle]

@interface MSLoginBundle : OEMBundle

@end

