//
//  MSLoginError.m
//  MSLogin
//
//  Created by syp on 2020/6/28.
//

#import "MSLoginError.h"
#import "MSLoginBundle.h"
#import <OEMFoundation/OEMCustomize.h>

NSString * const MSLoginPresenterErrorDomain = @"MSLoginPresenterErrorDomain";


@implementation MSLoginError

+ (instancetype)errorWithLoginErrorCode:(MSLoginErrorCode)code{
    NSString *key = @"";
    switch (code) {
        case MSLoginErrorCodeInvalidEmail:{
            if ([OEMCustomize getUIntValueWithKey:@"SupportedAccount"] == 0) {
                key = @"register_page_tip_mail_format_error";
            }else{
                key = @"register_page_tip_mail_format_error_email_account_only";
            }
        }
            break;
        case MSLoginErrorCodePasswordNotSame:{
            key = @"login_page_login_password_inconsistent";
        }
            break;
        case MSLoginErrorCodePasswordLengthError:{
            key = @"login_page_password_minimal_length";
        }
            break;
        case MSLoginErrorCodeThirdLoginError:{
            key = @"login_page_thirdpart_login_fail";
        }
            break;
        case MSLoginErrorCodeThirdLoginCancel:{
            key = @"login_page_thirdpart_login_cancel";
        }
            break;
        case MSLoginErrorCodeVerifyCodeError:{
            key = @"login_page_verification_code_length";
        }
            break;
            
        default:
            break;
    }
    
//    NSString *key = [NSString stringWithFormat:@"MSLoginErrorCode_%lu", (unsigned long)code];
    NSString *localizedDescription = MSResourceString(key);
    
    MSLoginError *loginError = [[MSLoginError alloc] initWithDomain:@"MSLoginPresenterErrorDomain" code:code userInfo:@{NSLocalizedDescriptionKey : localizedDescription}];
    
    return loginError;
}

@end
