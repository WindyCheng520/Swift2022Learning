//
//  OEMAccountManager.m
//  MSLogin
//
//  Created by Neil 韦学宁 on 2022/3/15.
//

#import "OEMAccountManager.h"
#import <MSBusiness/MSLoginInfo.h>
#import <MSBusiness/MSUserInfoManager.h>
#import "MSLoginUtils.h"
#import <OEMFoundation/UIDevice+Category.h>
#import <MSBusiness/MSUserDefaultTools.h>

@implementation OEMAccountManager

+ (BOOL)isLogin{
    return [MSUserInfoManager shareManager].isLogin;
}

+ (nullable MSLoginInfo *)getLoginUser{
    return [MSUserInfoManager shareManager].loginInfoModel;
}

+ (nullable NSString *)getAccessToken{
    return [MSUserInfoManager shareManager].loginInfoModel.accessToken;
}

+ (nullable NSString *)getUid{
    return [MSUserInfoManager shareManager].loginInfoModel.uid;
}

+ (void)loginWithAccount:(NSString *)account
                password:(NSString *)password
                 success:(MSLoginRepositoryUserLoginSuccess)success
                 failure:(MSLoginRepositoryFailureBlock)failure{
    password = [MSLoginUtils encryptRegisterPassword:password];
    BOOL isEmail = [MSLoginUtils isValidEmail:account]; //是否邮箱
    NSString *receiver = isEmail?account:[NSString stringWithFormat:@"%@%@", HGCurrentCountry.phoneCode, account];
    NSString *token = [[NSUserDefaults standardUserDefaults] objectForKey:@"MSDeviceTokenKey"];
    NSDictionary *paras = @{@"loginAccount" : receiver,
                            @"password": password,
                            @"phoneModel" : [UIDevice machineType],
                            @"phoneSysVNum" : [[UIDevice currentDevice] systemVersion],
                            @"encryptVersion": @"1",
                            @"pushToken":token?:@""
    };
    
    [MSLoginAndRegistRepository loginWithParas:paras
                                           success:^(MSLoginInfo *result) {
        [[MSUserInfoManager shareManager] saveLoginInfoDataWithModel:result];
        [MSUserDefaultTools saveLastLoginAccount:account];
        safeCallBlock(success, result);
    }
                                           failure:^(MSBusinessError *error) {
        safeCallBlock(failure, error);
    }];
}

@end
