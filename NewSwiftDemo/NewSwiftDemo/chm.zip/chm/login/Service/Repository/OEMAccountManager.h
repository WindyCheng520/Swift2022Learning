//
//  OEMAccountManager.h
//  MSLogin
//
//  Created by Neil 韦学宁 on 2022/3/15.
//

#import "MSLoginAndRegistRepository.h"
#import <MSBusiness/MSLoginInfo.h>

NS_ASSUME_NONNULL_BEGIN

/*
 被踢下线通知 kMideaForceLogoutNotification
 */

//用户退出

@interface OEMAccountManager : MSLoginAndRegistRepository

//判断是否已经登录
+ (BOOL)isLogin;

//获取已登录的用户信息
+ (nullable MSLoginInfo *)getLoginUser;

//获取当前已登录用户token
+ (nullable NSString *)getAccessToken;

//获取当前已登录用户id
+ (nullable NSString *)getUid;

+ (void)loginWithAccount:(NSString *)account
                password:(NSString *)password
                 success:(MSLoginRepositoryUserLoginSuccess)success
                 failure:(MSLoginRepositoryFailureBlock)failure;

@end

NS_ASSUME_NONNULL_END
