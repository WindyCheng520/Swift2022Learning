//
//  MSLoginRepository.h
//  MSLogin
//
//  Created by syp on 2020/6/13.
//

#import <Foundation/Foundation.h>
#import "MSLoginAndRegistTypes.h"
#import <MSBusiness/MSLoginInfo.h>
#import <MSBusiness/MSUserInfo.h>

//通用block
typedef void(^MSLoginRepositorySuccessBlock)(void);
typedef void(^MSLoginRepositoryFailureBlock)(MSBusinessError *error);

//业务block
typedef void(^MSLoginRepositoryUserLoginSuccess)(MSLoginInfo *result);
typedef void(^MSLoginRepositoryUserVerifyCodeAuthSuccess)(MSVerifyCodeAuthResult *result);
typedef void(^MSLoginRepositoryUserRegisterSuccess)(MSLoginInfo *result);
typedef void(^MSLoginRepositoryUserGetCountrySuccess)(NSArray<MSCountryGetResult *> *result);
typedef void(^MSLoginRepositoryUserThirdLoginSuccess)(MSLoginInfo *result);
typedef void(^MSLoginRepositoryUserThirdLoginBindSuccess)(void);
typedef void(^MSLoginRepositoryUserAutoLoginSuccess)(MSAutoLoginResult *result);
typedef void(^MSLoginRepositoryUserUnregisterSuccessBlock)(void);
typedef void(^MSLoginRepositoryUserInfoSuccess)(MSUserInfo *result);


@interface MSLoginAndRegistRepository : NSObject

//验证账号是否存在
/*
 paras说明
 参数        必选         说明
 account    true        用户邮箱、手机号码（带区号，不带加号）
 
 存在时报错 ("14003", "User is already existed")
 */
+ (void)verifyUserExistWithParas:(NSDictionary *)paras
                         success:(MSLoginRepositorySuccessBlock)success
                         failure:(MSLoginRepositoryFailureBlock)failure;


/// 获取验证码
/// @param paras 入参
/*
 paras说明
 参数                 必选      类型          说明
 verifyIdReceiver    true     string        验证码的接收地址（邮箱，带有区号的手机号码）
 type                false    int           1 注册、2 忘记密码、3 修改密码、4第三方登录、5账号注销 默认为1
 channel             false    int           当type=4时，必填 32 facebook 79 apple 89 Twitter
 userFlag            false    int           验证码接收方式，0：邮箱、1：手机，如果不送，默认为0
 */
+ (void)sendVerifyCodeWithParas:(NSDictionary *)paras
                        success:(MSLoginRepositorySuccessBlock)success
                        failure:(MSLoginRepositoryFailureBlock)failure;

//校验验证码
/*
 paras说明
 参数                 必选         说明
 verifyId            true        验证码（验证码只有一次使用机会，只要验证码成功匹配了，服务端就把服务端保存的验证码失效）
 verifyIdReceiver    true        验证码的接收地址（邮箱，手机号码），必须跟发送验证码时的值一样
 */
+ (void)authVerifyIdWithParas:(NSDictionary *)paras
                      success:(MSLoginRepositoryUserVerifyCodeAuthSuccess)success
                      failure:(MSLoginRepositoryFailureBlock)failure;

//账号注册
/*
 paras说明
 参数                 必选        说明
 email               false       用户邮箱 ，以邮箱注册时，必输
 phoneAreacode       false       手机区号，以手机注册时，必输
 countryCode         true        国家代码，例如CN，US，DE等等
 userFlag            false       0：邮箱注册、1：手机注册，如果不送，默认为0
 verifyIdReceiver    true        验证码的接收地址（邮箱，手机号码），必须跟发送验证码时的值一样
 password            true        用户密码，AES CBC(sha256（密码）,sha256(appkey).substring(0,16),sha256(appkey).substring(16,32))
 verifyId            true        验证码（验证码只有一次使用机会，只要验证码成功匹配了，服务端就把服务端保存的验证码失效）
 
 邮箱注册必填字段 email password verifyId userFlag countryCode verifyIdReceiver
 
 手机注册必填字段 mobile password verifyId userFlag countryCode phoneAreacode verifyIdReceiver

 */
+ (void)registerWithParas:(NSDictionary *)paras
                  success:(MSLoginRepositoryUserRegisterSuccess)success
                  failure:(MSLoginRepositoryFailureBlock)failure;

//用户登录
/*
 paras说明
 参数             必选     说明
 loginAccount    True     用户账号：1：邮箱、 2：手机号码（附带区号，没有前缀加号）
 password        True     用户密码（SHA256密码）      SHA256. encrypt (loginId +sha256(password原文) + apiKey)
 phoneModel      false    用户使用的手机型号，如：IPHONE 6
 phoneSysVNum    false    用户使用的手机操作系统版本号，如：IOS 9.3.1
 encryptVersion  false    加密版本，1是aes128 cbc 加密方式
 pushToken       false    iOS或者Android的pushToken
 */
+ (void)loginWithParas:(NSDictionary *)paras
               success:(MSLoginRepositoryUserLoginSuccess)success
               failure:(MSLoginRepositoryFailureBlock)failure;

        
/// 获取国家地区信息
/// @param paras 参数可传空
/// @param success 成功回调
/// @param failure 失败回调
+ (void)getArea:(NSDictionary *)paras
        success:(MSLoginRepositoryUserGetCountrySuccess)success
        failure:(MSLoginRepositoryFailureBlock)failure;


//设置国家地区信息
+ (void)userSetCountryDataWithParas:(NSDictionary *)paras
                            success:(MSLoginRepositorySuccessBlock)success
                            failure:(MSLoginRepositoryFailureBlock)failure;

//第三方账号登录
/*
 paras说明
 参数                 必选     说明
 thirdUID           True     第三方登录ID，使用AES_CBC加密，与校验码的加密方法一样
 token              True     第三方应用的token
 channel            True     第三方登录渠道标识 32 facebook 79 apple 89 twitter
 email              false    要绑定第三方ID的我方用户邮箱（只在绑定第三方ID时需要）
 mobile             false    要绑定第三方ID的我方手机号码（只在绑定第三方ID时需要）
 phoneAreacode      false    要绑定第三方ID的我方手机区号（只在绑定第三方ID时需要）
 countryCode        false    要绑定第三方ID的我方国家代码（只在绑定第三方ID时需要）
 userFlag           false    要绑定第三方ID的验证码接收方式（只在绑定第三方ID时需要），送null时，表示三方登录，否则表示绑定三方账号时，我方账号得注册方式 0：邮箱 1：手机邮箱
 verifyIdReceiver   false    要绑定第三方ID的验证码接收地址（只在绑定第三方ID时需要）
 extraInfo          false    要绑定第三方ID的额外信息，例如第三方ID的邮箱（只在绑定第三方ID时需要）
 password           false    要绑定第三方ID的我方用户邮箱密码（只在绑定第三方ID时，且该邮箱没有被注册）
 verifyId           false    校验码（只在绑定第三方ID时需要）
 phoneModel         false    用户使用的手机型号，如：IPHONE 6
 phoneSysVNum       false    用户使用的手机操作系统版本号，如：IOS 9.3.1
 encryptVersion     false    加密版本，1是aes128 cbc 加密方式
 pushToken          false    iOS或者Android的pushToken
 */
+ (void)thirdLoginWithParas:(NSDictionary*)paras
                    success:(MSLoginRepositoryUserThirdLoginSuccess)success
                    failure:(MSLoginRepositoryFailureBlock)failure;

//第三方账号绑定
/*
 paras说明
 参数         必选    说明
 thirdUID    True    第三方登录ID，使用AES_CBC加密，与校验码的加密方法一样
 token       True    第三方应用的token
 channel     True    第三方登录渠道标识 32 facebook 79 apple 89 twitter
 extraInfo   false   要绑定第三方ID的额外信息，例如第三方ID的邮箱
 */
+ (void)thirdBindWithParas:(NSDictionary*)paras
                   success:(MSLoginRepositoryUserThirdLoginBindSuccess)success
                   failure:(MSLoginRepositoryFailureBlock)failure;
//第三方账号解绑
/*
 paras说明
 参数        必选    说明
 channel    True    第三方登录渠道标识 32 facebook 79 apple 89 twitter
 */
+ (void)thirdUnBindWithParas:(NSDictionary*)paras
                     success:(MSLoginRepositorySuccessBlock)success
                     failure:(MSLoginRepositoryFailureBlock)failure;

//自动登录续签token，APP已将token缓存至本地，当应用启动时，并且本地有缓存token，建议调用一次此接口
/*
 paras说明：可传空
 */
+ (void)tokenExtendWithParas:(NSDictionary *)paras
                     success:(MSLoginRepositoryUserAutoLoginSuccess)success
                     failure:(MSLoginRepositoryFailureBlock)failure;

//更新APNS token
/*
 参数         必选      说明
 pushToken   true      用于推送的pushToken,退出登录传空
 */
+ (void)pushTokenWithParas:(NSDictionary *)paras
                   success:(MSLoginRepositorySuccessBlock)success
                   failure:(MSLoginRepositoryFailureBlock)failure;

//用户登出
/*
 paras说明:传空
 */
+ (void)logoutWithParas:(NSDictionary *)paras
                success:(MSLoginRepositorySuccessBlock)success
                failure:(MSLoginRepositoryFailureBlock)failure;

//用户账号注销
/*
 paras说明
 参数                 必选        说明
 verifyId            true        验证码（验证码只有一次使用机会，只要验证码成功匹配了，服务端就把服务端保存的验证码失效）
 verifyIdReceiver    true        验证码的接收地址（邮箱，手机号码），必须跟发送验证码时的值一样
 */
+ (void)unresigerWithParas:(NSDictionary *)paras
               success:(MSLoginRepositoryUserUnregisterSuccessBlock)success
               failure:(MSLoginRepositoryFailureBlock)failure;

//用户信息查询
+ (void)queryUserInfo:(MSLoginRepositoryUserInfoSuccess)success
              failure:(MSLoginRepositoryFailureBlock)failure;

//更新用户信息
/*
 参数         必选          说明
 email       false        用户邮箱（目前用户邮箱和用户账号都是email）
 password    false        用户密码，AES CBC(sha256（密码）,sha256(appkey).substring(0,16),sha256(appkey).substring(16,32))
 nickName    false        用户昵称
 gender      false        性别
 birthday    false        生日
 mobile      false        手机号码
 face        false        头像base64
 face200     false        头像 200x200x80 url
 srcface     false        原图头像url
 memo        false        备注
 */
+ (void)updateUserInfoWithParas:(NSDictionary *)paras
                       ssuccess:(MSLoginRepositorySuccessBlock)success
                        failure:(MSLoginRepositoryFailureBlock)failure;

//更改密码
/*
 参数                 必选         说明
 password            true        用户密码，AES CBC(sha256（密码）,sha256(appkey).substring(0,16),sha256(appkey).substring(16,32))
 verifyId            true        验证码（验证码只有一次使用机会，只要验证码成功匹配了，服务端就把服务端保存的验证码失效）
 verifyIdReceiver    true        验证码的接收地址（邮箱，手机号码），必须跟发送验证码时的值一样
 */
+ (void)resetPasswordWithParas:(NSDictionary *)paras
                      ssuccess:(MSLoginRepositorySuccessBlock)success
                       failure:(MSLoginRepositoryFailureBlock)failure;

//设置语言
/*
 参数                 必选         说明
 language            true        目前仅支持4种语言分别是 zh_CN（默认）：简体中文、en_US：美国英语 ru_RU:俄语 zh_HK：繁体中文
 
 */
+ (void)setLanguageWithParas:(NSDictionary *)paras
                     success:(MSLoginRepositorySuccessBlock)success
                     failure:(MSLoginRepositoryFailureBlock)failure;
//上传图片
/*
 
 */
+ (void)uploadImageWithParas:(NSDictionary *)paras
                     success:(MSLoginRepositorySuccessBlock)success
                     failure:(MSLoginRepositoryFailureBlock)failure;

@end

