//
//  MSLoginAndRegistRepository.m
//  MSLogin
//
//  Created by syp on 2020/6/13.
//

#import "MSLoginAndRegistRepository.h"
#import <MSBusiness/BusinessRequestManager.h>
#import <MSBusiness/BusinessResponse.h>
#import <MSBusiness/MSAppInfo.h>
#import <MJExtension/MJExtension.h>
#import <MSBusiness/MSMessageCenterProtocol.h>
#import <MSBusiness/MSUserInfoRepository.h>

#define Get_Response      BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject]

#define If_Get_Response_Is_OK Get_Response; if (res.isOK)

#define If_Get_Response_Is_OK_Or_Not_Handler(E)                                 \
    If_Get_Response_Is_OK {                                                     \
        E *result = [E mj_objectWithKeyValues:res.data];                      \
        safeCallBlock(success, result);                                         \
    } else {                                                                    \
        MSBusinessError *e = [MSBusinessError errorWithDomain:MSLoginAndRegistErrorDomain code:res.code localizedDescription:res.msg];        \
        safeCallBlock(failure, e);                                              \
    }

#define If_Get_Response_Is_OK_Or_Not_Handler2                                    \
    If_Get_Response_Is_OK {                                                     \
        safeCallBlock(success);                                                 \
    } else {                                                                    \
        MSBusinessError *e = [MSBusinessError errorWithDomain:MSLoginAndRegistErrorDomain code:res.code localizedDescription:res.msg];        \
        safeCallBlock(failure, e);                                              \
    }

#define Success_Block(E) ^(NSURLSessionTask * _Nonnull httpbase, id  _Nonnull responseObject) {If_Get_Response_Is_OK_Or_Not_Handler(E)}

#define Success_Block2 ^(NSURLSessionTask * _Nonnull httpbase, id  _Nonnull responseObject) {If_Get_Response_Is_OK_Or_Not_Handler2}


#define Failure_Handler                                                         \
    MSBusinessError *e = [MSBusinessError errorWithNetwork:error];                              \
    safeCallBlock(failure, e);

#define Failure_Block ^(NSURLSessionTask * _Nonnull httpbase, NSError * _Nonnull error) {Failure_Handler}

#define Post(url,paras,result)    [self POST:url parameters:paras success:Success_Block(result) failure:Failure_Block]

#define Post2(url,paras)    [self POST:url parameters:paras success:Success_Block2 failure:Failure_Block]

//获取国家地区信息
#define MSCountry_Get                               @"/v1/user/area/get"

//获取(短信或邮箱）验证码--1.1.2
#define MSLogin_User_Verify_Code_Get                @"/v1/user/verify/code/send"

//校验验证码-----1.1.2
#define MSLogin_User_Verify_Code_Auth               @"/v1/user/auth/verifyId"

//验证账号是否存在---1.1.2
#define MSLogin_User_Exist                          @"/v1/user/exist/verify"

//用户注册-----1.1.2
#define MSLogin_User_Register                       @"/v1/user/register"

//用户登录
#define MSLogin_User_Login                          @"/v1/user/login"

//第三方用户登录
#define MSLogin_User_Third_Login                    @"/v1/user/third/login"

//第三方用户绑定
#define MSLogin_User_Third_Bind                     @"/v1/user/third/bind"

//第三方用户解除绑定
#define MSLogin_User_Third_unBind                   @"/v1/user/third/unbind"

//自动登录token失效重新获取token
#define MSLogin_User_AutoLogin                      @"/v1/user/token/extend"

//退出登录
#define MSLogin_User_Logout                         @"/v1/user/logout"

//更新用户信息
#define MSLogin_User_Update_Info                    @"/v1/user/update"

//密码重置
#define MSLogin_User_Reset                          @"/v1/user/passwd/reset"

//设置国家地区信息
#define MSCountry_Set                               @"111"







//账户注销
#define MSLogin_User_unregister                  @"/v1/user/account/unregister"

//设置语言
#define MSLogin_language_setting                  @"/v1/user/lan/area/setting"


//根据账号搜索用户user/account/search

//上传用户头像 user/profile/pic/upload
//获取用户详细信息 user/info/get
//修改用户基本信息 user/info/modify
//用户更换邮箱 user/email/ change
//用户密码验证 user/password/auth
//用户设置语言、地区user/lan/area/setting
//消息订阅开关获取user/msg/subscribe/get
//消息订阅开关更新user/msg/subscribe/update
//用户授权 user/private/authorize
//用户取消授权 user/private/authorize/cancel
//用户查询授权状态 user/private/authorize/status
//刷新pushToken user/push/token/update
//家电分享-用户请求分享appliance/user/share/request/send（单用户）
//家电主人分享家电给用户 appliance/user/share/invite/send（单用户）
//家电分享-（好友、主人）回应appliance/user/share/response（单用户）
//用户注销账号 user/account/cancel



@implementation MSLoginAndRegistRepository

+ (void)verifyUserExistWithParas:(NSDictionary*)paras
                success:(MSLoginRepositorySuccessBlock)success
                failure:(MSLoginRepositoryFailureBlock)failure{
    Post2(MSLogin_User_Exist, paras);
}

+ (void)sendVerifyCodeWithParas:(NSDictionary *)paras
               success:(MSLoginRepositorySuccessBlock)success
               failure:(MSLoginRepositoryFailureBlock)failure{
    Post2(MSLogin_User_Verify_Code_Get, paras);
}

+ (void)authVerifyIdWithParas:(NSDictionary *)paras
             success:(MSLoginRepositoryUserVerifyCodeAuthSuccess)success
             failure:(MSLoginRepositoryFailureBlock)failure{
    Post(MSLogin_User_Verify_Code_Auth, paras, MSVerifyCodeAuthResult);
}

+ (void)registerWithParas:(NSDictionary *)paras
                  success:(MSLoginRepositoryUserRegisterSuccess)success
                  failure:(MSLoginRepositoryFailureBlock)failure{
    [self POST:MSLogin_User_Register parameters:paras success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK && [res.data isKindOfClass:[NSDictionary class]]) {
            MSLoginInfo *loginInfo = [MSLoginInfo modelWithDic:res.data];
            safeCallBlock(success, loginInfo);
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSLoginAndRegistErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
        
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}


+ (void)loginWithParas:(NSDictionary *)paras
                   success:(MSLoginRepositoryUserLoginSuccess)success
                   failure:(MSLoginRepositoryFailureBlock)failure{
    [self POST:MSLogin_User_Login parameters:paras success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK && [res.data isKindOfClass:[NSDictionary class]]) {
            MSLoginInfo *loginInfo = [MSLoginInfo modelWithDic:res.data];
            safeCallBlock(success, loginInfo);
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSLoginAndRegistErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
        
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}


+(void)getArea:(NSDictionary *)paras
       success:(MSLoginRepositoryUserGetCountrySuccess)success
       failure:(MSLoginRepositoryFailureBlock)failure{
    
    [self POST:MSCountry_Get parameters:paras success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK){
            if (res.data[@"list"] && [res.data[@"list"] isKindOfClass:[NSArray class]]) {
                NSArray* list = [MSCountryGetResult mj_objectArrayWithKeyValuesArray:res.data[@"list"]];
                safeCallBlock(success, list);
            }else{
                safeCallBlock(success, @[]);
            }
        }else{
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSLoginAndRegistErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}

+(void)userSetCountryDataWithParas:(NSDictionary *)paras
                           success:(MSLoginRepositorySuccessBlock)success
                           failure:(MSLoginRepositoryFailureBlock)failure{
    Post2(MSCountry_Set, paras);
}

//第三方账号登录
+(void)thirdLoginWithParas:(NSDictionary *)paras
                   success:(MSLoginRepositoryUserThirdLoginSuccess)success
                   failure:(MSLoginRepositoryFailureBlock)failure{
    [self POST:MSLogin_User_Third_Login
    parameters:paras
       success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK && [res.data isKindOfClass:[NSDictionary class]]) {
            MSLoginInfo *loginInfo = [MSLoginInfo modelWithDic:res.data];
            safeCallBlock(success, loginInfo);
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSLoginAndRegistErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
    }
       failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}

//第三方账号绑定(已登录）
+(void)thirdBindWithParas:(NSDictionary *)paras
                  success:(MSLoginRepositoryUserThirdLoginBindSuccess)success
                  failure:(MSLoginRepositoryFailureBlock)failure{
    [self POST:MSLogin_User_Third_Bind
    parameters:paras
       success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK ) {
            if (success) {
                success();
            }
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSLoginAndRegistErrorDomain code:res.code localizedDescription:res.msg];
            if (failure) {
                failure(e);
            }
        }
    }
       failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}

+ (void)thirdUnBindWithParas:(NSDictionary*)paras
                     success:(MSLoginRepositorySuccessBlock)success
                     failure:(MSLoginRepositoryFailureBlock)failure{
    [self POST:MSLogin_User_Third_unBind
    parameters:paras
       success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK ) {
            if (success) {
                success();
            }
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSLoginAndRegistErrorDomain code:res.code localizedDescription:res.msg];
            if (failure) {
                failure(e);
            }
        }
    }
       failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}

+(void)tokenExtendWithParas:(NSDictionary *)paras
                    success:(MSLoginRepositoryUserAutoLoginSuccess)success
                    failure:(MSLoginRepositoryFailureBlock)failure{
    Post(MSLogin_User_AutoLogin, paras, MSAutoLoginResult);
}

+ (void)pushTokenWithParas:(NSDictionary *)paras
          success:(MSLoginRepositorySuccessBlock)success
          failure:(MSLoginRepositoryFailureBlock)failure {
    id<MSMessageCenterProtocol> s = [OEMRouter getServiceInstance:@protocol(MSMessageCenterProtocol)];
    if (s) {
        [s bindPushToken:[paras objectForKey:@"pushToken"]  success:success failure:failure];
    }
}

+ (void)logoutWithParas:(NSDictionary *)paras
                success:(MSLoginRepositorySuccessBlock)success
                failure:(MSLoginRepositoryFailureBlock)failure{
    [self POST:MSLogin_User_Logout parameters:paras success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            safeCallBlock(success);
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSLoginAndRegistErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}

//用户账号注销
+ (void)unresigerWithParas:(NSDictionary *)paras
                   success:(MSLoginRepositoryUserUnregisterSuccessBlock)success
                   failure:(MSLoginRepositoryFailureBlock)failure{
    Post2(MSLogin_User_unregister, paras);
}

+ (void)queryUserInfo:(MSLoginRepositoryUserInfoSuccess)success
              failure:(MSLoginRepositoryFailureBlock)failure{
    [MSUserInfoRepository getUserInfoWithSuccess:success failure:failure];
}

+ (void)updateUserInfoWithParas:(NSDictionary *)paras
                       ssuccess:(MSLoginRepositorySuccessBlock)success
                        failure:(MSLoginRepositoryFailureBlock)failure{
    [self POST:MSLogin_User_Update_Info parameters:paras success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            safeCallBlock(success);
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSLoginAndRegistErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}

+ (void)resetPasswordWithParas:(NSDictionary *)paras
                      ssuccess:(MSLoginRepositorySuccessBlock)success
                       failure:(MSLoginRepositoryFailureBlock)failure{
    [self POST:MSLogin_User_Reset parameters:paras success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            safeCallBlock(success);
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSLoginAndRegistErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}

+ (void)setLanguageWithParas:(NSDictionary *)paras
                     success:(MSLoginRepositorySuccessBlock)success
                     failure:(MSLoginRepositoryFailureBlock)failure{
    Post2(MSLogin_language_setting, paras);
}

+ (NSURLSessionDataTask *_Nullable)POST:(NSString *_Nullable)URLString
                             parameters:(NSDictionary *_Nullable)parameters
                                success:(BusinessRequestManagerSuccess _Nullable )success
                                failure:(BusinessRequestManagerFailure _Nullable )failure{
    return [[BusinessRequestManager sharedInstance] POST:URLString
                                              parameters:parameters
                                                   cache:nil
                                                 success:^(NSURLSessionTask * _Nonnull httpbase, id  _Nonnull responseObject) {
        safeCallBlock(success, httpbase, responseObject);
    } failure:^(NSURLSessionTask * _Nonnull httpbase, NSError * _Nonnull error) {
        safeCallBlock(failure, httpbase, error);
    }];
}

@end
