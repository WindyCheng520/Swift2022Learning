//
//  HGCollectionView.h
//  HGUIKit
//
//  Created by syp on 2020/6/17.
//

#import <UIKit/UIKit.h>


@interface HGCollectionView : UICollectionView

@end
