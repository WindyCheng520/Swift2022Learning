//
//  HGBaseNavigationController.h
//  OEMFoundation
//
//  Created by midea on 2021/2/25.
//

#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN

@interface HGBaseNavigationController : UINavigationController

@end

NS_ASSUME_NONNULL_END
