//
//  MSInputView.h
//  MSLogin
//
//  Created by syp on 2020/6/12.
//

#import <UIKit/UIKit.h>

@class MSInputView;
@protocol MSInputViewDelegate <UITextFieldDelegate>

@optional
- (void)inputView:(MSInputView *)inputView didChangeText:(NSString *)text;
- (void)didClickInputView:(MSInputView *)inputView;

@end

@interface MSInputView : UIView

@property (nonatomic, weak) id<MSInputViewDelegate> delegate;
@property (nonatomic, copy)   NSString               *text;
@property (nonatomic, strong) UIColor                *textColor;
@property (nonatomic, strong) UIColor                *placeholderColor;

@property (nonatomic, strong) UIFont                 *font;
@property (nonatomic, copy)   NSString               *placeholder;
@property (nonatomic, getter = isSecureTextEntry) BOOL secureTextEntry;
@property(nonatomic, assign) UIKeyboardType keyboardType;

@property (nonatomic, copy) dispatch_block_t clickRightButtonBlock;

- (void)setLeftIcon:(UIImage *)icon;

- (void)setRightTitle:(NSString *)title font:(UIFont *)font;
- (void)setRightTitleColor:(UIColor *)color;
- (void)setRightImage:(UIImage *)image;
- (void)setRightButtonEnable:(BOOL)enable;
- (void)setBorderColor:(UIColor *)color;

- (void)setTextFieldTag:(NSInteger)tag;
- (void)setRightButtonHidden:(BOOL)hidden;
- (void)setTextFieldBecomeFirstResponder;
- (void)addClickEventToTextField;

-(void)makeConstraints;

@end
