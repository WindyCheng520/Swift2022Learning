//
//  MSTitleAndOneButtonAlertView.h
//  OEMFoundation
//
//  Created by pactera on 2020/12/26.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MSTitleAndOneButtonAlertView : UIView

@property (nonatomic, copy) void(^clickConfirmBlock)(void);

- (instancetype)initWithTitle:(NSString *)title confirmButtonName:(NSString *)confirmButtonName;
- (void)show;
- (void)showWithSuperview:(UIView *)superview;
- (void)dismiss;

@end

NS_ASSUME_NONNULL_END
