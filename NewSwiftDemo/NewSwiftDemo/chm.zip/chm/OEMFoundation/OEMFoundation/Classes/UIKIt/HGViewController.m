//
//  HGViewController.m
//  OEMFoundation
//
//  Created by syp on 2020/6/22.
//

#import "HGViewController.h"
#import "UINavigationController+OEMFullscreenPopGesture.h"
@interface HGViewController() <UIGestureRecognizerDelegate>

@property (nonatomic, assign) BOOL preNavigationBarHidden;
@property (nonatomic, strong) UITapGestureRecognizer *hideKeyboardWhenTapGestureRecognizer;

@end

@implementation HGViewController

static UIImage *__defaultBackImage;
+ (void)setDefaultBackImage:(UIImage *)defaultBackImage
{
    __defaultBackImage = defaultBackImage;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // 配置popFullScreen
    self.fd_prefersNavigationBarHidden = [self navigationBarHidden];
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.canRightSlideBack = YES;
    [self createLeftButtonWithImage:__defaultBackImage];
    [self printStack];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];

    if([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.delegate = self;
    }
}

-(void)setCanRightSlideBack:(BOOL)canRightSlideBack{
    _canRightSlideBack = canRightSlideBack;
    self.fd_interactivePopDisabled = !_canRightSlideBack;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (BOOL)navigationBarHidden
{
    return NO;
}

- (UIButton *)createRightButtonWithTitle:(NSString *)title font:(UIFont *)font color:(UIColor *)color
{
    if (title.length == 0 || !font || !color) return nil;
    
    UIButton *rightButton = [[UIButton alloc] initWithFrame:CGRectZero];
    [rightButton setTitle:title forState:UIControlStateNormal];
    rightButton.titleLabel.font = font;
    [rightButton sizeToFit];
    [rightButton setTitleColor:color forState:UIControlStateNormal];
    [rightButton addTarget:self action:@selector(rightBarButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
    self.navigationItem.rightBarButtonItem = rightItem;
    return rightButton;
}

- (UIButton *)createRightButtonWithImage:(UIImage *)image
{
    if (!image) return nil;
    
    return [self createRightButtonWithTitlesWithImages:@[image]].firstObject;
}

- (NSArray<UIButton *> *)createRightButtonWithTitlesWithImages:(NSArray<UIImage *> *)images
{
    if (images.count == 0) return nil;
    
    NSMutableArray<UIButton *> *buttons = [NSMutableArray new];
    NSMutableArray *itemArray = NSMutableArray.new;
    [images enumerateObjectsUsingBlock:^(UIImage *image, NSUInteger idx, BOOL * _Nonnull stop) {
        UIButton *rightButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, image.size.width, image.size.height)];
        [rightButton setImage:image forState:UIControlStateNormal];
        [rightButton addTarget:self action:@selector(rightBarButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        rightButton.tag = idx;
        UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
        [itemArray addObject:rightItem];
        [buttons addObject:rightButton];
    }];
    self.navigationItem.rightBarButtonItems = itemArray;
    return buttons;
}

- (void)rightBarButtonClick:(UIButton *)button
{
    
}

- (UIButton *)createLeftButtonWithImage:(UIImage *)image
{
    if (!image) return nil;
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setImage:image forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 0, image.size.width, image.size.height);
    [button addTarget:self action:@selector(leftBarButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *Item = [[UIBarButtonItem alloc] initWithCustomView:button];
    [Item setBackgroundImage:image forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    self.navigationItem.leftBarButtonItem = Item;
    return button;
}

- (void)leftBarButtonClick:(UIButton *)button
{
    if (self.navigationController.viewControllers.count > 1) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    else {
        [self dismissViewControllerAnimated:YES completion:Nil];
    }
}

- (void)setHiddenKeyboardWhenTap:(BOOL)hiddenKeyboardWhenTap
{
    _hiddenKeyboardWhenTap = hiddenKeyboardWhenTap;
    
    if (hiddenKeyboardWhenTap) {
        if (!self.hideKeyboardWhenTapGestureRecognizer) {
            self.hideKeyboardWhenTapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideKeyboard)];
            self.hideKeyboardWhenTapGestureRecognizer.cancelsTouchesInView = NO;
            [self.view addGestureRecognizer:self.hideKeyboardWhenTapGestureRecognizer];
        }
    } else {
        if (self.hideKeyboardWhenTapGestureRecognizer) {
            [self.view removeGestureRecognizer:self.hideKeyboardWhenTapGestureRecognizer];
        }
    }
}

- (void)hideKeyboard
{
    [self.view endEditing:YES];
}

- (void)printStack {
    if (self.navigationController.viewControllers.count > 0) {
        NSLog(@"+++++++++++++++++++++++++++++++++++++");
        for (NSInteger i = 0; i < self.navigationController.viewControllers.count; i++) {
            UIViewController *VC = self.navigationController.viewControllers[i];
            NSLog(@"栈编号%ld,类名==%@",(long)i,NSStringFromClass([VC class]));
        }
        NSLog(@"+++++++++++++++++++++++++++++++++++++");
    }
    
}

#pragma mark - UIGestureRecognizerDelegate
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer
{
    if (self.navigationController.viewControllers.count <= 1 || !self.canRightSlideBack) {
        return NO;
    }
    return YES;
}


@end
