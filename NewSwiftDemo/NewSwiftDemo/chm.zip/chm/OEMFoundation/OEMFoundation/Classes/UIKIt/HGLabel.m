//
//  HGLabel.m
//  HGUIKit
//
//  Created by syp on 2020/6/17.
//


#import "HGLabel.h"


@interface HGLabel ()

/** 描边宽度*/
@property (nonatomic, assign) CGFloat outLineWidth;

/** 描边颜色*/
@property (nonatomic, strong) UIColor *outLinetextColor;

/** 里面字体默认颜色*/
@property (nonatomic, strong) UIColor *labelTextColor;

@end


@implementation HGLabel

//-(instancetype)init{
//    if (self = [super init]) {
//        self.textAlignment = NSTextAlignmentNatural;
//    }
//    return self;
//}
//
//- (instancetype)initWithFrame:(CGRect)frame
//{
//    self = [super initWithFrame:frame];
//    if (self) {
//    }
//    return self;
//}

- (void)drawTextInRect:(CGRect)rect
{
    //描边
    if (self.outLineWidth > 0) {
        CGContextRef c = UIGraphicsGetCurrentContext();

        CGContextSetLineWidth(c, self.outLineWidth);

        CGContextSetLineJoin(c, kCGLineJoinRound);

        CGContextSetTextDrawingMode(c, kCGTextStroke);

        self.textColor = self.outLinetextColor;

        [super drawTextInRect:UIEdgeInsetsInsetRect(rect, self.edgeInsets)];

        self.textColor = self.labelTextColor;

        CGContextSetTextDrawingMode(c, kCGTextFill);
    }

    [super drawTextInRect:UIEdgeInsetsInsetRect(rect, self.edgeInsets)];
}

- (void)setOutLineWidth:(CGFloat)outLineWidth outLinetextColor:(UIColor *)outLinetextColor labelTextColor:(UIColor *)labelTextColor
{
    self.outLineWidth = outLineWidth;
    self.outLinetextColor = outLinetextColor;
    self.labelTextColor = labelTextColor;
}

+ (instancetype)labelWithFont:(UIFont *)font
                         text:(NSString *)text
                    textColor:(UIColor *)textColor
{
    return [self labelWithFont:font text:text textAlignment:NSTextAlignmentNatural textColor:textColor];
}

+ (instancetype)labelWithFont:(UIFont *)font
                         text:(NSString *)text
                textAlignment:(NSTextAlignment)textAlignment
                    textColor:(UIColor *)textColor
{
    return [self labelWithFont:font text:text textAlignment:textAlignment textColor:textColor frame:CGRectZero];
}

+ (instancetype)labelWithFont:(UIFont *)font
                         text:(NSString *)text
                textAlignment:(NSTextAlignment)textAlignment
                    textColor:(UIColor *)textColor
                        frame:(CGRect)frame
{
    HGLabel *label = [[HGLabel alloc] initWithFrame:frame];
    label.font = font;
    label.text = text;
    label.textAlignment = textAlignment;
    label.textColor = textColor;

    return label;
}

- (CGRect)textRectForBounds:(CGRect)bounds limitedToNumberOfLines:(NSInteger)numberOfLines
{
    CGRect rect = [super textRectForBounds:bounds limitedToNumberOfLines:numberOfLines];
    rect.origin.x = self.edgeInsets.left;
    rect.origin.y = self.edgeInsets.top;
    rect.size.width += self.edgeInsets.left + self.edgeInsets.right;
    rect.size.height += self.edgeInsets.top + self.edgeInsets.bottom;
    return rect;
}
-(void)dealloc{
    
}
@end
