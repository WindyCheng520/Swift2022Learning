//
//  HGTableView.h
//  pkgame iOS
//
//  Created by shiyanpeng on 2018/3/23.
//

#import <UIKit/UIKit.h>


@interface HGTableView : UITableView

@end
