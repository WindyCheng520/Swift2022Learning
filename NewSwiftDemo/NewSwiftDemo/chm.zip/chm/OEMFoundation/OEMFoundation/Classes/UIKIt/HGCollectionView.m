//
//  HGCollectionView.m
//  HGUIKit
//
//  Created by syp on 2020/6/17.
//


#import "HGCollectionView.h"


@implementation HGCollectionView


@end
