//
//  commenProgressView.m
//  TestMasonry
//
//  Created by zhongch18 on 2022/3/24.
//

#import "OEMProgressView.h"
#import <Masonry/Masonry.h>

@interface OEMProgressView ()

@property (strong,nonatomic) UIView *progressBgView;
@property (strong,nonatomic) UIView *progressView;
@property (nonatomic, strong) MASConstraint *proTrailing;

@end

@implementation OEMProgressView
+(instancetype)progressView{
    return  [[self alloc]init];
}

-(instancetype)init{
    if (self = [super init]) {
        [self.progressBgView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.mas_top);
            make.bottom.equalTo(self.mas_bottom);
            make.trailing.equalTo(self.mas_trailing);
            make.leading.equalTo(self.mas_leading);
        }];
        
        
        [self.progressView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.mas_top);
            make.bottom.equalTo(self.mas_bottom);
            self.proTrailing =  make.trailing.equalTo(self.mas_leading);
            make.leading.equalTo(self.mas_leading);
        }];
    }
    return self;
}

- (UIView *)progressBgView{
    if (_progressBgView == nil){
        UIView *fView = [[UIView alloc]init];
        fView.backgroundColor = _proViewBgColor;
        [self addSubview:fView];
        _progressBgView = fView;
    }
    return _progressBgView;
}

- (UIView *)progressView{
    if (_progressView == nil){
        UIView *sView = [[UIView alloc]init];
        sView.backgroundColor = _proViewTintColor;
        [self.progressBgView addSubview:sView];
        _progressView = sView;
    }
    return _progressView;
}

- (void)layoutSubviews{
    [super layoutSubviews];

}

#pragma mark - set&&get
- (void)setProViewBgColor:(UIColor *)proViewBgColor{
    _proViewBgColor = proViewBgColor;
    self.progressBgView.backgroundColor = proViewBgColor;
}



-(void)setProgress:(CGFloat)progress{
    _progress = progress;
    [self.proTrailing uninstall];
    [self.progressView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top);
        make.bottom.equalTo(self.mas_bottom);
        make.trailing.equalTo(self.mas_trailing).offset( - self.frame.size.width * (1-progress));
        make.leading.equalTo(self.mas_leading);
    }];
    [self setNeedsLayout];
}

- (void)setProViewTintColor:(UIColor *)proViewTintColor{
    self.layer.borderColor = proViewTintColor.CGColor;
    _proViewTintColor = proViewTintColor;
    self.progressView.backgroundColor = proViewTintColor;
}


- (void)setProCornerRadius:(NSInteger)proCornerRadius{
    _proCornerRadius = proCornerRadius;
    self.progressBgView.layer.masksToBounds = YES;
    self.progressBgView.layer.cornerRadius = proCornerRadius;
}


- (void)setProBorderWidth:(NSInteger)proBorderWidth{
     self.layer.borderWidth = proBorderWidth;
}

- (void)addRounded:(UIView *)view Corners:(UIRectCorner)corners
                withRadii:(CGSize)radii {

    UIBezierPath* rounded = [UIBezierPath bezierPathWithRoundedRect:view.bounds byRoundingCorners:corners cornerRadii:radii];
    CAShapeLayer* shape = [[CAShapeLayer alloc] init];
    shape.backgroundColor = [UIColor blackColor].CGColor;
    shape.frame = view.bounds;
    [shape setPath:rounded.CGPath];
    view.layer.mask = shape;
}


@end
