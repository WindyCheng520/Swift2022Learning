//
//  HGView.m
//  pkgame iOS
//
//  Created by Vic on 2018/3/20.
//

#import "HGView.h"


@implementation HGView

+ (instancetype)viewWithBackgroundColor:(UIColor *)bgColor
{
    return [self viewWithBackgroundColor:bgColor frame:CGRectZero];
}

+ (instancetype)viewWithBackgroundColor:(UIColor *)bgColor frame:(CGRect)frame
{
    HGView *view = [[HGView alloc] initWithFrame:frame];
    view.backgroundColor = bgColor;
    return view;
}

@end
