//
//  HGImageView.m
//  HGUIKit
//
//  Created by syp on 2020/6/17.
//


#import "HGImageView.h"


@implementation HGImageView

+ (instancetype)imageViewWithImage:(UIImage *)image
{
    HGImageView *imageView = [[HGImageView alloc] initWithImage:image];
    return imageView;
}

@end
