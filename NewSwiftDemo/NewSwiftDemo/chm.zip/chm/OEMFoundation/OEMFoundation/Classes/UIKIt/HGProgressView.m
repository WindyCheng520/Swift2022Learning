//
//  HGProgressView.m
//  HGUIKit
//
//  Created by syp on 2020/6/17.
//


#import "HGProgressView.h"


@implementation HGProgressView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
