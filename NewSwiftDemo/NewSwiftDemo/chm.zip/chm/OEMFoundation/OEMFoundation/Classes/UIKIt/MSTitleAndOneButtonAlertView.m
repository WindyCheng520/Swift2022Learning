//
//  MSTitleAndOneButtonAlertView.m
//  OEMFoundation
//
//  Created by pactera on 2020/12/26.
//

#import "MSTitleAndOneButtonAlertView.h"
#import "HGFoundationMacros.h"
#import "HGUIKit.h"
#import "OEMFoundationBundle.h"

@interface MSTitleAndOneButtonAlertView ()

@property (nonatomic, strong) HGView *backView;
@property (nonatomic, strong) HGLabel *titleLabel;
@property (nonatomic, strong) HGButton *confirmButton;
@property (nonatomic, strong) HGView *firstLineView;

@end

@implementation MSTitleAndOneButtonAlertView

- (instancetype)initWithTitle:(NSString *)title confirmButtonName:(NSString *)confirmButtonName {
    if (self = [super init]) {
        self.backgroundColor = RGBA_HEX(0x000000, 0.4f);
        self.frame = [UIScreen mainScreen].bounds;
        
        self.backView = [HGView new];
        self.backView.backgroundColor = RGBA_HEX(0xffffff, 1.f);
        self.backView.layer.cornerRadius = 13.f;
        [self addSubview:self.backView];
        
        self.titleLabel = [HGLabel new];
        self.titleLabel.textColor = RGB_HEX(0x000000);
        self.titleLabel.font = [UIFont systemFontOfSize:17 weight:UIFontWeightMedium];
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.numberOfLines = 0;
        [self.backView addSubview:self.titleLabel];
        self.titleLabel.text = title;
        
        self.confirmButton = [HGButton new];
        [self.confirmButton setTitle:confirmButtonName forState:UIControlStateNormal];
        [self.confirmButton setTitleColor:RGB_HEX(0xEC1C24) forState:UIControlStateNormal];
        self.confirmButton.titleLabel.font = [UIFont systemFontOfSize:17 weight:UIFontWeightMedium];
        [self.confirmButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
        [self.backView addSubview:self.confirmButton];
        
        self.firstLineView = [HGView new];
        self.firstLineView.backgroundColor = RGB_HEX(0xC8C7CC);
        [self.backView addSubview:self.firstLineView];
        
        [self makeContstraints];
        
    }
    return self;
}

- (void)makeContstraints {
    CGFloat margin = 15;
    CGFloat backWidth = 270;
    CGFloat titleHeight = ceil([self.titleLabel.text boundingRectWithSize:CGSizeMake(backWidth-margin*2, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : self.titleLabel.font} context:nil].size.height);
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.backView).offset(16);
        make.leading.equalTo(self.backView).offset(margin);
        make.trailing.equalTo(self.backView).offset(-margin);
        make.height.mas_equalTo(titleHeight);
    }];
    [self.confirmButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleLabel.mas_bottom).offset(16);
        make.leading.equalTo(self.backView).offset(margin);
        make.trailing.equalTo(self.backView).offset(-margin);
        make.height.mas_equalTo(44);
    }];
    [self.firstLineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleLabel.mas_bottom).offset(16);
        make.leading.equalTo(self.backView);
        make.trailing.equalTo(self.backView);
        make.height.mas_equalTo(0.5f);
    }];
    [self.backView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(backWidth);
        make.center.equalTo(self);
        make.height.mas_equalTo(16+titleHeight+16+44);
    }];
    
}

#pragma mark - click event
- (void)clickButton:(HGButton *)sender {
    if (sender == self.confirmButton) {
        [self dismiss];
        safeCallBlock(self.clickConfirmBlock);
    }
}

#pragma mark - show selector
- (void)show {
    self.alpha = 0;
    self.backView.alpha = 0;
    self.backView.transform = CGAffineTransformMakeScale(1.2, 1.2);
    UIWindow* keyWindow = [UIApplication sharedApplication].keyWindow;
    [keyWindow addSubview:self];
    [UIView animateWithDuration:0.3 animations:^{
        self.backView.transform = CGAffineTransformMakeScale(1, 1);
        self.alpha = 1;
        self.backView.alpha = 1;
    } completion:nil];
}

- (void)showWithSuperview:(UIView *)superview {
    if (!superview) {
        superview = [UIApplication sharedApplication].keyWindow;
    }
    self.alpha = 0;
    self.backView.alpha = 0;
    self.backView.transform = CGAffineTransformMakeScale(1.2, 1.2);
    [superview addSubview:self];
    [UIView animateWithDuration:0.3 animations:^{
        self.backView.transform = CGAffineTransformMakeScale(1, 1);
        self.alpha = 1;
        self.backView.alpha = 1;
    } completion:nil];
}
 
- (void)dismiss {
    [self removeFromSuperview];
}

@end
