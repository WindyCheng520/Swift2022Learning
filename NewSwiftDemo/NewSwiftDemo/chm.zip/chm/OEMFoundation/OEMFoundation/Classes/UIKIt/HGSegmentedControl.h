//
//  HGSegmentedControl.h
//  pkgame iOS
//
//  Created by Vic on 2018/3/20.
//

#import <UIKit/UIKit.h>


@interface HGSegmentedControl : UISegmentedControl

@end
