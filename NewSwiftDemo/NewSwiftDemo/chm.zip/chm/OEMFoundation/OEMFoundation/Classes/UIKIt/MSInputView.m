//
//  MSInputView.m
//  MSLogin
//
//  Created by syp on 2020/6/12.
//

#import "MSInputView.h"
#import "HGTextField.h"
#import "HGImageView.h"
#import "HGButton.h"
#import "HGFoundationMacros.h"
#import "OEMMacros.h"
#import "HGLabel.h"
@interface MSInputView () <UITextFieldDelegate>

@property (nonatomic, strong) HGTextField *textField;
@property (nonatomic, strong) HGImageView *iconImageView;
@property (nonatomic, strong) HGButton *actionButton;
@property(nonatomic,strong) HGLabel * placeHolderLabel;
@end

@implementation MSInputView

- (void)dealloc
{
    REMOVE_NOTIFY;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.layer.borderColor = RGB_HEX(0xCCCCCC).CGColor;
        self.layer.borderWidth = 0.5;
        
        self.iconImageView = [HGImageView new];
        [self addSubview:self.iconImageView];
        
        self.textField = [HGTextField new];
        self.textField.autocorrectionType = UITextAutocorrectionTypeNo;
        self.textField.textAlignment = NSTextAlignmentLeft;
        [self addSubview:self.textField];
        
        self.actionButton = [HGButton new];
        [self.actionButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:self.actionButton];
        
//        self.placeHolderLabel = [HGLabel new];
//        self.placeHolderLabel.text = @"fadfasdfa";
//        self.placeHolderLabel.backgroundColor = [UIColor blackColor];
//        self.placeHolderLabel.textAlignment = NSTextAlignmentLeft;
//        [self addSubview:self.placeHolderLabel];
        
        ADD_NOTIFY_SelectorName_OBJECT(UITextFieldTextDidChangeNotification, self.textField);
        [self makeConstraints];
    }
    return self;
}

//子类重写
-(void)makeConstraints{
    if (self.iconImageView.image) {
        [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leading.equalTo(self.mas_leading);
            make.centerY.equalTo(self.mas_centerY);
        }];
        
        [self.actionButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.trailing.equalTo(self.mas_trailing);
            make.centerY.equalTo(self.mas_centerY);
            make.width.mas_equalTo(50);
            make.height.equalTo(self.mas_height);
        }];
        
        [self.textField mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leading.equalTo(self.iconImageView.mas_trailing);
            make.trailing.equalTo(self.actionButton.mas_leading);
            make.centerY.equalTo(self.mas_centerY);
            make.height.equalTo(self.mas_height);
        }];
        
//        [self.placeHolderLabel mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.trailing.top.bottom.equalTo(self.textField);
//        }];
        
    }else{
        [self.actionButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.trailing.equalTo(self.mas_trailing);
            make.centerY.equalTo(self.mas_centerY);
            make.width.mas_equalTo(50);
            make.height.equalTo(self.mas_height);
        }];
        
        [self.textField mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leading.equalTo(self.mas_leading).offset(16);
            make.trailing.equalTo(self.actionButton.mas_leading);
            make.centerY.equalTo(self.mas_centerY);
            make.height.equalTo(self.mas_height);
        }];
        
//        [self.placeHolderLabel mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.trailing.top.bottom.equalTo(self.textField);
//        }];
    }
    
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    CGFloat height = CGRectGetHeight(self.bounds);
    self.layer.cornerRadius = height / 2.0;

//    CGFloat width = CGRectGetWidth(self.bounds);
//    CGFloat midY = CGRectGetMidY(self.bounds);
//        self.iconImageView.center = CGPointMake(CGRectGetWidth(self.iconImageView.frame) / 2 + 16, midY);
//        self.actionButton.center = CGPointMake(width - 16 - CGRectGetWidth(self.actionButton.frame) / 2,  midY);
//        CGFloat textFieldX = CGRectGetMaxX(self.iconImageView.frame) + 0;
//        CGFloat textFieldMaxX = CGRectGetMinX(self.actionButton.frame) - 16;
//        self.textField.frame = CGRectMake(textFieldX, 0, textFieldMaxX - textFieldX, height);
}

- (void)setText:(NSString *)text
{
    self.textField.text = text;
}

- (NSString *)text
{
    return self.textField.text;
}

- (void)setTextColor:(UIColor *)textColor
{
    self.textField.textColor = textColor;
}

- (UIColor *)textColor
{
    return self.textField.textColor;
}

- (void)setFont:(UIFont *)font
{
    self.textField.font = font;
}

- (UIFont *)font
{
    return self.textField.font;
}

-(void)setPlaceholderColor:(UIColor *)placeholderColor{
    if ([UIDevice currentDevice].systemVersion.floatValue >= 13.0) {
        NSMutableDictionary * dict = [NSMutableDictionary dictionary];
        dict[NSForegroundColorAttributeName] = placeholderColor;
        NSAttributedString *attrStr = [[NSAttributedString alloc] initWithString:self.placeholder attributes:dict];
        self.textField.attributedPlaceholder = attrStr;
    }else{
        [self.textField setValue:placeholderColor forKeyPath:@"_placeholderLabel.textColor"];
    }
}


- (void)setPlaceholder:(NSString *)placeholder
{
    NSMutableParagraphStyle* paragraphStyle = [[NSMutableParagraphStyle alloc]init];
    paragraphStyle.lineSpacing = 5;
    paragraphStyle.alignment = NSTextAlignmentLeft;
    NSMutableAttributedString *mutableString = [[NSMutableAttributedString alloc]initWithString:placeholder attributes:@{NSParagraphStyleAttributeName : paragraphStyle, NSFontAttributeName : [UIFont systemFontOfSize:16], NSForegroundColorAttributeName : RGB_HEX(0x000000)}];
//    self.placeHolderLabel.text = placeholder;
    self.textField.attributedPlaceholder = mutableString;
//    self.textField.placeholder = placeholder;
}

- (NSString *)placeholder
{
    
//    return  self.placeHolderLabel.text;
    return self.textField.placeholder;
}

- (void)setSecureTextEntry:(BOOL)secureTextEntry
{
    self.textField.secureTextEntry = secureTextEntry;
}

- (BOOL)isSecureTextEntry
{
    return self.textField.isSecureTextEntry;
}

- (void)setKeyboardType:(UIKeyboardType)keyboardType
{
    self.textField.keyboardType = keyboardType;
}

- (UIKeyboardType)keyboardType
{
    return self.textField.keyboardType;
}

- (void)setLeftIcon:(UIImage *)icon
{
    self.iconImageView.image = icon;
    [self.iconImageView sizeToFit];
    [self setNeedsLayout];
}

- (void)setRightTitle:(NSString *)title font:(UIFont *)font
{
    [self.actionButton setTitle:title forState:UIControlStateNormal];
    self.actionButton.titleLabel.font = font;
    [self.actionButton sizeToFit];
    [self setNeedsLayout];
    
    CGFloat left = MAX(0, (40 - CGRectGetWidth(self.actionButton.frame)) / 2);
    CGFloat top = MAX(0, (40 - CGRectGetHeight(self.actionButton.frame)) / 2);
    self.actionButton.enlargeTouchAreaInsets = UIEdgeInsetsMake(top, left, top, left);
}

- (void)setRightTitleColor:(UIColor *)color
{
    [self.actionButton setTitleColor:color forState:UIControlStateNormal];
}

- (void)setRightImage:(UIImage *)image
{
    [self.actionButton setImage:image forState:UIControlStateNormal];
    [self.actionButton sizeToFit];
    [self setNeedsLayout];

    CGFloat left = MAX(0, (40 - CGRectGetWidth(self.actionButton.frame)) / 2);
    CGFloat top = MAX(0, (40 - CGRectGetHeight(self.actionButton.frame)) / 2);
    self.actionButton.enlargeTouchAreaInsets = UIEdgeInsetsMake(top, left, top, left);
}

- (void)setRightButtonEnable:(BOOL)enable
{
    self.actionButton.enabled = enable;
}

-(void)setDelegate:(id<MSInputViewDelegate>)delegate
{
    _delegate = delegate;
    self.textField.delegate = delegate;
}

-(void)setTextFieldTag:(NSInteger)tag
{
    self.textField.tag = tag;
}

-(void)setRightButtonHidden:(BOOL)hidden{
    self.actionButton.hidden = hidden;
}

- (void)setBorderColor:(UIColor *)color {
    self.layer.borderColor = color.CGColor;
}

- (void)setTextFieldBecomeFirstResponder {
    [self.textField becomeFirstResponder];
}

- (void)clickButton:(UIButton *)button
{
    safeCallBlock(self.clickRightButtonBlock);
}

Handler_NOTIFY_SelectorName(UITextFieldTextDidChangeNotification)
{
    CHECK_DELEGATE(inputView:didChangeText:);
    
    [self.delegate inputView:self didChangeText:self.textField.text];
}

- (void)addClickEventToTextField {
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(clickInput:)];
    [self.textField addGestureRecognizer:tap];
}

- (void)clickInput:(UITapGestureRecognizer *)recognizer {
    CHECK_DELEGATE(didClickInputView:);
    [self.delegate didClickInputView:self];
}

@end
