//
//  MSRefreshHeader.h
//  OEMFoundation
//
//  Created by pactera on 2020/8/6.
//

#import <MJRefresh/MJRefresh.h>
#import <MJRefresh/NSBundle+MJRefresh.h>


@interface MSRefreshHeader : MJRefreshStateHeader

@property (weak, nonatomic, readonly) UIImageView *arrowView;
/** 菊花的样式 */
@property (assign, nonatomic) UIActivityIndicatorViewStyle activityIndicatorViewStyle;

@end

