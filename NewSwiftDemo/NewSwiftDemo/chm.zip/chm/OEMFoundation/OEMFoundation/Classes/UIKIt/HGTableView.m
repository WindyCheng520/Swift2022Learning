//
//  HGTableView.m
//  pkgame iOS
//
//  Created by shiyanpeng on 2018/3/23.
//

#import "HGTableView.h"


@implementation HGTableView

- (instancetype)initWithFrame:(CGRect)frame style:(UITableViewStyle)style
{
    self = [super initWithFrame:frame style:style];
    if (self) {
        self.estimatedRowHeight = 0;
        self.estimatedSectionFooterHeight = 0;
        self.estimatedSectionHeaderHeight = 0;
    }
    return self;
}

@end
