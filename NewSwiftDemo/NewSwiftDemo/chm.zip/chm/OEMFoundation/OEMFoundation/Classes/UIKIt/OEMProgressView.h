//
//  commenProgressView.h
//  TestMasonry
//
//  Created by zhongch18 on 2022/3/24.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface OEMProgressView : UIView
//你还可以根据自己的需要创建其他的属性
@property (strong,nonatomic) UIColor *proViewBgColor;       //背景色
@property (strong,nonatomic) UIColor *proViewTintColor;             //进度条颜色
@property (assign,nonatomic) CGFloat progress;                  //进度条进度的值
@property (assign,nonatomic) NSInteger proCornerRadius;         //进度条圆角
+(instancetype)progressView;
@end

NS_ASSUME_NONNULL_END
