//
//  HGButton.m
//  HGUIKit
//
//  Created by syp on 2020/6/17.
//


#import "HGButton.h"
#import "HGFoundationMacros.h"



@implementation HGButton

- (void)setStyle:(HGButtonStyle)style
{
    _style = style;

    [self setNeedsLayout];
}

- (void)layoutSubviews
{
    [super layoutSubviews];

    CGFloat span_2 = self.span / 2;

    if (self.style == HGButtonStyleLeftTitleRightImage) {
        self.titleEdgeInsets = UIEdgeInsetsMake(0, -CGRectGetWidth(self.imageView.frame) - span_2, 0, CGRectGetWidth(self.imageView.frame) + span_2);
        self.imageEdgeInsets = UIEdgeInsetsMake(0, CGRectGetWidth(self.titleLabel.frame) + span_2, 0, -CGRectGetWidth(self.titleLabel.frame) - span_2);
    } else if (self.style == HGButtonStyleTopImageBottomTitle) {
        self.titleEdgeInsets = UIEdgeInsetsMake(self.imageView.frame.size.height + span_2,
                                                -self.imageView.frame.size.width - 20,
                                                -span_2,
                                                -20);
        self.imageEdgeInsets = UIEdgeInsetsMake(-self.titleLabel.bounds.size.height - span_2,
                                                0,
                                                span_2,
                                                -self.titleLabel.bounds.size.width);
    } else if (self.style == HGButtonStyleLeftImageRightTitle) {
        self.titleEdgeInsets = UIEdgeInsetsMake(0, span_2, 0, -span_2);
        self.imageEdgeInsets = UIEdgeInsetsMake(0, -span_2, 0, span_2);
    }
}

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    UIEdgeInsets touchAreaInsets = self.enlargeTouchAreaInsets;
    CGRect bounds = self.bounds;
    bounds = CGRectMake(bounds.origin.x - touchAreaInsets.left,
                        bounds.origin.y - touchAreaInsets.top,
                        bounds.size.width + touchAreaInsets.left + touchAreaInsets.right,
                        bounds.size.height + touchAreaInsets.top + touchAreaInsets.bottom);
    bool result = CGRectContainsPoint(bounds, point);
    return result;
}

@end
