//
//  HGTableViewCell.m
//  pkgame iOS
//
//  Created by Vic on 2018/3/20.
//

#import "HGTableViewCell.h"


@implementation HGTableViewCell

- (void)awakeFromNib
{
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
