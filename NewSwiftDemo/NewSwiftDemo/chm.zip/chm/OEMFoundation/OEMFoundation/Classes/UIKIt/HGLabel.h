//
//  HGLabel.h
//  HGUIKit
//
//  Created by syp on 2020/6/17.
//


#import <UIKit/UIKit.h>


@interface HGLabel : UILabel

//描边
- (void)setOutLineWidth:(CGFloat)outLineWidth outLinetextColor:(UIColor *)outLinetextColor labelTextColor:(UIColor *)labelTextColor;

+ (instancetype)labelWithFont:(UIFont *)font
                         text:(NSString *)text
                    textColor:(UIColor *)textColor;

+ (instancetype)labelWithFont:(UIFont *)font
                         text:(NSString *)text
                textAlignment:(NSTextAlignment)textAlignment
                    textColor:(UIColor *)textColor;

+ (instancetype)labelWithFont:(UIFont *)font
                         text:(NSString *)text
                textAlignment:(NSTextAlignment)textAlignment
                    textColor:(UIColor *)textColor
                        frame:(CGRect)frame;

@property (nonatomic, assign) UIEdgeInsets edgeInsets;


@end
