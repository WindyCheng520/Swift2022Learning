//
//  HGTextField.m
//  pkgame iOS
//
//  Created by Vic on 2018/3/20.
//

#import "HGTextField.h"
#import "OEMMacros.h"
//if (isRTL()) {
//    CGSize textSize1 = [self.placeholder sizeWithAttributes:@{NSFontAttributeName:self.font}];
//    CGRect inset = CGRectMake(bounds.size.width - textSize1.width, bounds.origin.y, bounds.size.width, bounds.size.height);
//    return [self rtl_placeholderRectForBounds:inset];
//}else{
//    return [self rtl_placeholderRectForBounds:bounds];
//}
@implementation HGTextField
//bounds textField的宽高
//-(CGRect)placeholderRectForBounds:(CGRect)bounds{
//    NSLog(@"===%@",NSStringFromCGRect(bounds));
//    if (self.leftView) {
//        CGRect inset = CGRectMake(bounds.size.width - self.leftView.frame.size.width, bounds.origin.y, bounds.size.width, bounds.size.height);
//        bo =  inset;
//    }else{
//
//    }
//    CGRect bo = bounds;
//    if (isRTL()) {
//        CGSize textSize1 = [self.placeholder sizeWithAttributes:@{NSFontAttributeName:self.font}];
//        CGRect inset = CGRectMake(bounds.size.width - textSize1.width, bounds.origin.y, bounds.size.width, bounds.size.height);
//        bo =  inset;
//    }
//    NSLog(@"bounds0==%@",NSStringFromCGRect(bo));
//    return bo;
//}

//-(CGRect)leftViewRectForBounds:(CGRect)bounds{
//    CGRect bo = bounds;
//    NSLog(@"bounds1==%@",NSStringFromCGRect(bo));
//    return bo;
//}

//frame位置没有变,textAlignment 会改变，所以placeHolder label的width最好是text的width
-(CGRect)placeholderRectForBounds:(CGRect)bounds{
    CGRect bo = bounds;

    CGSize textSize1 = [self.placeholder sizeWithAttributes:@{NSFontAttributeName:self.font}];
    if (isRTL()) {
        CGFloat width =  CGRectGetWidth(self.leftView.frame);
//        NSLog(@"leftView==%@",NSStringFromCGRect(self.leftView.frame));
        CGRect inset = CGRectMake(bounds.size.width - width - textSize1.width, bounds.origin.y, textSize1.width, bounds.size.height);
        bo =  inset;
    }else{
        CGFloat maxss =  CGRectGetMaxX(self.leftView.frame);
//        NSLog(@"maxss==%f",maxss);
        CGRect inset = CGRectMake(maxss, bounds.origin.y, textSize1.width, bounds.size.height);
        bo =  inset;
    }
//    NSLog(@"bounds0==%@",NSStringFromCGRect(bo));
    return bo;
}
@end
