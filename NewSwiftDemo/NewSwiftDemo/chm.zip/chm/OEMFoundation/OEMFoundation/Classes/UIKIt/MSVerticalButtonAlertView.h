//
//  MSVerticalButtonAlertView.h
//  OEMFoundation
//
//  Created by pactera on 2020/11/25.
//

#import <UIKit/UIKit.h>


@interface MSVerticalButtonAlertView : UIView

@property (nonatomic, copy) void(^clickConfirmBlock)(void);
@property (nonatomic, copy) void(^clickCancelBlock)(void);

- (instancetype)initWithTitle:(NSString *)title message:(NSString *)message confirmButtonName:(NSString *)confirmButtonName cancelButtonName:(NSString *)cancelButtonName;
- (void)show;
- (void)showWithSuperview:(UIView *)superview;
- (void)dismiss;

@end

