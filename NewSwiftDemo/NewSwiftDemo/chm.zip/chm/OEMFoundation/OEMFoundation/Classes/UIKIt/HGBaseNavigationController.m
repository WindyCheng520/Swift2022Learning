//
//  HGBaseNavigationController.m
//  OEMFoundation
//
//  Created by midea on 2021/2/25.
//

#import "HGBaseNavigationController.h"

@interface HGBaseNavigationController ()

@end

@implementation HGBaseNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
    [self.navigationBar setShadowImage:[UIImage new]];
    self.navigationBar.barTintColor = [UIColor whiteColor];

}


@end
