//
//  HGViewController.h
//  OEMFoundation
//
//  Created by syp on 2020/6/22.
//

#import <UIKit/UIKit.h>

@interface HGViewController : UIViewController

+ (void)setDefaultBackImage:(UIImage *)defaultBackImage;

@property (nonatomic, assign) BOOL hiddenKeyboardWhenTap;
@property (nonatomic, assign) BOOL canRightSlideBack;

- (BOOL)navigationBarHidden;

- (UIButton *)createRightButtonWithImage:(UIImage *)image;
- (NSArray<UIButton *> *)createRightButtonWithTitlesWithImages:(NSArray<UIImage *> *)images;

- (UIButton *)createRightButtonWithTitle:(NSString *)title font:(UIFont *)font color:(UIColor *)color;

- (UIButton *)createLeftButtonWithImage:(UIImage *)image;

- (void)rightBarButtonClick:(UIButton *)button;
- (void)leftBarButtonClick:(UIButton *)button;

@end
