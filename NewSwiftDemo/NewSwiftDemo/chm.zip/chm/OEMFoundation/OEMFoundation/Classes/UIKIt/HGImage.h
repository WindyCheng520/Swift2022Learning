//
//  HGImage.h
//  OEMFoundation
//
//  Created by 及时行乐 on 2020/6/24.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, HGGradientType) {
    HGGradientTypeTopToBottom = 0,//从上到下
    HGGradientTypeLeftToRight = 1,//从左到右
    HGGradientTypeUpleftToLowright = 2,//左上到右下
    HGGradientTypeUprightToLowleft = 3,//右上到左下
};


@interface HGImage : UIImage


/// 创建一张渐变色的图片
/// @param colors 颜色数组
/// @param gradientType 渐变类型
/// @param imgSize 图片尺寸
+ (UIImage *)createGradientColorImageWithColors:(NSArray<UIColor*>*)colors gradientType:(HGGradientType)gradientType imgSize:(CGSize)imgSize;


/// 根据颜色创建一张图片
/// @param color 颜色
/// @param size 图片尺寸
+ (UIImage *)createImageWithColor:(UIColor *)color size:(CGSize)size;


@end

