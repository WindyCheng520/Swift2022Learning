//
//  UIDevice+Category.m
//  OEMFoundation
//
//  Created by Neil 韦学宁 on 2022/2/8.
//

#import "UIDevice+Category.h"
#include <sys/utsname.h>

@implementation UIDevice (Category)

+ (BOOL)hasNotch{
    if (@available(iOS 11.0, *)) {
        if ([UIDevice currentDevice].orientation == UIDeviceOrientationPortrait) {
            return [[[UIApplication sharedApplication] keyWindow] safeAreaInsets].bottom > 0;
        }else{
            return [[[UIApplication sharedApplication] keyWindow] safeAreaInsets].left > 0 ||
            [[[UIApplication sharedApplication] keyWindow] safeAreaInsets].right > 0;
        }
    } else {
        return NO;
    }
    return NO;
}

+ (NSString *)machineType
{
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString *machineType = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    
    if ([machineType isEqualToString:@"iPhone3,1"])    return @"iPhone 4";
    if ([machineType isEqualToString:@"iPhone3,2"])    return @"iPhone 4";
    if ([machineType isEqualToString:@"iPhone3,3"])    return @"iPhone 4";
    if ([machineType isEqualToString:@"iPhone4,1"])    return @"iPhone 4S";
    if ([machineType isEqualToString:@"iPhone5,1"])    return @"iPhone 5";
    if ([machineType isEqualToString:@"iPhone5,2"])    return @"iPhone 5 (GSM+CDMA)";
    if ([machineType isEqualToString:@"iPhone5,3"])    return @"iPhone 5c (GSM)";
    if ([machineType isEqualToString:@"iPhone5,4"])    return @"iPhone 5c (GSM+CDMA)";
    if ([machineType isEqualToString:@"iPhone6,1"])    return @"iPhone 5s (GSM)";
    if ([machineType isEqualToString:@"iPhone6,2"])    return @"iPhone 5s (GSM+CDMA)";
    if ([machineType isEqualToString:@"iPhone7,1"])    return @"iPhone 6 Plus";
    if ([machineType isEqualToString:@"iPhone7,2"])    return @"iPhone 6";
    if ([machineType isEqualToString:@"iPhone8,1"])    return @"iPhone 6s";
    if ([machineType isEqualToString:@"iPhone8,2"])    return @"iPhone 6s Plus";
    if ([machineType isEqualToString:@"iPhone8,4"])    return @"iPhone SE";
    // 日行两款手机型号均为日本独占，可能使用索尼FeliCa支付方案而不是苹果支付
    if ([machineType isEqualToString:@"iPhone9,1"])    return @"iPhone 7";
    if ([machineType isEqualToString:@"iPhone9,2"])    return @"iPhone 7 Plus";
    if ([machineType isEqualToString:@"iPhone9,3"])    return @"iPhone 7";
    if ([machineType isEqualToString:@"iPhone9,4"])    return @"iPhone 7 Plus";
    if ([machineType isEqualToString:@"iPhone10,1"])   return @"iPhone_8";
    if ([machineType isEqualToString:@"iPhone10,4"])   return @"iPhone_8";
    if ([machineType isEqualToString:@"iPhone10,2"])   return @"iPhone_8_Plus";
    if ([machineType isEqualToString:@"iPhone10,5"])   return @"iPhone_8_Plus";
    if ([machineType isEqualToString:@"iPhone10,3"])   return @"iPhone X";
    if ([machineType isEqualToString:@"iPhone10,6"])   return @"iPhone X";
    if ([machineType isEqualToString:@"iPhone11,8"])   return @"iPhone XR";
    if ([machineType isEqualToString:@"iPhone11,2"])   return @"iPhone XS";
    if ([machineType isEqualToString:@"iPhone11,6"])   return @"iPhone XS Max";
    if ([machineType isEqualToString:@"iPhone11,4"])   return @"iPhone XS Max";
    if ([machineType isEqualToString:@"iPhone12,1"])   return @"iPhone 11";
    if ([machineType isEqualToString:@"iPhone12,3"])   return @"iPhone 11 Pro";
    if ([machineType isEqualToString:@"iPhone12,5"])   return @"iPhone 11 Pro Max";
    if ([machineType isEqualToString:@"iPhone12,8"])   return @"iPhone SE2";
    if ([machineType isEqualToString:@"iPhone13,1"])   return @"iPhone 12 mini";
    if ([machineType isEqualToString:@"iPhone13,2"])   return @"iPhone 12";
    if ([machineType isEqualToString:@"iPhone13,3"])   return @"iPhone 12 Pro";
    if ([machineType isEqualToString:@"iPhone13,4"])   return @"iPhone 12 Pro Max";
    
    if ([machineType isEqualToString:@"iPhone14,4"])   return @"iPhone 13 mini";
    if ([machineType isEqualToString:@"iPhone14,5"])   return @"iPhone 13";
    if ([machineType isEqualToString:@"iPhone14,2"])   return @"iPhone 13 Pro";
    if ([machineType isEqualToString:@"iPhone14,3"])   return @"iPhone 13 Pro Max";
    
    if ([machineType isEqualToString:@"iPod1,1"])      return @"iPod Touch 1G";
    if ([machineType isEqualToString:@"iPod2,1"])      return @"iPod Touch 2G";
    if ([machineType isEqualToString:@"iPod3,1"])      return @"iPod Touch 3G";
    if ([machineType isEqualToString:@"iPod4,1"])      return @"iPod Touch 4G";
    if ([machineType isEqualToString:@"iPod5,1"])      return @"iPod Touch (5 Gen)";
    if ([machineType isEqualToString:@"iPad1,1"])      return @"iPad";
    if ([machineType isEqualToString:@"iPad1,2"])      return @"iPad 3G";
    if ([machineType isEqualToString:@"iPad2,1"])      return @"iPad 2 (WiFi)";
    if ([machineType isEqualToString:@"iPad2,2"])      return @"iPad 2";
    if ([machineType isEqualToString:@"iPad2,3"])      return @"iPad 2 (CDMA)";
    if ([machineType isEqualToString:@"iPad2,4"])      return @"iPad 2";
    if ([machineType isEqualToString:@"iPad2,5"])      return @"iPad Mini (WiFi)";
    if ([machineType isEqualToString:@"iPad2,6"])      return @"iPad Mini";
    if ([machineType isEqualToString:@"iPad2,7"])      return @"iPad Mini (GSM+CDMA)";
    if ([machineType isEqualToString:@"iPad3,1"])      return @"iPad 3 (WiFi)";
    if ([machineType isEqualToString:@"iPad3,2"])      return @"iPad 3 (GSM+CDMA)";
    if ([machineType isEqualToString:@"iPad3,3"])      return @"iPad 3";
    if ([machineType isEqualToString:@"iPad3,4"])      return @"iPad 4 (WiFi)";
    if ([machineType isEqualToString:@"iPad3,5"])      return @"iPad 4";
    if ([machineType isEqualToString:@"iPad3,6"])      return @"iPad 4 (GSM+CDMA)";
    if ([machineType isEqualToString:@"iPad4,1"])      return @"iPad Air (WiFi)";
    if ([machineType isEqualToString:@"iPad4,2"])      return @"iPad Air (Cellular)";
    if ([machineType isEqualToString:@"iPad4,4"])      return @"iPad Mini 2 (WiFi)";
    if ([machineType isEqualToString:@"iPad4,5"])      return @"iPad Mini 2 (Cellular)";
    if ([machineType isEqualToString:@"iPad4,6"])      return @"iPad Mini 2";
    if ([machineType isEqualToString:@"iPad4,7"])      return @"iPad Mini 3";
    if ([machineType isEqualToString:@"iPad4,8"])      return @"iPad Mini 3";
    if ([machineType isEqualToString:@"iPad4,9"])      return @"iPad Mini 3";
    if ([machineType isEqualToString:@"iPad5,1"])      return @"iPad Mini 4 (WiFi)";
    if ([machineType isEqualToString:@"iPad5,2"])      return @"iPad Mini 4 (LTE)";
    if ([machineType isEqualToString:@"iPad5,3"])      return @"iPad Air 2";
    if ([machineType isEqualToString:@"iPad5,4"])      return @"iPad Air 2";
    if ([machineType isEqualToString:@"iPad6,3"])      return @"iPad Pro 9.7";
    if ([machineType isEqualToString:@"iPad6,4"])      return @"iPad Pro 9.7";
    if ([machineType isEqualToString:@"iPad6,7"])      return @"iPad Pro 12.9";
    if ([machineType isEqualToString:@"iPad6,8"])      return @"iPad Pro 12.9";

    if ([machineType isEqualToString:@"AppleTV2,1"])      return @"Apple TV 2";
    if ([machineType isEqualToString:@"AppleTV3,1"])      return @"Apple TV 3";
    if ([machineType isEqualToString:@"AppleTV3,2"])      return @"Apple TV 3";
    if ([machineType isEqualToString:@"AppleTV5,3"])      return @"Apple TV 4";

    if ([machineType isEqualToString:@"i386"])         return @"Simulator";
    if ([machineType isEqualToString:@"x86_64"])       return @"Simulator";
        
    return @"unknow";
}

@end
