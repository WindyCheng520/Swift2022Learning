//
//  NSDate+OEMCategory.h
//  OEMFoundation
//
//  Created by Neil 韦学宁 on 2022/1/20.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSDate (OEMCategory)

+ (NSCalendar *)oemCurrentCalendar;

+ (NSString *)oem_getNSStringFromNSDate:(NSDate *)date withFormat:(NSString *)format;

- (BOOL)isToday;

- (NSString *)oem_stringWithFormat:(NSString *)format;

@end

NS_ASSUME_NONNULL_END
