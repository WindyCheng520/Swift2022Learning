//
//  NSData+OEMExtention.h
//  BHFoundation
//
//  Created by armark.yan on 2017/12/12.
//

#import <Foundation/Foundation.h>


/***********************************************
 enum {
 kCCAlgorithmAES128 = 0,
 kCCAlgorithmAES = 0,
 kCCAlgorithmDES,
 kCCAlgorithm3DES,
 kCCAlgorithmCAST,
 kCCAlgorithmRC4,
 kCCAlgorithmRC2,
 kCCAlgorithmBlowfish
 };
 typedef uint32_t CCAlgorithm;
 **********************************************/
typedef NS_ENUM(uint32_t, BH_CCAlgorithm) {
    BH_kCCAlgorithmAES128 = 0,
    BH_kCCAlgorithmAES = 0,
    BH_kCCAlgorithmDES,
    BH_kCCAlgorithm3DES,
    BH_kCCAlgorithmCAST,
    BH_kCCAlgorithmRC4,
    BH_kCCAlgorithmRC2,
    BH_kCCAlgorithmBlowfish
};

/***********************************************
enum {
    kCCSuccess          = 0,
    kCCParamError       = -4300,
    kCCBufferTooSmall   = -4301,
    kCCMemoryFailure    = -4302,
    kCCAlignmentError   = -4303,
    kCCDecodeError      = -4304,
    kCCUnimplemented    = -4305,
    kCCOverflow         = -4306,
    kCCRNGFailure       = -4307,
    kCCUnspecifiedError = -4308,
    kCCCallSequenceError= -4309,
    kCCKeySizeError     = -4310,
};
typedef int32_t CCStatus;
typedef int32_t CCCryptorStatus;
***********************************************/
typedef NS_ENUM(int32_t, CBCCryptorStatus) {
    BH_kCCSuccess          = 0,
    BH_kCCParamError       = -4300,
    BH_kCCBufferTooSmall   = -4301,
    BH_kCCMemoryFailure    = -4302,
    BH_kCCAlignmentError   = -4303,
    BH_kCCDecodeError      = -4304,
    BH_kCCUnimplemented    = -4305,
    BH_kCCOverflow         = -4306,
    BH_kCCRNGFailure       = -4307,
    BH_kCCUnspecifiedError = -4308,
    BH_kCCCallSequenceError= -4309,
    BH_kCCKeySizeError     = -4310,
};
typedef CBCCryptorStatus BH_CCStatus;
typedef CBCCryptorStatus BH_CCCryptorStatus;


/***********************************************
enum {
    kCCOptionPKCS7Padding   = 0x0001,
    kCCOptionECBMode        = 0x0002
};
typedef uint32_t CCOptions;
***********************************************/
typedef NS_ENUM(int32_t, BH_CCOptions) {
    BH_kCCOptionPKCS7Padding   = 0x0001,
    BH_kCCOptionECBMode        = 0x0002
};

/***********************************************
enum {
    kCCHmacAlgSHA1,
    kCCHmacAlgMD5,
    kCCHmacAlgSHA256,
    kCCHmacAlgSHA384,
    kCCHmacAlgSHA512,
    kCCHmacAlgSHA224
};
typedef uint32_t CCHmacAlgorithm;
 ***********************************************/
typedef NS_ENUM(int32_t, BH_CCHmacAlgorithm) {
    BH_kCCHmacAlgSHA1,
    BH_kCCHmacAlgMD5,
    BH_kCCHmacAlgSHA256,
    BH_kCCHmacAlgSHA384,
    BH_kCCHmacAlgSHA512,
    BH_kCCHmacAlgSHA224
};



@interface NSData (OEMExtention)

@end

extern NSString * const kCommonCryptoErrorDomain;

@interface NSError (CBCCryptoErrorDomain)
+ (NSError *)BH_errorWithCCCryptorStatus: (BH_CCCryptorStatus) status;
@end

@interface NSData (CBCCryptoCommonDigest)

- (NSData *) BH_MD2Sum;
- (NSData *) BH_MD4Sum;
- (NSData *) BH_MD5Sum;
- (NSString *) BH_MD5_16;

- (NSData *) BH_SHA1Hash;
- (NSData *) BH_SHA224Hash;
- (NSData *) BH_SHA256Hash;
- (NSData *) BH_SHA384Hash;
- (NSData *) BH_SHA512Hash;

@end

@interface NSData (CBCCryptoCommonCryptor)
- (NSData *) BH_base64EncodedData;
- (NSString *) BH_base64EncodedString;
- (NSData *) BH_base64DecodedData;
- (NSString *) BH_base64DecodedString;

- (NSData *)BH_AES128EncryptedDataUsingKey:(NSString *)key iv:(NSString *)iv;
- (NSData *)BH_AES128DecryptDataUsingKey:(NSString *)key iv:(NSString *)iv;

- (NSData *) BH_AES256EncryptedDataUsingKey: (id) key error: (NSError **) error;
- (NSData *) BH_decryptedAES256DataUsingKey: (id) key error: (NSError **) error;

- (NSData *) BH_DESEncryptedDataUsingKey: (id) key error: (NSError **) error;
- (NSData *) BH_decryptedDESDataUsingKey: (id) key error: (NSError **) error;

- (NSData *) BH_CASTEncryptedDataUsingKey: (id) key error: (NSError **) error;
- (NSData *) BH_decryptedCASTDataUsingKey: (id) key error: (NSError **) error;

@end

@interface NSData (CBCCryptoLowLevelCommonCryptor)

- (NSData *)BH_dataEncryptedUsingAlgorithm:(BH_CCAlgorithm)algorithm
                                        key:(id)key        // data or string
                                      error:(BH_CCCryptorStatus *)error;

- (NSData *)BH_dataEncryptedUsingAlgorithm:(BH_CCAlgorithm)algorithm
                                        key:(id)key        // data or string
                                    options:(BH_CCOptions)options
                                      error:(BH_CCCryptorStatus *)error;

- (NSData *)BH_dataEncryptedUsingAlgorithm:(BH_CCAlgorithm)algorithm
                                        key:(id)key        // data or string
                       initializationVector:(id)iv        // data or string
                                    options:(BH_CCOptions)options
                                      error:(BH_CCCryptorStatus *)error;

- (NSData *)BH_decryptedDataUsingAlgorithm:(BH_CCAlgorithm)algorithm
                                        key:(id)key        // data or string
                                      error:(BH_CCCryptorStatus *)error;

- (NSData *)BH_decryptedDataUsingAlgorithm:(BH_CCAlgorithm)algorithm
                                        key:(id)key        // data or string
                                    options:(BH_CCOptions)options
                                      error:(BH_CCCryptorStatus *)error;

- (NSData *)BH_decryptedDataUsingAlgorithm:(BH_CCAlgorithm)algorithm
                                        key:(id)key        // data or string
                       initializationVector:(id)iv        // data or string
                                    options:(BH_CCOptions)options
                                      error:(BH_CCCryptorStatus *)error;

@end

@interface NSData (CBCCryptoCommonHMAC)

- (NSData *)BH_HMACWithAlgorithm:(BH_CCHmacAlgorithm) algorithm;
- (NSData *)BH_HMACWithAlgorithm:(BH_CCHmacAlgorithm) algorithm key:(id)key;

@end

@interface NSData (BH_GZip)

+ (NSData *)BH_UnGzipData:(NSData *)compressedData;

+ (NSData*)BH_GzipData:(NSData*)pUncompressedData;


- (NSString *)dataToHexString;

@end





