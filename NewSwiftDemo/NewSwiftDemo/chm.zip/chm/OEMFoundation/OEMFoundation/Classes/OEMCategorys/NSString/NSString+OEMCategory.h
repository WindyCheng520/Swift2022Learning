//
//  NSString+OEMCategory.h
//  OEMFoundation
//
//  Created by Neil 韦学宁 on 2022/4/9.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (OEMCategory)

+ (NSString *)OEMStringToHex:(NSString *)str;

+ (NSData *)OEMDataFromHexString:(NSString *)string;

@end

NS_ASSUME_NONNULL_END
