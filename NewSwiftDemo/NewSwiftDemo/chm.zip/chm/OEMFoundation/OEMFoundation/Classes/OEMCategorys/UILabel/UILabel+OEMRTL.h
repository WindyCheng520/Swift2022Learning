//
//  NSObject+OEMRTL.h
//  OEMFoundation
//
//  Created by zhongch18 on 2022/3/21.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UILabel (OEMRTL)

@end

NS_ASSUME_NONNULL_END
