//
//  NSArray+OEMExtension.h
//  testCollection
//
//  Created by midea on 2017/6/19.
//  Copyright © 2017年 RW. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (OEMExtension)
- (id)objectAtIndexCheck:(NSUInteger)index;
@end
