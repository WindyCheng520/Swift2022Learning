//
//  UIImage+OEMRTL.m
//  OEMFoundation
//
//  Created by zhongch18 on 2022/3/22.
//

#import "UIImage+OEMRTL.h"
#import "OEMMacros.h"
#import <objc/runtime.h>
#import <objc/message.h>
@implementation UIImage (OEMRTL)

- (UIImage *)oem_imageFlippedForRightToLeftLayoutDirection
{
//    NSSet * set = whiteList();
    UIImage * flipImage = [UIImage imageWithCGImage:self.CGImage
                                              scale:self.scale
                                        orientation:UIImageOrientationUpMirrored];
    flipImage.isFlip = YES;
    return flipImage;
}

- (void)setIsFlip:(BOOL)isFlip {
    objc_setAssociatedObject(self, @selector(isFlip), [NSNumber numberWithInt:isFlip], OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (BOOL)isFlip {
    NSNumber *value = objc_getAssociatedObject(self, _cmd);
    return [value boolValue];
}

@end
