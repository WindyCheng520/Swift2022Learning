//
//  NSObject+OEMRTL.m
//  OEMFoundation
//
//  Created by zhongch18 on 2022/3/21.
//

#import "UILabel+OEMRTL.h"
#import "OEMMacros.h"
@implementation UILabel (OEMRTL)
+ (void)load
{
//    static dispatch_once_t onceToken;
//    dispatch_once(&onceToken, ^{
//        swizzleInstanceMethod([self class], @selector(init), @selector(rtl_init));
//        swizzleInstanceMethod([self class], @selector(initWithFrame:), @selector(rtl_initWithFrame:));
//    swizzleInstanceMethod([self class], @selector(setTextAlignment:), @selector(rtl_setTextAlignment:));
////    });
}


//- (instancetype)rtl_init
//{
//    if ([self rtl_init]) {
//        self.textAlignment = NSTextAlignmentNatural;
//    }
//    return self;
//}
//
//- (instancetype)rtl_initWithFrame:(CGRect)frame
//{
//    if ([self rtl_initWithFrame:frame]) {
//        self.textAlignment = NSTextAlignmentNatural;
//    }
//    return self;
//}

- (void)rtl_setTextAlignment:(NSTextAlignment)textAlignment
{
    if (isRTL()) {
        if (textAlignment == NSTextAlignmentNatural || textAlignment == NSTextAlignmentLeft) {
            textAlignment = NSTextAlignmentRight;
        } else if (textAlignment == NSTextAlignmentRight) {
            textAlignment = NSTextAlignmentLeft;
        }
    }
    [self rtl_setTextAlignment:textAlignment];
}



@end
