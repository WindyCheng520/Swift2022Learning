//
//  NSFileManager+OEMExtention.m
//  BHFoundation
//
//  Created by armark.yan on 2017/12/27.
//

#import "NSFileManager+OEMExtention.h"


@implementation NSFileManager (OEMExtention)

+ (NSString *)documentsDirectoryPath {
    
    NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES) objectAtIndex:0];
    return documentPath;
}

+ (NSString *)libraryDirectoryPath {
    NSString* libraryPath = [NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSAllDomainsMask, YES) objectAtIndex:0];
    return libraryPath;
}

+ (NSString *)applicationSupportDirectoryPath {
    NSArray* libraryPaths = NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSAllDomainsMask, YES);
    
    NSString *path = nil;
    if ([libraryPaths count] > 0) {
        path = [libraryPaths objectAtIndex:0];
    }
    if (![NSFileManager fileExist:path]) {
        [NSFileManager createDir:path];
    }
    return path;
}

+ (NSString *)cachesDirectoryPath {
    NSString *cachePath = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory,NSUserDomainMask,YES) objectAtIndex:0];
    return cachePath;
    
}

#pragma mark - 扩展方法
+ (BOOL)createDir:(NSString*)newDir {
    if ([newDir length] <= 0) return NO;
    if([self fileExist:newDir]) return YES;
    NSError * error = nil;
    BOOL createOK = [[NSFileManager defaultManager] createDirectoryAtPath:newDir
                                              withIntermediateDirectories:YES
                                                               attributes:nil
                                                                    error:&error];
    if (!createOK) {
        NSLog(@"create file directory failled:%@", error);
    }
    return createOK;
}

+ (BOOL)deleteFilesysItem:(NSString*)strItem {
    if ([strItem length] > 0) {
        NSError * error = nil;
        BOOL deleteOK = [[NSFileManager defaultManager] removeItemAtPath:strItem error:&error];
        if (!deleteOK) {
            NSLog(@"delete file error:%@", error);
        }
        return deleteOK;
    }
    return NO;
}

+ (BOOL)fileExist:(NSString*)strPath {
    if ([strPath length] > 0) {
        NSFileManager *file_manager = [NSFileManager defaultManager];
        BOOL fExist = [file_manager fileExistsAtPath:strPath];
        return fExist;
    }
    return NO;
}

+ (NSString *)relativePathsByAbsolute:(NSString *)path {
    if (!path) return nil;
    
    NSString *home = NSHomeDirectory();
    
    NSString *relatePath = [path copy];
    if ([path containsString:home]) {
        NSArray *array = [path componentsSeparatedByString:home];
        relatePath = array[1];
    }
    return relatePath;
}


+ (NSString *)relativePathsToAbsolute:(NSString *)relativePath {
    if (!relativePath) return nil;
    NSString *home = NSHomeDirectory();
    NSString *absolute = [home stringByAppendingString:relativePath];
    return absolute;
}

#pragma mark - 通用文件目录路径
+ (NSString *)logFilesDirectoryPath {
    NSString *dir = [[NSFileManager cachesDirectoryPath] stringByAppendingString:@"/Logs"];
    [NSFileManager createDir:dir];
    return dir;
}

+ (NSString *)rootDirectoryPathForUser:(NSString *)userId {
    if (userId) {
        NSString *docPath = [NSFileManager documentsDirectoryPath];
        NSString *userRootDir = [docPath stringByAppendingString:@"/userRoot"];
        if ([NSFileManager createDir:userRootDir]) {
            NSString *userDir = [userRootDir stringByAppendingFormat:@"/%@", userId];
            if ([NSFileManager createDir:userDir]) {
                return userDir;
            }
        }
    }
    return nil;
}




@end
