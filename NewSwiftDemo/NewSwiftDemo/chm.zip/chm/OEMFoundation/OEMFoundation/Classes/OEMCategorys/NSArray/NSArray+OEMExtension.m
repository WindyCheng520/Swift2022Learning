//
//  NSArray+OEMExtension.m
//  testCollection
//
//  Created by midea on 2017/6/19.
//  Copyright © 2017年 RW. All rights reserved.
//

#import "NSArray+OEMExtension.h"

@implementation NSArray (OEMExtension)
- (id)objectAtIndexCheck:(NSUInteger)index
{
    if (index >= [self count]) {
        return nil;
    }
    
    id value = [self objectAtIndex:index];
    if (value == [NSNull null]) {
        return nil;
    }
    return value;
}
@end
