//
//  NSFileManager+OEMExtention.h
//  BHFoundation
//
//  Created by armark.yan on 2017/12/27.
//

#import <Foundation/Foundation.h>

@interface NSFileManager (OEMExtention)

#pragma mark - 系统文件目录路径
/**
 *  <Application_Home>/Documents 系统文件目录，只用于用户特有相关文件，而非通用信息或app信息，
 * Use this directory to store user-generated content.
 */
+ (NSString *)documentsDirectoryPath;

/**
 *  <Application_Home>/Library 系统文件目录，只用于app运行期间存储文件的顶级目录
 *  This is the top-level directory for any files that are not user data files.
 */
+ (NSString *)libraryDirectoryPath;

/**
 *  <Application_Home>/Library/Application Support 系统文件目录
 *  Use this directory to store all app data files except those associated with the user’s documents. For example,
 *  you might use this directory to store app-created data files, configuration files, templates, or other fixed or
 *  modifiable resources that are managed by the app. An app might use this directory to store a modifiable copy of
 *  resources contained initially in the app’s bundle. A game might use this directory to store new levels purchased
 *  by the user and downloaded from a server.
 *  All content in this directory should be placed in a custom subdirectory whose name is that of your app’s bundle identifier or your company.
 *  In iOS, the contents of this directory are backed up by iTunes and iCloud.
 *
 */
+ (NSString *)applicationSupportDirectoryPath;

/**
 *  <Application_Home>/Library/Caches 系统文件目录
 *  Use this directory to write any app-specific support files that your app can re-create easily. Your app is generally
 *  responsible for managing the contents of this directory and for adding and deleting files as needed.
 *  In iOS 2.2 and later, the contents of this directory are not backed up by iTunes or iCloud. In addition, the system
 *  removes files in this directory during a full restoration of the device.
 *  In iOS 5.0 and later, the system may delete the Caches directory on rare occasions when the system is very low on
 *  disk space. This will never occur while an app is running. However, be aware that restoring from backup is not
 *  necessarily the only condition under which the Caches directory can be erased.
 */
+ (NSString *)cachesDirectoryPath;

#pragma mark - 扩展方法

+ (BOOL)createDir:(NSString*)newDir;

+ (BOOL)deleteFilesysItem:(NSString*)strItem;

+ (BOOL) fileExist:(NSString*)strPath;

///文件绝对路径转相对路径
+ (NSString *)relativePathsByAbsolute:(NSString *)path;

///文件相对路径转绝对路径
+ (NSString *)relativePathsToAbsolute:(NSString *)relativePath;

#pragma mark - 通用文件目录路径
/**
 *  日志文件集成目录
 */
+ (NSString *)logFilesDirectoryPath;

/*!
 @method 用户数据根目录
 @brief 此目录用于存储当前登陆用户的个人信息
 @discussion 用户已登录是前提，如果用户未登录，返回nil，基于<Application_Home>/Documents 系统文件目录，只用于用户特有相关文件，而非通用信息或app信息，
 @result 用户目录路径
 */
+ (NSString *)rootDirectoryPathForUser:(NSString *)userId;



@end
