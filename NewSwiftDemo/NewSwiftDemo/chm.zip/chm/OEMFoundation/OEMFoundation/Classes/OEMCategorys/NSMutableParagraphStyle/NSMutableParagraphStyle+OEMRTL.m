//
//  NSMutableParagraphStyle+OEMRTL.m
//  AvoidCrash
//
//  Created by zhongch18 on 2022/3/24.
//

#import "NSMutableParagraphStyle+OEMRTL.h"
#import "OEMMacros.h"
@implementation NSMutableParagraphStyle (OEMRTL)
+ (void)load
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        swizzleInstanceMethod([self class], @selector(init), @selector(rtl_init));
        swizzleInstanceMethod([self class], @selector(setAlignment:), @selector(rtl_setAlignment:));
    });
}

-(instancetype)rtl_init{
    if ([self rtl_init]) {
        self.alignment = NSTextAlignmentNatural;
    }
    return self;
}

-(void)rtl_setAlignment:(NSTextAlignment)textAlignment{
    __block BOOL isrtl = NO;
    //Rn sometime change state in other thread.
    //use lock to fix
    if ([NSThread isMainThread]) {
        isrtl = isRTL();
    } else {
        dispatch_semaphore_t semaphore = dispatch_semaphore_create(1);
        dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
        dispatch_async(dispatch_get_main_queue(), ^{
            isrtl = isRTL();
            dispatch_semaphore_signal(semaphore);
        });
        dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
        dispatch_semaphore_signal(semaphore);
    }
    if (isrtl) {
        if (textAlignment == NSTextAlignmentNatural || textAlignment == NSTextAlignmentLeft) {
            textAlignment = NSTextAlignmentRight;
        } else if (textAlignment == NSTextAlignmentRight) {
            textAlignment = NSTextAlignmentLeft;
        }
    }
    [self rtl_setAlignment:textAlignment];
}
@end
