//
//  UINavigationController+OEMRTL.m
//  OEMFoundation
//
//  Created by zhongch18 on 2022/3/24.
//

#import "UINavigationController+OEMRTL.h"
#import "OEMMacros.h"
@implementation UINavigationController (OEMRTL)
//处理手势
+ (void)load
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        swizzleInstanceMethod([self class], @selector(initWithNibName:bundle:), @selector(rtl_initWithNibName:bundle:));
        swizzleInstanceMethod([self class], @selector(initWithRootViewController:), @selector(rtl_initWithRootViewController:));
    });
    
}

-(instancetype)rtl_initWithRootViewController:(UIViewController*)rootViewVC{
    
    if ([self rtl_initWithRootViewController:rootViewVC]) {
        if (isRTL()) {
            self.navigationBar.semanticContentAttribute = UISemanticContentAttributeForceRightToLeft;
            self.view.semanticContentAttribute = UISemanticContentAttributeForceRightToLeft;
        }else{
            self.navigationBar.semanticContentAttribute = UISemanticContentAttributeForceLeftToRight;
            self.view.semanticContentAttribute = UISemanticContentAttributeForceLeftToRight;
        }
    }
    return self;
}

- (instancetype)rtl_initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil
{
    if ([self rtl_initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        if (isRTL()) {
            self.navigationBar.semanticContentAttribute = UISemanticContentAttributeForceRightToLeft;
            self.view.semanticContentAttribute = UISemanticContentAttributeForceRightToLeft;
        }else{
            self.navigationBar.semanticContentAttribute = UISemanticContentAttributeForceLeftToRight;
            self.view.semanticContentAttribute = UISemanticContentAttributeForceLeftToRight;
        }
    }
    return self;
}

@end
