//
//  UIButton+OEMRTL.m
//  OEMFoundation
//
//  Created by zhongch18 on 2022/3/24.
//

#import "UIButton+OEMRTL.h"
#import "OEMMacros.h"

@implementation UIButton (OEMRTL)
UIEdgeInsets RTLEdgeInsetsWithInsets(UIEdgeInsets insets) {
    if (insets.left != insets.right && isRTL()) {
        CGFloat temp = insets.left;
        insets.left = insets.right;
        insets.right = temp;
    }
    return insets;
}

+ (void)load{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        swizzleInstanceMethod([self class], @selector(setContentEdgeInsets:), @selector(rtl_setContentEdgeInsets:));
        swizzleInstanceMethod([self class], @selector(setImageEdgeInsets:), @selector(rtl_setImageEdgeInsets:));
        swizzleInstanceMethod([self class], @selector(setTitleEdgeInsets:), @selector(rtl_setTitleEdgeInsets:));
    });
}

- (void)rtl_setContentEdgeInsets:(UIEdgeInsets)contentEdgeInsets {
    [self rtl_setContentEdgeInsets:RTLEdgeInsetsWithInsets(contentEdgeInsets)];
}

- (void)rtl_setImageEdgeInsets:(UIEdgeInsets)imageEdgeInsets {
    [self rtl_setImageEdgeInsets:RTLEdgeInsetsWithInsets(imageEdgeInsets)];
}

- (void)rtl_setTitleEdgeInsets:(UIEdgeInsets)titleEdgeInsets {
    [self rtl_setTitleEdgeInsets:RTLEdgeInsetsWithInsets(titleEdgeInsets)];
}
@end
