//
//  UITextField+OEMRTL.m
//  AvoidCrash
//
//  Created by zhongch18 on 2022/3/22.
//

#import "UITextField+OEMRTL.h"
#import "OEMMacros.h"
@implementation UITextField (OEMRTL)
+ (void)load
{
//    static dispatch_once_t onceToken;
//    dispatch_once(&onceToken, ^{
//        swizzleInstanceMethod([self class], @selector(placeholderRectForBounds:), @selector(rtl_placeholderRectForBounds:));
//
//    });
}
//
//
//- (instancetype)rtl_initWithFrame:(CGRect)frame
//{
//    if ([self rtl_initWithFrame:frame]) {
//        self.textAlignment = NSTextAlignmentNatural;
//    }
//    return self;
//}
//
//- (void)rtl_setTextAlignment:(NSTextAlignment)textAlignment
//{
//    if (isRTL()) {
//        if (textAlignment == NSTextAlignmentNatural || textAlignment == NSTextAlignmentLeft) {
//            textAlignment = NSTextAlignmentRight;
//        } else if (textAlignment == NSTextAlignmentRight) {
//            textAlignment = NSTextAlignmentLeft;
//        }
//    }
//    [self rtl_setTextAlignment:textAlignment];
//}
//
-(CGRect)rtl_placeholderRectForBounds:(CGRect)bounds{
    //如果进入app，发现是RTL布局就不需要适配了，系统会默认适配
    if (isRTL()) {
        CGSize textSize1 = [self.placeholder sizeWithAttributes:@{NSFontAttributeName:self.font}];
        CGRect inset = CGRectMake(bounds.size.width - textSize1.width, bounds.origin.y, bounds.size.width, bounds.size.height);
        return [self rtl_placeholderRectForBounds:inset];
    }else{
        return [self rtl_placeholderRectForBounds:bounds];
    }

}
@end
