//
//  NSDate+OEMCategory.m
//  OEMFoundation
//
//  Created by Neil 韦学宁 on 2022/1/20.
//

#import "NSDate+OEMCategory.h"

static const unsigned oem_componentFlags = (NSCalendarUnitYear| NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitWeekOfMonth |  NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond | NSCalendarUnitWeekday | NSCalendarUnitWeekdayOrdinal);

@implementation NSDate (OEMCategory)

+ (NSCalendar *)oemCurrentCalendar
{
    static NSCalendar *sharedCalendar = nil;
    if (!sharedCalendar)
        sharedCalendar = [NSCalendar autoupdatingCurrentCalendar];
    return sharedCalendar;
}


- (BOOL)isToday;
{
    return [self isEqualToDateIgnoringTime:[NSDate date]];
}

- (BOOL) isEqualToDateIgnoringTime: (NSDate *) aDate
{
    NSDateComponents *components1 = [[NSDate oemCurrentCalendar] components:oem_componentFlags fromDate:self];
    NSDateComponents *components2 = [[NSDate oemCurrentCalendar] components:oem_componentFlags fromDate:aDate];
    return ((components1.year == components2.year) &&
            (components1.month == components2.month) &&
            (components1.day == components2.day));
}

+ (NSDictionary *)staticformatTable{
    static dispatch_once_t onceToken;
    static NSDictionary * p = nil;
    dispatch_once(&onceToken, ^{
        p = @{
            @"yyyyMMddHHmmss":            @"%Y%m%d%H%M%S",
            @"yyyy-MM-dd HH:mm:ss":       @"%Y-%m-%d %H:%M:%S",
            @"yyyy-MM-dd":                @"%Y-%m-%d",
            @"yyyy-MM-dd HH:mm":          @"%Y-%m-%d %H:%M",
            @"HH:mm":                     @"%H:%M",
            @"yyyy年MM月dd日":             @"%Y年%m月%d日",
            @"EEE, dd MMM yyyy HH:mm:ss": @"%a, %d %m %Y %H:%M:%S",
            @"yyyy/MM/dd HH:mm:ss":       @"%Y/%m/%d %H:%M:%S",
        };
    });
    return p;
}

+ (NSDateFormatter *)oem_sharedDateFormater
{
    static NSDateFormatter *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [NSDateFormatter new];
        NSLocale *locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
        instance.locale = locale;
        [instance setTimeZone:[NSTimeZone localTimeZone]];
    });
    return instance;
}


+ (NSString *)oem_dateStringForTime:(NSTimeInterval)dateTime dateFormat:(NSString *)dateFormat
{
    char buffer[80];

    time_t sec = (time_t)dateTime;
    const char *format = [dateFormat UTF8String];
    struct tm *timeinfo;
    
    timeinfo = localtime(&sec);
    strftime(buffer, 80, format, timeinfo);
    NSString *result = [NSString  stringWithCString:buffer encoding:NSUTF8StringEncoding];
    return result;
}

+ (NSString *)oem_getNSStringFromNSDate:(NSDate *)date withFormat:(NSString *)format
{
    NSString *newFormat = [[self staticformatTable] objectForKey:format];
    if (newFormat) {
        return [self oem_dateStringForDate:date dateFormat:newFormat];
    } else {
        NSDateFormatter *dateFormatter = [self oem_sharedDateFormater];
        [dateFormatter setDateFormat:format];
        return [dateFormatter stringFromDate:date];
    }
}

+ (NSString *)oem_dateStringForDate:(NSDate *)date dateFormat:(NSString *)dateFormat
{
    NSTimeInterval interval = [date timeIntervalSince1970];
    NSString *result = [self oem_dateStringForTime:interval dateFormat:dateFormat];
    return result;
}

- (NSString *)oem_stringWithFormat:(NSString *)format
{
    NSDateFormatter *formatter = [NSDateFormatter new];
    formatter.dateFormat = format;
    return [formatter stringFromDate:self];
}


@end
