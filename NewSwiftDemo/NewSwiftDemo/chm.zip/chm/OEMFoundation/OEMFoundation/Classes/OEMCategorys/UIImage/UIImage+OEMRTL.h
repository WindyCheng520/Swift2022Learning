//
//  UIImage+OEMRTL.h
//  OEMFoundation
//
//  Created by zhongch18 on 2022/3/22.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (OEMRTL)
//RTL图片处理，镜像图片
- (UIImage *)oem_imageFlippedForRightToLeftLayoutDirection;
//判断是否已经镜像
@property(nonatomic,assign)BOOL isFlip;
@end

NS_ASSUME_NONNULL_END
