//
//  UIImageView+OEMRTL.m
//  OEMFoundation
//
//  Created by zhongch18 on 2022/3/24.
//

#import "UIImageView+OEMRTL.h"
#import "OEMMacros.h"
#import "UIImage+OEMRTL.h"

//白名单做法风险太大
static inline  NSArray * whiteList(){
    return @[NSClassFromString(@"UIKBSplitImageView")];
}

@implementation UIImageView (OEMRTL)
//目前hook imageView 的这个方法是因为没法处理sd_setImage 网络图片翻转的情况
//除非修改sd源码
//考虑后端兼容方案
+ (void)load
{
//    static dispatch_once_t onceToken;
//    dispatch_once(&onceToken, ^{
//        swizzleInstanceMethod([self class], @selector(setImage:), @selector(rtl_setImage:));
//        swizzleInstanceMethod([self class], @selector(initWithImage:), @selector(rtl_initWithImage:));
//
//    });
}
//RTL图片翻转
//UIKBSplitImageView 是系统keyBoard 显示的图片，不能做翻转，
//如果翻转之后，keyboard就会白屏
//    Class cls00 = NSClassFromString(@"UIKeyboardDockItemButton");
//    Class cls01 = NSClassFromString(@"TUIPredictionViewCell");
-(void)rtl_setImage:(UIImage *)image{
    //已经翻转
    if (image.isFlip) {
        return [self rtl_setImage:image];
    }
    Class cls01 = NSClassFromString(@"UIKBSplitImageView");
    if ([self.superview.superview isKindOfClass:cls01]) {
        return [self rtl_setImage:image];
    }
    if (isRTL()) {
        image = [image oem_imageFlippedForRightToLeftLayoutDirection];
    }
    return [self rtl_setImage:image];
}

//RTL图片翻转
-(instancetype)rtl_initWithImage:(UIImage *)image{
    if (image.isFlip) {
        return [self rtl_initWithImage:image];
    }
    Class cls01 = NSClassFromString(@"UIKBSplitImageView");
    if ([self.superview.superview isKindOfClass:cls01]) {
        return [self rtl_initWithImage:image];
    }
    if (isRTL()) {
        image = [image oem_imageFlippedForRightToLeftLayoutDirection];
    }
    if ([self rtl_initWithImage:image]) {
        
    }
    return self;
}
@end
