//
//  NSDictionary+OEMExtension.h
//  midea
//
//  Created by MaYifang on 16/6/12.
//  Copyright © 2016年 Midea. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (OEMExtension)

+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString;
-(id)objectForKeySafe:(id)aKey;

@end
