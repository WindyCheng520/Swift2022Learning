//
//  NSDictionary+OEMExtension.m
//  midea
//
//  Created by MaYifang on 16/6/12.
//  Copyright © 2016年 Midea. All rights reserved.
//

#import "NSDictionary+OEMExtension.h"

@implementation NSDictionary (OEMExtension)

+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString {
    if (jsonString == nil || [jsonString isKindOfClass:[NSNull class]]) {
        return nil;
    }
    
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    if (jsonData == nil) {
        return nil;
    }
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                        options:NSJSONReadingMutableContainers
                                                          error:&err];
    if(err) {
        NSLog(@"json解析失败：%@",err);
        return nil;
    }
    return dic;
}

-(id)objectForKeySafe:(id)aKey{
    if (!aKey) {
        return nil;
    }
    return [self objectForKey:aKey];
}


@end
