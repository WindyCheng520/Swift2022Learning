//
//  OEMNetworkService+Auth.swift
//  OEMFoundation
//
//  Created by Neil 韦学宁 on 2021/11/3.
//

import Foundation

struct DataFiled: Decodable {
    var accessToken: String?
}

struct AuthField: Decodable{
    var code: Int = 0
    var msg: String = ""
    var data: DataFiled?
}

enum HTTPStatusCode: Int{
    case illegalToken = 401
}

private let hmacKey = "o8dk8vm6cbuyxdrl4se4c6i3h4tdea9b"

//open
extension OEMToBAuthService{
    
    open class func updateOpenID(_ openID: String,
                                  authConfigure: OEMRequestConfig,
                                  completion: ((_ isSuccess: Bool, _ error: Error?) -> Void)?){
        self.openID = openID
        self.authConfigure = authConfigure
        self.sdkInitCompletion = completion
        
        self.doRefreshToken { success, error in
            if let block = self.sdkInitCompletion{
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    //等待持久化完成
                    block(success, error)
                }
            }
        }
    }
    
    open class func cleanOpenID(){
        self.cleanPersistence()
        //清理完成后才清空openid
        self.openID = nil
    }
}

private let AuthTokenPrefix = "AuthToken_"
private let AuthDataPrefix = "AuthData_"

//internall
class OEMToBAuthService: NSObject{
    
    //外部传入auth 请求token的地址
    static var authConfigure: OEMRequestConfig?
    
    static var openID: String?
    
    static var refreshingToken: Bool = false
    
    static var sdkInitCompletion: ((_ isSuccess: Bool,_ error: Error?) -> Void)?
    
    internal class func keyForPersistance() -> (String?, String?){
        guard let openID = self.openID else {
            return (nil, nil)
        }
        let key = openID.hmac(key: hmacKey)
        return ((AuthTokenPrefix + key), (AuthDataPrefix + key))
    }
    
    /// 返回当前用户tokne
    /// - Returns: 如果有token返回值，如果没有token，包括空字符串，返回nil
    internal class func getPersistenceAccessToken() -> String?{
        guard let key = self.keyForPersistance().0 else {
            return nil
        }
        //根据用户ID持久化token
        if let token = UserDefaults.standard.value(forKey: key) as? String, token.count > 0{
            return token
        }
        return nil
    }
    
    /// 返回当前用户AuthData, 即获取token的响应内容
    /// - Returns: 返回响应body data
    internal class func getPersistenceAuthData() -> Data?{
        guard let key = self.keyForPersistance().1 else {
            return nil
        }
        //根据用户ID持久化data
        if let data = UserDefaults.standard.value(forKey: key) as? Data{
            return data
        }
        return nil
    }
    
    internal class func doRefreshToken(completion:@escaping (_ success: Bool, _ error: Error?) -> Void){
        guard let authConfigure = self.authConfigure else {
            completion(false, nil)
            return
        }
        OEMNetworkService.request(config: authConfigure) { (raw, decoded: DecodableResult<AuthField>?) in
            guard let auth = decoded?.entity,
                  let token = auth.data?.accessToken else{
                completion(false, nil)
                return
            }
            self.tokenPersistence(token: token, data: raw.rawData)
            completion(true, nil)
        }
    }
}

//private
extension OEMToBAuthService{
    
    private class func cleanPersistence(){
        self.tokenPersistence(token: "", data: nil)
    }
    
    private class func tokenPersistence(token: String, data: Data?){
        let keys = self.keyForPersistance()
        guard let tokenKey = keys.0,
        let dataKey = keys.1 else {
            return
        }
        //根据用户ID持久化token
        
        UserDefaults.standard.setValue(token, forKey: tokenKey)
        UserDefaults.standard.setValue(data ?? Data(), forKey: dataKey)
        UserDefaults.standard.synchronize()
    }
}
