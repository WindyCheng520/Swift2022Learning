//
//  OEMNetworkService.swift
//  OEMFoundation
//
//  Created by Neil 韦学宁 on 2021/10/28.
//

import Foundation

open class OEMNetworkService {
    
    @discardableResult
    open class func request<T: Decodable>(
        config: OEMRequestConfig,
        completion: ((_ response: OEMResponse,
                      _ decodableResult: DecodableResult<T>?) -> Void)? = nil) -> String?{
        
        guard let url = config.getFullPath() else {
            if let block = completion {
                block(OEMResponse.errorParam(), nil)
            }
            return nil
        }
        let parameters = config.getRequestBody()
        let headers = config.getHeaderWithSignature(param: parameters)
        
        var enc: ParameterEncoding = JSONEncoding(options: [])
        if config.method == .get {
            enc = URLEncoding.default
        }
        
        let req = AF.request(url, method: HTTPMethod(rawValue: config.method.getString()), parameters: parameters, encoding: enc, headers: HTTPHeaders(headers), interceptor: nil, requestModifier: nil)
        guard let block = completion else {
            return nil
        }
        let reqIdentifier = req.memoryIdentifier()
        req.response { composition in
            self.ResponseAOP(response: composition, reqIdentifier)
            let casted = OEMResponse.cast(resp: composition)
            switch composition.result{
            case .success(_):
                if let data = composition.data {
                    let dec = JSONDecoder()
                    if let entity = try? dec.decode( T.self, from: data){
                        block(casted, DecodableResult(entity: entity))
                    }else{
                        block(casted, nil)
                    }
                }else{
                    block(OEMResponse.emptyResponse(), nil)
                }
            case .failure(let error):
                block(OEMResponse.errorResponse(error), nil)
            }
        }
        
        return reqIdentifier

    }
    
    @discardableResult
    open class func request(config: OEMRequestConfig,
                            completion: ((_ response: OEMResponse) -> Void)? = nil) -> String? {
        guard let url = config.getFullPath() else {
            if let block = completion {
                block(OEMResponse.errorParam())
            }
            return nil
        }
        
        //todo
        let parameters = config.getRequestBody()
        let headers = config.getHeaderWithSignature(param: parameters)
        
        var enc: ParameterEncoding = JSONEncoding(options: [])
        if config.method == .get {
            enc = URLEncoding.default
        }
        
        let req = AF.request(url, method: HTTPMethod(rawValue: config.method.getString()), parameters: parameters, encoding: enc, headers: HTTPHeaders(headers), interceptor: nil, requestModifier: nil)
        
        let reqIdentifier = req.memoryIdentifier()
        guard let block = completion else{
            return nil
        }
        req.response { composition in
            self.ResponseAOP(response: composition, reqIdentifier)
            let casted = OEMResponse.cast(resp: composition)
            switch composition.result{
            case .success(_):
                block(casted)
            case .failure(let error):
                block(OEMResponse.errorResponse(error))
            }
        }
        return reqIdentifier
    }
    
    @objc
    @discardableResult
    open class func request(url: String,
                            path: String = "",
                            method: OEMMethod,
                            parameters: ParamsMap? = nil,
                            headers: HeadersMap? = nil,
                            signType: OEMSignType = .none,
                            completion: ((_ data: Data?,
                                          _ error: Error?) -> Void)? = nil) -> String? {
        let request = DefaustRequest(baseURL: url, path: path, method: method, headers: headers, parameters: parameters, signType: signType)
        let reqIdentifier = self.request(config: request) { oemRes in
            guard let block = completion else{
                return
            }
            if let code = oemRes.detail?.httpStatusCode,
                code >= 200, code < 300{
                block(oemRes.rawData, nil)
            }else{
                let e = NSError(domain: "", code: oemRes.code, userInfo: ["message": oemRes.message ?? ""])
                block(oemRes.rawData, e)
            }
        }
        return reqIdentifier
    }
    
    @discardableResult
    open class func upload(url: String,
                           data: Data,
                           progress: ((_ progress: Progress) -> Void)? = nil,
                           completion: ((_ data: Data?,
                                         _ error: Error?) -> Void)? = nil) -> String? {
        let req = AF.upload(data, to: url)
        let reqIdentifier = req.memoryIdentifier()
        
        if let block = progress {
            req.uploadProgress { progress in
                block(progress)
            }
        }
        
        if let block = completion {
            req.response { response in
                self.ResponseAOP(response: response, reqIdentifier)
                block(response.data, response.error)
            }
        }
        return reqIdentifier
    }
    
    @discardableResult
    open class func download(url: String,
                           progress: ((_ progress: Progress) -> Void)? = nil,
                           completion: ((_ data: Data?,
                                         _ error: Error?) -> Void)? = nil) -> String?
    {
        let req = AF.download(url)
        let reqIdentifier = req.memoryIdentifier()
        if let block = progress {
            req.downloadProgress { progress in
                block(progress)
            }
        }
        if let block = completion {
            req.responseData { response in
                self.DownloadResponseAOP(response: response, reqIdentifier)
                block(response.resumeData ,response.error)
            }
        }
        return reqIdentifier
    }
    
}

extension OEMNetworkService{
    
    open class func cancel(identifier: String){
        RequestManager.defaultManager.cancel(identifier)
    }
    
}


