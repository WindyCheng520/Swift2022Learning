//
//  OEMRequestConfig.swift
//  OEMFoundation
//
//  Created by Neil 韦学宁 on 2021/11/2.
//

import Foundation

public protocol OEMRequestConfig {
    
    var baseURL: String { get }

    var path: String { get }

    var method: OEMMethod { get }

    var headers: HeadersMap? { get }
    
    var parameters: ParamsMap? { get }
    
    var signType: OEMSignType { get }
}

public struct DefaustRequest: OEMRequestConfig{
    
    public var baseURL: String
    
    public var path: String
    
    public var method: OEMMethod
    
    public var headers: HeadersMap?
    
    public var parameters: ParamsMap?
    
    public var signType: OEMSignType
}

public typealias ParamsMap = [String: Any]

public typealias HeadersMap = [String: String]

@objc public enum OEMMethod: Int {
    case option, get, head, post, put, patch, delete, trace, connect
}

@objc public enum OEMSignType: Int {
    case none, tob2_0
}

extension OEMMethod{
    func getString() -> String {
        switch self {
        case .option:
            return "OPTION"
        case .get:
            return "GET"
        case .head:
            return "HEAD"
        case .post:
            return "POST"
        case .put:
            return "PUT"
        case .patch:
            return "PATCH"
        case .delete:
            return "DELETE"
        case .trace:
            return "TRACE"
        case .connect:
            return "CONNECT"
        }
    }
}

enum UniqueKeyIdentifier: String{
    case signParamKey = "Signature"
    case AuthorizationKey = "Authorization"
    case Bearer = "Bearer "
    case ClientIdParamKey = "ClientId"
    case HeaderSignVersionKey = "SignatureVersion"
    case HeaderSignVersionValue = "2.0"
}

public enum ResponseType{
    case codable
    case string
    case data
    case dictinary
}

public enum ResponseObj<Value>{
    
    case codable(Value)
    case string(string: String?)
    case data(data: Data?)
    case dictinary(Any?)
    
    public var value: Value? {
        return nil
    }
}


let formatter = DateFormatter()

public extension OEMRequestConfig{
    
    func getFullPath() -> String? {
        return self.baseURL + self.path
    }
    
    func getSign() -> String? {
        return self.baseURL + self.path
    }
    
    func getReqInfo() -> Dictionary<String, String> {
        formatter.dateFormat="yyyyMMddHHmmss"
        let stamp = formatter.string(from: Date())
        var reqId = UUID().uuidString
        reqId = reqId.lowercased()
        reqId = reqId.replacingOccurrences(of: "-", with: "")
        return [
            :
//            "reqId": reqId,
//            "stamp": stamp,
        ]
    }
    
    func getRequestBody() -> Parameters? {
        var returnValue : Parameters?
        if self.parameters?.values.count == 0 && self.method == .get {
            //iOS 13，get请求 body只能为空
            return nil
        }
        var params = self.parameters
        if self.signType == .tob2_0 && self.method == .post {
            //tob业务额外新增reqid，stamp
            let reqInfo = self.getReqInfo()
            if let p = self.parameters {
                params = p.merging(reqInfo, uniquingKeysWith: { (first, _) in first })
                returnValue = params
            }else{
                returnValue = reqInfo
            }
        }else{
            returnValue = self.parameters
        }
        return returnValue
    }
    
    func getHeaderWithSignature(param: Parameters?) -> HeadersMap{
        var mergesHaders = self.headers
        //如果签名版本是2.0，添加http请求头 签名版本
        if self.signType == .tob2_0{
            let map = [
                UniqueKeyIdentifier.HeaderSignVersionKey.rawValue : UniqueKeyIdentifier.HeaderSignVersionValue.rawValue
            ]
            if let header = self.headers {
                mergesHaders = header.merging(map, uniquingKeysWith: { (first, _) in first })
            }else{
                mergesHaders = map
            }
        }
        
        //如果签名版本是2.0，并且是get请求 则添加reqId stamp字段
        if self.signType == .tob2_0 && self.method == .get {
            let map = self.getReqInfo()
            if let header = mergesHaders {
                mergesHaders = header.merging(map, uniquingKeysWith: { (first, _) in first })
            }else{
                mergesHaders = map
            }
        }
        
        //如果签名版本是2.0，非获取token的接口，统一增加Bearer请求头
        if self.signType == .tob2_0,
           let authPath = OEMToBAuthService.authConfigure?.path,
           authPath != self.path,
           let token = OEMToBAuthService.getPersistenceAccessToken(),
           let headers = mergesHaders {
            let auth = [ UniqueKeyIdentifier.AuthorizationKey.rawValue : UniqueKeyIdentifier.Bearer.rawValue + token ]
            mergesHaders = headers.merging(auth, uniquingKeysWith: { (first, _) in first })
        }
        
        //如果签名版本是2.0，则添加clientid
        if self.signType == .tob2_0,
           let clientID = BaseService.clientId,
           let headers = mergesHaders,
           headers[UniqueKeyIdentifier.ClientIdParamKey.rawValue] == nil{
            let map = [ UniqueKeyIdentifier.ClientIdParamKey.rawValue : clientID ]
            mergesHaders = headers.merging(map, uniquingKeysWith: { (first, _) in first })
        }
        
        //拼接 reqId
        var reqId = UUID().uuidString
        reqId = reqId.lowercased()
        reqId = reqId.replacingOccurrences(of: "-", with: "")
        mergesHaders = mergesHaders?.merging(["reqId":reqId], uniquingKeysWith: { (first, _) in first })
        
        var queryString = ""
        
        let components = self.path.components(separatedBy: "?")
        if components.count >= 2{
            queryString = components.reduce("") { pre, next in
                pre + next
            }
        }
        
        var paramString = ""
        //紧凑JSON，不能是pretty print
        let opt : JSONSerialization.WritingOptions = []
        if let p = param,
           let data = try? JSONSerialization.data(withJSONObject: p, options: opt),
           let str = String(data: data, encoding: .utf8),
           str.count > 0{
            paramString = str
        }
        var fullString = self.method.getString() + self.path + queryString + paramString
        if queryString.count > 0 {
            //对get请求重新拼接处理
            fullString = self.method.getString() + queryString + paramString
        }
        if self.signType == .tob2_0,
           let signedHex = fullString.hmac(key: BaseService.clientSecret ?? "").hexadecimal{
            let s = [UniqueKeyIdentifier.signParamKey.rawValue : signedHex.toBase64()] as HeadersMap
            if let p = mergesHaders{
                let merge = s.merging(p, uniquingKeysWith: { (first, _) in first })
                return merge
            }
            return s
        }
        return self.headers ?? [:]
    }
    
}
