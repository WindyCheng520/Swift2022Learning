//
//  NetworkUtils.swift
//  OEMFoundation
//
//  Created by Neil 韦学宁 on 2021/11/1.
//

import Foundation
import CommonCrypto

protocol ObjectIdentifier {
    func memoryIdentifier() -> String;
}

extension Request: ObjectIdentifier{
    func memoryIdentifier() -> String {
        let identifier = Address(of: self).description
        RequestManager.defaultManager.store(identifier, self)
        return identifier
    }
}

public extension Progress{
    func preciseValue() -> Double{
        return (Double(self.completedUnitCount) / Double(self.totalUnitCount))
    }
}

public extension Data{
    func toBase64() -> String {
        return self.base64EncodedString()
    }
}

public extension String {

    func hmac(key: String) -> String {
        guard let ckey = key.cString(using: .ascii),
              let cData = self.cString(using: .utf8) else {
            return "hmac error"
        }

        var digest = [CUnsignedChar](repeating: 0, count: Int(CC_SHA256_DIGEST_LENGTH))
        CCHmac(CCHmacAlgorithm(kCCHmacAlgSHA256), ckey, strlen(ckey), cData, strlen(cData), &digest)
        let data = Data.init(bytes: digest, count: key.count)
        return data.map { String(format: "%02hhx", $0) }.joined()
    }
    
    func fromBase64() -> String? {
        guard let data = Data(base64Encoded: self) else {
            return nil
        }

        return String(data: data, encoding: .utf8)
    }

    var hexadecimal: Data? {
        var data = Data(capacity: self.count / 2)
        let regex = try! NSRegularExpression(pattern: "[0-9a-f]{1,2}", options: .caseInsensitive)
        regex.enumerateMatches(in: self, range: NSRange(startIndex..., in: self)) { match, _, _ in
            let byteString = (self as NSString).substring(with: match!.range)
            let num = UInt8(byteString, radix: 16)!
            data.append(num)
        }
        guard data.count > 0 else { return nil }
        return data
    }

}


public extension Dictionary {

    func jsonPrettyPrint() -> String {
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: self, options: [.prettyPrinted])
            return String(data: jsonData, encoding: .utf8) ?? "{}"
        } catch {
            print("json serialization error: \(error)")
            return "{}"
        }
    }
}
