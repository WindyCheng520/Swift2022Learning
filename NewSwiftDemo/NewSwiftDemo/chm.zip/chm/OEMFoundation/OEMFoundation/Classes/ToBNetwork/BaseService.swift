//
//  BaseService.swift
//  OEMFoundation
//
//  Created by Neil 韦学宁 on 2021/11/9.
//

import Foundation

public struct AuthConfig: OEMRequestConfig{
    
    public var signType: OEMSignType
    
    public var headers: HeadersMap?
    
    public var parameters: ParamsMap?
    
    public var baseURL: String{
        return BaseService.authURL
    }
    
    public var path: String = "/midea/open/business/v1/token"
    
    public var method: OEMMethod = .post
}

public let defuaultURL = "http://b-dev-public.smartmidea.net"

@objc
public protocol BaseServiceProtocol {
    func log(info: String);
}

@objc
open class BaseService: NSObject {
    @objc public private(set) static var clientId: String?
    @objc public private(set) static var clientSecret: String?
    @objc public private(set) static var authURL: String = defuaultURL
    @objc public private(set) static var serviceImpl: BaseServiceProtocol?
    @objc public static var enableConsoleLog: Bool = true
    
    @objc open class func initService(clientId: String?,
                                      clientSecret: String?,
                                      authURL: String = defuaultURL,
                                      serviceImpl: BaseServiceProtocol? = nil){
        self.clientId = clientId
        self.clientSecret = clientSecret
        self.authURL = authURL
        self.serviceImpl = serviceImpl
    }
    
    @objc open class func updateOpenID(_ openID: String,
                                       signType: OEMSignType = .none,
                                  completion: ((_ isSuccess: Bool, _ error: Error?) -> Void)?){
        var auth = AuthConfig(signType: signType)
        auth.parameters = [ "openUserId" : openID]
        OEMToBAuthService.updateOpenID(openID, authConfigure: auth, completion: completion)
    }
    
    @objc open class func getAccessToken() -> String?{
        return OEMToBAuthService.getPersistenceAccessToken()
    }
    
    @objc open class func getAuthData() -> Data?{
        return OEMToBAuthService.getPersistenceAuthData()
    }
    
    @objc open class func cleanOpenID(){
        OEMToBAuthService.cleanOpenID()
    }
}

@objc
open class NetworkBridging: NSObject {
    @objc public class func request(param: Dictionary<String, Any>,
                                    path: String,
                                    method: OEMMethod,
                                    parameters: ParamsMap?,
                                    headers: HeadersMap?,
                                    signType: OEMSignType = .none,
                                    completion: ( (Data?, Error?) -> Void )?){
        OEMNetworkService.request(url: path, method: method, parameters: parameters, headers: headers, signType: signType, completion: completion)
    }
}
