//
//  OEMNetworkService+AOP.swift
//  OEMFoundation
//
//  Created by Neil 韦学宁 on 2021/11/4.
//

import Foundation

extension OEMNetworkService{
    
    internal class func ResponseAOP(response: AFDataResponse<Data?>, _ identifier: String = ""){
        self.printInfo(response: response, identifier: identifier)
        self.checkToken(response: response)
        self.updateRequestManager(response, identifier)
    }
    
    internal class func DownloadResponseAOP(response: AFDownloadResponse<Data>, _ identifier: String = ""){
        //下载不需要打印详情和校对token
        RequestManager.defaultManager.clean(identifier)
    }
    
    internal class func updateRequestManager(_ response: AFDataResponse<Data?>,  _ identifier: String = ""){
        RequestManager.defaultManager.clean(identifier)
    }
    
    internal class func checkToken(response: AFDataResponse<Data?>){
        guard let authPath = OEMToBAuthService.authConfigure?.path,
              authPath.count > 0,
              let fullURL = response.request?.url?.absoluteString,
              fullURL.count > 0,
              //如果是刷新token的接口，那么就忽略掉，避免一直在刷新token
              fullURL.range(of: authPath) == nil else {
            return
        }
        
        if let res = response.response, res.statusCode == HTTPStatusCode.illegalToken.rawValue {
            OEMToBAuthService.refreshingToken = true
            OEMToBAuthService.doRefreshToken { (success, error) in
                OEMToBAuthService.refreshingToken = false
            }
        }
   
    }
    
    internal class func prettyPrint(_ items: Any...) {
        if BaseService.enableConsoleLog{
            items.forEach{ print($0) }
        }
        
        if let impl = BaseService.serviceImpl {
            items.forEach{ if let s = $0 as? String{
                impl.log(info: s)
            } }
        }
    }
    
    internal class func printInfo(response: AFDataResponse<Data?>, identifier: String? = nil){
        var info = ""
        let filter = " * "
        var isSuccess = false
        if let c = response.response?.statusCode, c >= 200, c < 300{
            isSuccess = true
        }
        info += "\(filter)🌏 >>>>>>>>>>>>>>>>> ToB request info start    \n"
        let url = response.request?.url?.absoluteString ?? "unknow"
        info += "\(filter)url:\(url)    \n"
        info += "\(filter)identifier:\(identifier ?? "unknow")"
        info += "\(filter)method:\(response.request?.httpMethod ?? "unknow")    \n"
        info += "\(filter)HTTP statusCode:\(response.response?.statusCode ?? 0) " + ((isSuccess)  ? "✅    \n" : "❌    \n")
        info += "\(filter)header:\(response.request?.allHTTPHeaderFields ?? [:])"
        if let body = response.request?.httpBody {
            if let bodyString = String(data: body, encoding: .utf8){
                info += "\(filter)body:\(bodyString)    \n"
            }else{
                info += "\(filter)body: body binary decode fail    \n"
            }
        }else{
            info += "\(filter)body: zero bytes    \n"
        }
        if let data = response.data {
            if let resString = String(data: data, encoding: .utf8){
                info += "\(filter)response:\(resString)    \n"
            }else{
                info += "\(filter)response: body binary decode fail    \n"
            }
        }else{
            info += "\(filter)response: zero bytes    \n"
        }
        info += "\(filter)error: \(String(describing: response.error))    \n"
        
        info += "\(filter)<<<<<<<<<<<<<<<<<<< ToB request info end    \n"
        prettyPrint(info)
    }
    
}



