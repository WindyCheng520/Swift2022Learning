//
//  RequestManager.swift
//  OEMFoundation
//
//  Created by Neil 韦学宁 on 2021/11/5.
//

import Foundation

protocol RequestBehavior {
    associatedtype T: AnyObject
    func cancel(_ identifier: String) -> Bool
    func redoRequest(_ identifier: String) -> Bool
    func clean(_ identifier: String) -> Bool
    func store(_ identifer: String, _ element: T)
}

class RequestManager: RequestBehavior{
    
    typealias T = Request
    
    static let defaultManager = RequestManager()
    
    var requestStorage = RequestStore<T>()
    
    func store(_ identifer: String, _ element: T){
        self.requestStorage.update(identifer, element)
    }
    
    @discardableResult
    func cancel(_ identifier: String) -> Bool{
        guard let req = self.requestStorage.get(identifier) else {
            return false
        }
        req.cancel()
        return true
    }
    
    @discardableResult
    func clean(_ identifier: String) -> Bool{
        self.requestStorage.clean(identifier)
        return true
    }
    
    func redoRequest(_ identifier: String) -> Bool{
        //暂时不需要实现
        return true
    }
    
}

internal extension OEMNetworkService{
    @discardableResult
    class func printRequestInfo() -> Int{
        var descriptions = [String]()
        RequestManager.defaultManager.requestStorage.items.forEach { k, item in
            descriptions.append("key:\(k) value: \(item.v?.request?.url?.absoluteString ?? "emptyURL")")
        }
        if BaseService.enableConsoleLog {
            print("\n💡 >>>>>>>>>>>>>>>>>RequestManager:")
            for des in descriptions {
                prettyPrint(des)
            }
            prettyPrint("<<<<<<<<<<<<<<<<<<< RequestManager end")
        }
        return descriptions.count
    }
}

class WeakObject<T: AnyObject> {
  weak var v : T?
  init (v: T) {
    self.v = v
  }
}

internal struct RequestStore<T: AnyObject>{
    
    var items : [String: WeakObject<T>] = [:]
    
    mutating func update(_ identifier: String, _ element: T) {
        let weakObj = WeakObject(v: element)
        items[identifier] = weakObj
        self.purge()
    }
    
    mutating func purge(){
        //T只能是class则有可能需要purge，但alomofire的request对象由框架管理，这里不一定能够清理掉
        self.items.forEach { (key: String, value: WeakObject<T>) in
            if value.v == nil{
                self.clean(key)
            }
        }
    }
    
    mutating func clean(_ identifier: String) {
        items.removeValue(forKey: identifier)
    }
    
    mutating func get(_ identifier: String) -> T?{
        let weakObj = items[identifier]
        guard let element = weakObj?.v  else {
            return nil
        }
        return element
    }
}

struct Address<T>: CustomStringConvertible {

    let intValue: Int

    var description: String {
        let length = 2 + 2 * MemoryLayout<UnsafeRawPointer>.size
        return String(format: "%0\(length)p", intValue)
    }

    init(of structPointer: UnsafePointer<T>) {
        intValue = Int(bitPattern: structPointer)
    }
}

extension Address where T: AnyObject {
    init(of classInstance: T) {
        intValue = unsafeBitCast(classInstance, to: Int.self)
    }
}
