//
//  OEMResponse.swift
//  OEMFoundation
//
//  Created by Neil 韦学宁 on 2021/11/3.
//

import Foundation

public struct OEMResponse{
    public var code: Int
    public var message: String?
    public var rawData: Data?
    public var detail: OEMResponseDetail?
    public var error: Error?
}

public enum OEMResponseCode: Int {
    case success, fail, errorParam
}

public struct OEMResponseDetail{
    public var httpStatusCode: Int?
    public var httpError: NSError?
}

public struct DecodableResult<T> {
    public var entity: T
}

public enum CommonError: Error{
    case illegalURL
    case illegalAuth
}

extension OEMResponse{
    
    static func cast(resp: AFDataResponse<Data?>) -> OEMResponse {
        var code = OEMResponseCode.success.rawValue
        switch resp.result {
        case .success(_):
            code = OEMResponseCode.success.rawValue
        case .failure(_):
            code = OEMResponseCode.fail.rawValue
        }
        var message: String?
        if let data = resp.data,
           let map = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]{
            code = map["code"] as? Int ?? OEMResponseCode.fail.rawValue
            message = map["message"] as? String
        }
        let detail = OEMResponseDetail(httpStatusCode: resp.response?.statusCode)
        var response = OEMResponse(code: code, message: message, rawData: resp.data, detail: detail)
        if let err = resp.error {
            //strong ref???
            response.error = err
        }
        return response
    }
    
    static func errorParam() -> OEMResponse{
        return OEMResponse(code: OEMResponseCode.errorParam.rawValue, message: "error param", rawData: nil, detail: nil)
    }
    
    static func emptyResponse() -> OEMResponse{
        return OEMResponse(code: OEMResponseCode.success.rawValue, message: "", rawData: nil, detail: nil)
    }
    
    static func errorResponse(_ error: Error) -> OEMResponse{
        if let err = error as? NSError {
            return OEMResponse(code: err.code, message: err.localizedDescription, rawData: nil, detail: nil, error: nil)
        }else{
            return OEMResponse(code: OEMResponseCode.fail.rawValue, message: error.localizedDescription, rawData: nil, detail: nil)
        }
    }
}

