//
//  OEMRequest.swift
//  OEMFoundation
//
//  Created by Neil 韦学宁 on 2022/1/21.
//

import Foundation

public typealias OFHttpRequestCache = (_ responseObject: Any?) -> Void
public typealias OFReqSuccess = (_ responseObject: Any?, _ response: HTTPURLResponse?, _ request: URLRequest?) -> Void
public typealias OFReqFailure = (_ error: NSError?, _ response: HTTPURLResponse?, _ request: URLRequest?) -> Void
public typealias OFResponseInterceptor = (_ input: Any?) -> Any?
public typealias OFErrorInterceptor = (_ error: Error, _ response: HTTPURLResponse?, _ request: URLRequest?) -> Error
public typealias OFHttpRequestProgress = (_ progress: Progress?) -> Void


@objc public enum OFHttpMethod: Int {
    case option, get, head, post, put, patch, delete, trace, connect
}

@objc public enum OFErrorInterceptorCode: Int {
    case serverError_Not2xx = 99999
}

@objc public class OFHttpMultipFormData: NSObject{
    @objc public var fileURL = ""
    @objc public var name = ""
    @objc public var fileName = ""
    @objc public var mimeType = ""
}

extension Data {
    var hexDescription: String {
        return reduce("") {$0 + String(format: "%02x", $1)}
    }
}
