//
//  OEMNetworkService.swift
//  OEMFoundation
//
//  Created by Neil 韦学宁 on 2022/1/20.
//

import Foundation

let OFRequestDomain = "com.OFRequestManager"

@objc
public class OFRequestManager: NSObject{
    
    @objc public static let manager = OFRequestManager()
    
    private var OFS = AF
    
    private var domainsAndCerName: [String: String] = [:]
    
    private var errorInterceptor: OFErrorInterceptor?
    
    private var responseInterceptor: OFResponseInterceptor?
    
    public override init() {
        super.init()
    }
    
    @objc public func getGlobalConfigureHeader() -> [[String: String]]{
        let originSets = AF.sessionConfiguration.headers.map{ return [$0.name : $0.value]}
        return originSets
    }
    
    @objc public func configureSessionWithServerTrust(domainsAndCerName: [String: String]){
        
        self.domainsAndCerName = domainsAndCerName
        guard domainsAndCerName.values.count > 0 else{
            return
        }
        var evaluatings : [String : ServerTrustEvaluating] = [:]
        domainsAndCerName.forEach {
            if let filePath = Bundle.main.path(forResource: $0.value, ofType: "cer"),
                let data = try? Data(contentsOf: URL(fileURLWithPath: filePath)),
               let certificate = SecCertificateCreateWithData(nil, data as CFData){
                let evalutor = PinnedCertificatesTrustEvaluator(certificates: [certificate], acceptSelfSignedCertificates: false, performDefaultValidation: false, validateHost: false)
                evaluatings[$0.key] = evalutor
            }
        }
        
        let trustManager = ServerTrustManager(evaluators: evaluatings)
        OFS = Session(serverTrustManager:trustManager)
    }
    
    @objc public func configureResponseInterceptor(_ responseInterceptor: OFResponseInterceptor?){
        self.responseInterceptor = responseInterceptor
    }
    
    @objc public func configureErrorInterceptor(_ errorInterceptor: @escaping OFErrorInterceptor){
        self.errorInterceptor = errorInterceptor
    }
    
    private func getRequestSession(urlString: String) -> Session{
        var isInnerRequest = false
        self.domainsAndCerName.values.forEach {
            if urlString.contains($0){
                isInnerRequest = true
            }
        }
        return isInnerRequest ? OFS: AF
    }
    
    @objc public func jsonEncode(params: [String: Any]?) -> Data?{
        //Objective-C和Swift JSON序列化后二进制不一致，这里需要统一
        guard let nnp = params, nnp.count > 0 else {
            return nil
        }
        guard let data = try? JSONSerialization.data(withJSONObject: nnp, options: JSONSerialization.WritingOptions.init(rawValue: 0)) else {
            return nil
        }
        return data;
    }
    
    @objc public func doRequest(url: String,
                                method: OFHttpMethod,
                                body: Data?,
                                requestTimeout: TimeInterval,
                                header: [String: String]?,
                                success: OFReqSuccess?,
                                fail: OFReqFailure?){
        guard let validUrl = URL(string: url) else{
            if let fail = fail {
                fail(nil, nil, nil)
            }
            return
        }
        var request = URLRequest(url: validUrl, cachePolicy: URLRequest.CachePolicy.reloadIgnoringCacheData, timeoutInterval: requestTimeout)
        request.method = self.methodCast(m: method)
        if let body = body{
            request.httpBody = body
        }
        if let header = header {
            request.headers = HTTPHeaders(header)
        }
        let session = type(of: self).manager.getRequestSession(urlString: url)
        session.request(request, interceptor: nil).response { composition in
            switch composition.result{
            case .success(_):
                guard let successb = success else{
                    return
                }
                if self.shouldHandleNot2xxResult(composition.response, composition.request, composition.data, fail) {
                    return
                }
                if let d = composition.data,
                   let map = try? JSONSerialization.jsonObject(with: d, options: []){
                    if let responseInterceptor = OFRequestManager.manager.responseInterceptor {
                        successb(responseInterceptor(map), composition.response, composition.request)
                    }else{
                        successb(map, composition.response, composition.request)
                    }
                }else{
                    successb(nil, composition.response, composition.request)
                }
                
            case .failure(let error):
                guard let failb = fail else{
                    return
                }
                var interceptError = error as NSError
                if let interceptor = self.errorInterceptor{
                    interceptError = interceptor(interceptError, composition.response, composition.request) as NSError
                }
                failb(interceptError, composition.response, composition.request)
            }
        }
    }
    
    @objc public func doRequest(url: String,
                                method: OFHttpMethod,
                                params: [String: Any]?,
                                header: [String: String]?,
                                success: OFReqSuccess?,
                                fail: OFReqFailure?){
        var enc: ParameterEncoding = JSONEncoding(options: [])
        if method == .get {
            enc = URLEncoding.default
        }
        let session = type(of: self).manager.getRequestSession(urlString: url)
        session.request(url, method: self.methodCast(m: method), parameters: params, encoding: enc, headers: HTTPHeaders(header ?? [:]), interceptor: nil, requestModifier: nil).response { composition in
            switch composition.result{
            case .success(_):
                guard let successb = success else{
                    return
                }
                if self.shouldHandleNot2xxResult(composition.response, composition.request, composition.data, fail) {
                    return
                }
                if let d = composition.data,
                   let map = try? JSONSerialization.jsonObject(with: d, options: []){
                    if let responseInterceptor = OFRequestManager.manager.responseInterceptor {
                        successb(responseInterceptor(map), composition.response, composition.request)
                    }else{
                        successb(map, composition.response, composition.request)
                    }
                }else{
                    successb(nil, composition.response, composition.request)
                }
                
            case .failure(let error):
                guard let failb = fail else{
                    return
                }
                var interceptError = error as NSError
                if let interceptor = self.errorInterceptor{
                    interceptError = interceptor(interceptError, composition.response, composition.request) as NSError
                }
                failb(interceptError, composition.response, composition.request)
            }
        }
    }
    
    @objc public func doUpload(url: String,
                               headers: [String: String]? = nil,
                               formData: OFHttpMultipFormData,
                               progress:OFHttpRequestProgress?,
                                success: OFReqSuccess?,
                                fail: OFReqFailure?){
        AF.upload(multipartFormData: { AFFormdata in
            AFFormdata.append(URL(fileURLWithPath: formData.fileURL), withName: formData.name , fileName: formData.fileName, mimeType: formData.mimeType)
        }, to: url, headers: HTTPHeaders(headers ?? [:]) ).uploadProgress { p in
            if let progress = progress {
                progress(p)
            }
        }.response { composition in
            switch composition.result{
            case .success(_):
                guard let successb = success else{
                    return
                }
                if let d = composition.data,
                   let map = try? JSONSerialization.jsonObject(with: d, options: []){
                    successb(map, composition.response, composition.request)
                }else{
                    successb(nil, composition.response, composition.request)
                }
                
            case .failure(let error):
                guard let failb = fail else{
                    return
                }
                failb(error as NSError, composition.response, composition.request)
            }
        }
    }
    
    @objc public func download(){
        
    }
    
}

extension OFRequestManager{
    func methodCast(m: OFHttpMethod) -> HTTPMethod {
        var rmethod = HTTPMethod.post
        switch m {
        case .option:
            rmethod = HTTPMethod.options
        case .get:
            rmethod = HTTPMethod.get
        case .head:
            rmethod = HTTPMethod.head
        case .post:
            rmethod = HTTPMethod.post
        case .put:
            rmethod = HTTPMethod.put
        case .patch:
            rmethod = HTTPMethod.patch
        case .delete:
            rmethod = HTTPMethod.delete
        case .trace:
            rmethod = HTTPMethod.trace
        case .connect:
            rmethod = HTTPMethod.connect
        }
        return rmethod
    }
}


extension OFRequestManager{
    
    private func shouldHandleNot2xxResult(_ response: HTTPURLResponse?,
                                          _ request: URLRequest?,
                                          _ data: Data?,
                                          _ fail: OFReqFailure?) -> Bool{
        if let nonResp = response,
            (nonResp.statusCode >= 400 && nonResp.statusCode <= 600){

            guard let failb = fail else{
                return false
            }
            
            var isInnerRequest = true
            //非配置域名请求的https不拦截
            self.domainsAndCerName.values.forEach {
                if let url = request?.url?.absoluteString, url.contains($0){
                    isInnerRequest = false
                }
            }
            if !isInnerRequest {
                return false
            }
            
            var dataDes = "http statusCode:\(nonResp.statusCode)"
            if let d = data, let detail = String(data: d, encoding: .utf8){
                dataDes = dataDes + " " + detail
            }
            var interceptError = NSError(domain: OFRequestDomain, code: OFErrorInterceptorCode.serverError_Not2xx.rawValue, userInfo:[NSLocalizedFailureReasonErrorKey: dataDes]
            )
            if let interceptor = self.errorInterceptor{
                interceptError = interceptor(interceptError, response, request) as NSError
            }
            failb(interceptError, response, request)
            return true
        }
        return false
    }
}
