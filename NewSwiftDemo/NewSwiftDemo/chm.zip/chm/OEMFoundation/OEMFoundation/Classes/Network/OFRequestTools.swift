//
//  OFRequestTools.swift
//  OEMFoundation
//
//  Created by Neil 韦学宁 on 2022/1/25.
//

import Foundation
import MapKit
import CommonCrypto

public typealias OFToolsParameters = [String: Any]

public typealias OFToolsHeadersMap = [String: String]

enum OFUniqueKeyIdentifier: String{
    case signParamKey = "Signature"
    case AuthorizationKey = "Authorization"
    case ClientIdParamKey = "ClientId"
    case HeaderSignVersionKey = "SignatureVersion"
}

enum OFUniqueValueIdentifier: String{
    case Bearer = "Bearer "
    case version = "2.0"
}

@objc
public class OFRequestTools: NSObject{
    @objc public class func getHeaderWithSignature(body: Data?,
                                       header: OFToolsHeadersMap?,
                                       subPath: String,
                                       clientSecret: String,
                                       addSignVersion: Bool = true,
                                       clientID: String?,
                                       addClientHeader: Bool = true,
                                       token: String?,
                                       addTokenHeader: Bool = true,
                                       methodString: String = "POST") -> OFToolsHeadersMap {
        var mergesHaders = OFToolsHeadersMap()
        if let header = header{
            mergesHaders = header.merging(header, uniquingKeysWith: { (first, _) in first })
        }
        
        if addSignVersion {
            //添加http请求头 签名版本
            let map = [
                OFUniqueKeyIdentifier.HeaderSignVersionKey.rawValue : OFUniqueValueIdentifier.version.rawValue
            ]
            mergesHaders = mergesHaders.merging(map, uniquingKeysWith: { (first, _) in first })
        }
        
        //统一增加Bearer请求头
        if let  token =  token, addTokenHeader{
            let auth = [ OFUniqueKeyIdentifier.AuthorizationKey.rawValue : OFUniqueValueIdentifier.Bearer.rawValue + token ]
            mergesHaders = mergesHaders.merging(auth, uniquingKeysWith: { (first, _) in first })
        }
        
        //添加clientid
        if let clientID = clientID, addClientHeader{
            let map = [ OFUniqueKeyIdentifier.ClientIdParamKey.rawValue : clientID ]
            mergesHaders = mergesHaders.merging(map, uniquingKeysWith: { (first, _) in first })
        }
        
        var queryString = ""
        let components = subPath.components(separatedBy: "?")
        if components.count >= 2 {
            queryString = components.reduce("") { pre, next in
                pre + next
            }
        }
        
        var paramString = ""
        if let data = body,
           let str = String(data: data, encoding: .utf8),
           str.count > 0{
            paramString = str
        }
        var fullString = methodString + subPath + queryString + paramString
        if queryString.count > 0 {
            //对get请求重新拼接处理
            fullString = methodString + queryString + paramString
        }
        
        if let signedHex = fullString.hmac(key: clientSecret).hexadecimal{
         let s = [OFUniqueKeyIdentifier.signParamKey.rawValue : signedHex.toBase64()] as OFToolsHeadersMap
            mergesHaders = s.merging(mergesHaders, uniquingKeysWith: { (first, _) in first })
            return mergesHaders
        }
        return mergesHaders
    }

}



