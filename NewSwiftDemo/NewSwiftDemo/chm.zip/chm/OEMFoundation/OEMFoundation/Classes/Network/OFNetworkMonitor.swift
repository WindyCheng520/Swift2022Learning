//
//  OFNetworkMonitor.swift
//  OEMFoundation
//
//  Created by Neil 韦学宁 on 2022/2/10.
//

import Foundation

@objc public enum OEMNetWorkReachableStatus: Int {
    case unknown, notReachable, reachable
}

@objc public enum OEMNetWorkConType: Int {
    case unknown, ethernetOrWiFi, cellular
}

@objc public class OFNetworkMonitorObserver: NSObject{
    public weak var refrence: NSObject?
    public var block: os_block_t?
}

@objc
public class OFNetworkMonitor: NSObject{
    
    //Public
    @objc public var reachableStatus = OEMNetWorkReachableStatus.unknown
    
    @objc public var connectType = OEMNetWorkConType.unknown
    
    //public typealias OFNetworkCallbak = (_ monitor: OFNetworkMonitor) -> Void
    
    let reachabilityManager = NetworkReachabilityManager(host:"www.apple.com")
    
    @objc public static let shared = OFNetworkMonitor()
    
    static let lock = NSLock()
    
    public override init() {
        super.init()
        reachabilityMonitor()
    }
    
    @objc
    public func registerListener(_ observe: OFNetworkMonitorObserver){
        OFNetworkMonitor.lock.lock()
        self.clean()
        observes.append(observe)
        OFNetworkMonitor.lock.unlock()
    }
    
    private func clean(){
        observes.removeAll()
        let existeds = observes.filter{ return $0.refrence != nil }
        observes.append(contentsOf: existeds)
    }
    
    //Private
    private var observes: [OFNetworkMonitorObserver] = []
    
}

extension OFNetworkMonitor{
    //网络监控
    func reachabilityMonitor() {
        reachabilityManager?.startListening(onUpdatePerforming: {[weak self] status in
            guard let self = self else{
                return
            }
            switch status{
            case .unknown:
                self.reachableStatus = .unknown
                self.connectType = .unknown
            case .notReachable:
                self.reachableStatus = .notReachable
                self.connectType = .unknown
            case .reachable(let t):
                self.reachableStatus = .reachable
                switch t{
                case .ethernetOrWiFi:
                    self.connectType = .ethernetOrWiFi
                case .cellular:
                    self.connectType = .cellular
                }
            }
            self.observes.forEach { item in
                if let b = item.block{
                    b()
                }
            }
        })
    }
}
