//
//  OEMDeviceTool.m
//  midea
//
//  Created by MaYifang on 16/6/12.
//  Copyright © 2016年 Midea. All rights reserved.
//

#import "OEMDeviceTool.h"
#import <UIKit/UIKit.h>

#import <sys/socket.h>
#import <netinet/in.h>
#import <netinet6/in6.h>
#import <arpa/inet.h>
#import <ifaddrs.h>
#import <netdb.h>
#import "sys/utsname.h"
#import <SystemConfiguration/CaptiveNetwork.h>
@implementation OEMDeviceTool

#pragma mark - 获取当前连接的wifi名称
+ (NSString *)currentWifiSSID {
    
    NSString *ssid = nil;
    
    CFArrayRef arrRef = CNCopySupportedInterfaces();
    
    NSArray *ifs = (__bridge id)arrRef;
    
    for (NSString *ifnam in ifs) {
        
        CFDictionaryRef dicRef = CNCopyCurrentNetworkInfo((__bridge CFStringRef)ifnam);
        
        NSDictionary *info = (__bridge id)dicRef;
        
        if (info[@"BSSID"]) {
            ssid = info[@"SSID"];
        }
        
        if (dicRef != nil) {
            CFRelease(dicRef);
        }
    }
    
    if (arrRef != nil) {
        CFRelease(arrRef);
    }
    
    return ssid;
}

#pragma mark - 获取设备剩余容量MB
+ (float)freeDiskSpace
{
    NSDictionary *fattributes = [[NSFileManager defaultManager] attributesOfFileSystemForPath:NSHomeDirectory() error:nil];
    return ([[fattributes objectForKey:NSFileSystemFreeSize] floatValue]/1024.0f/1024.0f);
}

#pragma mark - 获取ip地址
+ (NSString *)getIPAddress
{
    NSString *address = @"error";
    
    struct ifaddrs *interfaces = NULL;
    
    struct ifaddrs *temp_addr = NULL;
    
    int success = 0;
    // retrieve the current interfaces - returns 0 on success
    success = getifaddrs(&interfaces);
    
    if (success == 0) {
        // Loop through linked list of interfaces
        temp_addr = interfaces;
        while (temp_addr != NULL) {
            if( temp_addr->ifa_addr->sa_family == AF_INET) {
                // Check if interface is en0 which is the wifi connection on the iPhone
                if ([[NSString stringWithUTF8String:temp_addr->ifa_name] isEqualToString:@"en0"]) {
                    // Get NSString from C String
                    address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
                }
            }
            temp_addr = temp_addr->ifa_next;
        }
    }
    // Free memory
    freeifaddrs(interfaces);
    
    if([address isEqualToString:@"error"])
    {
        return nil;
    }
    
    return address;
}

+ (NSString*)deviceString
{
    // 需要#import "sys/utsname.h"
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString *deviceString = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    
    if ([deviceString isEqualToString:@"iPhone1,1"])    return @"iPhone 1G";
    if ([deviceString isEqualToString:@"iPhone1,2"])    return @"iPhone 3G";
    if ([deviceString isEqualToString:@"iPhone2,1"])    return @"iPhone 3GS";
    if ([deviceString isEqualToString:@"iPhone3,1"])    return @"iPhone 4";
    if ([deviceString isEqualToString:@"iPhone3,2"])    return @"iPhone 4";
    if ([deviceString isEqualToString:@"iPhone3,3"])    return @"iPhone 4";
    if ([deviceString isEqualToString:@"iPhone4,1"])    return @"iPhone 4S";
    if ([deviceString isEqualToString:@"iPhone5,1"])    return @"iPhone 5";
    if ([deviceString isEqualToString:@"iPhone5,2"])    return @"iPhone 5";
    if ([deviceString isEqualToString:@"iPhone5,3"])    return @"iPhone 5C";
    if ([deviceString isEqualToString:@"iPhone5,4"])    return @"iPhone 5C";
    if ([deviceString isEqualToString:@"iPhone6,1"])    return @"iPhone 5S";
    if ([deviceString isEqualToString:@"iPhone6,2"])    return @"iPhone 5S";
    if ([deviceString isEqualToString:@"iPhone7,1"])    return @"iPhone 6Plus";
    if ([deviceString isEqualToString:@"iPhone7,2"])    return @"iPhone 6";
    if ([deviceString isEqualToString:@"iPhone8,1"])    return @"iPhone 6S";
    if ([deviceString isEqualToString:@"iPhone8,2"])    return @"iPhone 6SPlus";
    if ([deviceString isEqualToString:@"iPhone9,1"])    return @"iPhone 7";
    if ([deviceString isEqualToString:@"iPhone9,2"])    return @"iPhone 7Plus";
    if ([deviceString isEqualToString:@"iPod1,1"])      return @"iPod Touch";
    if ([deviceString isEqualToString:@"iPod2,1"])      return @"iPod Touch";
    if ([deviceString isEqualToString:@"iPod3,1"])      return @"iPod Touch";
    if ([deviceString isEqualToString:@"iPod4,1"])      return @"iPod Touch";
    if ([deviceString isEqualToString:@"iPad1,1"])      return @"iPad";
    if ([deviceString isEqualToString:@"iPad2,1"])      return @"iPad 2";
    if ([deviceString isEqualToString:@"iPad2,2"])      return @"iPad 2";
    if ([deviceString isEqualToString:@"iPad2,3"])      return @"iPad 2";
    if ([deviceString isEqualToString:@"i386"])         return @"Simulator";
    if ([deviceString isEqualToString:@"x86_64"])       return @"Simulator";
    
    NSLog(@"NOTE: Unknown device type: %@", deviceString);
    return deviceString;
}

/*
 那行 就定：
 手机品牌：phoneBrand ：苹果、小米、三星
 手机的设备型号: phoneType  : iPhone4s、 小米note
 手机系统版本: osVersion : iOS9.0.3 、 Android 4.0.3
 美居App版本: AppVersion : 3.0.1.128
 */

+ (NSMutableDictionary*)getDeviceData
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    NSString *strSysName = [[UIDevice currentDevice] systemVersion];
    NSDictionary *dicInfo = [[NSBundle mainBundle] infoDictionary];
    NSString *strAppVersion = [dicInfo objectForKey:@"CFBundleShortVersionString"];
    [dic setObject:[NSString stringWithFormat:@"iOS%@",strSysName] forKey:@"osVersion"];
    [dic setObject:strAppVersion forKey:@"AppVersion"];
    [dic setObject:[self deviceString] forKey:@"phoneType"];
    [dic setObject:@"苹果" forKey:@"phoneBrand"];
    return dic;
}

+ (void)localData
{
    NSString *strName = [[UIDevice currentDevice] name];
    NSLog(@"设备名称：%@", strName);//e.g. "My iPhone"
    
    NSString *strSysName = [[UIDevice currentDevice] systemName];
    NSLog(@"系统名称：%@", strSysName);// e.g. @"iOS"
    
    NSString *strSysVersion = [[UIDevice currentDevice] systemVersion];
    NSLog(@"系统版本号：%@", strSysVersion);// e.g. @"4.0"
    
    NSString *strModel = [[UIDevice currentDevice] model];
    NSLog(@"设备模式：%@", strModel);// e.g. @"iPhone", @"iPod touch"
    
    NSString *strLocModel = [[UIDevice currentDevice] localizedModel];
    NSLog(@"本地设备模式：%@", strLocModel);// localized version of model
    
    //app应用相关信息的获取
    NSDictionary *dicInfo = [[NSBundle mainBundle] infoDictionary];
    //    CFShow(dicInfo);
    
    NSString *strAppName = [dicInfo objectForKey:@"CFBundleDisplayName"];
    NSLog(@"App应用名称：%@", strAppName);
    
    NSString *strAppVersion = [dicInfo objectForKey:@"CFBundleShortVersionString"];
    NSLog(@"App应用版本：%@", strAppVersion);
    
    NSString *strAppBuild = [dicInfo objectForKey:@"CFBundleVersion"];
    NSLog(@"App应用Build版本：%@", strAppBuild);
    
    NSLog(@"deviceString:%@",[self deviceString]);
    
}

+ (NSString *)deviceId
{
    NSString *subString = [NSString string];
    
    NSString *deviceIdString = [[NSUserDefaults standardUserDefaults] objectForKey:@"UUIDdeviceId"];
    
    if (deviceIdString == nil) {
        CFUUIDRef deviceId = CFUUIDCreate (NULL);
        CFStringRef deviceIdStringRef = CFUUIDCreateString(NULL,deviceId);
        CFRelease(deviceId);
        deviceIdString = (__bridge NSString *)deviceIdStringRef;
        [[NSUserDefaults standardUserDefaults] setValue:deviceIdString forKey:@"UUIDdeviceId"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    
    if (deviceIdString.length >= 6) {
        subString = [deviceIdString substringToIndex:6];
    }
    
    return subString;
}

@end
