//
//  OEMDeviceTool.h
//  midea
//
//  Created by MaYifang on 16/6/12.
//  Copyright © 2016年 Midea. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OEMDeviceTool : NSObject

//获取设备剩余容量MB
+ (float)freeDiskSpace;

+ (NSString *)currentWifiSSID;

//获取ip地址
+ (NSString *)getIPAddress;

+ (NSString*)deviceString;

//获取手机设备信息
+ (NSMutableDictionary*)getDeviceData;

+ (NSString *)deviceId;

@end
