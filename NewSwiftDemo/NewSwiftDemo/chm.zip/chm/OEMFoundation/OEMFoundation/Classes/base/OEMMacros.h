//
//  OEMMacros.h
//  常用宏定义
//
//  Created by yanghy on 19-02-20.
//  Copyright (c) 2019年 Midea.com. All rights reserved.
//

#ifndef OEMMacros_h
#define OEMMacros_h
#import <objc/runtime.h>
#import "HGInternationalization.h"


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#pragma mark - 强弱引用解耦 -
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
// block self
#define WEAKSELF typeof(self) __weak weakSelf = self;
#define STRONGSELF typeof(weakSelf) __strong strongSelf = weakSelf;

#ifndef strongify
#if DEBUG
#if __has_feature(objc_arc)
#define strongify(object) autoreleasepool{} __typeof__(object) object = weak##_##object;
#else
#define strongify(object) autoreleasepool{} __typeof__(object) object = block##_##object;
#endif
#else
#if __has_feature(objc_arc)
#define strongify(object) try{} @finally{} __typeof__(object) object = weak##_##object;
#else
#define strongify(object) try{} @finally{} __typeof__(object) object = block##_##object;
#endif
#endif
#endif

#ifndef weakify
#if DEBUG
#if __has_feature(objc_arc)
#define weakify(object) autoreleasepool{} __weak __typeof__(object) weak##_##object = object;
#else
#define weakify(object) autoreleasepool{} __block __typeof__(object) block##_##object = object;
#endif
#else
#if __has_feature(objc_arc)
#define weakify(object) try{} @finally{} {} __weak __typeof__(object) weak##_##object = object;
#else
#define weakify(object) try{} @finally{} {} __block __typeof__(object) block##_##object = object;
#endif
#endif
#endif






/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#pragma mark - System Version -
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

#define SYSTEMVERSION_FLOAT     ([[[UIDevice currentDevice] systemVersion] floatValue])
#define SYSTEMVERSION_DOUBLE    ([[[UIDevice currentDevice] systemVersion] doubleValue])
#define SYSTEMVERSION_STRING    ([[UIDevice currentDevice] systemVersion])





/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#pragma mark - Debug -
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/





/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#pragma mark - Notification -
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

#undef    BHNoteCenterRegisterObserver
#define BHNoteCenterRegisterObserver(__name, __observer, __selector) { \
    [[NSNotificationCenter defaultCenter] removeObserver:__observer\
                                                    name:__name \
                                                  object:nil];\
    \
    if ([__observer respondsToSelector:__selector]){ \
        [[NSNotificationCenter defaultCenter] addObserver:__observer\
                                                 selector:__selector \
                                                     name:__name \
                                                   object:nil]; \
    }\
}


#undef    BHNoteCenterPost
#define BHNoteCenterPost(__name, __object, __userInfo) [[NSNotificationCenter defaultCenter] postNotificationName:__name object:__object userInfo:__userInfo];


#undef BHNoteCenterRemoveObserver
#define BHNoteCenterRemoveObserver(__name, __observer)  [[NSNotificationCenter defaultCenter] removeObserver:__observer name:__name object:nil];


#undef BHNoteCenterRemoveAllObserver
#define BHNoteCenterRemoveAllObserver(__observer)  [[NSNotificationCenter defaultCenter] removeObserver:__observer];




/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#pragma mark - Color -
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

#define RGBCOLOR(r,g,b)             [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:1]
#define RGBACOLOR(r,g,b,a)          [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)]

// RGB颜色转换（16进制->10进制）
#define UIColorFromRGB(rgbValue) [UIColor \
    colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
    green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
    blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

#define UIColorFromRGBA(rgbValue, a) [UIColor \
    colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
    green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
    blue:((float)(rgbValue & 0xFF))/255.0 \
    alpha:a]

#define RGBWith16Band(rgbValue)  [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

#define HexColorAlpha(rgbValue, alphaValue)  [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
                                                             green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
                                                              blue:((float)(rgbValue & 0xFF))/255.0 \
                                                             alpha:alphaValue]


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#pragma mark - Degree -
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define DEGREES_TO_RADIANS(angle) ((angle)/180.0 *M_PI)


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#pragma mark - Image -
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//获取当前包的资源
#define PNGPATH(NAME)           [[NSBundle mainBundle] pathForResource:[NSString stringWithUTF8String:NAME] ofType:@"png"]
#define JPGPATH(NAME)           [[NSBundle mainBundle] pathForResource:[NSString stringWithUTF8String:NAME] ofType:@"jpg"]
#define PATH(NAME, EXT)         [[NSBundle mainBundle] pathForResource:(NAME) ofType:(EXT)]

#define PNGIMAGE(NAME)          [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:(NAME) ofType:@"png"]]
#define JPGIMAGE(NAME)          [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:(NAME) ofType:@"jpg"]]
#define IMAGE(NAME, EXT)        [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:(NAME) ofType:(EXT)]]

#define BHResourceBundle        [NSBundle bundleForClass:[self class]]
#define BHBundle                [NSBundle bundleForClass:[self class]]
#define IMAGENAMED(NAME)        [UIImage imageNamed:NAME]//[UIImage imageNamed:NAME inBundle:BHResourceBundle compatibleWithTraitCollection:nil] //加载ResourceFramework下的资源文件
#define LIMAGENAMED(NAME)       [UIImage imageNamed:NAME inBundle:BHBundle compatibleWithTraitCollection:nil]  //加载当前Framework下的资源文件

//从Frame包中获取图片
#define BHResPath(RES, EXT)     [BHResourceBundle pathForResource:RES ofType:EXT]
#define BundleImage(NAME, EXT)  [UIImage imageWithContentsOfFile:BHResPath(NAME, EXT)]
#define BundlePNGImage(NAME)    [UIImage imageWithContentsOfFile:BHResPath(NAME, @"png")]
#define BundleJPGImage(NAME)    [UIImage imageWithContentsOfFile:BHResPath(NAME, @"jpg")]

//获取ResourceBundle 下的images.bundle 存放大图片
#define BHResourceBundleImage(ImageBundlePath)    [UIImage imageWithContentsOfFile:QFResourecImagesPath(ImageBundlePath)]

#define BHResourecImagesPath(NAME)               [[NSBundle bundleWithPath:[[BHBundle resourcePath] stringByAppendingPathComponent:@"images.bundle"]] pathForResource:[NSString stringWithFormat:@"%@",NAME] ofType:@"png"]

#define IMAGEWIDTH(image)       ((image).size.width)
#define IMAGEHEIGHT(image)      ((image).size.height)



/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#pragma mark - Font -
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define BOLDSYSTEMFONT(FONTSIZE)[UIFont boldSystemFontOfSize:FONTSIZE]
#define SYSTEMFONT(FONTSIZE)    [UIFont systemFontOfSize:FONTSIZE]
#define FONT(NAME, FONTSIZE)    [UIFont fontWithName:(NAME) size:(FONTSIZE)]

//#define Font_PingFang_(size) [UIFont fontWithName:@"PingFang SC" size:size]
//#define Font_PingFang_14 FSystenVersion >= 9.0 ? [UIFont fontWithName:@"PingFang SC" size:14] : [UIFont systemFontOfSize:14]
//#define Font_PingFang_16 FSystenVersion >= 9.0 ? [UIFont fontWithName:@"PingFang SC" size:16] : [UIFont systemFontOfSize:16]
//#define Font_PingFang_18 FSystenVersion >= 9.0 ? [UIFont fontWithName:@"PingFang SC" size:18] : [UIFont systemFontOfSize:18]



/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#pragma mark - Frame -
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
// Screen Scale
#define BHScreenScale       [[UIScreen mainScreen] scale]
#define ScreenScale         [UIScreen mainScreen].scale

// App Frame
#define BHAppFrame          [[UIScreen mainScreen] applicationFrame]

// App Frame Height&Width
#define BHAppFrameHeight    [[UIScreen mainScreen] applicationFrame].size.height
#define BHAppFrameWidth     [[UIScreen mainScreen] applicationFrame].size.width
#define BHAppDelegate       [UIApplication sharedApplication].delegate


//屏幕宽度、高度
#define BHScreenHeight      [[UIScreen mainScreen] bounds].size.height
#define BHScreenWidth       [[UIScreen mainScreen] bounds].size.width
#define SCREEN_HEIGHT       BHScreenHeight
#define SCREEN_WIDTH        BHScreenWidth

#define kMSScreenWidth      BHScreenWidth
#define kMSScreenHeight     BHScreenHeight

#define BHStatusBarHeight   [[UIApplication sharedApplication] statusBarFrame].size.height

#define BHLineHeight        1/[UIScreen mainScreen].scale

// 以 iPhone 6、7、8、X、XS 屏幕宽度为基准点，放大或缩小
#define SCREEN_SCALE_WIDTH(a) ((a) * SCREEN_WIDTH / 375.f)

// View 坐标(x,y)和宽高(width,height)
#define X(v)                    (v).frame.origin.x
#define Y(v)                    (v).frame.origin.y
#define WIDTH(v)                (v).frame.size.width
#define HEIGHT(v)               (v).frame.size.height
#define CENTER_X(v)             (v).center.x
#define CENTER_Y(v)             (v).center.y

#define MinX(v)                 CGRectGetMinX((v).frame)
#define MinY(v)                 CGRectGetMinY((v).frame)

#define MidX(v)                 CGRectGetMidX((v).frame)
#define MidY(v)                 CGRectGetMidY((v).frame)

#define MaxX(v)                 CGRectGetMaxX((v).frame)
#define MaxY(v)                 CGRectGetMaxY((v).frame)



#define W(height)    BHScreenWidth * (height) / BHScreenHeight
#define H(width)    BHScreenHeight * (width) / BHScreenWidth


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#pragma mark - iPhoneX 安全区域 -
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

#define kSafeAreaTop ((iPhoneXOrLater && isDevicePortrait) ? 44.f : 0.f)
#define kSafeAreaBottom ((iPhoneXOrLater && isDevicePortrait) ? 34.f : 0.f)
#define kSafeAreaLeft ((iPhoneXOrLater && isDeviceLandscape) ? 44.f : 0.f)
#define kSafeAreaRight ((iPhoneXOrLater && isDeviceLandscape) ? 44.f : 0.f)


//安全边距
#define BHSafeAreaInsets(view) ({ UIEdgeInsets i; if (@available(iOS 11.0, *)) { i = view.safeAreaInsets; } else { i = UIEdgeInsetsZero; } i; })

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#pragma mark - NSString -
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
//国际化字符串获取
#define NeuLocalizedString(key) NSLocalizedStringFromTable(key, @"Localization", nil)

#define FormatString(s, ...)    [NSString stringWithFormat:(s), ##__VA_ARGS__]
#define StringWithObject(mideaObject)  [NSString stringWithFormat:@"%@",mideaObject]

#define NONULLSTRING(str)    ((str == nil || [str isKindOfClass:[NSNull class]]) ? @"" : str)
#define NONULLOBJ(obj)       (([obj isKindOfClass:[NSNull class]]) ? nil : obj)
#define NONULLINTEGER(obj)   ((obj == nil || [obj isKindOfClass:[NSNull class]]) ? 0 : obj)

#define StringOf(str) (str==nil)?(@""):(str)
#define StringOfInt(i) [NSString stringWithFormat:@"%ld",(long)i]

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#pragma mark - Screen -
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

/*
 * 320 x 480 - iPhone 3GS(Max:iOS6)/4(Max:iOS7)/4S
 * 320 x 568(640x1136) - iPhone 5/5C/5S
 * 375 x 667(750x1334) - iPhone 6
 * 414 x 736(1242x2208) - iPhone 6+(3x)
 */

// 注意：以下宏定义都是基于竖屏条件的

#define IsRetinaDisplay   (([[UIScreen mainScreen] respondsToSelector:@selector(scale)] \
                           && [[UIScreen mainScreen] scale] == 2.0) ? YES : NO)

#define Is3_5InchDisplay  (([[UIScreen mainScreen] bounds].size.height == 480) ? YES : NO)

#define Is4_0InchDisplay  (([[UIScreen mainScreen] bounds].size.height == 568) ? YES : NO)

#define Is4_7InchDisplay  (([[UIScreen mainScreen] bounds].size.height == 667) ? YES : NO)

#define Is5_5InchDisplay  (([[UIScreen mainScreen] bounds].size.height == 736) ? YES : NO)

#define BHSYS_VERION [[[UIDevice currentDevice] systemVersion] floatValue]

#define IS_IOS6         (BHSYS_VERION < 7.0)
#define IS_IOS7         (BHSYS_VERION >= 7.0)
#define IS_IOS8         (BHSYS_VERION >= 8.0)
#define IS_IOS9         (BHSYS_VERION >= 9.0)
#define IS_PORTRAIT     UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation])
#define IS_IPHONE       (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)    //判断是否为iPhone
#define IS_PAD          (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)      //判断是否为iPad
#define IS_IPOD         ([[[UIDevice currentDevice] model] isEqualToString:@"iPod touch"])//判断是否为ipod


#define iPhone4 ((NSInteger)MAX_LENGTH([UIScreen mainScreen].bounds.size) < 568.0)
#define iPhone5 ((NSInteger)MAX_LENGTH([UIScreen mainScreen].bounds.size) == 568.0)
#define iPhone6 ((NSInteger)MAX_LENGTH([UIScreen mainScreen].bounds.size) == 667.0)
#define iPhone6Plus ((NSInteger)MAX_LENGTH([UIScreen mainScreen].bounds.size) == 736.0)
#define iPhoneXs ((NSInteger)MAX_LENGTH([UIScreen mainScreen].bounds.size) == 896.0)
#define iPhoneXR ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(828, 1792), [[UIScreen mainScreen] currentMode].size) && !IS_PAD : NO)
#define iPhoneXSMax ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2688), [[UIScreen mainScreen] currentMode].size) && !IS_PAD : NO)
#define iPhone12 ((NSInteger)MAX_LENGTH([UIScreen mainScreen].bounds.size) == 844.0 || \
(NSInteger)MAX_LENGTH([UIScreen mainScreen].bounds.size) == 926.0)


// 获取Size中的较大值
#define MAX_LENGTH(size) (size.width > size.height ? size.width : size.height)


// 判断当前设备是否是iPhoneX
#define iPhoneX ((NSInteger)MAX_LENGTH([UIScreen mainScreen].bounds.size) == 812)
#define iPhoneXOrLater (iPhoneX || iPhoneXs || iPhoneXR || iPhoneXSMax || iPhone12)
#define IS_IPHONEX [MideaTool isiPhoneXScreen]

#define isDevicePortrait ([UIApplication sharedApplication].statusBarOrientation==UIInterfaceOrientationPortrait || [UIApplication sharedApplication].statusBarOrientation==UIInterfaceOrientationPortraitUpsideDown)



#define BHNavBarHeight                (iPhoneXOrLater?88.0f:64.0f)
#define BHTabBarHeight                (iPhoneXOrLater?83.0f:49.0f)

//用来消除一些地方调用performSelector方法的警告
#define QFSuppressPerformSelectorLeakWarning(Stuff) \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Warc-performSelector-leaks\"") \
Stuff; \
_Pragma("clang diagnostic pop")

#define QFSuppressDeprecatedWarning(Stuff) \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Wdeprecated-declarations\"") \
Stuff; \
_Pragma("clang diagnostic pop")

//#pragma clang diagnostic ignored "-Wunused-variable" 未使用的变量
//#pragma clang diagnostic ignored "-Warc-retain-cycles" retain cycle
//#pragma clang diagnostic ignored "-Wdeprecated-declarations" 方法弃用警告
//#pragma clang diagnostic ignored "-Wincompatible-pointer-types" 不兼容的指针类型


/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#pragma mark - Other
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

#define GetObjectFromDicWithKey(dictonary, key , Class) [[dictonary objectForKey:key] isKindOfClass:[Class class]] ? [dictonary objectForKey:key] : nil


#define ReturnNilIfNotMatchType(object,Class) [object isKindOfClass:[Class class]]?object:nil

//计算数组大小
#define ARRAY_SIZE(x) (sizeof(x)/sizeof((x)[0]))


// 过期
#define BHDeprecated(instead) NS_DEPRECATED(2_0, 2_0, 2_0, 2_0, instead)

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#pragma mark - Language
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define isChineseLan [CURRENTLANGUAGE containsString:@"zh-"]

//当前语言
#define CURRENTLANGUAGE           ([[NSLocale preferredLanguages] objectAtIndexCheck:0])


#pragma mark - THREAD 线程相关操作

//--------------------------THREAD--------------------------
#define DISPATCH_ONCE_BLOCK(onceBlock) static dispatch_once_t onceToken; dispatch_once(&onceToken, onceBlock);

#define DISPATCH_ON_MAIN_THREAD(mainQueueBlock)                 dispatch_async(dispatch_get_main_queue(), mainQueueBlock);
#define DISPATCH_ON_GLOBAL_QUEUE_HIGH(globalQueueBlock)         dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), globalQueueBlock);
#define DISPATCH_ON_GLOBAL_QUEUE_DEFAULT(globalQueueBlock)      dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), globalQueueBlock);
#define DISPATCH_ON_GLOBAL_QUEUE_LOW(globalQueueBlock)          dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0), globalQueueBlock);
#define DISPATCH_ON_GLOBAL_QUEUE_BACKGROUND(globalQueueBlock)   dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), globalQueueBlock);
#define DISPATCH_AFTER_BLOCK(time, block)                       dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(time * NSEC_PER_SEC)), dispatch_get_main_queue(), block);

#define safeCallBlock(block, ...) if(block) {block(__VA_ARGS__);}

#define RUN_ON_MAIN_THREAD(mainQueueBlock) \
({ \
if ([NSThread isMainThread]) { \
mainQueueBlock(); \
} else { \
DISPATCH_ON_MAIN_THREAD(mainQueueBlock); \
} \
})

//用于判断是否是从右往左书写形式(阿拉伯语)
//UIUserInterfaceLayoutDirectionLeftToRight,
//UIUserInterfaceLayoutDirectionRightToLeft,
#define isRTL() [[[HGInternationalization sharedInstance] convertSystemLanguangeCodeToUnifyLanguangeCode:HGCurrentLanguage.code] hasPrefix:@"ar"]


void swizzleClassMethod(Class cls, SEL originalSelector, SEL swizzledSelector) {
    Method originalClassMethod = class_getClassMethod(cls, originalSelector);
    Method swizzledClassMethod = class_getClassMethod(cls, swizzledSelector);

    cls = object_getClass((id)cls);
    BOOL didAddMethod = class_addMethod(cls, originalSelector, method_getImplementation(swizzledClassMethod), method_getTypeEncoding(swizzledClassMethod));
    if (didAddMethod) {
        class_replaceMethod(cls, swizzledSelector, method_getImplementation(originalClassMethod), method_getTypeEncoding(originalClassMethod));
    } else {
        method_exchangeImplementations(originalClassMethod, swizzledClassMethod);
    }
}

void swizzleInstanceMethod(Class cls, SEL originalSelector, SEL swizzledSelector) {
    Method originalMethod = class_getInstanceMethod(cls, originalSelector);
    Method swizzledMethod = class_getInstanceMethod(cls, swizzledSelector);
    BOOL didAddMethod =
    class_addMethod(cls,
                    originalSelector,
                    method_getImplementation(swizzledMethod),
                    method_getTypeEncoding(swizzledMethod));
    if (didAddMethod) {
        class_replaceMethod(cls,
                            swizzledSelector,
                            method_getImplementation(originalMethod),
                            method_getTypeEncoding(originalMethod));
    } else {
        method_exchangeImplementations(originalMethod, swizzledMethod);
    }
}


//--------------------------THREAD--------------------------


#endif
