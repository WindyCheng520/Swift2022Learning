//
//  OEMGCDTimer.h
//  OEMFoundation
//
//  Created by syp on 2020/6/21.
//


#import <Foundation/Foundation.h>


@interface OEMGCDTimer : NSObject

+ (OEMGCDTimer *)scheduleTimer:(NSTimeInterval)anInterval
                  actionBlock:(void (^)(void))anActionBlock
                   willRepeat:(BOOL)willRepeat;

+ (OEMGCDTimer *)scheduleTimer:(NSTimeInterval)anInterval
                  actionBlock:(void (^)(void))anActionBlock
                   willRepeat:(BOOL)willRepeat
                dispatchQueue:(dispatch_queue_t)aDispatchQueue;

- (void)start:(NSTimeInterval)anInterval;

- (void)start;

- (void)stop;

- (void)suspend;

- (BOOL)isValid;

- (void)applicationDidEnterBackground;

#pragma mark - initialization

- (id)initWithInterval:(NSTimeInterval)anInterval
           actionBlock:(void (^)(void))anActionBlock
            willRepeat:(BOOL)willRepeat;

- (id)initWithInterval:(NSTimeInterval)anInterval
           actionBlock:(void (^)(void))anActionBlock
            willRepeat:(BOOL)willRepeat
         dispatchQueue:(dispatch_queue_t)aDispatchQueue;

@end
