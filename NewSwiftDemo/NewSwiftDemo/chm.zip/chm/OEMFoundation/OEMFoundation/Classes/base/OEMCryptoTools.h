//
//  OEMCryptoTools.h
//  OEMFoundation
//
//  Created by Neil 韦学宁 on 2022/4/11.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface OEMCryptoTools : NSObject

+ (NSData *)AES128ParmDecryptWithKey:(NSString *)key iv:(NSString *)iv data:(NSData *)data;

+ (NSString*)HMACMD5WithSecret:(NSString*)secret andString:(NSString *)str;

@end

NS_ASSUME_NONNULL_END
