//
//  OEMFoundationMacros.h
//  MFFoundation
//
//  Created by syp on 2020/6/18.
//


#pragma mark - Weak/Strong
#define WEAKIFY_OBJECT(__obj__) __weak __typeof(__obj__) weak##__obj__ = __obj__

#define WEAK_SELF __weak __typeof(self) weak_self = self
#define STRONG_SELF __strong __typeof(self) self = weak_self
#define STRONG_SELF_AND_CHECK                 \
    ;                                         \
    __strong __typeof(self) self = weak_self; \
    if (!self) {                              \
        return;                               \
    }

#pragma mark - System Version

#define SYSTEMVERSION_FLOAT     ([[[UIDevice currentDevice] systemVersion] floatValue])
#define SYSTEMVERSION_DOUBLE    ([[[UIDevice currentDevice] systemVersion] doubleValue])
#define SYSTEMVERSION_STRING    ([[UIDevice currentDevice] systemVersion])

#pragma mark - Notification

#define DECLARE_NOTIFICATION(__notification__) NSString *const __notification__ = @ #__notification__;
#define EXTERN_NOTIFICATION(__notification__) extern NSString *const __notification__;

#define POST_NOTIFY(__NAME__) [[NSNotificationCenter defaultCenter] postNotificationName:__NAME__ object:nil];
#define POST_NOTIFY_OBJECT(__NAME__, __OBJECT__) [[NSNotificationCenter defaultCenter] postNotificationName:__NAME__ object:__OBJECT__];

#define ADD_NOTIFY(__NAME__, __SELECTOR__) [[NSNotificationCenter defaultCenter] addObserver:self selector:__SELECTOR__ name:__NAME__ object:nil];
#define ADD_NOTIFY_OBJECT(__NAME__, __SELECTOR__, __OBJECT__) [[NSNotificationCenter defaultCenter] addObserver:self selector:__SELECTOR__ name:__NAME__ object:__OBJECT__];

#define ADD_NOTIFY_SelectorName(__NAME__) ADD_NOTIFY(__NAME__, @selector(on##__NAME__:))
#define ADD_NOTIFY_SelectorName_OBJECT(__NAME__, __OBJECT__) ADD_NOTIFY_OBJECT(__NAME__, @selector(on##__NAME__:), __OBJECT__)

#define Handler_NOTIFY_SelectorName(__NAME__) -(void)on##__NAME__ : (NSNotification *)notification

#define REMOVE_NOTIFY [[NSNotificationCenter defaultCenter] removeObserver:self];


#pragma mark - 检查 delegate
#define CHECK_DELEGATE(__SEL__)                                           \
    if (!_delegate || ![_delegate respondsToSelector:@selector(__SEL__)]) \
        return;
#define CHECK_DELEGATE_OBJ(__OBJ__, __SEL__)                              \
    if (!(__OBJ__) || ![(__OBJ__) respondsToSelector:@selector(__SEL__)]) \
    return
#define CHECK_DELEGATE_RET(__SEL__, __RET__)                              \
    if (!_delegate || ![_delegate respondsToSelector:@selector(__SEL__)]) \
        return __RET__;
#define CHECK_DELEGATE_RET_OBJ(__OBJ__, __SEL__, __RET__)                 \
    if (!(__OBJ__) || ![(__OBJ__) respondsToSelector:@selector(__SEL__)]) \
    return __RET__

#pragma mark - 单例

#define DECLARE_SIGNALTON +(instancetype)sharedObject;

#define IMPLEMENT_SIGNALTON(__TYPE__)             \
    +(instancetype)sharedObject                   \
    {                                             \
        static dispatch_once_t __once;            \
        static __TYPE__ *__instance = nil;        \
        dispatch_once(&__once, ^{                 \
            __instance = [[__TYPE__ alloc] init]; \
        });                                       \
        return __instance;                        \
    }


#pragma mark - Color

#define RGB(r,g,b)             RGBA(r,g,b,1.0)
#define RGBA(r,g,b,a)          [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)]

#define RGBA_HEX(rgbValue, alphaValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:alphaValue]
#define RGB_HEX(rgbValue) RGBA_HEX(rgbValue, 1.0)

#pragma mark - Degree

#define DEGREES_TO_RADIANS(angle) ((angle)/180.0 *M_PI)

#pragma mark - Font

#define BOLD_SYSTEM_FONT(FONTSIZE)  [UIFont boldSystemFontOfSize:FONTSIZE]
#define SYSTEM_FONT(FONTSIZE)       [UIFont systemFontOfSize:FONTSIZE]
#define FONT(NAME, FONTSIZE)        [UIFont fontWithName:(NAME) size:(FONTSIZE)]

#pragma mark - Frame
// Screen Scale
#define SCREEN_SCALE       [UIScreen mainScreen].scale
#define HG_SCREEN_HEIGHT      [[UIScreen mainScreen] bounds].size.height
#define HG_SCREEN_WIDTH       [[UIScreen mainScreen] bounds].size.width

#define STATUSBAR_HEIGHT   [[UIApplication sharedApplication] statusBarFrame].size.height
#define ONE_POINT          1.0/[UIScreen mainScreen].scale

// 以 iPhone 6、7、8、X、XS 屏幕宽度为基准点，放大或缩小
#define HG_SCREEN_SCALE_WIDTH(a) ((a) * HG_SCREEN_WIDTH / 375.f)
// 小于375的小屏幕屏幕宽度，按比例缩放UI尺寸
#define SCALE_SIZE_SMALL(SIZE) MIN(SIZE, HG_SCREEN_SCALE_WIDTH(SIZE))

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#pragma mark - iPhoneX 安全区域 -
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

#define kSafeAreaTop ((iPhoneXOrLater && isDevicePortrait) ? 44.f : 0.f)
#define kSafeAreaBottom ((iPhoneXOrLater && isDevicePortrait) ? 34.f : 0.f)
#define kSafeAreaLeft ((iPhoneXOrLater && isDeviceLandscape) ? 44.f : 0.f)
#define kSafeAreaRight ((iPhoneXOrLater && isDeviceLandscape) ? 44.f : 0.f)


//安全边距
#define BHSafeAreaInsets(view) ({ UIEdgeInsets i; if (@available(iOS 11.0, *)) { i = view.safeAreaInsets; } else { i = UIEdgeInsetsZero; } i; })


/*
 * 320 x 480 - iPhone 3GS(Max:iOS6)/4(Max:iOS7)/4S
 * 320 x 568(640x1136) - iPhone 5/5C/5S
 * 375 x 667(750x1334) - iPhone 6
 * 414 x 736(1242x2208) - iPhone 6+(3x)
 */

// 注意：以下宏定义都是基于竖屏条件的

#define IsRetinaDisplay   (([[UIScreen mainScreen] respondsToSelector:@selector(scale)] \
                           && [[UIScreen mainScreen] scale] == 2.0) ? YES : NO)

#define Is3_5InchDisplay  (([[UIScreen mainScreen] bounds].size.height == 480) ? YES : NO)

#define Is4_0InchDisplay  (([[UIScreen mainScreen] bounds].size.height == 568) ? YES : NO)

#define Is4_7InchDisplay  (([[UIScreen mainScreen] bounds].size.height == 667) ? YES : NO)

#define Is5_5InchDisplay  (([[UIScreen mainScreen] bounds].size.height == 736) ? YES : NO)

#define BHSYS_VERION [[[UIDevice currentDevice] systemVersion] floatValue]

#define IS_IOS6         (BHSYS_VERION < 7.0)
#define IS_IOS7         (BHSYS_VERION >= 7.0)
#define IS_IOS8         (BHSYS_VERION >= 8.0)
#define IS_IOS9         (BHSYS_VERION >= 9.0)
#define IS_PORTRAIT     UIInterfaceOrientationIsPortrait([[UIApplication sharedApplication] statusBarOrientation])
#define IS_IPHONE       (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)    //判断是否为iPhone
#define IS_PAD          (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)      //判断是否为iPad
#define IS_IPOD         ([[[UIDevice currentDevice] model] isEqualToString:@"iPod touch"])//判断是否为ipod


#define iPhone4 ((NSInteger)MAX_LENGTH([UIScreen mainScreen].bounds.size) < 568.0)
#define iPhone5 ((NSInteger)MAX_LENGTH([UIScreen mainScreen].bounds.size) == 568.0)
#define iPhone6 ((NSInteger)MAX_LENGTH([UIScreen mainScreen].bounds.size) == 667.0)
#define iPhone6Plus ((NSInteger)MAX_LENGTH([UIScreen mainScreen].bounds.size) == 736.0)
#define iPhoneXs ((NSInteger)MAX_LENGTH([UIScreen mainScreen].bounds.size) == 896.0)
#define iPhoneXR ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(828, 1792), [[UIScreen mainScreen] currentMode].size) && !IS_PAD : NO)
#define iPhoneXSMax ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2688), [[UIScreen mainScreen] currentMode].size) && !IS_PAD : NO)
#define iPhone12 ((NSInteger)MAX_LENGTH([UIScreen mainScreen].bounds.size) == 844.0 || (NSInteger)MAX_LENGTH([UIScreen mainScreen].bounds.size) == 926.0)

// 获取Size中的较大值
#define MAX_LENGTH(size) (size.width > size.height ? size.width : size.height)


// 判断当前设备是否是iPhoneX
#define iPhoneX ((NSInteger)MAX_LENGTH([UIScreen mainScreen].bounds.size) == 812)
#define iPhoneXOrLater (iPhoneX || iPhoneXs || iPhoneXR || iPhoneXSMax || iPhone12)


#define isDevicePortrait ([UIApplication sharedApplication].statusBarOrientation==UIInterfaceOrientationPortrait || [UIApplication sharedApplication].statusBarOrientation==UIInterfaceOrientationPortraitUpsideDown)



#define BHNavBarHeight                (iPhoneXOrLater?88.0f:64.0f)
#define BHTabBarHeight                (iPhoneXOrLater?83.0f:49.0f)

//用来消除一些地方调用performSelector方法的警告
#define QFSuppressPerformSelectorLeakWarning(Stuff) \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Warc-performSelector-leaks\"") \
Stuff; \
_Pragma("clang diagnostic pop")

#define QFSuppressDeprecatedWarning(Stuff) \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Wdeprecated-declarations\"") \
Stuff; \
_Pragma("clang diagnostic pop")



/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#pragma mark - Other
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

#define GetObjectFromDicWithKey(dictonary, key , Class) [[dictonary objectForKey:key] isKindOfClass:[Class class]] ? [dictonary objectForKey:key] : nil
#define ReturnNilIfNotMatchType(object,Class) [object isKindOfClass:[Class class]]?object:nil

//计算数组大小
#define ARRAY_SIZE(x) (sizeof(x)/sizeof((x)[0]))


// 过期
#define BHDeprecated(instead) NS_DEPRECATED(2_0, 2_0, 2_0, 2_0, instead)

/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#pragma mark - Language
/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
#define isChineseLan [CURRENTLANGUAGE containsString:@"zh-"]

//系统语言
#define SYSTEM_LANGUAGE   ([[NSLocale preferredLanguages] objectAtIndexCheck:0])


#pragma mark - THREAD 线程相关操作

//--------------------------THREAD--------------------------
#define DISPATCH_ONCE_BLOCK(onceBlock) static dispatch_once_t onceToken; dispatch_once(&onceToken, onceBlock);

#define DISPATCH_ON_MAIN_THREAD(mainQueueBlock)                 dispatch_async(dispatch_get_main_queue(), mainQueueBlock);
#define DISPATCH_ON_GLOBAL_QUEUE_HIGH(globalQueueBlock)         dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), globalQueueBlock);
#define DISPATCH_ON_GLOBAL_QUEUE_DEFAULT(globalQueueBlock)      dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), globalQueueBlock);
#define DISPATCH_ON_GLOBAL_QUEUE_LOW(globalQueueBlock)          dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_LOW, 0), globalQueueBlock);
#define DISPATCH_ON_GLOBAL_QUEUE_BACKGROUND(globalQueueBlock)   dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), globalQueueBlock);
#define DISPATCH_AFTER_BLOCK(time, block)                       dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(time * NSEC_PER_SEC)), dispatch_get_main_queue(), block);

#define safeCallBlock(block, ...) if(block) {block(__VA_ARGS__);}

#define RUN_ON_MAIN_THREAD(mainQueueBlock) \
({ \
if ([NSThread isMainThread]) { \
mainQueueBlock(); \
} else { \
DISPATCH_ON_MAIN_THREAD(mainQueueBlock); \
} \
})
