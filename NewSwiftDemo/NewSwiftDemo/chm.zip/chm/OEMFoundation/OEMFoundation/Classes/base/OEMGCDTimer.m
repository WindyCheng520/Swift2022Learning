//
//  OEMGCDTimer.m
//  OEMFoundation
//
//  Created by syp on 2020/6/21.
//


#import "OEMGCDTimer.h"
#import <UIKit/UIKit.h>

@interface OEMGCDTimer ()

@property (nonatomic, strong) dispatch_source_t dispatchTimer;
@property (nonatomic, assign) NSTimeInterval interval;
@property (nonatomic, assign) BOOL isSuspended;
@property (nonatomic, assign) BOOL willRepeat;

@end


@implementation OEMGCDTimer

+ (OEMGCDTimer *)scheduleTimer:(NSTimeInterval)anInterval
                  actionBlock:(void (^)(void))anActionBlock
                   willRepeat:(BOOL)willRepeat
{
    OEMGCDTimer *aHGGCDTimer = [[OEMGCDTimer alloc] initWithInterval:anInterval
                                                       actionBlock:anActionBlock
                                                        willRepeat:willRepeat];
    [aHGGCDTimer start];
    return aHGGCDTimer;
}

+ (OEMGCDTimer *)scheduleTimer:(NSTimeInterval)anInterval
                  actionBlock:(void (^)(void))anActionBlock
                   willRepeat:(BOOL)willRepeat
                dispatchQueue:(dispatch_queue_t)aDispatchQueue
{
    OEMGCDTimer *aHGGCDTimer = [[OEMGCDTimer alloc] initWithInterval:anInterval
                                                       actionBlock:anActionBlock
                                                        willRepeat:willRepeat
                                                     dispatchQueue:aDispatchQueue];
    [aHGGCDTimer start];
    return aHGGCDTimer;
}

- (void)start:(NSTimeInterval)anInterval
{
    if (NO == self.isValid || NO == self.isSuspended) {
        return;
    }

    self.interval = anInterval;

    [self start];
}

- (void)start
{
    if (NO == self.isValid || NO == self.isSuspended) {
        return;
    }

    self.isSuspended = NO;

    uint64_t anInterval = self.interval * NSEC_PER_SEC;

    dispatch_time_t aStartTime = dispatch_time(DISPATCH_TIME_NOW,
                                               anInterval);
    if (YES == self.willRepeat) {
        dispatch_source_set_timer(self.dispatchTimer,
                                  aStartTime, anInterval, 0);
    } else {
        dispatch_source_set_timer(self.dispatchTimer,
                                  aStartTime, DISPATCH_TIME_FOREVER, 0);
    }

    dispatch_resume(self.dispatchTimer);
}

- (void)stop
{
    if (YES == self.isValid) {
        dispatch_source_cancel(self.dispatchTimer);
    }
}

- (void)suspend
{
    if (YES == self.isValid && NO == self.isSuspended) {
        dispatch_suspend(self.dispatchTimer);
        self.isSuspended = YES;
    }
}

- (BOOL)isValid
{
    return (nil != self.dispatchTimer && 0 == dispatch_source_testcancel(self.dispatchTimer));
}

- (void)applicationDidEnterBackground {
    UIApplication*   app = [UIApplication sharedApplication];
    __block    UIBackgroundTaskIdentifier bgTask;
    bgTask = [app beginBackgroundTaskWithExpirationHandler:^{
        dispatch_async(dispatch_get_main_queue(), ^{
            if (bgTask != UIBackgroundTaskInvalid)
            {
                bgTask = UIBackgroundTaskInvalid;
            }
        });
    }];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            if (bgTask != UIBackgroundTaskInvalid)
            {
                bgTask = UIBackgroundTaskInvalid;
            }
        });
    });
}


#pragma mark - initialization

- (id)init
{
    if (self = [super init]) {
        _dispatchTimer = nil;
        _isSuspended = NO;
        _willRepeat = NO;
        _interval = 0;
    }
    return self;
}

- (id)initWithInterval:(NSTimeInterval)anInterval
           actionBlock:(void (^)(void))anActionBlock
            willRepeat:(BOOL)willRepeat
{
    return [self initWithInterval:anInterval
                      actionBlock:anActionBlock
                       willRepeat:willRepeat
                    dispatchQueue:dispatch_get_main_queue()];
}

- (id)initWithInterval:(NSTimeInterval)anInterval
           actionBlock:(void (^)(void))anActionBlock
            willRepeat:(BOOL)willRepeat
         dispatchQueue:(dispatch_queue_t)aDispatchQueue
{
    if (self = [super init]) {
        _dispatchTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER,
                                                0, 0, aDispatchQueue);

        dispatch_source_t aDispatchTimer = _dispatchTimer;
        dispatch_source_set_event_handler(aDispatchTimer, ^{
            if (NO == willRepeat) {
                dispatch_source_cancel(aDispatchTimer);
            }

            if (anActionBlock) {
                anActionBlock();
            };
        });

        _isSuspended = YES;
        _willRepeat = willRepeat;
        _interval = anInterval;
    }
    return self;
}

- (void)dealloc
{
    [self stop];
}

@end
