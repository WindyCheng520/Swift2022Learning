//
//  OEMWeakProxy.h
//  OEMFoundation
//
//  Created by syp on 2020/6/21.
//


#import <Foundation/Foundation.h>

// 用于避免强引用，如NSTimer,CADisplayLink,performselector:afterdelay,
//  eg: _timer = [NSTimer timerWithTimeInterval:3 target:[OEMWeakProxy proxyWithTarget:self] selector:@selector(test:) userInfo:nil repeats:NO];  ps:userInfo不要传self,否则也会被强引用


@interface OEMWeakProxy : NSObject

@property (nonatomic, weak, readonly) id target;

+ (instancetype)proxyWithTarget:(id)target;

@end
