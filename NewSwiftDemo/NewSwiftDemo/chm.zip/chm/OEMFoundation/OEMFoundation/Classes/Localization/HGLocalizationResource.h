//
//  HGLocalizationResource.h
//  MSBusiness
//
//  Created by syp on 2020/6/17.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface HGLocalizationResource : NSObject

+ (NSString *)localizedStringForKey:(NSString *)key table:(nullable NSString *)tableName inBundle:(NSBundle *)bundle;
+ (UIImage *)localizedImageForImageName:(NSString *)imageName inBundle:(NSBundle *)bundle;
+ (nullable UIImage *)imageWithName:(nullable NSString *)imageName bundleName:(nullable NSString *)bundleName;
@end

