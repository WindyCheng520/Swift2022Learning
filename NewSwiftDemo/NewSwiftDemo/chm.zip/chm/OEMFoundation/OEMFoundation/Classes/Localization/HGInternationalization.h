//
//  HGInternationalization.h
//  AFNetworking
//
//  Created by syp on 2020/6/10.
//

#import <Foundation/Foundation.h>


@class HGLanguage;
@class HGCountry;

FOUNDATION_EXTERN NSString *const MSInternationalizationDidUpdateLanguageNotification;
FOUNDATION_EXTERN NSString *const MSInternationalizationDidUpdateCountryNotification;

#define HGCurrentLanguage [HGInternationalization sharedInstance].currentLanguage
#define HGCurrentCountry [HGInternationalization sharedInstance].currentCountry


@interface HGInternationalization : NSObject

@property (nonatomic, readonly) NSArray<HGLanguage *> *allAvailableLanguages;
@property (nonatomic, strong) HGLanguage *currentLanguage;

@property (nonatomic, readonly) NSArray<HGCountry *> *allAvailableCountries;
@property (nonatomic, strong) HGCountry *currentCountry;

+ (instancetype)sharedInstance;
- (NSString *)convertSystemLanguangeCodeToUnifyLanguangeCode:(NSString *)code;
- (NSString *)convertUnifyLanguangeCodeToSystemLanguangeCode:(NSString *)code;

@end

@interface HGLanguage : NSObject

@property (nonatomic, copy) NSString *code;
@property (nonatomic, copy) NSString *name;//该语言书写的语言名称
@property (nonatomic, copy) NSString *localizedName;

@end

@interface HGCountry : NSObject

@property (nonatomic, copy) NSString *code;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *url;

@property (nonatomic, copy)NSString *phoneCode;  //国家电话码

@property (nonatomic, copy)NSString *mqttBroker;  //aws 节点



@end
