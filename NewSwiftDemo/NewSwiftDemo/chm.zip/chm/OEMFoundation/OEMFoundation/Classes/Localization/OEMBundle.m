//
//  MSBundle.m
//  OEMFoundation
//
//  Created by syp on 2020/6/21.
//

#import "OEMBundle.h"

@implementation OEMBundle
+ (NSBundle *)strBundle{
    return [NSBundle bundleForClass:[self class]];
}

+ (NSBundle *)currentBundle
{
    return [NSBundle bundleForClass:[self class]];
}

@end
