//
//  OEMFoundationBundle.m
//  OEMFoundation
//
//  Created by pactera on 2020/11/24.
//

#import "OEMFoundationBundle.h"

@implementation OEMFoundationBundle

+(NSBundle *)strBundle{
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *bundlePath = [bundle.resourcePath stringByAppendingPathComponent:@"MSBusiness.bundle"];
    return [NSBundle bundleWithPath:bundlePath];
}

+ (NSBundle *)currentBundle {
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *bundlePath = [bundle.resourcePath stringByAppendingPathComponent:@"OEMFoundation.bundle"];
    return [NSBundle bundleWithPath:bundlePath];
}

@end
