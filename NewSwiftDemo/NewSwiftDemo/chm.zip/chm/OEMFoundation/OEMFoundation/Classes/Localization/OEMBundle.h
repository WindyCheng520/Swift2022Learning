//
//  MSBundle.h
//  OEMFoundation
//
//  Created by syp on 2020/6/21.
//

#import <Foundation/Foundation.h>


@interface OEMBundle : NSBundle

+ (NSBundle *)currentBundle;
+ (NSBundle *)strBundle;

@end
