//
//  HGLocalizationResource.m
//  MSBusiness
//
//  Created by syp on 2020/6/17.
//

#import "HGLocalizationResource.h"
#import "HGInternationalization.h"
#import "OEMMacros.h"
#import "UIImage+OEMRTL.h"
//白名单，过滤不需要镜像的图片
static inline  NSSet * whiteList(){
    NSSet * set = [[NSSet alloc] initWithObjects:@"ic_country_selected",@"iotap_ssid_rtl",@"net_ssid_rtl",@"iotap_net_rtl",@"ic_checkbox_s",@"ic_n_hook", nil];
    return set;
}

@implementation HGLocalizationResource

+ (NSString *)localizedStringForKey:(NSString *)key table:(nullable NSString *)tableName inBundle:(NSBundle *)bundle
{
    NSLog(@"HGCurrentLanguage.code==%@",HGCurrentLanguage.code);
    NSString *path = [bundle pathForResource:HGCurrentLanguage.code ofType:@"lproj"];
    NSBundle *localizedLanguageBundle = [NSBundle bundleWithPath:path];
    NSString *localizedString;
    localizedString = [localizedLanguageBundle localizedStringForKey:key value:nil table:tableName];
    return localizedString?:@"";
}

+ (UIImage *)localizedImageForImageName:(NSString *)imageName inBundle:(NSBundle *)bundle
{
    NSSet * set = whiteList();
    if (isRTL() && ![set containsObject:imageName]) {
        return [[UIImage imageNamed:imageName inBundle:bundle compatibleWithTraitCollection:nil] oem_imageFlippedForRightToLeftLayoutDirection];
    }
    return [UIImage imageNamed:imageName inBundle:bundle compatibleWithTraitCollection:nil];
    
}

+ (nullable UIImage *)imageWithName:(nullable NSString *)imageName bundleName:(nullable NSString *)bundleName{
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *bundlePath = [bundle.resourcePath stringByAppendingPathComponent:bundleName];
    NSBundle * b = [NSBundle bundleWithPath:bundlePath];
    if (!b) {
        return nil;
    }
    return [self localizedImageForImageName:imageName inBundle:b];
}

@end
