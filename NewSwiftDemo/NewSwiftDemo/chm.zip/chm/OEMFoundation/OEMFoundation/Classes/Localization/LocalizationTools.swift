//
//  LocalizationTools.swift
//  MSBusiness
//
//  Created by Neil 韦学宁 on 2022/2/11.
//

import Foundation

public extension Bundle{
    class func getBundleInMain(name: String) -> Bundle?{
        guard let path = Bundle.main.resourcePath?.appending("/\(name)"), let bundle = Bundle(path: path) else{
            return nil
        }
        return bundle
    }
}

//extension String{
//    public static func OFLocalizeString(key: String, tableName: String?, bundleName: String = "Business.bundle") -> String{
//        guard let bundle = Bundle.getBundleInMain(name: bundleName) else{
//            return ""
//        }
//        let language = HGInternationalization.sharedInstance().currentLanguage.code
//        let lprojPath = bundle.path(forResource: language, ofType: "lproj")
//        guard let p = lprojPath,
//              let lprojBundle = Bundle(path: p) else{
//            return ""
//        }
//        return lprojBundle.localizedString(forKey: key, value: nil, table: tableName)
//    }
//}
