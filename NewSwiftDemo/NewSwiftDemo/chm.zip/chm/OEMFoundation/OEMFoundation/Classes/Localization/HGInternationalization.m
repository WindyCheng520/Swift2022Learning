//
//  HGInternationalization.m
//  AFNetworking
//
//  Created by syp on 2020/6/10.
//

#import "HGInternationalization.h"
#import "OEMFoundationBundle.h"

NSString * const MSInternationalizationDidUpdateLanguageNotification = @"MSInternationalizationDidUpdateLanguageNotification";
NSString * const MSInternationalizationDidUpdateCountryNotification = @"MSInternationalizationDidUpdateCountryNotification";


@interface HGLanguage ()

//@property (nonatomic, strong) NSString *code;
//@property (nonatomic, strong) NSString *name;//该语言书写的语言名称
//@property (nonatomic, strong) NSString *localizedName;

@end

@interface HGCountry ()

//@property (nonatomic, strong) NSString *code;
//@property (nonatomic, strong) NSString *name;

@end

@interface HGInternationalization ()
{
    HGLanguage *_currentLanguage;
    HGCountry *_currentCountry;
}

@property (nonatomic, strong) NSDictionary<NSString *, HGLanguage *> *availableLanguages;

@property (nonatomic, strong) NSDictionary<NSString *,HGCountry *> *availableCountries;

@end

@implementation HGInternationalization

static NSString *const MSLocalizationCurrentLanguageKey = @"MSLocalizationCurrentLanguageKey";
static NSString *const MSLocalizationCurrentCountryKey = @"MSLocalizationCurrentCountryKey";

+ (instancetype)sharedInstance {
    static id instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
    }
    return self;
}

- (NSDictionary<NSString *, HGLanguage *> *)availableLanguages {
    if (!_availableLanguages) {
        NSString *plistPath = [MSCurrentBundle pathForResource:@"HGLanguages" ofType:@"plist"];
        NSArray *plistArray = [NSArray arrayWithContentsOfFile:plistPath];
        NSMutableDictionary<NSString *, HGLanguage *> *languages = [NSMutableDictionary new];
        for (NSDictionary *dict in plistArray) {
            HGLanguage *language = [HGLanguage new];
            NSString * code = [dict objectForKey:@"code"];
            NSString * name = [dict objectForKey:@"name"];
            NSString * localizedName = [dict objectForKey:@"localizedName"];
            if ([code isKindOfClass:[NSString class]]) {
                language.code = code;
            }
            if ([name isKindOfClass:[NSString class]]) {
                language.name = name;
            }
            if ([localizedName isKindOfClass:[NSString class]]) {
                language.localizedName = localizedName;
            }
            [languages setValue:language forKey:language.code ?: @""];
        }
        _availableLanguages = [languages copy];
    }
    return _availableLanguages;    
}

- (NSDictionary<NSString *,HGCountry *> *)availableCountries {
    if (!_availableCountries) {
        NSString *plistPath = [MSCurrentBundle pathForResource:@"HGCountries" ofType:@"plist"];
        NSDictionary *plistDict = [NSDictionary dictionaryWithContentsOfFile:plistPath];
        NSDictionary *langDict = plistDict[self.currentLanguage.code];
        
        NSString *countryCodesString = langDict[@"CountryCodes"];
        NSString *countryNamesString = langDict[@"CountryNames"];
        
        NSArray *countryCodes = [countryCodesString componentsSeparatedByString:@"_&_"];
        NSArray *countryNames = [countryNamesString componentsSeparatedByString:@"_&_"];
        
        NSMutableDictionary<NSString *,HGCountry *> *countries = nil;
        if (countryCodes.count == countryNames.count) {
            countries = [NSMutableDictionary new];
            for (int i = 0; i < countryCodes.count; ++i) {
                HGCountry *country = [HGCountry new];
                country.code = [countryCodes objectAtIndex:i];
                country.name = [countryNames objectAtIndex:i];
                
                [countries setValue:country forKey:country.code];
            }
        }
        _availableCountries = [countries copy];
    }
    return _availableCountries;
}

- (NSArray<HGLanguage *> *)allAvailableLanguages {
    return [self.availableLanguages allValues];
}

- (NSArray<HGCountry *> *)allAvailableCountries {
    return [self.availableCountries allValues];
}

- (HGLanguage *)currentLanguage {
    if (!_currentLanguage) {
        NSString *languageCode = [[NSUserDefaults standardUserDefaults] valueForKey:MSLocalizationCurrentLanguageKey];
        if (languageCode.length > 0) {
            _currentLanguage = [self.availableLanguages objectForKey:languageCode];
        }
        
        if (!_currentLanguage) {
            languageCode = [self getCurrentSystemLanguange]; //系统语言
            _currentLanguage = [self.availableLanguages objectForKey:languageCode];

            if (!_currentLanguage) {
                _currentLanguage = [self.availableLanguages objectForKey:@"en"];//默认用英语
                if (!_currentLanguage) {
                    _currentLanguage = self.allAvailableLanguages.firstObject;
                }
            }
        }
    }
    return _currentLanguage;
}

- (void)setCurrentLanguage:(HGLanguage *)currentLanguage {
    if ([_currentLanguage.code isEqualToString:currentLanguage.code]) {
        return;
    }
    
    _currentLanguage = currentLanguage;
    _availableCountries = nil;
    [[NSUserDefaults standardUserDefaults] setValue:currentLanguage.code forKey:MSLocalizationCurrentLanguageKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:MSInternationalizationDidUpdateLanguageNotification object:nil];
}

//#warning --------------------------暂时注释
- (HGCountry *)currentCountry {
    if (!_currentCountry) {
        NSDictionary* countryDic = [[NSUserDefaults standardUserDefaults] valueForKey:MSLocalizationCurrentCountryKey];
        if (countryDic && [countryDic isKindOfClass:[NSDictionary class]]) {
            _currentCountry = [HGCountry new];
            _currentCountry.code = countryDic[@"code"];
            _currentCountry.name = countryDic[@"name"];
            _currentCountry.url = countryDic[@"url"];
            _currentCountry.phoneCode = countryDic[@"phoneCode"];
            _currentCountry.mqttBroker = countryDic[@"mqttBroker"];
        }
    }
    return _currentCountry;
}
#warning --------------------------暂时注释

#warning --------------------------默认美国------------
//- (HGCountry *)currentCountry {
//    if (!_currentCountry) {
//        _currentCountry = [HGCountry new];
//        _currentCountry.code = @"US";
//        _currentCountry.name = @"美国";
//    }
//    return _currentCountry;
//}
#warning --------------------------默认美国------------

- (void)setCurrentCountry:(HGCountry *)currentCountry {
//    if ([_currentCountry.code isEqualToString:currentCountry.code] && [_currentCountry.name isEqualToString:currentCountry.name]) {
//        return;
//    }
    
    _currentCountry = currentCountry;
    [[NSUserDefaults standardUserDefaults] setValue:@{@"code":currentCountry.code?:@"", @"name":currentCountry.name?:@"", @"url":currentCountry.url?:@"", @"phoneCode":currentCountry.phoneCode?:@"", @"mqttBroker":currentCountry.mqttBroker?:@""} forKey:MSLocalizationCurrentCountryKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:MSInternationalizationDidUpdateCountryNotification object:nil];
}

- (NSString *)getCurrentSystemLanguange {
    // 返回的也是国际通用语言Code+国际通用国家地区代码
    NSArray *languagesArray = [NSLocale preferredLanguages];
    NSString *languageCode = [languagesArray firstObject];
    NSString *countryCode = [NSString stringWithFormat:@"-%@", [[NSLocale currentLocale] objectForKey:NSLocaleCountryCode]];
    if (languageCode) {
        languageCode = [languageCode stringByReplacingOccurrencesOfString:countryCode withString:@""];
    }
    if ([languageCode isEqualToString:@"zh-Hans"]) {
        languageCode = @"zh-Hans-CN";
    } else if ([languageCode isEqualToString:@"zh-Hant"]) {
        languageCode = @"zh-Hant-HK";
    } else if ([languageCode isEqualToString:@"pt"]) {
        languageCode = @"pt-PT";
    }
    return languageCode;
}

//把各端统一的语言code转换成APP内使用的code
- (NSString *)convertUnifyLanguangeCodeToSystemLanguangeCode:(NSString *)code {
    if ([code isEqualToString:@"en_US"]) {
        code = @"en";
    } else if ([code isEqualToString:@"zh_CN"]) {
        code = @"zh-Hans-CN";
    } else if ([code isEqualToString:@"vi_VN"]) {
        code = @"vi";
    } else if ([code isEqualToString:@"zh_HK"]) {
        code = @"zh-Hant-HK";
    } else if ([code isEqualToString:@"pt"]) {
        code = @"pt-PT";
    } else if ([code isEqualToString:@"fr"]) {
        code = @"fr";
    } else if ([code isEqualToString:@"es"]) {
        code = @"es";
    } else if ([code isEqualToString:@"th"]) {
        code = @"th";
    } else if ([code isEqualToString:@"nl"]) {
        code = @"nl";
    }else if ([code isEqualToString:@"ar_SA"]) {
        code = @"ar";
    }else if ([code isEqualToString:@"ru"] || [code isEqualToString:@"ru_RU"]) {
        code = @"ru";
    } else {
        code = @"en";
    }
    return code;
}

//把APP内使用的code转换成各端统一的语言code
- (NSString *)convertSystemLanguangeCodeToUnifyLanguangeCode:(NSString *)code {
    if ([code isEqualToString:@"en"]) {
        code = @"en_US";
    } else if ([code isEqualToString:@"zh-Hans-CN"]) {
        code = @"zh_CN";
    } else if ([code isEqualToString:@"vi"]) {
        code = @"vi_VN";
    } else if ([code isEqualToString:@"zh-Hant-HK"]) {
        code = @"zh_HK";
    } else if ([code isEqualToString:@"pt-PT"]) {
        code = @"pt";
    } else if ([code isEqualToString:@"fr"]) {
        code = @"fr";
    } else if ([code isEqualToString:@"es"]) {
        code = @"es";
    } else if ([code isEqualToString:@"th"]) {
        code = @"th";
    } else if ([code isEqualToString:@"nl"]) {
        code = @"nl";
    } else if ([code isEqualToString:@"ru"] || [code isEqualToString:@"ru_RU"] ) {
        code = @"ru_RU";
    }else if ([code isEqualToString:@"ar"] || [code isEqualToString:@"ar_SA"]){
        code = @"ar_SA";
    }else {
        code = @"en_US";
    }
    return code;
}

//- (HGCountry *)currentCountry
//{
//    if (!_currentCountry) {
//        NSString *countryCode = [[NSUserDefaults standardUserDefaults] valueForKey:MSLocalizationCurrentCountryKey];
//        if (countryCode.length > 0) {
//            _currentCountry = [self.availableCountries objectForKey:countryCode];
//        }
//        if (!_currentCountry) {
//            countryCode = [[NSLocale currentLocale] objectForKey:NSLocaleCountryCode];//系统国家
//            if ([countryCode isKindOfClass:[NSString class]]
//                && countryCode.length > 0) {
//                _currentCountry = [self.availableCountries objectForKey:countryCode];
//            }
//            if (!_currentCountry) {
//                _currentCountry = self.allAvailableCountries.firstObject;
//            }
//        }
//    }
//    return _currentCountry;
//}

//- (void)setCurrentCountry:(HGCountry *)currentCountry
//{
//    if ([_currentCountry.code isEqualToString:currentCountry.code]) {
//        return;
//    }
//
//    _currentCountry = currentCountry;
//    [[NSUserDefaults standardUserDefaults] setValue:currentCountry.code forKey:MSLocalizationCurrentCountryKey];
//    [[NSUserDefaults standardUserDefaults] synchronize];
//
//    [[NSNotificationCenter defaultCenter] postNotificationName:MSInternationalizationDidUpdateCountryNotification object:nil];
//}

@end

@implementation HGLanguage

@end

@implementation HGCountry

@end
