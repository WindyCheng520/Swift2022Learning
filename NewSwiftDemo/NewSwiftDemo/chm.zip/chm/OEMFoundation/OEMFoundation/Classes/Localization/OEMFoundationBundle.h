//
//  OEMFoundationBundle.h
//  OEMFoundation
//
//  Created by pactera on 2020/11/24.
//

#import <OEMFoundation/OEMBundle.h>
#import <OEMFoundation/HGLocalizationResource.h>

#define MSCurrentBundle [OEMFoundationBundle currentBundle]
#define OEMStringBundle [OEMFoundationBundle strBundle]

#define MSResourceString(key) [HGLocalizationResource localizedStringForKey:key table:nil inBundle:OEMStringBundle]
#define MSResourceImage(imageName) [HGLocalizationResource localizedImageForImageName:imageName inBundle:MSCurrentBundle]


@interface OEMFoundationBundle : OEMBundle

@end

