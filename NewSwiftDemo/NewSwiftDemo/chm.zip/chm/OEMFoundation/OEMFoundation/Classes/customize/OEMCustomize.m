//
//  OEMCustomize.m
//  AvoidCrash
//
//  Created by Neil 韦学宁 on 2022/3/23.
//

#import "OEMCustomize.h"
#import "NSString+OEMCategory.h"
#import "OEMCryptoTools.h"

#define OEMCustomizeShared [OEMCustomize sharedInstance]

@interface OEMCustomize()

@property(nonatomic, strong)NSDictionary * configuration;

//新增一个缓存，保存加密数据
@property(nonatomic, strong)NSMutableDictionary * cachedEncrypted;

@end

@implementation OEMCustomize

+ (instancetype)sharedInstance{
    static OEMCustomize * instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[OEMCustomize alloc] init];
    });
    return instance;
}

+ (nullable UIImage *)customizableImage:(NSString *)key{
    return OEMCustomizableImage(key);
}

+ (nullable NSDictionary *)getCustomizeConfig:(BOOL)refreshFromFile{
    if (!refreshFromFile && OEMCustomizeShared.configuration) {
        return OEMCustomizeShared.configuration;
    }
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *bundlePath = [bundle.resourcePath stringByAppendingPathComponent:OEMCustomizeBundleName];
    NSBundle * b = [NSBundle bundleWithPath:bundlePath];
    NSString *path = [b pathForResource:OEMCustomizeBundleConfigureName ofType:@"json"];
    if (!path) {
        return nil;
    }
    NSData * data = [NSData dataWithContentsOfFile:path];
    if (!data) {
        return nil;
    }
    NSError * jsonError = nil;
    NSDictionary * result = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
    OEMCustomizeShared.configuration = result;
    return result;
}

+ (BOOL)getBoolValueWithKey:(NSString *)key{
    NSDictionary * raw = [self getCustomizeConfig:NO];
    id obj = [raw objectForKey:key];
    if ([obj isKindOfClass:[NSNumber class]]) {
        return [(NSNumber *)obj boolValue];
    }
    if ([obj isKindOfClass:[NSString class]]) {
        NSString * str = (NSString *)obj;
        return  ([str isEqualToString:@"1"] ||
                 [str isEqualToString:@"true"] ||
                 [str isEqualToString:@"True"] ||
                 [str isEqualToString:@"YES"]);
    }
    return NO;
}

+ (NSUInteger)getUIntValueWithKey:(NSString *)key{
    NSDictionary * raw = [self getCustomizeConfig:NO];
    id obj = [raw objectForKey:key];
    if ([obj isKindOfClass:[NSNumber class]]) {
        return [(NSNumber *)obj intValue];
    }
    return 0;
}

+ (NSString *)getStringValueWithKey:(NSString *)key{
    NSDictionary * raw = [self getCustomizeConfig:NO];
    NSString * v = [raw objectForKey:key];
    return v;
}

+ (nullable NSString *)getEncryptedStringValueWithKey:(NSString *)key{
    if (key.length == 0) {
        NSAssert(NO, @"error app configuration");
        return nil;
    }
    if (!OEMCustomizeShared.cachedEncrypted) {
        OEMCustomizeShared.cachedEncrypted = [NSMutableDictionary new];
    }
    NSString * cached = [OEMCustomizeShared.cachedEncrypted objectForKey:key];
    if (cached && cached.length > 0) {
        return cached;
    }
    NSString * appid = [self getStringValueWithKey:@"appId"];
    NSString * fullkey = [OEMCryptoTools HMACMD5WithSecret:@"mideaoemcus" andString:appid];
    NSString * rawS = [self getStringValueWithKey:key];
    if (!rawS || ![rawS isKindOfClass:[NSString class]]) {
        return nil;
    }
    NSData * rawData = [[NSData alloc] initWithBase64EncodedString:rawS options:0];
    if (fullkey.length == 0) {
        return nil;
    }
    NSString * enckey = [fullkey substringWithRange:NSMakeRange(0, 16)];
    NSString * iv = [fullkey substringWithRange:NSMakeRange(16, 16)];
    if (!rawData || rawData.length == 0) {
        return nil;
    }
    NSData * data = [OEMCryptoTools AES128ParmDecryptWithKey:enckey iv:iv data:rawData];
    NSString * output = nil;
    if (data) {
        output = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    }
    if (output && [output length] > 0) {
        [OEMCustomizeShared.cachedEncrypted setObject:output forKey:key];
        return output;
    }
    return nil;
}

@end
