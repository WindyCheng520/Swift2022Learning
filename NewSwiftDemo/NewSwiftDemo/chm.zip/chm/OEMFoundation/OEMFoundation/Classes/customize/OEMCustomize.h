//
//  OEMCustomize.h
//  AvoidCrash
//
//  Created by Neil 韦学宁 on 2022/3/23.
//

#import <Foundation/Foundation.h>
#import <OEMFoundation/HGLocalizationResource.h>

#define OEMCustomizeBundleName @"oemcustomize.bundle"

#define OEMCustomizeBundleConfigureName @"oemcustomize"

#define OEMCustomizableImage(imageName) [HGLocalizationResource imageWithName:imageName bundleName:OEMCustomizeBundleName]

NS_ASSUME_NONNULL_BEGIN

@interface OEMCustomize : NSObject

+ (BOOL)getBoolValueWithKey:(NSString *)key;

+ (NSUInteger)getUIntValueWithKey:(NSString *)key;

+ (nullable NSString *)getStringValueWithKey:(NSString *)key;

+ (nullable UIImage *)customizableImage:(NSString *)key;

+ (nullable NSString *)getEncryptedStringValueWithKey:(NSString *)key;

@end

NS_ASSUME_NONNULL_END
