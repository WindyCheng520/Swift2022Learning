//
//  SceneDelegate.h
//  OEMFoudationNetworkExample
//
//  Created by Neil 韦学宁 on 2022/3/9.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

