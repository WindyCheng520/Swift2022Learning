workspace_name="OEMFoundation"
scheme_name='OEMFoundation'
framework_name='OEMFoundation'
build_dir="build"
output_DIR="build_output"
device___="Release-iphoneos"
simulator="Release-simulator"

if [[ ! -f 'build.sh' ]]; then
	echo "❌ error exe path"
	exit 1
fi

if [[ -d $build_dir ]]; then
  rm -rf $build_dir
fi


#https://www.userdesk.io/blog/how-to-build-a-binary-framework-in-xcode-11/

# xcodebuild clean;

xcodebuild archive \
  -project $workspace_name.xcodeproj \
  -scheme $scheme_name \
  -sdk iphoneos \
  -configuration "Release" \
  SKIP_INSTALL=NO \
  clean build ARCHS="arm64" \
  BUILD_DIR="./$build_dir"
  BUILD_LIBRARY_FOR_DISTRIBUTION=YES


xcodebuild archive \
  -project $workspace_name.xcodeproj \
  -scheme $scheme_name \
  -sdk iphonesimulator \
  -configuration "Release" \
  SKIP_INSTALL=NO \
  clean build ARCHS="x86_64" \
  BUILD_DIR="./$build_dir"
  BUILD_LIBRARY_FOR_DISTRIBUTION=YES
          

lipo -create \
${build_dir}/Release-iphoneos/${framework_name}.framework/${framework_name} \
${build_dir}/Release-iphonesimulator/${framework_name}.framework/${framework_name} \
-o ${build_dir}/Release-iphoneos/${framework_name}.framework/merge
mv ${build_dir}/Release-iphoneos/${framework_name}.framework/merge ${build_dir}/Release-iphoneos/${framework_name}.framework/${framework_name}
mv -f ${build_dir}/Release-iphonesimulator/${framework_name}.framework/Modules/${framework_name}.swiftmodule/* ${build_dir}/Release-iphoneos/${framework_name}.framework/Modules/${framework_name}.swiftmodule/

rm -rf ${framework_name}.framework
sleep 0.5
cp -R ${build_dir}/Release-iphoneos/${framework_name}.framework ./
