## Requirements

## Installation

OEMFoundation is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'OEMFoundation'
```