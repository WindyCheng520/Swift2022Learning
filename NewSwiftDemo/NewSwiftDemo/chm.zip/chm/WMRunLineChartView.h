//
//  WMRunLineChartView.h
//  Weima
//
//  Created by William Yin on 2018/9/1.
//  Copyright © 2018年 微马科技控股有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WMRunLineChartView : UIView

@property(nonatomic, assign)CGFloat yMaxValue;       //Y轴最大值
@property(nonatomic, assign)NSUInteger yLabelCount;  //Y轴刻度，几段区间
@property(nonatomic, strong)NSArray *xArray;         //x轴数据源


@property(nonatomic, assign)CGFloat xMaxValue;      //X轴最大值
@property(nonatomic, assign)NSUInteger xMaxVisibleCount;   //X轴设置能够显示的数据数量条数
@property(nonatomic, strong)NSArray *yArray;     //y轴数据源


@property(nonatomic, strong)NSArray *commonArray;     //整体数据源

@property (assign, nonatomic)WMChartsType type;

@end
