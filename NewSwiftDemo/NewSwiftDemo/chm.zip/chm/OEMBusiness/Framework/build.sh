workspace_name="MSBusiness"
scheme_name='MSBusiness'
framework_name='MSBusiness'
build_dir="build"
output_DIR="build_output"
deviceeee="Release-iphoneos"
simulator="Release-simulator"

if [[ ! -f 'build.sh' ]]; then
	echo "❌ error exe path"
	exit 1
fi

if [[ -d $build_dir ]]; then
  rm -rf $build_dir
fi


#https://www.userdesk.io/blog/how-to-build-a-binary-framework-in-xcode-11/

xcodebuild clean;

xcodebuild archive \
  -workspace $workspace_name.xcworkspace \
  -scheme $scheme_name \
  -destination "generic/platform=iOS" \
  -archivePath "$build_dir/$deviceeee" \
  -configuration "Release" \
  SKIP_INSTALL=NO \
  BUILD_LIBRARY_FOR_DISTRIBUTION=YES


            #-destination "generic/platform=iOS Simulator" \

              # xcodebuild clean;
              
              # xcodebuild archive \
              #   -workspace $workspace_name.xcworkspace \
              #   -scheme $scheme_name \
              #   -destination generic/platform=iOS \
              #   -archivePath "$build_dir/$simulator" \
              #   -configuration "Release" \
              #   SKIP_INSTALL=NO \
              #   BUILD_LIBRARY_FOR_DISTRIBUTION=YES              

deviceeeebinaryPath=${build_dir}/$deviceeee.xcarchive/Products/Library/Frameworks/${framework_name}.framework/${framework_name}


echo "😄arch info"
lipo -info $deviceeeebinaryPath

if [[ -d ${build_dir}/${framework_name}.framework ]]; then
  rm -rf ${build_dir}/${framework_name}.framework
fi
mv ${build_dir}/$deviceeee.xcarchive/Products/Library/Frameworks/${framework_name}.framework ${build_dir}/${framework_name}.framework
