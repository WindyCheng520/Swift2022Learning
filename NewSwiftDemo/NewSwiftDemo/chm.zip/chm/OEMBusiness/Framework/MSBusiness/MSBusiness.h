//
//  MSBusiness.h
//  MSBusiness
//
//  Created by Neil 韦学宁 on 2022/3/10.
//

#import <Foundation/Foundation.h>

//! Project version number for MSBusiness.
FOUNDATION_EXPORT double MSBusinessVersionNumber;

//! Project version string for MSBusiness.
FOUNDATION_EXPORT const unsigned char MSBusinessVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MSBusiness/PublicHeader.h>


