//
//  MSAppInfo.m
//  MSBusiness
//
//  Created by syp on 2020/6/28.
//

#import "MSAppInfo.h"
#import "MideaTool.h"
#import <OEMFoundation/HGInternationalization.h>
#import <OEMFoundation/NSDate+OEMExtension.h>
#import "MideaSectionCipheTool.h"
#import "MSUserDefaultTools.h"
#import <MSBusiness/MSBusiness-Swift.h>
#import "OEMBaseSDK.h"
#import <OEMFoundation/OEMCustomize.h>

#define MSLogin_Client_Type_IOS @"2"
#define TIME_STAMP [[NSDate date] stringWithFormat:@"yyyyMMddHHmmss"]
#define Bundle_MSOEM_AppStore @"com.midea.oem.iot"
#define Bundle_MSOEM_InHouse @"com.midea.iot.oem"

#define BaseUrl [HGInternationalization sharedInstance].currentCountry.url

#define DefaultUrl @"us.dollin.net"

#define OEMURLPrefixConcatenate(prefix) [NSString stringWithFormat:@"https://%@%@", prefix, BaseUrl.length > 0? BaseUrl :DefaultUrl]

//私有声明
@interface OEMBaseSDK()

@property (nonatomic, strong)OEMSDKConfig * defaultConfig;

+ (instancetype)sharedInstance;

@end

#define SDKDefaultConfig [OEMBaseSDK sharedInstance].defaultConfig

@implementation MSAppInfo

//项目环境
+ (MSAppEnvironmentType)environmentType {
    #if AppStore_ENV==0
        return MSAppEnvironmentTypeDev;
    #elif AppStore_ENV==1
        return MSAppEnvironmentTypePro;
    #endif
}

// @"http://ec2-35-84-72-146.us-west-2.compute.amazonaws.com";  //实际地址
// @"https://dev-us.aiotelink.com";   网关地址
+ (NSString *)mucBaseUrl {
    if (SDKDefaultConfig.domain.length > 0) {
        return SDKDefaultConfig.domain;
    }
    
#if AppStore_ENV==0
    MSUrlEnvironmentType type = [MSUserDefaultTools getUrlEnvironmentType];
    switch (type) {
        case MSUrlEnvironmentTypeSit:
            return OEMURLPrefixConcatenate(@"sit-");
            break;
        case MSUrlEnvironmentTypeDev:
            return OEMURLPrefixConcatenate(@"dev-");
            break;
        case  MSUrlEnvironmentTypeUat:
            return OEMURLPrefixConcatenate(@"uat-");
            break;
        case MSUrlEnvironmentTypeProd:
            return OEMURLPrefixConcatenate(@"");
            break;
        default:
            return OEMURLPrefixConcatenate(@"sit-");
            break;
    }
#else
    if ([self isUAT]) {
        return OEMURLPrefixConcatenate(@"uat-");
    }
    //如果生产环境包覆盖安装测试包，确保直接返回生产环境URL
    return OEMURLPrefixConcatenate(@"");
#endif
}

+ (NSString *)mucProductionBaseUrl{
    return OEMURLPrefixConcatenate(@"");
}

//中台，请求头，数据签名时使用
+ (NSString *)mucSignSecret {
    if (SDKDefaultConfig.mucSignSecret > 0) {
        return SDKDefaultConfig.mucSignSecret;
    }
    return @"meicloud";
}

/// AppKey秘钥存储安全  中台，请求头数据签名使用
+ (NSString *)getMasKey {
    
    if (SDKDefaultConfig.maskey.length > 0) {
        return SDKDefaultConfig.maskey;
    }
    NSString *decodedMasKey = nil;
#if AppStore_ENV==0
    //SIT_4VjZdg19laDoIrut
    decodedMasKey = [OEMCustomize getEncryptedStringValueWithKey:@"appSecret_dev_sit_uat"];
    MSUrlEnvironmentType type = [MSUserDefaultTools getUrlEnvironmentType];
    if (type == MSUrlEnvironmentTypeProd){ //dev，sit,uat 和Prod互切时，需要重启app
        decodedMasKey = [OEMCustomize getEncryptedStringValueWithKey:@"appSecret"];
    }
#else
    //PROD_VnoClJI9aikS8dyy
    decodedMasKey = [OEMCustomize getEncryptedStringValueWithKey:@"appSecret"];
    if ([self isUAT]) {
        decodedMasKey = [OEMCustomize getEncryptedStringValueWithKey:@"appSecret_dev_sit_uat"];
    }
#endif
    return decodedMasKey;
}

+ (BOOL)isUAT{
#if UAT_ENV==1
    return YES;
#endif
    return NO;
}

//iOS安卓双端密码加密key(秘钥）
+ (NSString *)appKey {
    if (SDKDefaultConfig.appkey.length > 0) {
        return SDKDefaultConfig.appkey;
    }
    return @"4dbc9ff6c15944d78eebb581c2b23de3";
}

+ (NSString *)msClientId{
    return [OEMCustomize getEncryptedStringValueWithKey:@"msClientId"];
}

+ (NSString *)msClientSecret{
    if ([MSUserDefaultTools getUrlEnvironmentType] == MSUrlEnvironmentTypeDev) {
        return [OEMCustomize getEncryptedStringValueWithKey:@"msClientSecret_dev"];
    }
    return [OEMCustomize getEncryptedStringValueWithKey:@"msClientSecret"];
}

//验证码三端加密key(秘钥）
+ (NSString *)verifyAESKey {
    return @"f526b03e0b591a6eeddf4fe77b9517fa";
}

+ (BOOL )isAppleSignEnable{
    NSDictionary *infoDict = [[NSBundle mainBundle] infoDictionary];
    NSString *bundleId = [infoDict objectForKey:@"CFBundleIdentifier"];
    if (![bundleId isEqualToString:Bundle_MSOEM_InHouse]) {
        return YES;
    }
    return NO;
}


+ (NSString *)currentLanguageCode{
    NSString *languageCode = [[HGInternationalization sharedInstance] convertSystemLanguangeCodeToUnifyLanguangeCode:HGCurrentLanguage.code];
    return languageCode;
}

+ (NSString *)countryCode{
    return [HGInternationalization sharedInstance].currentCountry.code;
}

//aws 节点
+ (NSString *)awsEndPoint{
    return [HGInternationalization sharedInstance].currentCountry.mqttBroker;
}

//本地数据 HMACSha256加密的secret
+ (NSString *)hmacSha256SecretForLocalData {
    return @"#UIuyf9%";
}

//云平台，请求的基础参数
+ (NSString *)getAppId {
    if (SDKDefaultConfig.appID.length > 0) {
        return SDKDefaultConfig.appID;
    }
    NSString * appId = [OEMCustomize getStringValueWithKey:@"appId"];
    return appId;
}

//云平台，请求的基础参数
+ (NSString *)getSrc {
    return @"20";
}

+ (NSMutableDictionary *)getCommonData {
    NSMutableDictionary *commomData = [NSMutableDictionary new];
    [commomData setValue:[self getAppId] forKey:@"appId"];
    [commomData setValue:[self getSrc] forKey:@"src"];
    [commomData setValue:MSLogin_Client_Type_IOS forKey:@"clientType"];
    NSString *timestamp = [NSDate dof_getNSStringFromNSDate:[NSDate date] withFormat:@"yyyyMMddHHmmss"];
    [commomData setValue:timestamp forKey:@"stamp"];
    [commomData setValue:[MideaTool getReqid] forKey:@"reqId"];
    NSString *languageCode = [[HGInternationalization sharedInstance] convertSystemLanguangeCodeToUnifyLanguangeCode:HGCurrentLanguage.code];
    [commomData setValue:languageCode forKey:@"language"];
    [commomData setValue:[MideaTool getUUID] forKey:@"deviceId"];
    [commomData setValue:[MSAppInfo appShortVersion] forKey:@"appVNum"];
    return commomData;
}

+ (NSString *)getEvnPrefix{
    NSArray * prefix = [[self mucBaseUrl] componentsSeparatedByString:@"."];
    if ([prefix count] == 0) {
        return @"us";
    }
    NSString * trim = [prefix.firstObject stringByReplacingOccurrencesOfString:@"https://" withString:@""];
    trim = [trim stringByReplacingOccurrencesOfString:@"http://" withString:@""];
    return trim;
}

+  (NSString *)appName
{
    return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleDisplayName"];
}
    
+  (NSString *)appVersion
{
    return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"];
}
    
+  (NSString *)appShortVersion
{
    return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
}
    
+  (NSString *)bundleIdentifier
{
    return [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleIdentifier"];
}

@end
