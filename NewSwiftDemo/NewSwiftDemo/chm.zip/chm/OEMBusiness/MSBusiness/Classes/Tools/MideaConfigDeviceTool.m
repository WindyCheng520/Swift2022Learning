//
//  MideaConfigDeviceTool.m
//  midea
//
//  Created by MaYifang on 16/6/13.
//  Copyright © 2016年 Midea. All rights reserved.
//

#import "MideaConfigDeviceTool.h"
#import "MideaSecurity.h"
#import "MSUserDefaultTools.h"
#import "MSUserInfoManager.h"

@implementation MideaConfigDeviceTool

#pragma mark - 埋点单次配网的session_id
+ (NSString *)getDeviceSessionId:(BOOL)isForceNew {
    static NSString *deviceSessionId = @"";
    if (isForceNew) {
        NSString *uid = [MSUserInfoManager shareManager].loginInfoModel.uid ?: @"";
        NSTimeInterval nowTime = [[NSDate date] timeIntervalSince1970];
        NSString *key = [NSString stringWithFormat:@"%@%ld",uid,(long)nowTime];
        deviceSessionId = [MideaSecurity getSha256String:key];
        // 埋点发现session_id为空，可能为算法问题或者大数据丢失，这里做个防护，防止算法返回空
        if (deviceSessionId.length == 0) {
            deviceSessionId = key;
        }
    }
    return deviceSessionId;
}

///获取配网埋点的device_session_id
+ (NSString *)getDeviceSessionId {
    return [self getDeviceSessionId:NO];
}
@end
