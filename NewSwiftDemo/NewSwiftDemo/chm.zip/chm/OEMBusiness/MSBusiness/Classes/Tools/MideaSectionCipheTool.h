//
//  MideaSectionCipheTool.h
//  BHBusiness
//
//  Created by IoT熊思 on 2019/12/9.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MideaSectionCipheTool : NSObject

+(NSString *)meijuSecEncode:(NSString *)inputStr;

+(NSString *)meijuSecDecode:(NSString *)inputStr;

@end

NS_ASSUME_NONNULL_END
