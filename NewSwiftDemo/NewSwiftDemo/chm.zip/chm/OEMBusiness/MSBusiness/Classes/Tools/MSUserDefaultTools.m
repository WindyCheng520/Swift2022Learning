//
//  MSUserDefaultTools.m
//  MSBusiness
//
//  Created by 及时行乐 on 2020/7/9.
//

#import "MSUserDefaultTools.h"
#import "MSAppInfo.h"
#import "MideaSecurity.h"
#import <OEMFoundation/NSDate+OEMExtension.h>

//static NSString* const MSMideaCloudAccessTokenKey = @"MSMideaCloudAccessTokenKey";
//static NSString* const MSMideaCloudRandomDataKey = @"MSMideaCloudRandomDataKey";
//static NSString* const MSUserAccountKey = @"MSUserAccountKey";
//static NSString* const MSMasAccessTokenKey = @"MSMasAccessTokenKey";
//static NSString* const MSMasTokenPwdKey = @"MSMasTokenPwdKey";
//static NSString* const MSUserUidKey = @"MSUserUidKey";
//static NSString* const MSUserNicknameKey = @"MSUserNicknameKey";

static NSString* const MSDeviceTokenKey = @"MSDeviceTokenKey";
static NSString* const MSFirstAgreePrivacyKey = @"MSFirstAgreePrivacyKey";
static NSString* const MSUserOperatedVersionNumberKey = @"MSUserOperatedVersionNumberKey";
static NSString* const MSLastLoginAccountKey = @"MSLastLoginAccountKey";

static NSString* const MSNSDateKey = @"MSNSDateKey";

static NSString* const MSAlexaTokenKey = @"MSAlexaTokenKey";
static NSString* const MSAlexaRefreshTokenKey = @"MSAlexaRefreshTokenKey";
static NSString* const MSAlexaTokenTimeKey = @"MSAlexaTokenTimeKey";


static NSString* const MSAppUrlEnvironmentKey = @"MSAppUrlEnvironmentKey";

@interface MSUserDefaultTools ()


@end


@implementation MSUserDefaultTools

//userDefault 存储数据方法
+ (void)saveToUserDefaultWithKey:(NSString *)key value:(id)value{
    [[NSUserDefaults standardUserDefaults] setObject:value forKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

//userDefault 获取数据方法
+ (id)getUserDefaultWithKey:(NSString *)key{
    return [[NSUserDefaults standardUserDefaults] valueForKey:key];
}

//userDefault 删除数据方法
+ (void)clearUserDefaultValueWithKey:(NSString *)key{
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

////存储云平台accessToken，用于加密敏感数据
//+ (void)saveMideaCloudAccessToken:(NSString*)accessToken{
//    if (!accessToken) {
//        return;
//    }
//    [self saveToUserDefaultWithKey:MSMideaCloudAccessTokenKey value:accessToken];
//}
//
//+ (NSString*)getMideaCloudAccessToken{
//    return [self getUserDefaultWithKey:MSMideaCloudAccessTokenKey]?:@"";
//}
//
////存储云平台randomData，用于加密敏感数据
//+ (void)saveMideaCloudRandomData:(NSString*)randomData{
//    if (!randomData) {
//        return;
//    }
//    [self saveToUserDefaultWithKey:MSMideaCloudRandomDataKey value:randomData];
//}
//
//+ (NSString*)getMideaCloudRandomData{
//    return [self getUserDefaultWithKey:MSMideaCloudRandomDataKey]?:@"";
//}
//
////存储用户账号
//+ (void)saveUserAccount:(NSString*)account{
//    if (!account) {
//        return;
//    }
//    [self saveToUserDefaultWithKey:MSUserAccountKey value:account];
//}
//
//+ (NSString*)getUserAccount{
//    return [self getUserDefaultWithKey:MSUserAccountKey]?:@"";
//}
//
////存储中台accessToken，用于置换uid，判断登录
//+ (void)saveMasAccessToken:(NSString*)accessToken{
//    if (!accessToken) {
//        return;
//    }
//    [self saveToUserDefaultWithKey:MSMasAccessTokenKey value:accessToken];
//}
//
//+ (NSString*)getMasAccessToken{
//    return [self getUserDefaultWithKey:MSMasAccessTokenKey]?:@"";
//}
//
////存储中台tokenPwd，用于刷新token
//+ (void)saveMasTokenPwd:(NSString*)tokenPwd{
//    if (!tokenPwd) {
//        return;
//    }
//    [self saveToUserDefaultWithKey:MSMasTokenPwdKey value:tokenPwd];
//}
//
//+ (NSString*)getMasTokenPwd{
//    return [self getUserDefaultWithKey:MSMasTokenPwdKey]?:@"";
//}
//
////存储用户uid
//+ (void)saveUserUid:(NSString*)uid {
//    if (!uid) {
//        return;
//    }
//    [self saveToUserDefaultWithKey:MSUserUidKey value:uid];
//}
//
//+ (NSString*)getUserUid {
//    return [self getUserDefaultWithKey:MSUserUidKey]?:@"";
//}
//
////存储用户昵称
//+ (void)saveUserNickname:(NSString *)nickname {
//    if (!nickname) {
//        return;
//    }
//    [self saveToUserDefaultWithKey:MSUserNicknameKey value:nickname];
//}
//
//+ (NSString *)getUserNickname {
//    return [self getUserDefaultWithKey:MSUserNicknameKey]?:@"";
//}

//存储上次登录的account
+ (void)saveLastLoginAccount:(NSString *)account {
    if (!account) {
        return;
    }
    [self saveToUserDefaultWithKey:MSLastLoginAccountKey value:[MideaSecurity saveSensitiveDataToLocal:account]];
}

+ (NSString *)getLastLoginAccount {
    NSString *account = [self getUserDefaultWithKey:MSLastLoginAccountKey];
    if (account.length == 0) {
        return @"";
    }
    return [MideaSecurity getSensitiveDataFromLocal:account] ?: @"";
}

//存储首次启动APP时同意了隐私协议
+ (void)saveUserFirstAgreePrivacy {
    [self saveToUserDefaultWithKey:MSFirstAgreePrivacyKey value:@"1"];
}

//获取首次启动APP时是否同意了隐私协议
+ (BOOL)judgeUserWhetherFirstAgreePrivacy {
    NSString *agreeString = [self getUserDefaultWithKey:MSFirstAgreePrivacyKey];
    if (agreeString) {
        if ([agreeString isEqualToString:@"1"]) {
            return YES;
        } else {
            return NO;
        }
    } else {
        return NO;
    }
}

//存储用户已经选择过是否更新的版本号（非强制）
+ (void)saveUpdateVersionNumber:(NSString *)versionNumber{
    [self saveToUserDefaultWithKey:MSUserOperatedVersionNumberKey value:versionNumber];
}

+ (NSString*)getUpdateVersionNumber {
    return [self getUserDefaultWithKey:MSUserOperatedVersionNumberKey]?:@"";
}

//存储用户更新日期（非强制）
+ (void)saveDateToDisk{
    NSString *stamp = [NSDate dof_getNSStringFromNSDate:[NSDate date] withFormat:@"yyyy-MM-dd"];
    [self saveToUserDefaultWithKey:MSNSDateKey value:stamp];
}

//获取用户更新日期(非强制)
+ (NSString *)getDateFromDisk{
    return [self getUserDefaultWithKey:MSNSDateKey]?:@"";
}



//获取本地存储的APNs的token
+ (NSString*)getAPNsToken {
    return [self getUserDefaultWithKey:MSDeviceTokenKey]?:@"";
}


//存储Alexa Token
+ (void)saveAlexaTokenToDisk:(NSString *)token{
    [self saveToUserDefaultWithKey:MSAlexaTokenKey value:token];
}

//获取Alexa Token
+ (NSString*)getAlexaToken {
    return [self getUserDefaultWithKey:MSAlexaTokenKey]?:@"";
}



//存储AlexaRefleshToken
+ (void)saveAlexaRefleshTokenToDisk:(NSString *)token{
    [self saveToUserDefaultWithKey:MSAlexaRefreshTokenKey value:token];
}

//获取AlexaRefleshToken
+ (NSString*)getAlexaRefleshToken {
    return [self getUserDefaultWithKey:MSAlexaRefreshTokenKey]?:@"";
}



//存储AlexaTokenTime
+ (void)saveAlexaTokenTimeToDisk:(NSString *)timestamp{
   [self saveToUserDefaultWithKey:MSAlexaTokenTimeKey value:timestamp];
}


//获取AlexaTokenTime
+ (NSString*)getAlexaTokenTimstamp {
    return [self getUserDefaultWithKey:MSAlexaTokenTimeKey]?:@"";
}


//保存UrlEnvironmentType
+ (void)saveUrlEnvironmentType:(MSUrlEnvironmentType)type{
    [self saveToUserDefaultWithKey:MSAppUrlEnvironmentKey value:@(type)];
}


//获取UrlEnvironmentType
+ (MSUrlEnvironmentType)getUrlEnvironmentType{
    return [[self getUserDefaultWithKey:MSAppUrlEnvironmentKey] integerValue];
}





//+ (void)clearUserLoginOrRegisterData {
//    [[NSUserDefaults standardUserDefaults] removeObjectForKey:MSMideaCloudAccessTokenKey];
//    [[NSUserDefaults standardUserDefaults] removeObjectForKey:MSMideaCloudRandomDataKey];
//    [[NSUserDefaults standardUserDefaults] removeObjectForKey:MSMasAccessTokenKey];
//    [[NSUserDefaults standardUserDefaults] removeObjectForKey:MSMasTokenPwdKey];
//    [[NSUserDefaults standardUserDefaults] removeObjectForKey:MSUserUidKey];
//    [[NSUserDefaults standardUserDefaults] removeObjectForKey:MSUserNicknameKey];
//    [[NSUserDefaults standardUserDefaults] synchronize];
//}


@end
