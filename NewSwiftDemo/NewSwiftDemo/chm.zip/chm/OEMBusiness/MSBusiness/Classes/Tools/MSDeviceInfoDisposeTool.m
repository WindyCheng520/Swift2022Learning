//
//  MSDeviceInfoDisposeTool.m
//  MSBusiness
//
//  Created by WindyCheng on 2021/10/12.
//

#import "MSDeviceInfoDisposeTool.h"

static NSDictionary *deviceModelMap;

@implementation MSDeviceInfoDisposeTool



+ (NSDictionary *)getDeviceModelMap{
    if (!deviceModelMap) {
        deviceModelMap = @{
            @"E2":@{
                    @"1":@"00A06882",
                    @"2":@""
            },
            @"B4":@{
                    @"1":@"",
                    @"2":@""
            },
            @"AC":@{
                    @"1":@"",
                    @"2":@""
            }
        };
    }
    return deviceModelMap;
}

+(NSString *)fecthModelByType:(NSString *)type value:(NSInteger)value{
    NSDictionary *map = [self getDeviceModelMap];
    NSString *model = @"";
    if ([map.allKeys containsObject:type]) {
        NSDictionary *dict = map[type];
        NSString *valueString = [NSString stringWithFormat:@"%ld", value];
        if ([dict.allKeys containsObject:valueString]) {
            model = dict[valueString];
        }
    }
    return model;
}

@end
