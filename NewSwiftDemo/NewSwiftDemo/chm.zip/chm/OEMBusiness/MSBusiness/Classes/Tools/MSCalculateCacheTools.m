//
//  MSCalculateCacheTools.m
//  MSBusiness
//
//  Created by pactera on 2020/8/18.
//

#import "MSCalculateCacheTools.h"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@implementation MSCalculateCacheTools

//获取指定文件/文件夹路径下的所有文件大小
+ (void)getCacheFileSize:(NSString *)directoryPath completion:(void (^)(float size))completion {
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        NSFileManager *mgr = [NSFileManager defaultManager];
        BOOL dir = NO;
        BOOL exits = [mgr fileExistsAtPath:directoryPath isDirectory:&dir];
        if (!exits) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion(0);
                return;
            });
        }
        
        CGFloat totalSize = 0;
        if (dir) {
            NSArray *subPaths = [mgr subpathsAtPath:directoryPath];
            //遍历所有子路径
            for (NSString *subPath in subPaths) {
                //拼成全路径
                NSString *fullSubPath = [directoryPath stringByAppendingPathComponent:subPath];
                BOOL isDirectory = NO;
                BOOL isExist = [[NSFileManager defaultManager] fileExistsAtPath:fullSubPath isDirectory:&isDirectory];
                if (!isExist || isDirectory || [fullSubPath containsString:@".DS"]){
                    // 过滤: 1. 文件夹不存在  2. 过滤文件夹  3. 隐藏文件
                    continue;
                }
                NSDictionary *attrs = [mgr attributesOfItemAtPath:fullSubPath error:nil];
                totalSize += [attrs[NSFileSize] floatValue];
            }
        } else {
            NSDictionary *attrs = [mgr attributesOfItemAtPath:directoryPath error:nil];
            totalSize = [attrs[NSFileSize] floatValue];
        }
        totalSize = totalSize / (1024 * 1024.0);//单位M
        dispatch_async(dispatch_get_main_queue(), ^{
            completion(totalSize);
        });
    });
    
}

//清除指定文件路径下的所有内容
+ (void)clearCacheWithDirectoryPath:(NSString *)directoryPath completion:(void (^)(void))completion {
    
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        NSFileManager *mgr = [NSFileManager defaultManager];
        BOOL exits = [mgr fileExistsAtPath:directoryPath];
        if (!exits) {
            dispatch_async(dispatch_get_main_queue(), ^{
                completion();
                return;
            });
        }
        
        NSArray *subPaths = [mgr subpathsAtPath:directoryPath];
        //遍历所有子路径
        for (NSString *subPath in subPaths) {
            //拼成全路径
            NSString *fullSubPath = [directoryPath stringByAppendingPathComponent:subPath];
            NSError *error = nil;
            [mgr removeItemAtPath:fullSubPath error:&error];
            if (error) {
//                DDLogBusinessInfo(@"删除文件出错:%@, 原因:%@", fullSubPath, error.localizedDescription);
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            completion();
        });
    });
    
}



@end
