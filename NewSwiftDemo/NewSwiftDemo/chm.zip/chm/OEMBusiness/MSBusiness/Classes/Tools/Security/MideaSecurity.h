//
//  MideaDataSecurity.h
//  midea
//
//  Created by xuenianxiang on 14-8-14.
//  Copyright (c) 2014年 keane. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MideaSecurity : NSObject

// 登陆密码加密(本地)
+ (NSString *)localLoginPasswordEncryption:(NSString *)msg;

// 注册密码加密
+ (NSString *)registerPasswordEncryption:(NSString *)msg;

// MD5_128加密
+ (NSString *)getMD5_128:(NSString *)str;
+ (NSString *)getMD5_128WithData:(NSData *)data;

// SHA256加密
+ (NSString *)getSha256String:( NSString *)srcString;

// NSData 转换成 16进制小写字符串
+ (NSString*)hexStringForData:(NSData*)data;

// 16进制小写字符串 转换成 NSData
+ (NSData*)dataForHexString:(NSString*)hexString;

// AES128加密、解密(utf8)
+ (NSString *)AES128Encrypt:(NSString *)plainText key:(NSString *)key;
+ (NSString *)AES128Decrypt:(NSString *)encryptText key:(NSString *)key;

// AES128加密、解密(hexStr)
+ (NSData *)AES128EncryptWithData:(NSData *)data key:(NSString *)key;
+ (NSData *)AES128DecryptWithData:(NSData *)data key:(NSString *)key;

+ (NSString *)AESCBCEncrypt:(NSString *)plainText key:(NSString *)key iv:(NSString *)iv;
+ (NSString *)AESCBCDecrypt:(NSString *)encryptText key:(NSString *)key iv:(NSString *)iv;


+ (NSString *)convertDataToHexStr:(NSData *)data;

+ (NSString *)hexStringFromString:(NSString *)string;

+(NSString *)md5:(NSString *)str;

// IoT 网络请求  openid加密
+ (NSString *)iOtOpenidEncrypt:(NSString *)plainText key:(NSString *)key;

// HMAC-SHA256加密方法
/// HMAC-SHA256加密方法
/// @param secret 秘钥
/// @param content 要加密的文本
+ (NSString *)hmacSHA256WithSecret:(NSString *)secret
                           content:(NSString *)content;

//登录后的敏感数据加密方法
+ (NSString *)encryptDataAfterLogin:(NSString *)content;

//登录后的敏感数据解密方法
+ (NSString *)decryptDataAfterLogin:(NSString *)content;

//登录前的敏感数据加密方法
+ (NSString *)encryptDataBeforeLogin:(NSString *)content;

//登录前的敏感数据解密方法
+ (NSString *)decryptDataBeforeLogin:(NSString *)content;

//本地敏感数据存取方法 （加密+完整性校验）
+ (NSString *)saveSensitiveDataToLocal:(NSString *)content;
//本地敏感数据存取方法 （解密+完整性校验）
+ (NSString *)getSensitiveDataFromLocal:(NSString *)content;

@end
