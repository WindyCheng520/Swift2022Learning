//
//  AuthorizationCell.m
//  MSBusiness
//
//  Created by pactera on 2021/2/6.
//

#import "AuthorizationCell.h"

@interface AuthorizationCell ()

@property (nonatomic, strong) HGView *roundView;
@property (nonatomic, strong) HGLabel *titleLabel;

@end

@implementation AuthorizationCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        self.roundView = [HGView new];
        self.roundView.backgroundColor = RGB_HEX(0x666666);
        self.roundView.layer.cornerRadius = 2;
        self.roundView.layer.masksToBounds = YES;
        [self.contentView addSubview:self.roundView];
        
        self.titleLabel = [HGLabel new];
        self.titleLabel.numberOfLines = 0;
        self.titleLabel.textColor = RGB_HEX(0x666666);
        self.titleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightRegular];
        [self.contentView addSubview:self.titleLabel];
        
        [self makeContstraints];
    }
    return self;
}

- (void)makeContstraints {
    CGFloat margin = 0;
    
    [self.roundView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(margin);
        make.top.mas_equalTo(8 + (self.titleLabel.font.lineHeight / 2.f) - 2);
        make.size.mas_equalTo(CGSizeMake(4, 4));
    }];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.roundView.mas_trailing).offset(8);
        make.trailing.mas_equalTo(-margin);
        make.top.mas_equalTo(8);
        make.bottom.equalTo(self.contentView);
    }];
    
}

+ (CGFloat)cellHeightWithTitle:(NSString *)title maxWidth:(CGFloat)maxWidth {
    return ceil([title boundingRectWithSize:CGSizeMake(maxWidth - 4 - 8, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : [UIFont systemFontOfSize:14 weight:UIFontWeightRegular]} context:nil].size.height + 8);
}

- (void)refreshTitle:(NSString *)title {
    self.titleLabel.text = title;
}


@end
