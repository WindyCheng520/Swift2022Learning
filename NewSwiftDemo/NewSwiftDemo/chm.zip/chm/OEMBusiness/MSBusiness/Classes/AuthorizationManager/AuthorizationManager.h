//
//  AuthorizationManager.h
//  MSBusiness
//
//  Created by pactera on 2021/2/6.
//

#import <Foundation/Foundation.h>
#import "MSBusinessError.h"
#import "AuthorizationResult.h"

NS_ASSUME_NONNULL_BEGIN

//https://datatracker.ietf.org/doc/html/rfc6749#section-4.1.1
@interface OAuth2Info : NSObject

//https://developer.amazon.com/en-US/docs/alexa/account-linking/configure-authorization-code-grant.html
//https://sit-us.aiotelink.com/mideaoem/authorize/alexa (配置在Alexa 开发者控制台的我方Universal Links，mideaoem/authorize/alexa代表唤起并打开我方app授权页）
//第三方如（Alexa)唤起我方App URl (样式为我方Universal Links前缀？+key1=value1&key2=value2...)后面拼接第三方平台传递给我方App的参数
//https://sit-us.aiotelink.com/mideaoem/link/alexa（
@property (nonatomic, strong, nullable) NSURL *url;

@property (nonatomic, copy, nullable) NSString *urlString;

//Alexa 开发者控制台配置的自己所创建的Skill 标识
@property (nonatomic, copy, nullable) NSString *clientId;

//Alexa 服务在内部使用的状态值，用于通过帐户链接过程跟踪用户。Alexa 应用程序通过授权 URI 向授权服务器发送一个值。授权服务器在随后调用该特定帐户链接请求的重定向 URI 时必须使用相同的值。对授权服务器的每个请求都有其自身的状态值。
@property (nonatomic, copy, nullable) NSString *state;

//Alexa 分配给你所创建的这个Skill的重定向地址链接
@property (nonatomic, copy, nullable) NSString *redirectUri;

//Alexa 开发者控制台配置的自己所创建的Skill 允许访问的范围
@property (nonatomic, copy, nullable) NSString *scope;

//Alexa 回传的授权登录码
@property (nonatomic, copy, nullable) NSString *code;

@property (nonatomic, copy, nullable) NSString *responseType;

//@property (nonatomic, assign) AuthorizationType type;

@property (nonatomic, assign) BOOL isShowLogined;  //记录登录成功后是否要显示授权页面

@end

@interface IOSAdditions :NSObject
@property (nonatomic , copy) NSString              *contain;
@property (nonatomic , copy) NSString              *mcact;
@property (nonatomic , copy) NSString              *lsaw;
@property (nonatomic , copy) NSString              *dws;
@property (nonatomic , copy) NSString              *inplus;
@property (nonatomic , strong) NSArray <NSString *>  *apps;

@end



@interface AlexaInfo : NSObject

@property (nonatomic , copy) NSString              *alexaAppBaseUrl;
@property (nonatomic , copy) NSString              *lwaUrl;
@property (nonatomic , copy) NSString              *client_id;              //OEM分配给Alexa的id
@property (nonatomic , copy) NSString              *client_secret;          //OEM分配给Alexa秘钥
@property (nonatomic , copy) NSString              *skill_id;               //Alexa 分配的skill id
@property (nonatomic , strong)NSArray              *redirect_uri;           //Alexa 分配的skill 重定向地址
@property (nonatomic , strong) NSDictionary        *alexaQueryItems;

@end

@interface GoogleInfo: NSObject

@property (nonatomic , copy) NSString              *tutorialUrl;
@property (nonatomic , copy) NSString              *projectId;

@end


@interface JumpThirdAppInfo :NSObject
@property (nonatomic , strong) AlexaInfo              *alexaInfo;
@property (nonatomic , strong) GoogleInfo              *googleInfo;
//@property (nonatomic , strong) IOSAdditions           *iOSAdditions;

@end






@interface AuthorizationManager : NSObject

@property(nonatomic, strong)__block JumpThirdAppInfo *entity;
//自身平台的授权码
@property (nonatomic, copy)__block NSString *authorCode;

+ (instancetype)sharedManager;



- (void)fetchJumpInfo:(void(^)(BOOL success, MSBusinessError * error))completionon;

- (BOOL)canHandleURL:(NSURL *)url;
- (void)handleURL:(NSURL *)url;
- (void)cancelAuthorization;
- (void)authSuccessWithResult:(AuthorizationResult *)result;
- (void)getAuthorizeResultWithParam:(NSDictionary *)param completionHandler:(void(^)(AuthorizationResult *result, MSBusinessError *error))completionHandler;
- (void)clickLeftCancelButton;
- (void)showAppUpdateAlertView;


//判断安装了应用
- (BOOL)isInstallApp:(NSString *)urlScheme;

//跳转Alexa App
-(void)jumpToAlexa;


@end

NS_ASSUME_NONNULL_END
