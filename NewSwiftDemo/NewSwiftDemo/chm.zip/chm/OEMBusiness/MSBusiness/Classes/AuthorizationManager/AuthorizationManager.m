//
//  AuthorizationManager.m
//  MSBusiness
//
//  Created by pactera on 2021/2/6.
//

#import "AuthorizationManager.h"
#import "MSUserInfoManager.h"
#import <OEMFoundation/HGInternationalization.h>
#import <MSBusiness/MSRouterUrl.h>
#import <MSBusiness/BusinessRequestManager.h>
#import <MSBusiness/MSAppInfo.h>
#import <MSBusiness/BusinessResponse.h>
#import "MJExtension.h"
#import "MSNotificationConst.h"
#import <OEMFoundation/HGBaseNavigationController.h>
#import "MSBusinessBundle.h"
#import <MSBusiness/MSSystemPermissionManager.h>
#import <OEMTheme/OEMHGAlertController.h>
#import <MSBusiness/MSUserInfoManager.h>
#import <MSBusiness/MSRouterUrl.h>
#import <OEMFoundation/OEMCustomize.h>

//static NSString *const Google_Uri_Test = @"https://oauth-redirect-sandbox.googleusercontent.com";
//static NSString *const Google_Uri = @"https://oauth-redirect.googleusercontent.com";
static NSString *const Amazon_Uri = @"https://pitangui.amazon.com/api/skill/link";
static NSString *const Authorization_Url = @"/v1/user/authcode/requestwithoutlogin";
static NSString *const JumpInfo_URL = @"/v1/user/jumpinfo";
static NSString *const OAuthor2_URL = @"/v1/user/oauth/code";

static NSString * const kGoogleHomeUrlScheme = @"chromecast://";

static NSString * const AlexaAuthorizeSubPath = @"mideaoem/authorize/alexa";

static NSString * const AlexaLinkSubPath = @"mideaoem/link/alexa";

static NSString * const GoogleAuthorizeSubPath = @"mideaoem/authorize/google";

@implementation IOSAdditions
@end


@implementation AlexaInfo
@end

@implementation GoogleInfo
@end

@implementation JumpThirdAppInfo
@end

@implementation OAuth2Info

- (void)construct:(NSURL *)url{
    
    self.urlString = url.absoluteString;
    
    NSString *clientId = nil;
    NSString *state = nil;
    NSString *redirectUri = nil;
    NSString *scope = nil;
    NSString *code = nil;
    
    //苹果用来替代NSMutableURL 的
    NSURLComponents *components = [[NSURLComponents alloc] initWithURL:url resolvingAgainstBaseURL:YES];
    for (NSURLQueryItem *item in components.queryItems) {
        NSLog(@"--------key:%@ =====  value:%@", item.name, item.value);
        if ([item.name isEqualToString:@"client_id"]) {
            self.clientId = item.value;
        }
        if ([item.name isEqualToString:@"state"]) {
            self.state = item.value;
        }
        if ([item.name isEqualToString:@"redirect_uri"]) {
            self.redirectUri = item.value;
        }
        if ([item.name isEqualToString:@"code"]) {
            self.responseType = item.value;
        }
        //LWA网页跳转回来
        if ([item.name isEqualToString:@"scope"]) {
            self.scope = item.value;
        }
        
        if ([item.name isEqualToString:@"code"]) {
            self.code = item.value;
        }
    }
}

- (BOOL)isValidForPath:(NSString *)path{
    if ([self.urlString containsString:AlexaAuthorizeSubPath]) {
         if (!self.clientId || !self.state || !self.redirectUri) {
            return NO;
        }
    }else if([self.urlString containsString:AlexaLinkSubPath]){
        if (!self.code || !self.state) {
           return NO;
       }
    }else if([self.urlString containsString:GoogleAuthorizeSubPath]){
        if (!self.clientId || !self.state || !self.redirectUri) {
           return NO;
       }
    }
    return YES;
}

- (void)clean{
    self.url = nil;
    self.urlString = nil;
    self.clientId = nil;
    self.state = nil;
    self.redirectUri = nil;
    self.scope = nil;
    self.code = nil;
    self.isShowLogined =  NO;
}

@end

@interface AuthorizationManager ()

@property (nonatomic, strong)OAuth2Info *oauthInfo;

@end

@implementation AuthorizationManager

+ (instancetype)sharedManager {
    static dispatch_once_t onceToken;
    static AuthorizationManager *manager = nil;
    dispatch_once(&onceToken, ^{
        manager = [[AuthorizationManager alloc] init];
    });
    return manager;
}

- (instancetype)init {
    if (self = [super init]) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginSuccess:) name:kMideaLoginSuccessNotification object:nil];
        self.oauthInfo = [[OAuth2Info alloc] init];
    }
    return self;
}

- (BOOL)canHandleURL:(NSURL *)url {
    DDLogBusinessInfo(@"判断是否能够处理此URL：%@",url);
    if (!url) {
        return NO;
    }
    [self.oauthInfo clean];
    [self.oauthInfo construct:url];
    if (![self.oauthInfo isValidForPath:AlexaAuthorizeSubPath] ||
        ![self.oauthInfo isValidForPath:AlexaLinkSubPath] ||
        ![self.oauthInfo isValidForPath:GoogleAuthorizeSubPath]) {
        return NO;
    }
    return YES;
}



//Alexa 返回
//https://sit-us.aiotelink.com/mideaoem/link/alexa?code=ANBfxquHVFAvDYswyzsv&scope=alexa%3A%3Askills%3Aaccount_linking&state=YXNoYWhkY2puYXNrYXNrY25qYWtua25ha25jc25rYXNrbG5ja25sYQ%3D%3D

//LWA 返回
//：https://sit-us.aiotelink.com/mideaoem/link/alexa?code=ANPMrQFUfjnDZezpgIoJ&state=YXNoYWhkY2puYXNrYXNrY25qYWtua25ha25jc25rYXNrbG5ja25sYQ%3D%3D

//Google Home返回 https://sit-us.dollin.net/mideaoem/authorize/alexa?response_type=code&client_id=oauth2.client.8af5ee45f311d6ee1b8cca10c89ad90647476e808816da4ddec16c0a7fd217e5&redirect_uri=https://oauth-redirect.googleusercontent.com/a/com.google.Chromecast&scope=GOOGLE&state=ABdO3MV_HLsSQdmB_gi9g_SrkLbpVKxuy0ycyhE_Thnt0QE7XiJeVt38wCQR-sYTxvX5JV3zaidyqMu4btLapjkZmo5YfYbtCbFcaLkkDJ2KoWh8fW434RgdEZq06OePsfLsEPzKCqFgBijvKD3xz6f3CsqJHZdFm5zIGzqaZ4O8VQ-a4b7y6XtHKCPKX9N8kDgFKqPhjGMSbXuoU5LRvmOUyzThfXvxBLU9K9yqyZ1jOhEJ9ht5dcyOU-54INJW_eejFFEqnLGkxF6Xt1CmBbdifubLdk0YFi39IszGWWa_0AVg9FEKD3zVQYt7f0df5V_pgabd43CrTH3INvL7QUctw3W1Cm4h0Wdf8v-BEeziHzNoXZR4bNxyeZA-O4ImSzp4eGIKdD7REBUP6xkZK7YPpq-gRsDkrJ6Ozbswiu4EDhJyaFNlNmFzqjqcc7uc7dyv7jvOjtRPEiMsphseO-twN4ARdLU2Hr6xrhjHDYKcFPmQTH2OxRChHgtjadoNChyHEyG8a5DkWDuG62_-CJfvHxyZQqIQKTJ9c7GQ9VxX2hNGfuP6rCv-EJAwm9ZYcONtmzTIesFpHri2ClWY3vmOb8dx5LYn2xfIBrrO82pFzll_ojpWznaPT3Owcsvg7SG8bGBSzacMAol5HQllA75LRHPaodbY103POBn7jtupNShRpqAh9L0

- (void)handleURL:(NSURL *)url {
    DDLogBusinessInfo(@"开始处理授权URL：%@",url.absoluteString);
    
//    NSMutableCharacterSet *characterSet  = [[NSMutableCharacterSet alloc] init];
//    [characterSet formUnionWithCharacterSet:[NSCharacterSet URLQueryAllowedCharacterSet]];
//    [characterSet formUnionWithCharacterSet:[NSCharacterSet URLPathAllowedCharacterSet]];
//    [characterSet formUnionWithCharacterSet:[NSCharacterSet URLUserAllowedCharacterSet]];
//    NSString *finalUrl =  [url.absoluteString stringByAddingPercentEncodingWithAllowedCharacters:characterSet];
//    DDLogBusinessInfo(@"开始处理授权最终URL：%@", finalUrl);
    
    if (![self canHandleURL:url]) {
        return;
    }
    if ([MSUserInfoManager shareManager].isLogin) {
        // 已登录，调起授权页
        if([self.oauthInfo.urlString containsString:GoogleAuthorizeSubPath]){
            dispatch_async(dispatch_get_main_queue(), ^{
                [self goToGoogleAuthPage];
            });
        } else if ([self.oauthInfo.urlString containsString:AlexaAuthorizeSubPath]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self goToAlexaAuthPage];
            });
        }else {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"getAlexaAuthorCodeSuccess" object:nil userInfo:@{@"code":self.oauthInfo.code}];
        }
    } else {
        // 未登录，有选择国家跳转到登录页，没有选择国家跳转到选择国家页面
        if ([self.oauthInfo.urlString containsString:AlexaAuthorizeSubPath] ||
            [self.oauthInfo.urlString containsString:GoogleAuthorizeSubPath]) {
            self.oauthInfo.isShowLogined = YES;
            if (HGCurrentCountry) {
                [self goToLoginPage];
            } else {
                [self goToSelectCountryPage];
            }
        }
    }
}

- (void)goToAlexaAuthPage {
    UIViewController *currentVC = [OEMRouterHandler getCurrentViewController];
    UIViewController *alexaVC = [OEMRouter objectForURL:MSRouterMineAlexa];
    HGBaseNavigationController *authNavigationController = [[HGBaseNavigationController alloc]initWithRootViewController:alexaVC];
    authNavigationController.modalPresentationStyle = UIModalPresentationFullScreen;
    [currentVC presentViewController:authNavigationController animated:NO completion:nil];
}

- (void)goToGoogleAuthPage {
    UIViewController *currentVC = [OEMRouterHandler getCurrentViewController];
    UIViewController * googleVC = [OEMRouter objectForURL:MSRouterMineGoogleAuth withParams:@{
        @"BindGoogleAssitantViewType": @(1),
        @"OAuth2Info": self.oauthInfo
    }];
    HGBaseNavigationController *authNavigationController = [[HGBaseNavigationController alloc]initWithRootViewController:googleVC];
    authNavigationController.modalPresentationStyle = UIModalPresentationFullScreen;
    [currentVC presentViewController:authNavigationController animated:NO completion:nil];
}

- (void)goToSelectCountryPage {
    UIViewController *currentVC = [OEMRouterHandler getCurrentViewController];
    UIViewController *countryVC = [OEMRouter objectForURL:MSRouterCountryIndex];
    //如果当前不在选择国家页面，则跳转
    if (![currentVC isKindOfClass:countryVC.class]) {
        @weakify(self)
        void(^clickLeftButtonBlock)(void) = ^{
            @strongify(self)
            [self clickLeftCancelButton];
        };
        
        [OEMRouter handleURL:MSRouterCountryIndex withParams:@{@"enterType" : @1, @"clickLeftButtonBlock" : clickLeftButtonBlock, @"isForAuthorize":@(YES)} sourceController:currentVC andCompletion:nil];
    }

}

- (void)goToLoginPage {
    UIViewController *currentVC = [OEMRouterHandler getCurrentViewController];
    UIViewController *loginVC = [OEMRouter objectForURL:MSRouterLoginIndex];
    @weakify(self)
    void(^clickLeftButtonBlock)(void) = ^{
        @strongify(self)
        [self clickLeftCancelButton];
    };
    
    if (currentVC.navigationController.viewControllers.count > 0) {
        NSArray<UIViewController *> *vcs = currentVC.navigationController.viewControllers;
        __block UIViewController *destVC = nil;
        [vcs enumerateObjectsUsingBlock:^(UIViewController *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([obj isKindOfClass:loginVC.class]) {
                destVC = obj;
                *stop = YES;
            }
        }];
        if (destVC) {
            [destVC setValue:clickLeftButtonBlock forKey:@"clickLeftButtonBlock"];
            [currentVC.navigationController popToViewController:destVC animated:YES];
            return;
        }
    }
    
    NSString *previousPageName = @"";
    if ([currentVC isKindOfClass:NSClassFromString(@"MSHomeViewController")]) {
        previousPageName = @"toshibaHomePage";
    } else if ([currentVC isKindOfClass:NSClassFromString(@"MSMineViewController")]) {
        previousPageName = @"personalPage";
    }
    
    [OEMRouter handleURL:MSRouterLoginIndex withParams:@{@"previousPageName" : previousPageName, @"clickLeftButtonBlock" : clickLeftButtonBlock, @"isForAuthorize":@(YES)} sourceController:currentVC andCompletion:nil];
}

// 取消授权
- (void)cancelAuthorization {
    DDLogBusinessInfo(@"取消授权");
    if (!self.oauthInfo.redirectUri) {
        return;
    }
    NSURLComponents *components = [[NSURLComponents alloc] initWithURL:[NSURL URLWithString:self.oauthInfo.redirectUri] resolvingAgainstBaseURL:NO];
    NSURLQueryItem *paramError = [[NSURLQueryItem alloc] initWithName:@"error" value:@"未能成功关联OEM Home Appliance"];
    NSURLQueryItem *paramDescription = [[NSURLQueryItem alloc] initWithName:@"error_description" value:@"未能成功关联OEM Home Appliance"];
    components.queryItems = @[paramError, paramDescription];
    if (components.URL) {
        if (@available(iOS 10.0, *)) {
            [[UIApplication sharedApplication] openURL:components.URL options:@{UIApplicationOpenURLOptionUniversalLinksOnly:@(YES)} completionHandler:nil];
        } else {
            [[UIApplication sharedApplication] openURL:components.URL];
        }
    }
    [self.oauthInfo clean];;
}

// 授权成功，返回之前的APP
- (void)authSuccessWithResult:(AuthorizationResult *)result {
    if (!result.code) {
        return;
    }
    NSURLComponents *components = [[NSURLComponents alloc] initWithURL:[NSURL URLWithString:self.oauthInfo.redirectUri] resolvingAgainstBaseURL:NO];
    NSURLQueryItem *code = [[NSURLQueryItem alloc] initWithName:@"code" value:result.code ?: @""];
    NSURLQueryItem *state = [[NSURLQueryItem alloc] initWithName:@"state" value:self.oauthInfo.state ?: @""];
    components.queryItems = @[code,state];
    DDLogBusinessInfo(@"授权成功，回调Url = %@",components.URL);
   //https://pitangui.amazon.com/api/skill/link/M2AAAAAAAAAAAA?state=xyz&code=SplxlOBeZQQYbYS6WxSbIA
    if (components.URL) {
        if (@available(iOS 10.0, *)) {
            [[UIApplication sharedApplication] openURL:components.URL options:@{UIApplicationOpenURLOptionUniversalLinksOnly:@(YES)} completionHandler:nil];
        } else {
            [[UIApplication sharedApplication] openURL:components.URL];
        }
    }
}

// 获取授权
- (void)getAuthorizeResultWithParam:(NSDictionary *)param completionHandler:(void(^)(AuthorizationResult *result, MSBusinessError *error))completionHandler {
    NSMutableDictionary *paras = @{}.mutableCopy;
    MSUserInfoManager *mgr = [MSUserInfoManager shareManager];
    NSString *email = mgr.userInfoModel.email?: @"";
    [paras setValue:email forKey:@"email"];
    if (param) {
        [paras addEntriesFromDictionary:param];
    }else{
        [paras setValue:self.oauthInfo.clientId ?: @"" forKey:@"client_id"];
        [paras setValue:self.oauthInfo.scope ?: @"" forKey:@"scope"];
        [paras setValue:self.oauthInfo.redirectUri ?: @"" forKey:@"redirect_uri"];
    }
    [[BusinessRequestManager sharedInstance] POST:OAuthor2_URL parameters:paras
                                      cache:nil
                                    success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            AuthorizationResult *result = [AuthorizationResult mj_objectWithKeyValues:res.data];
            safeCallBlock(completionHandler, result, nil);
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSBusinessAuthorizationErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(completionHandler, nil, e);
        }
        
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(completionHandler, nil, e);
    }];
    
}

- (void)loginSuccess:(NSNotification *)notification {
    if (self.oauthInfo.isShowLogined) {
        self.oauthInfo.isShowLogined = NO;
        if ([self.oauthInfo.urlString containsString:AlexaAuthorizeSubPath]){
            [self goToAlexaAuthPage];
        }else if([self.oauthInfo.urlString containsString:GoogleAuthorizeSubPath]){
            [self goToGoogleAuthPage];
        }
    }
}

//点击了左上角的返回按钮 （选择国家、登录相关页面）
- (void)clickLeftCancelButton {
    if (self.oauthInfo.isShowLogined) {
        self.oauthInfo.isShowLogined = NO;
    }
    [self cancelAuthorization];
}

//不支持打开的universallink，给弹框提示
- (void)showAppUpdateAlertView {
    HGAlertAction* cancelAction = [HGAlertAction actionWithTitle:MSResourceString(@"authorization_alert_cancel") style:HGAlertActionStyleCancel action:nil];
    cancelAction.font = [UIFont systemFontOfSize:17 weight:UIFontWeightRegular];
    HGAlertAction* updateAction = [HGAlertAction actionWithTitle:MSResourceString(@"authorization_to_update") action:^{
        //跳转到App Store
        [[MSSystemPermissionManager shareManager] jumpToAppStore];
    }];
    NSString * title = [NSString stringWithFormat:MSResourceString(@"authorization_with_lasted_oem_app"), [MSAppInfo appName]];
    HGAlertController* alertController = [OEMHGAlertController alertControllerWithTitle:title message:@"" actions:@[cancelAction, updateAction]];
    [alertController show];
}


//判断是否包含
- (BOOL)isInstallApp:(NSString *)urlScheme{
    NSURL *url = [NSURL URLWithString:urlScheme];
    return [[UIApplication sharedApplication] canOpenURL:url];
}

/*
#warning --------test
- (instancetype)getJsonDataJsonname:(NSString *)jsonname{
    NSString *path = [[NSBundle mainBundle] pathForResource:jsonname ofType:@"json"];
    NSData *jsonData = [[NSData alloc] initWithContentsOfFile:path];
    NSError *error;
    id jsonObj = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&error];
    if (!jsonData || error) {
        return nil;
    } else {
        return jsonObj;
    }
}
#warning --------test
 */

- (void)fetchJumpInfo:(void(^)(BOOL success, MSBusinessError * error))completion{
    WEAKSELF
    [[BusinessRequestManager sharedInstance] POST:JumpInfo_URL parameters:nil cache:nil success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            /*
            NSDictionary *dict = [self getJsonDataJsonname:@"jumpThirdAppInfo"];
            JumpThirdAppInfo *result = [JumpThirdAppInfo mj_objectWithKeyValues:dict];
             */
            JumpThirdAppInfo *result = [JumpThirdAppInfo mj_objectWithKeyValues:res.data];
            weakSelf.entity = result;
            safeCallBlock(completion, true, nil);
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSBusinessAuthorizationErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(completion, false, e);
        }
        
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(completion, false, e);
    }];
}


//跳转Alexa app或 Alexa 网页
-(void)jumpToAlexa{
    [self jumpToAlexApp];
}

//跳转Alex
//https://alexa.amazon.com/spa/skill-account-linking-consent?fragment=skill-account-linking-consent&client_id={ClientId}&scope=alexa::skills:account_linking&skill_stage={skillStage}&response_type=code&redirect_uri={yourRedirectUrl}&state={yourState}
-(void)jumpToAlexApp{
    AlexaInfo *entity =  [AuthorizationManager sharedManager].entity.alexaInfo;
    NSMutableDictionary *itemDict = [NSMutableDictionary dictionaryWithDictionary:entity.alexaQueryItems];
    NSURLComponents *components = [[NSURLComponents alloc] initWithURL:[NSURL URLWithString:entity.alexaAppBaseUrl] resolvingAgainstBaseURL:YES];
    __block NSMutableArray *itemArray = @[].mutableCopy;
    [itemDict enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        NSURLQueryItem *item = [[NSURLQueryItem alloc] initWithName:key value:obj];
        [itemArray addObject:item];
    }];
    [itemDict removeObjectForKey:@"secret"];
    components.queryItems = itemArray.copy;
    NSLog(@"跳转Alexa----%@", components.URL.absoluteString);
    [[UIApplication sharedApplication] openURL:components.URL options:@{UIApplicationOpenURLOptionUniversalLinksOnly:@(YES)} completionHandler:nil];
}


//跳转Lwa
//https://www.amazon.com/ap/oa?client_id={ClientId}&scope=alexa::skills:account_linking&response_type=code&redirect_uri={yourRedirectUrl}&state={yourState}
-(void)jumpToLwaH5{
    AlexaInfo *entity =  [AuthorizationManager sharedManager].entity.alexaInfo;
    NSMutableDictionary *itemDict = [NSMutableDictionary dictionaryWithDictionary:entity.alexaQueryItems];
    [itemDict removeObjectForKey:@"fragment"];
    [itemDict removeObjectForKey:@"skill_stage"];
    [itemDict removeObjectForKey:@"secret"];
    NSURLComponents *components = [[NSURLComponents alloc] initWithURL:[NSURL URLWithString:entity.lwaUrl] resolvingAgainstBaseURL:YES];
    __block NSMutableArray *itemArray = @[].mutableCopy;
    [itemDict enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        NSURLQueryItem *item = [[NSURLQueryItem alloc] initWithName:key value:obj];
        [itemArray addObject:item];
    }];
    components.queryItems = itemArray.copy;
    NSLog(@"跳转lwa----%@", components.URL.absoluteString);
    [[UIApplication sharedApplication] openURL:components.URL options:@{} completionHandler:nil];
}

@end
