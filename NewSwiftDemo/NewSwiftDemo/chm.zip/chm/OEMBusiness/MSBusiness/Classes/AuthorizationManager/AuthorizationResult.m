//
//  AuthorizationResult.m
//  MSBusiness
//
//  Created by pactera on 2021/2/22.
//

#import "AuthorizationResult.h"

NSString *const MSBusinessAuthorizationErrorDomain = @"MSBusinessAuthorizationErrorDomain";

@implementation AuthorizationResult

@end
