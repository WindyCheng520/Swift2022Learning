//
//  MSRequestFailView.h
//  OEMFoundation
//
//  Created by pactera on 2020/11/24.
//

#import <UIKit/UIKit.h>


@interface MSRequestFailView : UIView

@property (nonatomic, copy) dispatch_block_t clickButtonBlock;


@end

