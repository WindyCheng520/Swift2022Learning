//
//  MSRequestFailView.m
//  OEMFoundation
//
//  Created by pactera on 2020/11/24.
//  加载网络数据失败视图

#import "MSRequestFailView.h"
#import "MSBusinessBundle.h"
#import <OEMTheme/UILabel+OEMThemes.h>

@interface MSRequestFailView ()

@property (nonatomic, strong) HGImageView *iconImageView;
@property (nonatomic, strong) HGLabel *titleLabel;
@property (nonatomic, strong) HGButton *clickButton;

@end

@implementation MSRequestFailView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor clearColor];
        
        self.iconImageView = [HGImageView new];
        self.iconImageView.image =  MSResourceImage(@"pic_empty_light");
        [self addSubview:self.iconImageView];
        
        self.titleLabel = [HGLabel new];
        self.titleLabel.font = [UIFont systemFontOfSize:14 weight: UIFontWeightMedium];
        self.titleLabel.textColor = RGB_HEX(0x666666);
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.numberOfLines = 0;
        self.titleLabel.text = MSResourceString(@"global_loading_fail");
        [self addSubview:self.titleLabel];
        
        self.clickButton = [HGButton new];
        [self.clickButton setTitleColor:RGB_HEX(0xffffff) forState:UIControlStateNormal];
        self.clickButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
        [self.clickButton setTitle:MSResourceString(@"global_connect_request_fail_retry") forState:UIControlStateNormal];
        self.clickButton.layer.cornerRadius = 22;
        self.clickButton.contentEdgeInsets = UIEdgeInsetsMake(0, 16, 0, 16);
        [self.clickButton setBackgroundColor:RGB_HEX(0x267AFF)];
        [self.clickButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:self.clickButton];
        [self makeConstraints];
        [self configureOEMTheme];
        
    }
    return self;
}

- (void)configureOEMTheme{
    [self.titleLabel configure90TranslucentTrait];
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        [weakSelf setImageView];
    } callImmidiately:YES];
}


-(void)setImageView{
    if (OEMThemeIsDarkMode) {
        self.iconImageView.image = MSResourceImage(@"pic_empty_dm");
    }else{
        self.iconImageView.image = MSResourceImage(@"pic_empty_light");
    }
}


- (void)makeConstraints {
    CGFloat width = ceil([self.clickButton.titleLabel.text boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, 44) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:self.clickButton.titleLabel.font} context:nil].size.width+16*2);
    width = MAX(width, 120);
    width = MIN(width, self.bounds.size.width-48*2);
    
//    CGFloat height = ceil([self.titleLabel.text boundingRectWithSize:CGSizeMake(self.bounds.size.width-48*2, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:self.titleLabel.font} context:nil].size.height);
    
    CGRect frame = self.frame;
    frame.size.height = 148 + 14 + 20 + 38 + 44;
    self.frame = frame;
    
    [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(148, 148));
        make.top.mas_equalTo(0);
        make.centerX.equalTo(self);
    }];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.iconImageView.mas_bottom).offset(14);
        make.leading.equalTo(self).offset(48);
        make.trailing.equalTo(self).offset(-48);
        make.height.mas_equalTo(20);
    }];
    [self.clickButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(44);
        make.bottom.equalTo(self);
        make.centerX.equalTo(self);
        make.width.mas_equalTo(width);
    }];
    
}

- (void)clickButton:(HGButton *)sender {
    safeCallBlock(self.clickButtonBlock);
}

@end
