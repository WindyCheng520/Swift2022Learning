//
//  OEMCommomAlertViewController.m
//  MSDevice
//
//  Created by WindyCheng on 2022/3/15.
//

#import "OEMCommomAlertViewController.h"
#import "MSBusinessBundle.h"
#import <OEMTheme/UILabel+OEMThemes.h>
#import <MSBusiness/OEMGlobalUIManager.h>

@interface OEMCommomAlertViewController ()
@property (nonatomic, copy)NSArray *buttons;
@property (nonatomic, assign)BOOL isMiddleTheme;        //是否按钮背景是主题色

@property (nonatomic, strong) HGView *backView;          //容器
@property (nonatomic, strong) HGLabel *titleLabel;       //标题
@property (nonatomic, strong) HGLabel *contentLabel;      //内容

@property (nonatomic, copy)NSString *itemTitle;

@property (nonatomic, copy)NSString *content;


@property (nonatomic, strong) HGButton *leftButton;

@property (nonatomic, strong) HGButton *middleButton;

@property (nonatomic, strong) HGButton *rightButton;

@property (nonatomic, copy)NSString *leftButtonTitle;

@property (nonatomic, copy)NSString *mideleButtonTitle;

@property (nonatomic, copy)NSString *rightButtonTitle;



@end

@implementation OEMCommomAlertViewController


+(instancetype)alertControllerWithTitle:(NSString *)title
                                content:(NSString *)content
                                buttons:(NSArray *)buttons
                           isMiddleTheme:(BOOL)isMiddleTheme{
    OEMCommomAlertViewController *alert = [[OEMCommomAlertViewController alloc] init];
    alert.itemTitle = title;
    alert.content = content;
    alert.buttons = buttons;
    if(buttons.count == 1){
        alert.mideleButtonTitle = buttons.firstObject;
    }else{
        alert.leftButtonTitle =  buttons.firstObject;
        alert.rightButtonTitle =  buttons.lastObject;
    }
    alert.isMiddleTheme = isMiddleTheme;
    alert.modalPresentationStyle =  UIModalPresentationOverFullScreen;
    return alert;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithWhite:0 alpha:0.6];
    [self configSubviews];
    [self makeConstraints];
    [self configureOEMTheme];
}

- (void)configSubviews{
    self.backView = [HGView new];
    self.backView.backgroundColor = RGBA_HEX(0xffffff, 1.0f);
    self.backView.layer.cornerRadius = 20.f;
    [self.view addSubview:self.backView];
    
    
    self.titleLabel = [HGLabel new];
    self.titleLabel.font = kSemiboldFont(16);
    self.titleLabel.textColor = RGB_HEX(0x000000);
    self.titleLabel.text = self.itemTitle;
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.numberOfLines = 0;
    [self.titleLabel sizeToFit];
    [self.backView addSubview:self.titleLabel];
    
    
    self.contentLabel = [HGLabel new];
    self.contentLabel.font = kSemiboldFont(15);
    self.contentLabel.textColor = RGB_HEX(0x000000);
    self.contentLabel.text = self.content;
    self.contentLabel.textAlignment = NSTextAlignmentCenter;
    self.contentLabel.numberOfLines = 0;
    [self.contentLabel sizeToFit];
    [self.backView addSubview:self.contentLabel];
    
    
    
    
    self.leftButton = [HGButton new];
    self.leftButton.clipsToBounds = YES;
    self.leftButton.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
    self.leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    self.leftButton.titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.leftButton setTitle:self.leftButtonTitle forState:UIControlStateNormal];
    self.leftButton.backgroundColor = [UIColor clearColor];
    self.leftButton.layer.borderColor = kDarkText.mainColor.CGColor;
    self.leftButton.layer.borderWidth = 1.0;
    self.leftButton.titleEdgeInsets = UIEdgeInsetsMake(5, 10, 5, 10);
    self.leftButton.titleLabel.font = kRegularFont(18);
    [self.leftButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
    self.leftButton.backgroundColor = RGB_HEX(0xFFFFFF);
    [self.leftButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.backView addSubview:self.leftButton];
    

    self.rightButton = [HGButton new];
    self.rightButton.clipsToBounds = YES;
    self.rightButton.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
    self.rightButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    self.rightButton.titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.rightButton setTitle:self.rightButtonTitle forState:UIControlStateNormal];
    self.rightButton.titleEdgeInsets = UIEdgeInsetsMake(5, 10, 5, 10);
    self.rightButton.titleLabel.font = kRegularFont(18);
    [self.rightButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
    self.rightButton.backgroundColor = kBusiness.brandColor;
    [self.rightButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.backView addSubview:self.rightButton];
    
    
    
    self.middleButton = [HGButton new];
    self.middleButton.clipsToBounds = YES;
    self.middleButton.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
    self.middleButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    self.middleButton.titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.middleButton setTitle:self.mideleButtonTitle forState:UIControlStateNormal];
    self.middleButton.titleEdgeInsets = UIEdgeInsetsMake(5, 10, 5, 10);
    self.middleButton.titleLabel.font = kRegularFont(18);
    [self.middleButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
    
    if(self.isMiddleTheme){
        self.middleButton.backgroundColor = kBusiness.brandColor;
    }else{
        self.middleButton.layer.borderColor = kDarkText.mainColor.CGColor;
        self.middleButton.layer.borderWidth = 1.0;
    }
   
    [self.middleButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.backView addSubview:self.middleButton];
    
    
    [self makeConstraints];
    [self configureOEMTheme];
}

- (void)configureOEMTheme{
  //  [self configureThemeTag:OEMThemesTag_UIView_Background];
    [self.backView configureThemeTag:OEMThemesTag_UIView_Foreground];

    [self.titleLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.mainTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.mainTextColor
    }];
    
    [self.contentLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.secondColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.secondColor
    }];
    
    
    [self.leftButton specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : kBusiness.brandColor
    } lightModeProperties:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : kBusiness.brandColor
    }];
    
    
    [self.rightButton specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : RGB_HEX(0xFFFFFF)
    } lightModeProperties:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : RGB_HEX(0xFFFFFF)
    }];
    
    [self.leftButton specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIButton_Background) : kDarkModeLayoutColor.cardBackgroundColor
    } lightModeProperties:@{
        @(OEMThemesTag_UIButton_Background) : kLightModeLayout.cardBackgroundColor
    }];
    
    
    if (self.isMiddleTheme) {
        [self.middleButton specialPropertiesForDarkMode:@{
            @(OEMThemesTag_UIButton_TitleThemeColor) : RGB_HEX(0xFFFFFF)
        } lightModeProperties:@{
            @(OEMThemesTag_UIButton_TitleThemeColor) : RGB_HEX(0xFFFFFF)
        }];
        
        [self.middleButton specialPropertiesForDarkMode:@{
            @(OEMThemesTag_UIButton_Background) : kDarkModeLayoutColor.cardBackgroundColor
        } lightModeProperties:@{
            @(OEMThemesTag_UIButton_Background) : kLightModeLayout.cardBackgroundColor
        }];
        
    }else{
        [self.middleButton specialPropertiesForDarkMode:@{
            @(OEMThemesTag_UIButton_TitleThemeColor) : kBusiness.brandColor
        } lightModeProperties:@{
            @(OEMThemesTag_UIButton_TitleThemeColor) : kBusiness.brandColor
        }];
    }
    
}

- (void)makeConstraints{
    
    CGFloat width = SCREEN_SCALE_WIDTH(320);
    BOOL  hasContent = (self.content.length > 0);
    
    [self.backView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(width);
        make.center.centerX.mas_equalTo(self.view);
        make.center.centerY.mas_equalTo(self.view);
    }];
    
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.backView).offset(30);
        make.leading.equalTo(self.backView).offset(24);
        make.trailing.equalTo(self.backView).offset(-24);
    }];
    
    if (hasContent) {
        [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.titleLabel.mas_bottom).offset(15);
            make.leading.equalTo(self.backView).offset(24);
            make.trailing.equalTo(self.backView).offset(-24);
        }];
    }

    
    if (self.buttons.count > 1) {
   
    
    CGFloat leftW = (width) * 0.5 - 26;
    CGRect leftLabelTitleSize = [self.leftButtonTitle boundingRectWithSize:CGSizeMake(leftW, 200)
                                                                   options:NSStringDrawingUsesLineFragmentOrigin
                                                                attributes:@{NSFontAttributeName:kRegularFont(18)} context:nil];
    CGFloat leftHeiht = leftLabelTitleSize.size.height;
    if (leftHeiht <= 44) {
        leftHeiht = 44;
    }else{
        leftHeiht = leftHeiht + 20;
    }
    
    
    
    CGFloat rightW = (width) * 0.5 - 26;
    CGRect rightLabelTitleSize = [self.rightButtonTitle boundingRectWithSize:CGSizeMake(rightW, 200)
                                                                     options:NSStringDrawingUsesLineFragmentOrigin
                                                                  attributes:@{NSFontAttributeName:kRegularFont(18)} context:nil];
    CGFloat rightHeiht = rightLabelTitleSize.size.height;
    if (rightHeiht <= 44) {
        rightHeiht = 44;
    }else{
        rightHeiht = rightHeiht + 20;
    }
    
    CGFloat commomHeight = MAX(leftHeiht, rightHeiht);
    self.leftButton.layer.cornerRadius = commomHeight * 0.5;
    [self.leftButton mas_makeConstraints:^(MASConstraintMaker *make) {
        if (hasContent) {
            make.top.equalTo(self.contentLabel.mas_bottom).offset(30);
        }else{
            make.top.equalTo(self.titleLabel.mas_bottom).offset(30);
        }
        make.leading.mas_equalTo(self.backView.mas_leading).offset(20);
        make.trailing.mas_equalTo(self.backView.mas_centerX).offset(-6);
        make.height.mas_equalTo(commomHeight);
    }];
    
    self.rightButton.layer.cornerRadius = commomHeight * 0.5;
    [self.rightButton mas_makeConstraints:^(MASConstraintMaker *make) {
        if (hasContent) {
            make.top.equalTo(self.contentLabel.mas_bottom).offset(30);
        }else{
            make.top.equalTo(self.titleLabel.mas_bottom).offset(30);
        }
        make.leading.mas_equalTo(self.backView.mas_centerX).offset(6);
        make.trailing.mas_equalTo(self.backView.mas_trailing).offset(-20);
        make.height.mas_equalTo(commomHeight);
    }];
   
    }
    
    
    if (self.mideleButtonTitle.length > 0) {
        CGFloat middleW = (width) * 0.5 - 26;
        CGRect middleLabelTitleSize = [self.mideleButtonTitle boundingRectWithSize:CGSizeMake(middleW, 200)
                                                                       options:NSStringDrawingUsesLineFragmentOrigin
                                                                    attributes:@{NSFontAttributeName:kRegularFont(18)} context:nil];
        CGFloat middleHeiht = middleLabelTitleSize.size.height;
        if (middleHeiht <= 44) {
            middleHeiht = 44;
        }else{
            middleHeiht = middleHeiht + 20;
        }
        
        self.middleButton.layer.cornerRadius = middleHeiht * 0.5;
        [self.middleButton mas_makeConstraints:^(MASConstraintMaker *make) {
            
            if (hasContent) {
                make.top.equalTo(self.contentLabel.mas_bottom).offset(30);
            }else{
                make.top.equalTo(self.titleLabel.mas_bottom).offset(30);
            }
            
            make.leading.mas_equalTo(self.backView.mas_leading).offset(20);
            make.trailing.mas_equalTo(self.backView.mas_trailing).offset(-20);
            make.height.mas_equalTo(middleHeiht);
        }];
        
    }
    
    if (self.buttons.count == 1) {
        [self.backView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.middleButton.mas_bottom).offset(20);
        }];
    }else{
        [self.backView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.leftButton.mas_bottom).offset(20);
        }];
    }
}


-(void)clickButton:(UIButton*)sender{
    [self dismissViewControllerAnimated:NO completion:nil];
   if (sender == self.leftButton) {
       safeCallBlock(self.leftBlock);
   }else if (sender == self.rightButton){
       safeCallBlock(self.rightBlock);
   }else{
       safeCallBlock(self.middleBlock);
   }
}

-(void)dismiss{
    [self dismissViewControllerAnimated:NO completion:nil];
}


@end
