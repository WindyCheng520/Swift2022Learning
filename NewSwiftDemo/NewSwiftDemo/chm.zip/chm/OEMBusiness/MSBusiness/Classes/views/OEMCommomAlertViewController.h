//
//  OEMCommomAlertViewController.h
//  MSDevice
//
//  Created by WindyCheng on 2022/3/15.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface OEMCommomAlertViewController : UIViewController

@property (nonatomic, copy) dispatch_block_t leftBlock;
@property (nonatomic, copy) dispatch_block_t middleBlock;
@property (nonatomic, copy) dispatch_block_t rightBlock;

+(instancetype)alertControllerWithTitle:(NSString *)title
                                content:(NSString *)content
                                buttons:(NSArray *)buttons
                           isMiddleTheme:(BOOL)isMiddleTheme;

-(void)dismiss;

                                  

@end

NS_ASSUME_NONNULL_END
