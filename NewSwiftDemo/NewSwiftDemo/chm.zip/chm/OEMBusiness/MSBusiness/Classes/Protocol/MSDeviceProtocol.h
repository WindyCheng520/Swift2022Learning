//
//  MSDeviceProtocol.h
//  MSBusiness
//
//  Created by syp on 2020/6/10.
//

#ifndef MSMineProtocol_h
#define MSMineProtocol_h

#import <DolphinRouter/OEMServiceProtocol.h>
#import <MSBusiness/MSBusinessError.h>
#import <MSBusiness/MSDeviceConnectResult.h>
#import <MSBusiness/MSDeviceProductResult.h>
@class MSOEMCBPeripheral;
@protocol MSDeviceProtocol <OEMServiceProtocol>
//切换国家地区时调用
- (void)refreshCountryChannelRetrieveSuccess:(void (^)(void))success failure:(void (^)(MSBusinessError *error))failure;

//刷新设备名称，切换语言时调用
- (void)refreshApplianceTypeNameSuccess:(void (^)(NSString *name))success failure:(void (^)(MSBusinessError *error))failure;

- (NSString *)fetchApplianceTypeNameWithCategory:(NSString *)category;

- (void)fetchIotConnectInfoWithSN8:(NSString *)sn8 success:(void (^)(MSDeviceConnectResult *result))success failure:(void (^)(MSBusinessError *error))failure;

- (NSString *)fetchPasswordWithSsid:(NSString *)ssid;

- (void)modifyApplianceInfoWithApplicanceId:(NSString *)applianceId applianceName:(NSString *)name success:(void (^)(void))success failure:(void (^)(MSBusinessError *error))failure;

- (void)refreshApplianceTypeFromDCPSuccess:(void (^)(void))success failure:(void (^)(MSBusinessError *error))failure;

- (NSArray<MSDeviceProductResult *> *)fetchApplianceTypeFromDCP;

- (void)fetchApplianceCityCodeWithSuccess:(void(^)(void))success failure:(void (^)(MSBusinessError *error))failure;

//判断设备是否可以添加
- (BOOL)isAvailable:(MSOEMCBPeripheral *)per;

- (void)needsUpdateToBAuth:(void (^)(BOOL isSuccess, NSDictionary * data, NSError * error))completion;

@end

#endif /* MSDeviceProtocol */
