//
//  MSLoginProtocol.h
//  MSBusiness
//
//  Created by syp on 2020/6/10.
//

#ifndef MSLoginProtocol_h
#define MSLoginProtocol_h

#import <DolphinRouter/OEMServiceProtocol.h>

@protocol MSLoginProtocol <OEMServiceProtocol>

@optional
-(void)autoLoginWithCompletion:(dispatch_block_t _Nullable )completionBlock;

- (void)updateCountryNameAfterChangeLanguage;

- (void)performSettingLanguage:(NSString * _Nonnull)languageCode completion:(void (^_Nonnull)(BOOL success))completion;


-(void)thirdLoginWithChannel:(NSString * _Nonnull)channel completion:(void (^_Nonnull)(BOOL success, NSString * _Nullable accountInfo))completion;

@end

#endif /* MSLoginProtocol_h */
