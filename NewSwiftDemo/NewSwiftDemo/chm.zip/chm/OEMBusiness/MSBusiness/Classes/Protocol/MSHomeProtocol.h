//
//  MSHomeProtocol.h
//  Pods
//
//  Created by yanghy on 20/5/14.
//  Copyright © 2020年 Midea. All rights reserved.
//

#ifndef MSHomeProtocol_h
#define MSHomeProtocol_h

#import <DolphinRouter/OEMServiceProtocol.h>
#import <MSBusiness/MSDevicePluginResult.h>

typedef NS_ENUM(NSUInteger, KRNRouterResult) {
    KRNRouterResult_Success,                            //正确下载，可以正常路由
    KRNRouterResultNetworkError,                        //网络错误
    KRNRouterResult_DownloadTimeout = 1001,             //下载超时
    KRNRouterResult_FileError = 1101,                   //文件解压空文件夹
    KRNRouterResult_ConfigFileParseError = 1102,        //配置文件解析失败
    KRNRouterResult_ConfigFileNameEmpty = 1103,         //配置文件缺少name字段
    KRNRouterResult_PluginDirRemoveFail = 1104,         //原插件删除失败
    KRNRouterResult_PluginDirCopyFail = 1105,           //原插件拷贝失败
    KRNRouterResult_PluginUnzipFail = 1106,             //解压缩失败
    KRNRouterResult_PluginModuleNameFormatErr = 1107,   //RN moduleName错误
    KRNRouterResult_PluginDeviceTypeFormatErr = 1108,   //RN 对应设备类型格式错误
    KRNRouterResult_PluginDeviceModelFormatErr = 1109,  //RN 对应设备型号格式错误
    KRNRouterResult_PluginDeviceTypeMismatch = 1110,    //插件设备类型不匹配
    KRNRouterResult_PluginDeviceModelMismatch = 1111,   //插件设备型号不匹配
    KRNRouterResult_PluginNotupload = 1112,             //插件未上传
};

typedef void(^RNRouterCompletion)(KRNRouterResult result, id context);

@protocol MSHomeProtocol <OEMServiceProtocol>

//获取本地设备列表数据
- (NSArray *)getLocalDeviceInfo;
//获取指定型号的插件本地是否已经下载
- (MSDevicePluginResult *)getLocalPluginWithAppType:(NSString *)appType appModel:(NSString *)appModel;
//获取用户的设备数量
- (void)getUserDevicesCount:(void(^)(NSInteger count))countBlock;

/// 查询插件路由并跳转
/// @param params {thingModel: NSString, thingType: NSString} "thingModel": "000VR150",  "thingType": "0xB8"
- (void)reactNativePluginRouter:(id)params completion:(RNRouterCompletion)completion;


@end

#endif /* BHHomeProtocol_h */
