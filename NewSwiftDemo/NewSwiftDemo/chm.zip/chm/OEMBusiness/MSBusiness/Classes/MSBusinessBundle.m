//
//  MSBusinessBundle.m
//  MSHome
//
//  Created by syp on 2020/6/17.
//

#import "MSBusinessBundle.h"

@implementation MSBusinessBundle

+ (NSBundle *)currentBundle {
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *bundlePath = [bundle.resourcePath stringByAppendingPathComponent:@"MSBusiness.bundle"];
    return [NSBundle bundleWithPath:bundlePath];
}

@end
