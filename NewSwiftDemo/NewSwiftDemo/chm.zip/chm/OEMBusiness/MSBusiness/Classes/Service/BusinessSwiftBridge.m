//
//  BusinessSwiftBridge.m
//  MSBusiness
//
//  Created by Neil 韦学宁 on 2022/3/9.
//

#import "BusinessSwiftBridge.h"
#import "MSLoginProtocol.h"
#import <OEMFoundation/OEMFoundation-Swift.h>
#import <OEMLogger/OEMOCLog.h>

@implementation BusinessSwiftBridge

+ (instancetype)sharedInstance{
    static BusinessSwiftBridge * bridge = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        bridge = [BusinessSwiftBridge new];
    });
    return bridge;
}

+ (void)handleAutoLogin:(os_block_t)block{
    
    id<MSLoginProtocol> loginService = [OEMRouter getServiceInstance:@protocol(MSLoginProtocol)];
    if (loginService) {
        [loginService autoLoginWithCompletion:block];
    }
}

@end

@interface BusinessSwiftBridge(BaseServiceProtocolIMPL)<BaseServiceProtocol>

@end

@implementation BusinessSwiftBridge (BaseServiceProtocolIMPL)

- (void)logWithInfo:(NSString *)info{
    OEMLogInfo(@"MSBusiness/Net", @"%@", info);
}

@end


