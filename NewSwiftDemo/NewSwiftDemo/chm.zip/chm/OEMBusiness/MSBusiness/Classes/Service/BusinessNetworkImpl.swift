//
//  BusinessNetworkImpl.swift
//  MSBusiness
//
//  Created by Neil 韦学宁 on 2022/3/9.
//

import Foundation
import OEMFoundation
import OEMLogger

@objc
public class BusinessNetworkImpl: NSObject{
    
    private static let impl = BusinessNetworkImpl()
    
    @objc
    public class func sharedInstance() -> BusinessNetworkImpl{
        return impl
    }
}

private let BusinessSessionAccountForceLogout = 14005
private let BusinessSessionExpireCode         = 12001
private let BusinessSessionHttpSuccessCode    = 12001

extension BusinessNetworkImpl: BusinessRequestProtocol{

    public func configureSSLPinning() {
        let configure = ["us.dollin.net" : "us.dollin.net"]
        OFRequestManager.manager.configureSessionWithServerTrust(domainsAndCerName: configure)
    }
    
    public func configureResponseInterceptor() {
        OFRequestManager.manager .configureResponseInterceptor { input in
            guard let cast = input as? [String: Any] else{
                return input
            }
            guard let code = cast["code"] as? NSNumber else{
                return input
            }
            if code.intValue == BusinessSessionAccountForceLogout{
                let info = ["title": cast["msg"] ?? ""]
                NotificationCenter.default.post(name: NSNotification.Name.mideaForceLogout, object: nil, userInfo: info)
                return nil
            }
            if code.intValue == BusinessSessionExpireCode{
                //do nothing
            }
            return input
        }
    }
    
    public func configureErrorInterceptor() {
        OFRequestManager.manager.configureErrorInterceptor { error, response, request in
            let e = error as NSError
            OEMLogTools.logInfo(module: "MSBusiness/Net", format: "ErrorInterceptor * :\(error)")
            if e.code == 999999 || e.code == -1009 || e.code == -1001 || e.code == -1020 || e.code == 13 {
                let s = String.BusinessLocalizeString(key: "network_disconnect_tip", tableName: nil)
                return NSError(domain: e.domain, code: e.code, userInfo: [NSLocalizedDescriptionKey : s])
            }else if (e.code == OFErrorInterceptorCode.serverError_Not2xx.rawValue){
                if let r = response {
                    OEMLogTools.logInfo(module: "MSBusiness/Net", format: " * HTTP statusCode:\(r.statusCode) ❌")
                }
                //如果是ToB业务token失效，这里触发一次刷新token
                if let url = request?.url?.absoluteString,
                   url.contains(MSAppInfo.mucBaseUrl()),
                   url.contains("/open/business"),
                   let d = OEMRouter.getServiceInstance(MSDeviceProtocol.self) as? MSDeviceProtocol,
                   let r = response, r.statusCode == 401{
                    OEMLogTools.logInfo(module: "MSBusiness/Net", format: " * ToB trigger authorized")
                    d.needsUpdate(toBAuth: { _, _, _ in
                    })
                }
                let s = String.BusinessLocalizeString(key: "network_request_error_tip", tableName: nil) + " HttpCode:\(response?.statusCode ?? e.code)"
                return NSError(domain: e.domain, code: e.code, userInfo: [NSLocalizedDescriptionKey : s])
            }
            return error
        }
    }
    
    public func handleUserSessionExpired(_ block: os_block_t?) {
        guard let b = block else{
            return
        }
        BusinessSwiftBridge.handleAutoLogin(b)
    }
}


extension String{
    public static func BusinessLocalizeString(key: String, tableName: String?, bundleName: String = "Business.bundle") -> String{
        guard let bundle = Bundle.getBundleInMain(name: bundleName) else{
            return ""
        }
        let language = HGInternationalization.sharedInstance().currentLanguage.code
        let lprojPath = bundle.path(forResource: language, ofType: "lproj")
        guard let p = lprojPath,
              let lprojBundle = Bundle(path: p) else{
            return ""
        }
        return lprojBundle.localizedString(forKey: key, value: nil, table: tableName)
    }
}
