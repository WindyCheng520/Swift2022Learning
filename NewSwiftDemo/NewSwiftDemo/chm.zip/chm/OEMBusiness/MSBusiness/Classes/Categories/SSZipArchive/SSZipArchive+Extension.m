//
//  SSZipArchive+Extension.m
//  midea
//
//  Created by MaYifang on 16/6/12.
//  Copyright © 2016年 Midea. All rights reserved.
//

#import "SSZipArchive+Extension.h"

@implementation SSZipArchive (Extension)


#pragma mark - 文件解压缩
+ (BOOL)unzipWithZip:(NSString *)zip toPath:(NSString *)path
{
    BOOL zipSuccess = NO;
    NSError *error;
    
    NSString *tempFolderName = [NSString stringWithFormat:@"%ld%ld%ld",[[NSThread currentThread] hash],zip.hash,path.hash];
    
    NSString *tempFolderPath = [NSTemporaryDirectory() stringByAppendingPathComponent:tempFolderName];
    
    NSFileManager *fileMgr = [NSFileManager defaultManager];
    
   BOOL result = [fileMgr createDirectoryAtPath:tempFolderPath withIntermediateDirectories:YES attributes:nil error:&error];
    if (!result && error) {
        NSLog(@"unzipWithZip:%@ topath:%@ error:%@",zip,path,error);
        return NO;
    }
    
    //在内存中解压缩文件
    if([self unzipFileAtPath:zip toDestination:tempFolderPath])
    {
        NSArray * dirArray = [fileMgr contentsOfDirectoryAtPath:tempFolderPath error:nil];
        for (NSString *itemFileName in dirArray) {
            NSString *itemPath = [tempFolderPath stringByAppendingPathComponent:itemFileName];
            NSString *toPath = [path stringByAppendingPathComponent:itemFileName];
            if([fileMgr fileExistsAtPath:toPath]){
                [fileMgr removeItemAtPath:toPath error:nil];
            }
            [fileMgr moveItemAtPath:itemPath toPath:toPath error:nil];
        }
        zipSuccess = YES;
        BOOL bRet = [fileMgr fileExistsAtPath:zip];
        if (bRet) {
            NSError *err;
            [fileMgr removeItemAtPath:zip error:&err];
        }
    } else {
        NSError *err;
        [fileMgr removeItemAtPath:zip error:&err];
    }
    [fileMgr removeItemAtPath:tempFolderPath error:nil];
    return zipSuccess;
}

@end
