//
//  UIControl+JKBlock.m
//  FXCategories
//
//  Created by fox softer on 15/2/23.
//  Copyright (c) 2015年 foxsofter. All rights reserved.
//

#import "UIControl+OEMBusinessBlock.h"
#import <objc/runtime.h>


// UIControlEventTouchDown           = 1 <<  0,      // on all Touch downs
// UIControlEventTouchDownRepeat     = 1 <<  1,      // on multiple Touchdowns
// (tap count > 1)
// UIControlEventTouchDragInside     = 1 <<  2,
// UIControlEventTouchDragOutside    = 1 <<  3,
// UIControlEventTouchDragEnter      = 1 <<  4,
// UIControlEventTouchDragExit       = 1 <<  5,
// UIControlEventTouchUpInside       = 1 <<  6,
// UIControlEventTouchUpOutside      = 1 <<  7,
// UIControlEventTouchCancel         = 1 <<  8,
//
// UIControlEventValueChanged        = 1 << 12,     // sliders, etc.
//
// UIControlEventEditingDidBegin     = 1 << 16,     // UITextField
// UIControlEventEditingChanged      = 1 << 17,
// UIControlEventEditingDidEnd       = 1 << 18,
// UIControlEventEditingDidEndOnExit = 1 << 19,     // 'return key' ending
// editing
//
// UIControlEventAllTouchEvents      = 0x00000FFF,  // for Touch events
// UIControlEventAllEditingEvents    = 0x000F0000,  // for UITextField
// UIControlEventApplicationReserved = 0x0F000000,  // range available for
// application use
// UIControlEventSystemReserved      = 0xF0000000,  // range reserved for
// internal framework use
// UIControlEventAllEvents           = 0xFFFFFFFF

#define JK_UICONTROL_EVENT(methodName, eventName)                                \
-(void)methodName : (void (^)(void))eventBlock {                              \
    objc_setAssociatedObject(self, @selector(methodName:), eventBlock, OBJC_ASSOCIATION_COPY_NONATOMIC);\
    [self addTarget:self                                                        \
    action:@selector(methodName##Action:)                                       \
    forControlEvents:UIControlEvent##eventName];                                \
}                                                                               \
-(void)methodName##Action:(id)sender {                                        \
    void (^block)(void) = objc_getAssociatedObject(self, @selector(methodName:));  \
    if (block) {                                                                \
        block();                                                                \
    }                                                                           \
}

@interface UIControl ()

@end

@implementation UIControl (OEMBusinessBlock)

JK_UICONTROL_EVENT(oem_businessTouchDown, TouchDown)
JK_UICONTROL_EVENT(oem_businessTouchDownRepeat, TouchDownRepeat)
JK_UICONTROL_EVENT(oem_businessTouchDragInside, TouchDragInside)
JK_UICONTROL_EVENT(oem_businessTouchDragOutside, TouchDragOutside)
JK_UICONTROL_EVENT(oem_businessTouchDragEnter, TouchDragEnter)
JK_UICONTROL_EVENT(oem_businessTouchDragExit, TouchDragExit)
JK_UICONTROL_EVENT(oem_businessTouchUpInside, TouchUpInside)
JK_UICONTROL_EVENT(oem_businessTouchUpOutside, TouchUpOutside)
JK_UICONTROL_EVENT(oem_businessTouchCancel, TouchCancel)
JK_UICONTROL_EVENT(oem_businessValueChanged, ValueChanged)
JK_UICONTROL_EVENT(oem_businessEditingDidBegin, EditingDidBegin)
JK_UICONTROL_EVENT(oem_businessEditingChanged, EditingChanged)
JK_UICONTROL_EVENT(oem_businessEditingDidEnd, EditingDidEnd)
JK_UICONTROL_EVENT(oem_businessEditingDidEndOnExit, EditingDidEndOnExit)

//- (void)TouchUpInside:(void (^)(void))eventBlock {
//   objc_setAssociatedObject(self, @selector(TouchUpInside:, eventBlock, OBJC_ASSOCIATION_COPY_NONATOMIC);
//  [self addTarget:self action:@selector(TouchUpInsideAction:)
//  forControlEvents:UIControlEventTouchUpInside];
//}
//- (void)TouchUpInsideAction:(id)sender {
//  void (^block)() = objc_getAssociatedObject(self, @selector(TouchUpInsideAction:));
//  if (block) {
//    block();
//  }
//}

@end
