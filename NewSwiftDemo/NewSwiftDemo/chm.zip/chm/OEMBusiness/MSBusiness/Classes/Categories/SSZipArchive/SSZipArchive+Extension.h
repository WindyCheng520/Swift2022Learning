//
//  SSZipArchive+Extension.h
//  midea
//
//  Created by MaYifang on 16/6/12.
//  Copyright © 2016年 Midea. All rights reserved.
//

#import <SSZipArchive/SSZipArchive.h>

@interface SSZipArchive (Extension)

//加压缩文件
+ (BOOL)unzipWithZip:(NSString *)zip toPath:(NSString *)path;


@end
