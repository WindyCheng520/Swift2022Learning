//
//  UIControl+JKBlock.h
//  FXCategories
//
//  Created by fox softer on 15/2/23.
//  Copyright (c) 2015年 foxsofter. All rights reserved.
//  https://github.com/foxsofter/FXCategories
//  http://stackoverflow.com/questions/2437875/target-action-uicontrolevents
#import <UIKit/UIKit.h>

@interface UIControl (OEMBusinessBlock)

- (void)oem_businessTouchDown:(void (^)(void))eventBlock;
- (void)oem_businessTouchDownRepeat:(void (^)(void))eventBlock;
- (void)oem_businessTouchDragInside:(void (^)(void))eventBlock;
- (void)oem_businessTouchDragOutside:(void (^)(void))eventBlock;
- (void)oem_businessTouchDragEnter:(void (^)(void))eventBlock;
- (void)oem_businessTouchDragExit:(void (^)(void))eventBlock;
- (void)oem_businessTouchUpInside:(void (^)(void))eventBlock;
- (void)oem_businessTouchUpOutside:(void (^)(void))eventBlock;
- (void)oem_businessTouchCancel:(void (^)(void))eventBlock;
- (void)oem_businessValueChanged:(void (^)(void))eventBlock;
- (void)oem_businessEditingDidBegin:(void (^)(void))eventBlock;
- (void)oem_businessEditingChanged:(void (^)(void))eventBlock;
- (void)oem_businessEditingDidEnd:(void (^)(void))eventBlock;
- (void)oem_businessEditingDidEndOnExit:(void (^)(void))eventBlock;

@end
