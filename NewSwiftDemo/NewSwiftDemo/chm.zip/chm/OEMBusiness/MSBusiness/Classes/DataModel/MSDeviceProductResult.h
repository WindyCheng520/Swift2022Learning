//  
//  MSDeviceProductResult.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/10
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <Foundation/Foundation.h>

@interface MSDeviceProductResult : NSObject

@property(nonatomic, copy) NSString *appOrder;
@property(nonatomic, copy) NSString *category;
@property(nonatomic, copy) NSString *pId;
@property(nonatomic, copy) NSString *imgUrl;
@property(nonatomic, copy) NSString *typeName;


@end
