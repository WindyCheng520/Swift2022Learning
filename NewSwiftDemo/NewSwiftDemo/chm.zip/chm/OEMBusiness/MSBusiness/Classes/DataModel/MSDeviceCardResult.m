//
//  MSDeviceCardResult.m
//  MSHome
//
//  Created by 及时行乐 on 2020/7/17.
//

#import "MSDeviceCardResult.h"
#import <objc/runtime.h>
#import <MJExtension/MJExtension.h>
#import "MideaSecurity.h"
#import "MSUserInfoManager.h"


@implementation Home
@end


@implementation Binder
@end

@implementation MSDeviceCardExtras
@end

@implementation MSDeviceCardResult

MJExtensionCodingImplementation

- (id)copyWithZone:(NSZone *)zone {
    id obj = [[[self class] allocWithZone:zone] init];
    [self.class mj_enumerateProperties:^(MJProperty *property, BOOL *stop) {
        id value = [self valueForKey:property.name];
        [obj setValue:value forKey:property.name];
    }];
    return obj;
}

-(NSString *)uid{
    if (!_uid) {
        _uid = _binder.uid;
    }
    return _uid;
}

-(NSUInteger)relType{
    return _binder.relType;
}

- (int)safeIntCast:(id)obj{
    if ([obj isKindOfClass:[NSNumber class]]) {
        NSNumber * num = obj;
        return num.unsignedIntValue;
    }else if ([obj isKindOfClass:[NSString class]]){
        NSString * str = obj;
        return [str intValue];
    }
    return -1;
}

- (MSDeviceConnectedStatus)onlineStatus{
    int ret = [self safeIntCast:self.online_server];
    if (ret != -1) {
        return ret;
    }
    return MSDeviceConnectedStatus_Unknow;
}

- (MSDevicePowerStatus)powerStatus{
    int ret = [self safeIntCast:self.power_server];
    if (ret != -1) {
        return ret;
    }
    return MSDevicePowerStatus_Unknow;
}

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{
        @"deviceId" : @"thingId",
        @"name":@"thingName",
        @"firmwareVersion":@"firmwareVersion",
        @"sn8":@"model",
        @"online_server":@"online",
        @"power_server":@"power",
    };
}

+ (NSDictionary *)mj_objectClassInArray
{
    return @{
             @"extras": [MSDeviceCardExtras class]
             };
}

+ (NSArray<MSDeviceCardResult *> *)getDeviceCardResultFromLocalWithTableName:(NSString *)tablename {
//    NSArray *localArray = [MSDeviceCardResult bg_findAll:nil];
    NSArray *localArray = [NSArray bg_arrayWithName:tablename];
    if (localArray.count > 0) {
        for (MSDeviceCardResult *result in localArray) {
            if (result.isSecurity) {
                result.deviceId = [MideaSecurity getSensitiveDataFromLocal:result.deviceId];
                result.deviceType = [MideaSecurity getSensitiveDataFromLocal:result.deviceType];
                result.uid = [MideaSecurity getSensitiveDataFromLocal:result.uid];
                result.sn8 = [MideaSecurity getSensitiveDataFromLocal:result.sn8];
                result.sn = [MideaSecurity getSensitiveDataFromLocal:result.sn];
                result.name = [MideaSecurity getSensitiveDataFromLocal:result.name];
                result.localPlugin = [MSDevicePluginResult decryptDevicePluginResultForLocal:result.localPlugin];
                result.latestPlugin = [MSDevicePluginResult decryptDevicePluginResultForLocal:result.latestPlugin];
            }
        }
    }
    
    return localArray;
}

+ (void)clearDeviceCardResultFromLocalWithTableName:(NSString *)tablename {
//    [MSDeviceCardResult bg_clear:nil];
    [NSArray bg_clearArrayWithName:tablename];
}

+ (void)saveDeviceCardResultToLocal:(NSArray<MSDeviceCardResult *> *)resultArray tableName:(NSString *)tablename {
    [self clearDeviceCardResultFromLocalWithTableName:tablename];
    if (resultArray.count > 0) {
        NSMutableArray *saveArray = [NSMutableArray array];
        for (MSDeviceCardResult *resultItem in resultArray) {
            MSDeviceCardResult *result = [resultItem copy];
            //如果后端未返回相关用户ID，这里需要关联一下本地用户ID
            NSString *userID = result.uid;
            if (!userID || userID.length == 0) {
                userID = [MSUserInfoManager shareManager].userInfoModel.uid;
            }
            
            result.isSecurity = YES;
            result.deviceId = [MideaSecurity saveSensitiveDataToLocal:result.deviceId];
            result.deviceType = [MideaSecurity saveSensitiveDataToLocal:result.deviceType];
            result.uid = [MideaSecurity saveSensitiveDataToLocal:userID];
            result.sn8 = [MideaSecurity saveSensitiveDataToLocal:result.sn8];
            result.sn = [MideaSecurity saveSensitiveDataToLocal:result.sn];
            result.name = [MideaSecurity saveSensitiveDataToLocal:result.name];
            result.localPlugin = [MSDevicePluginResult encryptDevicePluginResultForLocal:result.localPlugin];
            result.latestPlugin = [MSDevicePluginResult encryptDevicePluginResultForLocal:result.latestPlugin];
            [saveArray addObject:result];
        }
//        [MSDeviceCardResult bg_saveOrUpdateArray:resultArray];
        [saveArray bg_saveArrayWithName:tablename];
    }
}



@end
