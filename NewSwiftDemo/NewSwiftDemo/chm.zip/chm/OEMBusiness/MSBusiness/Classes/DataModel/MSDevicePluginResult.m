//
//  MSDevicePluginResult.m
//  MSHome
//
//  Created by pactera on 2020/7/24.
//

#import "MSDevicePluginResult.h"
#import <MJExtension/MJExtension.h>
#import "MideaSecurity.h"

@implementation MSDevicePluginResult

MJExtensionCodingImplementation

- (id)copyWithZone:(NSZone *)zone {
    id obj = [[[self class] allocWithZone:zone] init];
    [self.class mj_enumerateProperties:^(MJProperty *property, BOOL *stop) {
        id value = [self valueForKey:property.name];
        [obj setValue:value forKey:property.name];
    }];
    return obj;
}

+ (NSArray* _Nonnull)bg_unionPrimaryKeys {
    return @[@"appType", @"appModel"];
}

+ (void)saveDevicePluginResultToLocal:(MSDevicePluginResult *)result {
    if (result) {
        MSDevicePluginResult *saveResult = [self encryptDevicePluginResultForLocal:[result copy]];
        [saveResult bg_saveOrUpdate];
    }
}

+ (void)saveAllDevicePluginResultToLocal:(NSArray<MSDevicePluginResult *> *)resultArray {
    [MSDevicePluginResult bg_clear:nil];
    
    NSMutableArray *saveArray = [NSMutableArray array];
    for (MSDevicePluginResult *result in resultArray) {
        MSDevicePluginResult *saveResult = [self encryptDevicePluginResultForLocal:[result copy]];
        [saveArray addObject:saveResult];
    }
    [MSDevicePluginResult bg_saveOrUpdateArray:saveArray];
}

+ (MSDevicePluginResult *)getDeviceCardLocalPluginWithAppType:(NSString *)appType appModel:(NSString *)appModel {
    appModel = [MideaSecurity saveSensitiveDataToLocal:appModel];
    appType = [MideaSecurity saveSensitiveDataToLocal:appType];
    NSString *where = [NSString stringWithFormat:@"where %@=%@ and %@=%@", bg_sqlKey(@"appType"), bg_sqlValue(appType), bg_sqlKey(@"appModel"), bg_sqlValue(appModel)];
    NSArray * resultArray = [MSDevicePluginResult bg_find:nil where:where];
    
    if (resultArray.count > 0) {
        MSDevicePluginResult *result = resultArray.firstObject;
        [self decryptDevicePluginResultForLocal:result];
        return result;
    } else {
        return nil;
    }
}

+ (NSArray<MSDevicePluginResult *> *)getAllDevicePluginDataFromLocal {
    NSArray *resultArray = [MSDevicePluginResult bg_findAll:nil];
    return resultArray;
}

+ (MSDevicePluginResult *)encryptDevicePluginResultForLocal:(MSDevicePluginResult *)result {
    if (result) {
        result.isSecurity = YES;
        result.appType = [MideaSecurity saveSensitiveDataToLocal:result.appType];
        result.appModel = [MideaSecurity saveSensitiveDataToLocal:result.appModel];
        result.url = [MideaSecurity saveSensitiveDataToLocal:result.url];
        result.localAddress = [MideaSecurity saveSensitiveDataToLocal:result.localAddress];
    }
    return result;
}

+ (MSDevicePluginResult *)decryptDevicePluginResultForLocal:(MSDevicePluginResult *)result {
    if (result && result.isSecurity) {
//    if (result) {
        result.appType = [MideaSecurity getSensitiveDataFromLocal:result.appType];
        result.appModel = [MideaSecurity getSensitiveDataFromLocal:result.appModel];
        result.url = [MideaSecurity getSensitiveDataFromLocal:result.url];
        result.localAddress = [MideaSecurity getSensitiveDataFromLocal:result.localAddress];
    }
    return result;
}




@end
