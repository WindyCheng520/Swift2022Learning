//
//  MSDeviceStatusDefine.h
//  Pods
//
//  Created by Neil 韦学宁 on 2021/12/14.
//

#ifndef MSDeviceStatusDefine_h
#define MSDeviceStatusDefine_h


typedef NS_ENUM(NSInteger, MSDeviceCardUpdateType) {
    MSDeviceCardUpdateType_No,             //不用更新
    MSDeviceCardUpdateType_Download,       //首次下载
    MSDeviceCardUpdateType_Update,         //更新
    MSDeviceCardUpdateType_ForceUpdate     //强制更新
};

typedef NS_ENUM(NSInteger, MSDeviceCardDownloadState) {
    MSDeviceCardDownloadState_Undownload,       //没有下载
    MSDeviceCardDownloadState_Downloading,      //正在下载
    MSDeviceCardDownloadState_Failed            //下载失败
};

//设备联网状态
typedef NS_ENUM(NSInteger, MSDeviceConnectedStatus) {
    MSDeviceConnectedStatus_Offline = 0,
    MSDeviceConnectedStatus_Online = 1,
    MSDeviceConnectedStatus_Unknow
};

//设备联网状态
typedef NS_ENUM(NSInteger, MSDeviceRelationType) {
    MSDeviceRelationType_Owner = 0,
    MSDeviceRelationType_Shared = 1,
};

//设备通电状态
typedef NS_ENUM(NSInteger, MSDevicePowerStatus) {
    MSDevicePowerStatus_Off = 0,
    MSDevicePowerStatus_On = 1,
    MSDevicePowerStatus_Unknow,
    MSDevicePowerStatus_Ignore,
};

//设备鉴权状态
typedef NS_ENUM(NSInteger, MSDeviceAuthStatus) {
    ////设备的确权信息 0已确权 1待确权 2未确权 3不支持确权 4未知
    MSDeviceAuthStatus_Authed = 0,
    MSDeviceAuthStatus_AuthWait = 1,
    MSDeviceAuthStatus_AuthNotAuth = 2,
    MSDeviceAuthStatus_AuthNotSupport = 3,
    MSDeviceAuthStatus_Unknow = 4,
};



#endif /* MSDeviceStatusDefine_h */
