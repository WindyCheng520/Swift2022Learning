//
//  MSDeviceAuthResult.h
//  MSDevice
//
//  Created by pactera on 2020/11/26.
//

#import <Foundation/Foundation.h>


@interface MSDeviceAuthResult : NSObject

@property (nonatomic, copy) NSString *category;     //配网品类编码
@property (nonatomic, copy) NSString *sn;         // sn8
@property (nonatomic, copy) NSString *confirmDesc;  // 指引文案
@property (nonatomic, copy) NSString *confirmImgUrl;// 指引图片
@property (nonatomic, copy) NSString *sourceSystem; // 来源系统

/*
{
            "id": 1,
            "deviceType": "0xE2",
            "subCategory": "510",
            "model": "10A06882",
            "guideType": 0,
            "guideContent": "[{\"guideContent\":\"配网介绍update\",\"guideURL\":\"http://配网update\"}]",
            "language": "zh_CN",
            "createTime": 1640269948000,
            "updateTime": 1640269948000
}
*/
@property (nonatomic , copy) NSString              *typeId;
@property (nonatomic , copy) NSString              *deviceType;   //品类
@property (nonatomic , copy) NSString              *subCategory;   //子类
@property (nonatomic , copy) NSString              *model;         //型号(SN8)
@property (nonatomic , copy) NSString              *guideType;    //指引分类，0配网，1重置，2确权
@property (nonatomic , strong) NSArray             *guideContent;  //指引内容数组
@property (nonatomic , copy) NSString              *language;      //语言code
@property (nonatomic , copy) NSString              *createTime;    //创建时间
@property (nonatomic , copy) NSString              *updateTime;    //更新时间


@end

