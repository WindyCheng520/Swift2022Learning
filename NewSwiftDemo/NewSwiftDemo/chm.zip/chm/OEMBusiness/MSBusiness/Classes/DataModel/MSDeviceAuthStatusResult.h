//
//  MSDeviceAuthStatusResult.h
//  MSBusiness
//
//  Created by pactera on 2020/11/26.
//

#import <Foundation/Foundation.h>


@interface MSDeviceAuthStatusResult : NSObject

@property (nonatomic, assign) NSInteger status;


@end

