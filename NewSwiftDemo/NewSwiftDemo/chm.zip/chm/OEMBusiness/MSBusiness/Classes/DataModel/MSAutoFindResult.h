//  
//  MSAutoFindResult.h
//  MSHome
//   
//  Created by 李 燕强 on 2020/7/24
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <Foundation/Foundation.h>
#import "BGFMDB.h"

@interface MSAutoFindResult : NSObject<BGProtocol, NSCoding, NSCopying>

@property (nonatomic, copy) NSString *bleProtcolVersion;
@property (nonatomic, copy) NSString *deviceName;
@property (nonatomic, copy) NSString *deviceSN8;
@property (nonatomic, copy) NSString *deviceSSID;
@property (nonatomic, copy) NSString *deviceSubType;
@property (nonatomic, copy) NSString *deviceType;
@property (nonatomic, copy) NSString *isWifiConfiged;
@property (nonatomic, copy) NSString *moduleType;
@property (nonatomic, copy) NSString *transportEnable;
@property (nonatomic, copy) NSString *wifiConfigEnable;


//蓝牙广播字典
@property (nonatomic, strong) NSDictionary *bleAdvDict;

@property (nonatomic, copy) NSString *originalModel;  //原始值型号（1-FF)值
@property (nonatomic, copy) NSString *model;  //映射真实型号(模组写死在固件中的8位字母+数字）

@property (nonatomic, copy) NSString *deviceMac;   //蓝牙mac地址
@property (nonatomic, strong) id peripheral;

/********以下不是接口返回数据*******/
@property (nonatomic, copy) NSString *dcpImageUrl;
@property (nonatomic, copy) NSString *cloudName;
@property (nonatomic, assign) BOOL isSecurity; //1.3.0版本开始数据有加密操作，为了兼容旧版本添加此字段标识数据是否有加密

+ (NSArray<MSAutoFindResult *> *)getTodayAllAutoFindResultWithTimeString:(NSString *)timeString;
+ (void)saveAllAutoFindResult:(NSArray<MSAutoFindResult *> *)resultArray;
+ (NSArray<MSAutoFindResult *> *)getAllAutoFindResultDataFromLocal;


@end
