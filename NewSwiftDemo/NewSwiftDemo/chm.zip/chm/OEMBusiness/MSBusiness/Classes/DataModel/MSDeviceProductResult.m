//  
//  MSDeviceProductResult.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/10
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSDeviceProductResult.h"
#import "BGFMDB.h"
#import <MJExtension/MJExtension.h>

@implementation MSDeviceProductResult



+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{
             @"category": @[@"deviceType", @"category"]};
}

@end
