//
//  DeviceMemoryTempStatus.m
//  MSHome
//
//  Created by Neil 韦学宁 on 2021/12/14.
//

#import "DeviceControlCenter.h"
#import "MSNotificationConst.h"
#import <MJExtension/MJExtension.h>

#define DeviceStatusKey_power                            @"power"
#define DeviceStatusKey_power_updaetTime                 @"power_updateTime"
#define DeviceStatusKey_targetTemp                       @"temperature"
#define DeviceStatusKey_targetTemp_updateTime            @"ttemperature_updaetTime"

#define DeviceStatusResetTime                            5

@interface DeviceStatusDescription : NSObject

@property(nonatomic, assign)CFTimeInterval createTime;

@property(nonatomic, strong)NSMutableDictionary * statusDetail;

@end

@implementation DeviceStatusDescription

- (instancetype)init{
    if (self = [super init]) {
        self.statusDetail = [NSMutableDictionary new];
    }
    return self;
}

- (void)enterEphemeralStatusWithKey:(NSString *)key{
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(wipeoutStatus:) object:nil];
    [self performSelector:@selector(wipeoutStatus:) withObject:key afterDelay:DeviceStatusResetTime];
}

- (void)wipeoutStatus:(NSString *)object{
    if (![object isKindOfClass:[NSString class]]) {
        return;
    }
    [self.statusDetail removeObjectForKey:object];
}

@end

@interface DeviceControlCenter()
@property(nonatomic, strong)NSMutableDictionary * statusMap;
@end

@implementation DeviceControlCenter

+ (instancetype)sharedInstance{
    static dispatch_once_t onceToken;
    static DeviceControlCenter * status = nil;
    dispatch_once(&onceToken, ^{
        status = [DeviceControlCenter new];
    });
    return status;
}

- (NSMutableDictionary *)statusMap{
    if (!_statusMap) {
        _statusMap = [NSMutableDictionary new];
    }
    return _statusMap;
}

- (void)setTemporaryState:(NSString *)thingCode power:(MSDevicePowerStatus)power{
    DeviceStatusDescription * status = [self.statusMap objectForKey:thingCode];
    if (!status) {
        status = [[DeviceStatusDescription alloc] init];
        status.createTime = CFAbsoluteTimeGetCurrent();
        [self.statusMap setObject:status forKey:thingCode];
    }
    [status.statusDetail setObject:@(power) forKey:DeviceStatusKey_power];
    [status.statusDetail setObject:@(CFAbsoluteTimeGetCurrent()) forKey:DeviceStatusKey_power_updaetTime];
    DDLogDeviceControlCenter(@"will store property:%@", status.statusDetail.mj_JSONString);
    [status enterEphemeralStatusWithKey:DeviceStatusKey_power];
    
    //开始倒计时
    [self beginRefreshDevicelistCountDown];
}

- (MSDevicePowerStatus)getTemporaryPowerStatusWithThingCode:(NSString *)thingCode{
    DeviceStatusDescription * status = [self.statusMap objectForKey:thingCode];
    if (status && status.statusDetail) {
        NSNumber * num = [status.statusDetail objectForKey:DeviceStatusKey_power];
        DDLogDeviceControlCenter(@"get store property:%@", status.statusDetail.mj_JSONString);
        if (num && [num isKindOfClass:[NSNumber class]]) {
            return num.integerValue;
        }
    }
    return MSDevicePowerStatus_Ignore;
}

- (void)beginRefreshDevicelistCountDown{
    //每次控制后，都开启一个倒计时，刷新设备列表
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(refreshDeviceList) object:nil];
    [self performSelector:@selector(refreshDeviceList) withObject:nil afterDelay:DeviceStatusResetTime];
}

- (void)refreshDeviceList{
    [[NSNotificationCenter defaultCenter] postNotificationName:kMideaDeviceListDataNeedReloadNotification object:nil];
}

+ (NSDictionary *)switchControlParamWithIsOn:(BOOL)isOn{
    return @{
        @"instruction": @{
                @"power": isOn ? @"1": @"0"
        }
    };
}

@end
