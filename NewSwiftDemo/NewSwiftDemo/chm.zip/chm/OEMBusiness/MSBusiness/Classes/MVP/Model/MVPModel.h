//
//  MVPModel.h
//  OEMFoundation
//
//  Created by syp on 2020/6/24.
//

#import <Foundation/Foundation.h>


@interface MVPModel : NSObject

@end

