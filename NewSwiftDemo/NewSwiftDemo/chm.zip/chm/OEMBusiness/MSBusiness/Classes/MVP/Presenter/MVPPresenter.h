//
//  HGBasePresenter.h
//  OEMFoundation
//
//  Created by syp on 2020/6/21.
//

#import <Foundation/Foundation.h>
#import "MVPViewProtocol.h"



@interface MVPPresenter<ViewClass:id<MVPViewProtocol>>: NSObject

//MVP中负责更新的视图
@property (nonatomic, weak) ViewClass view;

/**
 初始化函数

 @param view 要绑定的视图
 */
- (instancetype)initWithView:(ViewClass)view;

/**
 * 绑定视图
 * @param view 要绑定的视图
 */
- (void)attachView:(ViewClass)view;

/**
 解绑视图
 */
- (void)deattachView;

/**
 子类实现
 这个是对外的入口，通过这个入口，将控制权交给Presenter
 */
- (void)load;
- (void)unload;

@end
