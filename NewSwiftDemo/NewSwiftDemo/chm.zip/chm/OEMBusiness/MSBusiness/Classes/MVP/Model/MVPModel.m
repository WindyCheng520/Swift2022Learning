//
//  MVPModel.m
//  OEMFoundation
//
//  Created by syp on 2020/6/24.
//

#import "MVPModel.h"

@implementation MVPModel

@end
