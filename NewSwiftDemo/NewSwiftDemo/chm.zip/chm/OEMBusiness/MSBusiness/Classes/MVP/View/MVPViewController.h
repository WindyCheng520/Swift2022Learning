//
//  MVPViewController.h
//  MSBusiness
//
//  Created by syp on 2020/6/16.
//

#import "MVPViewProtocol.h"
#import <OEMFoundation/HGViewController.h>
#import "MVPPresenter.h"
#import "MVPViewProtocol.h"

@interface MVPViewController<PresenterClass:MVPPresenter *> : HGViewController <MVPViewProtocol>

@property (nonatomic, strong) PresenterClass presenter;


@end

