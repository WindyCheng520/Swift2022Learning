//
//  MSPresenterProtocol.h
//  OEMFoundation
//
//  Created by syp on 2020/6/21.
//


@protocol MVPViewProtocol <NSObject>

- (void)toastText:(NSString *)text;

- (void)showLoading;
- (void)hideLoading;

@end
