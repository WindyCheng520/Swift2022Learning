//
//  MVPViewController.m
//  MSBusiness
//
//  Created by syp on 2020/6/16.
//


#import "MVPViewController.h"
#import "MSUIConfiguration.h"


@interface MVPViewController() 

@end

@implementation MVPViewController

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [self.presenter attachView:self];
}

#pragma mark - HGBaseViewProtocol

- (void)toastText:(NSString *)text
{
    [MSUIConfiguration sh_showBlackToastHudToView:self.view text:text];
}

- (void)showLoading
{
    [MSUIConfiguration sh_showBlackLoadingHudToView:self.view];
}

- (void)hideLoading
{
    [MSUIConfiguration sh_hideAllHudForView:self.view animated:YES];
}

@end
