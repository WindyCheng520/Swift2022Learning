//
//  BusinessRequest.m
//  MSBusiness
//
//  Created by Neil 韦学宁 on 2022/1/21.
//

#import "BusinessRequest.h"

@implementation BusinessRequest

@end

@implementation BusinessUploadItem

@end
