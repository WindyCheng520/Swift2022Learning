//
//  MSRequestManager.m
//  MSBusiness
//
//  Created by syp on 2020/6/17.
//

#import "BusinessRequestManager.h"
#import "MSAppInfo.h"
#import "MSUserInfoManager.h"
#import <OEMFoundation/OEMFoundation-Swift.h>
#import "MSRequestManager_ToB_Private.h"
#import <MSBusiness/MSBusiness-Swift.h>
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCryptor.h>
#import <CommonCrypto/CommonHMAC.h>
#import <OEMLogger/OEMOCLog.h>

#import <OEMFoundation/HGInternationalization.h>
#import <OEMFoundation/NSDate+OEMExtension.h>


#define  MSRequestSessionExpireCode   12001    //token过期，||12002 错误token

@interface BusinessRequestManager ()
@end

@implementation BusinessRequestManager

#define BusinessNetworkLogSuccessBegin  @"\n\n * >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
#define BusinessNetworkLogSuccessEnd    @" * <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n\n"

#define BusinessNetworkLogFailBegin     @"\n\n * xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
#define BusinessNetworkLogFailEnd       @" * xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n\n"

#pragma mark - 初始化管理
+ (instancetype)sharedInstance
{
    static id instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.baseURL = @"";
    }
    return self;
}

- (void)setDelegate:(id)delegate{
    _delegate = delegate;
    [self initialConfig];
}

- (id<BusinessRequestProtocol>)getProtocolImpl{
    return self.delegate;
}

- (void)initialConfig
{
#if (AppStore_ENV==1 && UAT_ENV==0)
    if (self.delegate && [self.delegate respondsToSelector:@selector(configureSSLPinning)]) {
        [self.delegate configureSSLPinning];
    }
#endif

    if (self.delegate && [self.delegate respondsToSelector:@selector(configureResponseInterceptor)]) {
        [self.delegate configureResponseInterceptor];
    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(configureErrorInterceptor)]) {
        [self.delegate configureErrorInterceptor];
    }

}

- (void)setBaseURL:(NSString *)baseURL
{
    _baseURL = baseURL;
}

- (NSMutableDictionary *)addGenerateBodyParams:(NSDictionary *)parameters {
    //添加设置通用的请求体
    NSMutableDictionary *builtinBodys = [NSMutableDictionary dictionaryWithDictionary:parameters];
    return builtinBodys;
}

- (NSString *)getKeyValueStringWithUrl:(NSString *)url{
    NSArray *urlParams = [url componentsSeparatedByString:@"&"];
    NSMutableString *keyValueStrings;
    if (urlParams.count >=2) {
        keyValueStrings = [NSMutableString stringWithString:@""];
        NSMutableArray *list = [NSMutableArray arrayWithArray:urlParams];
        NSString *firstParam = [list objectAtIndex:0];
        [list removeObjectAtIndex:0];
        NSArray *headerArray =  [firstParam componentsSeparatedByString:@"?"];
        if (headerArray.count >= 2) {
            [list addObject:[headerArray lastObject]];
        }
        NSSortDescriptor *descriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES];
        NSArray *descriptors = [NSArray arrayWithObject:descriptor];
        NSArray *sortedArray = [list sortedArrayUsingDescriptors:descriptors];
        for (int i = 0; i < sortedArray.count; i ++) {
            NSString *keyValueString = sortedArray[i];
            keyValueString = [keyValueString stringByReplacingOccurrencesOfString:@"=" withString:@""];
            [keyValueStrings appendString:keyValueString];
        }
    }
    return keyValueStrings ?:@"";
}


/// 配置请求头信息
/// @param url 请求的url子路径 e.g.  /midea/open/business/v1/token
/// @param postData http请求体
/// @param addHeader http请求头，可为空
/// @param method 请求方法字符串 "POST" "GET"
- (NSDictionary *)configureRequestHeaderFoSingV2_0:(NSString *)url
                                postData:(nullable NSData *)postData
                                  header:(nullable NSDictionary *)addHeader
                                  method:(NSString *)method {
    NSMutableDictionary *mutHeaders = [NSMutableDictionary new];
    NSArray * originHeaders = [[OFRequestManager manager] getGlobalConfigureHeader];
    for (NSDictionary * head in originHeaders) {
        if ([head count] > 0) {
            [mutHeaders addEntriesFromDictionary:head];
        }
    }
    [mutHeaders setObject:@"application/json" forKey:@"Content-Type"];
    NSDictionary *dict = [MSAppInfo getCommonData]; //公共参数添加到头部
    [mutHeaders addEntriesFromDictionary:dict];
    NSString *randomStr = [self createRandomString];
    mutHeaders[@"random"] = randomStr;
    
    NSDictionary * param = [NSJSONSerialization JSONObjectWithData:postData options:0 error:nil];
    if (param && [param isKindOfClass:[NSDictionary class]]) {
        NSString * clientSecret = self.clientSecret;
        NSString * clientId = self.clientId;
        //请求接口 /midea/open/business/v1/token 时，accessToken需要传nil，获取到token后，传获取后的值
        NSString * accessToken = self.accessToken;
        NSDictionary<NSString *,NSString *> * newHeaders = [OFRequestTools getHeaderWithSignatureWithBody:postData header:mutHeaders subPath:url clientSecret:clientSecret addSignVersion:YES clientID:clientId addClientHeader:YES token:accessToken addTokenHeader:YES methodString:method];
        if ([newHeaders isKindOfClass:[NSDictionary class]]) {
            [mutHeaders addEntriesFromDictionary:newHeaders];
        }
    }
    return mutHeaders;
}


// 配置请求头信息
- (NSDictionary *)configRequestHeaderForUrl:(NSString *)url
                         postData:(NSData *)postData
                           header:(NSDictionary *)addHeader {
    NSMutableDictionary *mutHeaders = [NSMutableDictionary new];
    NSArray * originHeaders = [[OFRequestManager manager] getGlobalConfigureHeader];
    for (NSDictionary * head in originHeaders) {
        if ([head count] > 0) {
            [mutHeaders addEntriesFromDictionary:head];
        }
    }
    //HTTPHeader(name: "Content-Type", value: "application/json")
    [mutHeaders setObject:@"application/json" forKey:@"Content-Type"];
    
    NSDictionary *dict = [MSAppInfo getCommonData]; //公共参数添加到头部
    [mutHeaders addEntriesFromDictionary:dict];
    NSString *randomStr = [self createRandomString];
    mutHeaders[@"random"] = randomStr;
    mutHeaders[@"sign"] = [self signPostData:postData
                                      forUrl:url
                                  withRandom:randomStr];
   
    if ([MSUserInfoManager shareManager].loginInfoModel.accessToken) {
        mutHeaders[@"accessToken"] = [MSUserInfoManager shareManager].loginInfoModel.accessToken;
       // mutHeaders[@"uid"] = [MSUserInfoManager shareManager].loginInfoModel.uid;  //去掉uid
    }

    if ([addHeader isKindOfClass:[NSDictionary class]]) {
        [mutHeaders addEntriesFromDictionary:addHeader];
    }
    return mutHeaders;
}

- (NSDateFormatter *)formatter{
    static NSDateFormatter * formatter = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        formatter = [NSDateFormatter new];
        [formatter setDateFormat:@"yyyyMMddHHmmss"];
    });
    return formatter;
}

// 生成随机数
- (NSString *)createRandomString {
//    NSDateFormatter * formatter = [self formatter];
    //如果是阿拉伯文
//    if ([[[HGInternationalization sharedInstance] convertSystemLanguangeCodeToUnifyLanguangeCode:HGCurrentLanguage.code] hasPrefix:@"ar"]) {
//        formatter.locale = [NSLocale localeWithLocaleIdentifier:@"ar_DZ"];
//    }
//    NSString *stamp = [formatter stringFromDate:[NSDate date]];
    int tag = arc4random() % UINT16_MAX;
    NSString *stamp = [NSDate dof_getNSStringFromNSDate:[NSDate date] withFormat:@"yyyyMMddHHmmss"];
    NSString *reqIdStr = [NSString stringWithFormat:@"%@%d", stamp, tag];
    return reqIdStr;
}
- (NSString *)createRandomString2 {
    NSTimeInterval timeInterval = [[NSDate date] timeIntervalSince1970];
    NSString *timeString = [NSString stringWithFormat:@"%d",(int)timeInterval];
//    NSDateFormatter * formatter = [self formatter];
//    formatter.locale =  NSLocale(localeIdentifier: "ar_DZ")
//    formatter.locale = [NSLocale localeWithLocaleIdentifier:@"ar"];
//    NSString *stamp = [formatter stringFromDate:[NSDate date]];
//    int tag = arc4random() % UINT16_MAX;
//    NSString *reqIdStr = [NSString stringWithFormat:@"%@%d", stamp, tag];
    return timeString;
}


// 数据签名
- (NSString *)signPostData:(NSData *)postData
                    forUrl:(NSString *)url
                withRandom:(NSString *)randomStr {
    if (!url) {
        return @"";
    }
    
    NSString *paramsJson = [BusinessNetWorkTools dataToJSONString:postData] ? : @"";
    NSString *oriStr = [NSString stringWithFormat:@"%@%@%@", [MSAppInfo mucSignSecret], paramsJson, randomStr];
    NSString *result = [[self class] hmacSHA256WithSecret:[MSAppInfo getMasKey] content:oriStr];
    
    return result;
}

+ (NSString *)hmacSHA256WithSecret:(NSString *)secret
                           content:(NSString *)content {
    const char *cKey  = [secret cStringUsingEncoding:NSASCIIStringEncoding];
    const char *cData = [content cStringUsingEncoding:NSUTF8StringEncoding];
    unsigned char cHMAC[CC_SHA256_DIGEST_LENGTH];
    CCHmac(kCCHmacAlgSHA256, cKey, strlen(cKey), cData, strlen(cData), cHMAC);
    NSData *HMACData = [NSData dataWithBytes:cHMAC length:sizeof(cHMAC)];
    const unsigned char *buffer = (const unsigned char *)[HMACData bytes];
    NSMutableString *HMAC = [NSMutableString stringWithCapacity:HMACData.length * 2];
    for (int i = 0; i < HMACData.length; ++i){
        [HMAC appendFormat:@"%02x", buffer[i]];
    }
    return HMAC;
}

- (void)configureToBAuthInfo:(NSString * _Nonnull)clientSecret
                    clientId:(NSString * _Nonnull)clientId
                 accessToken:(NSString * _Nullable)accessToken{
    self.clientSecret = clientSecret;
    self.clientId = clientId;
    self.accessToken = accessToken;
}

#pragma mark - 缓存管理
- (void)clearRequestCache:(NSString *_Nullable)urlString {
    //[_requestConvertManager clearRequestCache:urlString];
}

- (void)clearRequestCache:(NSString *_Nullable)urlString identifier:(NSString *_Nullable)identifier {
    //[_requestConvertManager clearRequestCache:urlString identifier:identifier];
}

- (void)clearAllCache {
    //[_requestConvertManager clearAllCache];
}


#pragma mark - 请求数据

- (NSURLSessionDataTask *_Nullable)POST:(NSString *_Nullable)URLString
                             parameters:(NSDictionary *_Nullable)parameters
                                  cache:(BusinessRequestManagerCache _Nullable )cache
                                success:(BusinessRequestManagerSuccess _Nullable )success
                                failure:(BusinessRequestManagerFailure _Nullable )failure
{
    return [self requestMethod:BusinessRequestMethodPost URLString:URLString parameters:parameters cache:cache success:success failure:failure];
}

- (NSURLSessionDataTask *_Nullable)GET:(NSString *_Nullable)URLString
                            parameters:(NSDictionary *_Nullable)parameters
                                 cache:(BusinessRequestManagerCache _Nullable )cache
                               success:(BusinessRequestManagerSuccess _Nullable )success
                               failure:(BusinessRequestManagerFailure _Nullable )failure
{
    return [self requestMethod:BusinessRequestMethodGet URLString:URLString parameters:parameters cache:cache success:success failure:failure];
}

/**
 使用parameters提交请求
 */
- (NSURLSessionDataTask *_Nullable)requestMethod:(BusinessRequestMethod)method
                                       URLString:(NSString *_Nullable)URLString
                                      parameters:(NSDictionary *_Nullable)parameters
                                           cache:(BusinessRequestManagerCache _Nullable )cache
                                         success:(BusinessRequestManagerSuccess _Nullable )success
                                         failure:(BusinessRequestManagerFailure _Nullable )failure {
    NSData *postData = [[OFRequestManager manager] jsonEncodeWithParams:parameters];
    return [self requestMethod:method URLString:URLString httpBody:postData request:nil httpHeader:nil cache:nil success:success failure:failure];
}

//使用httpBody提交请求  可以传header 参数
- (NSURLSessionDataTask *_Nullable)requestMethod:(BusinessRequestMethod)method
                                       URLString:(NSString *_Nullable)URLString
                                        httpBody:(NSData *)httpBody
                                         request:(BusinessRequest *_Nullable)request
                                      httpHeader:(NSDictionary *)httpHeader
                                           cache:(BusinessRequestManagerCache _Nullable )cache
                                         success:(BusinessRequestManagerSuccess _Nullable )success
                                         failure:(BusinessRequestManagerFailure _Nullable )failure{
    NSDictionary * headers = [self configRequestHeaderForUrl:URLString postData:httpBody header:httpHeader];
    if (request && request.signType == BusinessSignType_ToB) {
        headers = [self configureRequestHeaderFoSingV2_0:URLString postData:httpBody header:httpHeader method:[self methodString:method]];
    }
    NSString * fullURL = [self fullPathWithSubpath:URLString];
    if (method == BusinessRequestMethodGet) {
        //拼接token
        NSURLComponents *components = [[NSURLComponents alloc] initWithURL:[NSURL URLWithString:fullURL] resolvingAgainstBaseURL:NO];
        components.queryItems = @[[[NSURLQueryItem alloc] initWithName:@"accessToken" value:[MSUserInfoManager shareManager].loginInfoModel.accessToken ?: @""]];
        fullURL = components.URL.absoluteString;
    }
    [self commonRequestWithMethod:method URLString:fullURL httpBody:httpBody request:request httpHeader:headers cache:cache success:^(NSURLSessionTask * _Nullable httpbase, id  _Nonnull responseObject) {
        NSDictionary *result = (NSDictionary *)responseObject;
        if ([result isKindOfClass:[NSDictionary class]] && [result[@"code"] integerValue] == MSRequestSessionExpireCode) {
            OEMLogInfo(@"MSBusiness/Net", @"<<<<<<<< error with code 40002!");
            if (self.delegate && [self.delegate respondsToSelector:@selector(handleUserSessionExpired:)]) {
                [self.delegate handleUserSessionExpired:^{
                    [self requestMethod:method
                              URLString:URLString
                               httpBody:httpBody
                                request:nil
                             httpHeader:httpHeader
                                  cache:cache
                                success:success
                                failure:failure];
                }];
            }
            return;
        }
        if (success) {
            success(nil, responseObject);
        }
    } failure:failure];
    return nil;
}



- (void)commonRequestWithMethod:(BusinessRequestMethod)method
                      URLString:(NSString *_Nullable)URLString
                       httpBody:(NSData *)httpBody
                        request:(BusinessRequest *_Nullable)request
                     httpHeader:(NSDictionary *)httpHeader
                          cache:(BusinessRequestManagerCache _Nullable )cache
                        success:(BusinessRequestManagerSuccess _Nullable )success
                        failure:(BusinessRequestManagerFailure _Nullable )failure{
    OFHttpMethod oemReqMethod = [self methodCast:method];
    NSTimeInterval reqTimeout = 30;
    if (request && request.requestTimeout > 0) {
        reqTimeout = request.requestTimeout;
    }
    WEAKSELF
    [[OFRequestManager manager] doRequestWithUrl:URLString method:oemReqMethod body:httpBody requestTimeout:reqTimeout header:httpHeader success:^(id _Nonnull responseObject, NSHTTPURLResponse * _Nullable response, NSURLRequest * _Nullable request) {
        NSString * jsonStr = [BusinessNetWorkTools dataToJSONString:httpBody];
        OEMLogInfo(@"MSBusiness/Net", @"%@\n<网络请求 * >:%@\n<请求头 * >:%@\n<请求参数 * >:%@\n<返回信息 * >:%@\n%@",
                   BusinessNetworkLogSuccessBegin,
                   URLString,
                   [weakSelf convertJsonFromObject:request.allHTTPHeaderFields],
                   jsonStr,
                   [weakSelf convertJsonFromObject:responseObject],
                   BusinessNetworkLogSuccessEnd);
        
        // 判断data是否为null，如为null则移除data
        if ([responseObject isKindOfClass:[NSDictionary class]]) {
            id data = [responseObject objectForKey:@"data"];
            if (data && [data isKindOfClass:[NSNull class]]) {
                NSMutableDictionary *mutDict = [responseObject mutableCopy];
                [mutDict removeObjectForKey:@"data"];
                responseObject = mutDict;
            }
        }
        // 新增httpsstatusCode
        if ([responseObject isKindOfClass:[NSDictionary class]]) {
            NSMutableDictionary * newResObj = [NSMutableDictionary dictionaryWithDictionary:responseObject ?: @{}];
            [newResObj addEntriesFromDictionary:@{@"httpStatusCode": @(response.statusCode)}];
            responseObject = newResObj;
        }
        
        if (success) {
            success(nil, responseObject);
        }
        
    } fail:^(NSError * _Nullable error, NSHTTPURLResponse * _Nullable response, NSURLRequest * _Nullable request) {
        NSString * jsonStr = [BusinessNetWorkTools dataToJSONString:httpBody];
        OEMLogInfo(@"MSBusiness/Net", @"%@\n<网络请求>:%@\n<请求头>:%@\n<请求参数>:%@\n<返回信息>:%@\n%@",
                   BusinessNetworkLogFailBegin,
                   URLString,
                   [BusinessNetWorkTools JSONToString:request.allHTTPHeaderFields],
                   jsonStr,
                   error,
                   BusinessNetworkLogFailEnd
                   );
        if (failure) {
            failure(nil, error);
        }
    }];
}

- (void)commonGetWithURLString:(NSString *_Nullable)URLString
                        request:(BusinessRequest *_Nullable)request
                     httpHeader:(NSDictionary * _Nullable)httpHeader
                          cache:(BusinessRequestManagerCache _Nullable )cache
                        success:(BusinessRequestManagerSuccess _Nullable )success
                       failure:(BusinessRequestManagerFailure _Nullable )failure{
    [[OFRequestManager manager] doRequestWithUrl:URLString method:OFHttpMethodGet body:nil requestTimeout:30 header:httpHeader success:^(id _Nonnull responseObject, NSHTTPURLResponse * _Nullable response, NSURLRequest * _Nullable request) {
        if (success) {
            success(nil, responseObject);
        }
        OEMLogInfo(@"MSBusiness/Net", @"%@\n<网络请求Get * >:%@\n<请求头 * >:%@\n<返回信息 * >:%@\n%@",
                    BusinessNetworkLogSuccessBegin,
                    URLString,
                    [BusinessNetWorkTools JSONToString:request.allHTTPHeaderFields],
                    [BusinessNetWorkTools JSONToString:responseObject],
                    BusinessNetworkLogSuccessEnd);
    } fail:^(NSError * _Nullable error, NSHTTPURLResponse * _Nullable response, NSURLRequest * _Nullable request) {
        if (failure) {
            failure(nil, error);
        }
        OEMLogInfo(@"MSBusiness/Net", @"%@\n<网络请求Get * >:%@\n<请求头 * >:%@\n<返回信息 * >:%@\n%@",
                    BusinessNetworkLogFailBegin,
                    URLString,
                   [BusinessNetWorkTools JSONToString:request.allHTTPHeaderFields],
                    error,
                    BusinessNetworkLogFailEnd
                    );
    }];
}

- (NSURLSessionTask *_Nullable)uploadWithURLString:(NSString *_Nullable)URLString
                                        parameters:(NSDictionary *_Nullable)parameters
                                   uploadIntercept:(BusinessRequestUploadIntercept _Nullable)uploadIntercept
                                          progress:(BusinessRequestManagerProgress _Nullable)progress
                                           success:(BusinessRequestManagerSuccess _Nullable )success
                                           failure:(BusinessRequestManagerFailure _Nullable )failure{
    
    NSData *postData = [[OFRequestManager manager] jsonEncodeWithParams:parameters];
    NSDictionary * header = [self configRequestHeaderForUrl:URLString postData:postData header:nil];
    OFHttpMultipFormData * formData = [OFHttpMultipFormData new];
    if (uploadIntercept) {
        BusinessUploadItem * fd = uploadIntercept();
        formData.fileURL = fd.fileURL;
        formData.name = fd.name;
        formData.fileName = fd.fileName;
        formData.mimeType = fd.mimeType;
    }
    NSString * fullURL = [self fullPathWithSubpath:URLString];
    [[OFRequestManager manager] doUploadWithUrl:fullURL headers:header formData:formData progress:^(NSProgress * _Nullable p) {
        if (progress) {
            progress(p);
        }
    } success:^(id _Nullable responseObject, NSHTTPURLResponse * _Nullable response, NSURLRequest * _Nullable request) {
        if (success) {
            success(nil, responseObject);
        }
        OEMLogInfo(@"MSBusiness/Net", @"%@\n<网络请求文件上传成功 * >:-><接口 * >：%@\n<请求头 * >:%@\n<路径 * >：%@ response:%@ \n%@",
                    BusinessNetworkLogSuccessBegin,
                    fullURL,
                   [BusinessNetWorkTools JSONToString:request.allHTTPHeaderFields],
                    formData.fileURL,
                   [BusinessNetWorkTools JSONToString:responseObject],
                    BusinessNetworkLogSuccessEnd);
    } fail:^(NSError * _Nullable error, NSHTTPURLResponse * _Nullable response, NSURLRequest * _Nullable request) {
        failure(nil, error);
        OEMLogInfo(@"MSBusiness/Net", @"%@\n<网络请求文件上传失败 * >:-><接口 * >：%@\n\n<请求头 * >：\n%@<路径 * >：%@ response:%@ \n%@",
                    BusinessNetworkLogFailBegin,
                    fullURL,
                    request.allHTTPHeaderFields,
                    formData.fileURL,
                    error.localizedDescription,
                    BusinessNetworkLogFailEnd);
    }];
    return  nil;
}


-(NSString *)serializeParams:(NSDictionary *)params {
    NSMutableArray *parts = [NSMutableArray array];
    [params enumerateKeysAndObjectsUsingBlock:^(id key, id<NSObject> obj, BOOL *stop) {
        NSString *part = [NSString stringWithFormat:@"%@=%@", key, obj];
        [parts addObject: part];
    }];
    if (parts.count > 0) {
        NSString *queryString = [parts componentsJoinedByString:@"&"];
        return queryString ?  : @"";
    }
    return @"";
}

- (OFHttpMethod)methodCast:(BusinessRequestMethod)method{
    switch (method) {
        case BusinessRequestMethodGet:
            return OFHttpMethodGet;
            break;
        case BusinessRequestMethodHead:
            return OFHttpMethodHead;
            break;
        case BusinessRequestMethodPost:
            return OFHttpMethodPost;
            break;
        case BusinessRequestMethodPut:
            return OFHttpMethodPut;
            break;
        case BusinessRequestMethodPatch:
            return OFHttpMethodPatch;
            break;
        case BusinessRequestMethodDelete:
            return OFHttpMethodDelete;
            break;
    }
    return OFHttpMethodPost;
}

- (NSString *)methodString:(BusinessRequestMethod)method{
    switch (method) {
        case BusinessRequestMethodGet:
            return @"GET";
            break;
        case BusinessRequestMethodHead:
            return @"HEAD";
            break;
        case BusinessRequestMethodPost:
            return @"POST";
            break;
        case BusinessRequestMethodPut:
            return @"PUT";
            break;
        case BusinessRequestMethodPatch:
            return @"PATCH";
            break;
        case BusinessRequestMethodDelete:
            return @"DELETE";
            break;
    }
    return @"";
}

- (NSString *)fullPathWithSubpath:(NSString *)subpath{
    NSString * fullURL = @"";
    if ([subpath hasPrefix:@"/"]) {
        fullURL = [[MSAppInfo mucBaseUrl] stringByAppendingString:subpath];
    }else{
        fullURL = [[MSAppInfo mucBaseUrl] stringByAppendingFormat:@"/%@", subpath];
    }
    return fullURL;
}


//转换为格式化json字符串
- (NSString *)convertJsonFromObject:(id)object{
    if (!object) {
        return @"";
    }
    NSData *data = [NSJSONSerialization dataWithJSONObject:object options:NSJSONWritingPrettyPrinted error:nil];
    NSString *jsonString = nil;
    id jsonObject = [NSJSONSerialization JSONObjectWithData:data options:0 error:NULL];
    if ([NSJSONSerialization isValidJSONObject:jsonObject]) {
        jsonString = [[NSString alloc] initWithData:[NSJSONSerialization dataWithJSONObject:jsonObject options:NSJSONWritingPrettyPrinted error:NULL] encoding:NSUTF8StringEncoding];
        // NSJSONSerialization escapes forward slashes. We want pretty json, so run through and unescape the slashes.
        jsonString = [jsonString stringByReplacingOccurrencesOfString:@"\\/" withString:@"/"];
    } else {
        jsonString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    }
    return jsonString;
}

@end



