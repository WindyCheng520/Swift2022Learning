//
//  MSRequestManager_Private.h
//  Pods
//
//  Created by Neil 韦学宁 on 2022/2/15.
//

#ifndef MSRequestManager_Private_h
#define MSRequestManager_Private_h

@interface BusinessRequestManager()
@property (nonatomic, copy)NSString * clientSecret;
@property (nonatomic, copy)NSString * clientId;
@property (nonatomic, copy)NSString * accessToken;
@end

#endif /* MSRequestManager_Private_h */
