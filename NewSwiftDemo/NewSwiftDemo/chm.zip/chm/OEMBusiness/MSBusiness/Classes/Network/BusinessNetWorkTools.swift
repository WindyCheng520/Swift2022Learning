//
//  BusinessNetWorkTools.swift
//  MSBusiness
//
//  Created by Neil 韦学宁 on 2022/2/10.
//

import Foundation
import OEMFoundation

@objc public protocol BusinessRequestProtocol {
    func configureSSLPinning()
    func configureResponseInterceptor()
    func configureErrorInterceptor()
    func handleUserSessionExpired(_ block: os_block_t?)
}

@objc
public class BusinessNetWorkTools: NSObject{
    
    @objc
    public class func isNetworkUnreachable() -> Bool{
        return OFNetworkMonitor.shared.reachableStatus == .notReachable
    }
    
    @objc
    public class func isNetworkConnectConnectViaWIFI() -> Bool{
        return OFNetworkMonitor.shared.connectType == .ethernetOrWiFi
    }
    
    @objc
    public class func registerListener(refrence: NSObject, block: @escaping os_block_t){
        let obs = OFNetworkMonitorObserver()
        obs.block = block
        obs.refrence = refrence
        OFNetworkMonitor.shared.registerListener(obs)
    }
    
    @objc
    public class func dataToJSONString(_ data: Data?) -> String?{
        guard let d = data else{
            return nil
        }
        return String(data: d, encoding: .utf8)
    }
    
    @objc
    public class func dataToJSON(_ data: Data?) -> Dictionary<String, Any>?{
        guard let d = data else{
            return nil
        }
        guard let json = try? JSONSerialization.jsonObject(with: d, options: []) as? Dictionary<String, Any> else{
            return nil
        }
        return json
    }
    @objc
    public class func JSONToString(_ jsonObject: Dictionary<String, Any>?) -> String?{
        guard let j = jsonObject,
              let data = try? JSONSerialization.data(withJSONObject: j, options: []),
              let str = String(data: data, encoding: .utf8) else{
            return nil
        }
        return str
    }
}



