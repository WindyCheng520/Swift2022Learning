//
//  OEMSDKConfig.swift
//  MSBusiness
//
//  Created by Neil 韦学宁 on 2022/3/9.
//

import UIKit
import OEMFoundation

public class OEMSDKConfig: NSObject {
    
    @objc static var instance = OEMSDKConfig()
    
    //MasKey OEM分配 请求头头数据签名使用 盐值
    @objc public var maskey: String?
    
    //app签名 OEM分配 明文密码hash 盐值
    @objc public var appkey: String?
 
    ////中台，请求头，数据签名时使用  e.g. meicloud
    @objc public var mucSignSecret: String?

    //APPID OEM分配的appid 应用ID
    @objc public var appID: String?
    
    //当前SDK环境，同时作为mqtt的主题配置
    /*
     分环境:
     dev-us.dollin.net
     sit-us.dollin.net
     uat-us.dollin.net
     us.dollin.net
     */
    @objc public var domain: String?
    
    //文件日志 enableFileLog 为true, enableConsoleLog才生效
    @objc public var enableFileLog: Bool = false
    
    //控制台日志
    @objc public var enableConsoleLog: Bool = false
    
    //语言 
    @objc public var language: String?
    
    //国家码
    @objc public var countryCode: String?
}
