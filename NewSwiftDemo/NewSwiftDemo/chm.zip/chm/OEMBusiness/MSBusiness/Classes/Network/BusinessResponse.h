//
//  MSResponse.h
//  MSBusiness
//
//  Created by syp on 2020/6/22.
//

#import <Foundation/Foundation.h>

@interface BusinessResponse : NSObject

@property (nonatomic, assign) NSInteger httpStatusCode;
@property (nonatomic, assign) NSInteger code;
@property (nonatomic, strong) NSString *msg;
@property (nonatomic, strong) id data;

@property (nonatomic, readonly) BOOL isOK;

@end
