//
//  OEMGlobalUIManager.m
//  MSBusiness
//
//  Created by WindyCheng on 2022/3/8.
//

#import "OEMGlobalUIManager.h"



@implementation OEMBusinessColor

@end


@implementation OEMDarkModeLayoutColor

@end

@implementation OEMLightModeLayoutColor

@end


@implementation OEMDarkModeTextColor

@end

@implementation OEMLightModeTextColor

@end




@implementation OEMGlobalUIManager

+ (instancetype)shareInstance{
    static OEMGlobalUIManager *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance  = [[OEMGlobalUIManager alloc] init];
    });
    return instance;
}

-(instancetype)init{
    if(self = [super init]){
        
        OEMBusinessColor *businessColor = [[OEMBusinessColor alloc] init];
        businessColor.brandColor = [self colorWithHexString:@"#267AFF" alpha:1];
        businessColor.greenColor = [self colorWithHexString:@"#01D28E" alpha:1];
        businessColor.redColor = [self colorWithHexString:@"#F35856" alpha:1];
        businessColor.orangeColor = [self colorWithHexString:@"#FF8F10" alpha:1];
        businessColor.whiteColor = [self colorWithHexString:@"#FFFFFF" alpha:1];
        businessColor.blackColor = [self colorWithHexString:@"#000000" alpha:1];
        self.businessColor = businessColor;
        
        OEMLightModeLayoutColor *lightModeLayoutColor = [[OEMLightModeLayoutColor alloc] init];
        lightModeLayoutColor.cardBackgroundColor = [self colorWithHexString:@"#FFFFFF" alpha:1];
        lightModeLayoutColor.backgroundColor = [self colorWithHexString:@"#F6F7FB" alpha:1];
        lightModeLayoutColor.separatorColor = [self colorWithHexString:@"#F0F0F0" alpha:1];
        lightModeLayoutColor.maskColor = [self colorWithHexString:@"#F0F0F0" alpha:0.6];
        self.lightModeLayoutColor = lightModeLayoutColor;
        
        OEMDarkModeLayoutColor *darkModeLayoutColor = [[OEMDarkModeLayoutColor alloc] init];
        darkModeLayoutColor.cardBackgroundColor = [self colorWithHexString:@"#1B1B1B" alpha:1];
        darkModeLayoutColor.backgroundColor = [self colorWithHexString:@"#111111" alpha:1];
        darkModeLayoutColor.separatorColor = [self colorWithHexString:@"#303030" alpha:1];
        darkModeLayoutColor.maskColor = [self colorWithHexString:@"#000000" alpha:0.6];
        self.darkModeLayoutColor = darkModeLayoutColor;
        
        OEMLightModeTextColor *light = [[OEMLightModeTextColor alloc] init];
        light.mainTextColor = [self colorWithHexString:@"#212121" alpha:1];
        light.secondColor = [self colorWithHexString:@"#6C757D" alpha:1];
        light.thirdColor = [self colorWithHexString:@"#A7ACB1" alpha:1];
        light.tipsColor = [self colorWithHexString:@"#D2D5D8" alpha:1];
        light.mainColor = [self colorWithHexString:@"#267AFF" alpha:1];
        light.alertColor = [self colorWithHexString:@"#F35856" alpha:1];
        light.mainLightColor = [self colorWithHexString:@"#FFFFFF" alpha:1];
        self.lightModeTextColor = light;
        
        
        OEMDarkModeTextColor *dark = [[OEMDarkModeTextColor alloc] init];
        dark.mainTextColor = [self colorWithHexString:@"#DEDEDE" alpha:1];
        dark.secondColor = [self colorWithHexString:@"#899197" alpha:1];
        dark.thirdColor = [self colorWithHexString:@"#52575B" alpha:1];
        dark.tipsColor = [self colorWithHexString:@"#373A3C" alpha:1];
        dark.mainColor = [self colorWithHexString:@"#267AFF" alpha:1];
        dark.alertColor = [self colorWithHexString:@"#F35856" alpha:1];
        dark.mainLightColor = [self colorWithHexString:@"#FFFFFF" alpha:1];
        
        self.darkModeTextColor = dark;
        
    }
    return self;
}

-(UIColor *)alphaColor:(UIColor *)color alpha:(CGFloat)alpha{
    return [color colorWithAlphaComponent:alpha];
}




-(UIColor *)colorWithHexString:(NSString *)stringToConvert
                         alpha:(CGFloat)alpha{
    if([stringToConvert hasPrefix:@"#"]){
        stringToConvert = [stringToConvert substringFromIndex:1];
    }
    NSScanner *scanner = [NSScanner scannerWithString:stringToConvert];
    unsigned hexNum;
    if(![scanner scanHexInt:&hexNum]){
        return nil;
    }
    return [self colorWithRGBHex:hexNum alpha:alpha];
}

- (UIColor *)colorWithRGBHex:(UInt32)hex alpha:(CGFloat)alpha{
    int r = (hex >>16) & 0xFF;
    int g = (hex >>8) & 0xFF;
    int b = (hex) & 0xFF;
    return [UIColor colorWithRed:r /255.0f
    green:g /255.0f
    blue:b /255.0f
    alpha:alpha];
}


@end
