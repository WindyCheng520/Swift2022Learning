//
//  MSUIConfiguration.m
//  BHSmartHome
//
//  Created by 邓立兵 on 2018/5/28.
//

#import "MSUIConfiguration.h"
#import "UIControl+OEMBusinessBlock.h"

@interface MSUIKeyboardMonitor: NSObject

//@property(nonatomic , assign)CGFloat keyboardHeight;

@property(nonatomic , assign)CGRect keyboardFrame;

@end

@implementation MSUIKeyboardMonitor

+ (void)load{
    [MSUIKeyboardMonitor sharedInstance];
}

+ (instancetype)sharedInstance{
    static MSUIKeyboardMonitor * monitor = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        monitor = [[MSUIKeyboardMonitor alloc] init];
    });
    return monitor;
}

- (void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (instancetype)init{
    if (self = [super init]) {
//        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(monitorKeyboardDidChange:) name:UIKeyboardDidChangeFrameNotification object:nil];
//        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(monitorKeyboardDidHide:) name:UIKeyboardDidHideNotification object:nil];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(monitorKeyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
        
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(monitorKeyboardFrameWillChange:) name:UIKeyboardWillChangeFrameNotification object:nil];
    }
    return self;
}

- (void)monitorKeyboardWillHide:(NSNotification *)notification{
    CGRect keyboardFrame = [notification.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    self.keyboardFrame = keyboardFrame;
    
}

//- (void)monitorKeyboardDidHide:(NSNotification *)notification{
//    self.keyboardHeight = 0.0f;
//
//}
// 外部根据Y值判断键盘是否弹出~
-(void)monitorKeyboardFrameWillChange:(NSNotification *)notification{
    CGRect keyboardFrame = [notification.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    self.keyboardFrame = keyboardFrame;
}

//- (void)monitorKeyboardDidChange:(NSNotification *)notification{
//    CGRect keyboardFrame = [notification.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
//    self.keyboardHeight = keyboardFrame.size.height;
//}

@end

@interface MSHudLoadingView : UIView

@property (strong, nonatomic) UIActivityIndicatorView *activityIndicator;

@end

@implementation MSHudLoadingView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor clearColor];
        _activityIndicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(0, 0, 37, 37)];
        [self addSubview:_activityIndicator];
        _activityIndicator.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin |
        UIViewAutoresizingFlexibleBottomMargin;
        _activityIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhiteLarge;
        [_activityIndicator startAnimating];
    }
    return self;
}

- (CGSize)intrinsicContentSize {
    return CGSizeMake(41, 41);
}

@end

#pragma mark - 一些常量
const CGFloat kMSBusinessCornerRadius = 5.0f;
const CGFloat kMSBusinessCornerRadius4 = 4.0f;
const CGFloat kMSBusinessToastDuration = 1.5f;
const CGFloat kMSBusinessDarkeningValue = 0.1f;
const CGFloat kMSBusinessCommonTipViewHeight = 34.0f;
const CGFloat kMSBusinessCommonViewHeight = 42.0f;
const CGFloat kMSBusinessCommonButtonHeight = 46.0f;


@implementation MSUIConfiguration

@dynamic sh_titleColor, sh_lightTitleColor, sh_summaryColor, sh_assistColor, sh_hintColor, sh_partingLineColor,
sh_bgColor, sh_cardBgColor, sh_redColor, sh_orangeColor, sh_yellowColor, sh_greenColor,
sh_tealBlueColor, sh_blueColor, sh_purpleColor, sh_darkColor, sh_4A4A4AColor, sh_cellBgColor;

@dynamic sh_bigTitleFont, sh_firstLevelTitleFont, sh_secondLevelTitleFont, sh_thirdLevelTitleFont,
sh_summaryFont, sh_assistFont, sh_hintFont, sh_20SizeFont, sh_36SizeFont;

@dynamic sh_verticalTinyDistance, sh_verticalSmallDistance, sh_verticalMiddleDistance,
sh_verticalBigDistance, sh_horizontalSmallDistance, sh_horizontalMiddleDistance,
sh_horizontalBigDistance, sh_horizontalHugeDistance, sh_bottomDistance, sh_onePoint;

+ (UIColor *)sh_titleColor {
    return [self ms_colorWithHex:0x000000];
}

+ (UIColor *)sh_lightTitleColor {
    return [self ms_colorWithHex:0x0A0A0A];
}

+ (UIColor *)sh_summaryColor {
    return [self ms_colorWithHex:0x666666];
}

+ (UIColor *)sh_assistColor {
    return [self ms_colorWithHex:0x8A8A8F];
}

+ (UIColor *)sh_hintColor {
    return [self ms_colorWithHex:0xC7C7C7];
}

+ (UIColor *)sh_partingLineColor {
    return [self ms_colorWithHex:0xF2F2F2];
}

+ (UIColor *)sh_bgColor {
    return [self ms_colorWithHex:0xF9F9F9];
}

+ (UIColor *)sh_cardBgColor {
    return [self ms_colorWithHex:0xFFFFFF];
}

+ (UIColor *)sh_redColor {
    return [self ms_colorWithHex:0xFF3B30];
}

+ (UIColor *)sh_orangeColor {
    return [self ms_colorWithHex:0xFF9500];
}

+ (UIColor *)sh_yellowColor {
    return [self ms_colorWithHex:0xFFCC00];
}

+ (UIColor *)sh_greenColor {
    return [self ms_colorWithHex:0x4CD964];
}

+ (UIColor *)sh_tealBlueColor {
    return [self ms_colorWithHex:0x5BD2FF];
}

+ (UIColor *)sh_blueColor {
    return [self ms_colorWithHex:0x267AFF];
}

+ (UIColor *)sh_purpleColor {
    return [self ms_colorWithHex:0x5856D6];
}

+ (UIColor *)sh_darkColor {
    return [self ms_colorWithHex:0x303030];
}

+ (UIColor *)sh_4A4A4AColor {
    return [self ms_colorWithHex:0x4A4A4A];
}

+ (UIColor *)sh_cellBgColor {
    return [self ms_colorWithHex:0xF7F7F7];
}


#pragma mark - 字体相关信息（中文：苹方字体、英文：San Francisco）

static inline BOOL sh_chineseLanguage () {
    NSArray *languages = [NSLocale preferredLanguages];
    NSString *currentLanguage = [languages firstObject];
    if ([currentLanguage hasPrefix:@"zh"]) {
        //中文
        return YES;
    }
    return NO;
}

static inline NSString * sh_customFont () {
    return @"SF Pro Text";
}

+ (UIFont *)sh_bigTitleFont {
    if (sh_chineseLanguage()) {
        return [UIFont systemFontOfSize:48];
    }
    return [UIFont fontWithName:sh_customFont() size:48];
}

+ (UIFont *)sh_36SizeFont {
    if (sh_chineseLanguage()) {
        return [UIFont systemFontOfSize:36];
    }
    return [UIFont fontWithName:sh_customFont() size:36];
}

+ (UIFont *)sh_firstLevelTitleFont {
    if (sh_chineseLanguage()) {
        return [UIFont systemFontOfSize:28];
    }
    return [UIFont fontWithName:sh_customFont() size:28];
}

+ (UIFont *)sh_secondLevelTitleFont {
    if (sh_chineseLanguage()) {
        return [UIFont systemFontOfSize:18];
    }
    return [UIFont fontWithName:sh_customFont() size:18];
}

+ (UIFont *)sh_thirdLevelTitleFont {
    if (sh_chineseLanguage()) {
        return [UIFont systemFontOfSize:16];
    }
    return [UIFont fontWithName:sh_customFont() size:16];
}


+ (UIFont *)sh_summaryFont {
    if (sh_chineseLanguage()) {
        return [UIFont systemFontOfSize:14];
    }
    return [UIFont fontWithName:sh_customFont() size:14];
}

+ (UIFont *)sh_assistFont {
    if (sh_chineseLanguage()) {
        return [UIFont systemFontOfSize:12];
    }
    return [UIFont fontWithName:sh_customFont() size:12];
}

+ (UIFont *)sh_hintFont {
    if (sh_chineseLanguage()) {
        return [UIFont systemFontOfSize:10];
    }
    return [UIFont fontWithName:sh_customFont() size:10];
}

+ (UIFont *)sh_20SizeFont {
    if (sh_chineseLanguage()) {
        return [UIFont systemFontOfSize:20];
    }
    return [UIFont fontWithName:sh_customFont() size:20];
}

+ (UIFont *)sh_buttonTitleBoldFont {
    if (sh_chineseLanguage()) {
        return [UIFont boldSystemFontOfSize:16];
    }
    return [UIFont fontWithName:sh_customFont() size:16];
}


+ (UIFont *)sh_pingFangSC_mediumFont:(NSInteger)fontSize {
    UIFont *font = [UIFont fontWithName:@"PingFangSC-Medium" size:fontSize];
    if (!font) {
        font = [UIFont boldSystemFontOfSize:fontSize];
    }
    return font;
}

+ (UIFont *)sh_pingFangSC_lightFont:(NSInteger)fontSize {
    UIFont *font = [UIFont fontWithName:@"PingFangSC-Regular" size:fontSize];
    if (!font) {
        font = [UIFont systemFontOfSize:fontSize];
    }
    return font;
}


#pragma mark - 控件距离相关信息
+ (CGFloat)sh_onePoint {
    return 1.0 / [UIScreen mainScreen].scale;
}

+ (CGFloat)sh_verticalTinyDistance{
    return 4.0f;
}

+ (CGFloat)sh_verticalSmallDistance{
    return 8.0f;
}

+ (CGFloat)sh_verticalMiddleDistance{
    return 12.0f;
}

+ (CGFloat)sh_verticalBigDistance{
    return 16.0f;
}

+ (CGFloat)sh_horizontalSmallDistance{
    return 8.0f;
}

+ (CGFloat)sh_horizontalMiddleDistance{
    return 12.0f;
}

+ (CGFloat)sh_horizontalBigDistance{
    return 16.0f;
}

+ (CGFloat)sh_horizontalHugeDistance{
    return 24.0f;
}

+ (CGFloat)sh_bottomDistance{
    return 36.0f;
}

+ (CGFloat)sh_bottomDistance_24{
    return 24.0f;
}

#pragma mark - UI快速生成
+ (UIButton *)sh_createButtonWithFrame:(CGRect)frame title:(NSString *)title titleColor:(UIColor *)titleColor font:(UIFont *)font {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = frame;
    if (title) {
        [button setTitle:title forState:UIControlStateNormal];
    }
    if (titleColor) {
        [button setTitleColor:titleColor forState:UIControlStateNormal];
    }
    if (font) {
        button.titleLabel.font = font;
    }
    return button;
}

+ (UITextField *)sh_createTextFieldWithFrame:(CGRect)frame
                                   leftSpace:(CGFloat)leftSpace
                                cornerRadius:(CGFloat)cornerRadius
                                 borderWidth:(CGFloat)borderWidth
                                 borderColor:(UIColor *)borderColor {
    UITextField *textField = [[UITextField alloc] initWithFrame:frame];
    if (cornerRadius > 0) {
        textField.layer.cornerRadius = cornerRadius;
        if (cornerRadius == kMSBusinessCornerRadius) {
            __weak typeof(textField) w_tf = textField;
            [textField oem_businessEditingDidBegin:^{
                w_tf.layer.borderColor = [self sh_summaryColor].CGColor;
            }];
            [textField oem_businessEditingDidEnd:^{
                w_tf.layer.borderColor = [self sh_hintColor].CGColor;
            }];
        }
    }
    if (leftSpace > 0) {
        UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, leftSpace, frame.size.height)];
        textField.leftView = leftView;
        textField.leftViewMode = UITextFieldViewModeAlways;
    }
    if (borderWidth > 0) {
        textField.layer.borderWidth = borderWidth;
    }
    if (borderColor) {
        textField.layer.borderColor = borderColor.CGColor;
    }
    return textField;
}

+ (UILabel *)sh_createLabelWithFrame:(CGRect)frame
                                text:(NSString *)text
                           textColor:(UIColor *)textColor
                                font:(UIFont *)font {
    UILabel *label = [[UILabel alloc] initWithFrame:frame];
    label.text = text;
    label.textColor = textColor;
    label.font = font;
    return label;
}


+ (UITextField *)sh_createLoginTextFieldWithFrame:(CGRect)frame
                                      borderStyle:(UITextBorderStyle )borderStyle
                                             font:(UIFont *)font
                                      placeholder:(NSString *)placeholder
                                     keyboardType:(UIKeyboardType )keyboardType
{
    UITextField *textField = [[UITextField alloc] initWithFrame:frame];
  
    textField.font = font;
    textField.backgroundColor = [UIColor clearColor];
    textField.borderStyle = borderStyle;
    NSMutableAttributedString *placeholderString = [[NSMutableAttributedString alloc] initWithString:placeholder attributes:@{NSForegroundColorAttributeName : [UIColor grayColor],
                     NSFontAttributeName:[UIFont systemFontOfSize:16.0]
    }];
    textField.attributedPlaceholder = placeholderString;
       
    textField.keyboardType = keyboardType;
    
    return textField;
}



+ (NSMutableAttributedString *)sh_getNewColorStr:(NSString *)headStr
                                        headFont:(UIFont *)headFont
                                       headColor:(UIColor *)headColor
                                         lastStr:(NSString *)lastStr
                                        lastFont:(UIFont *)lastFont
                                       lastColor:(UIColor *)lastColor {
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@%@",headStr,lastStr]];
    [str addAttribute:NSForegroundColorAttributeName value:headColor range:NSMakeRange(0,headStr.length)];
    [str addAttribute:NSForegroundColorAttributeName value:lastColor range:NSMakeRange(headStr.length, lastStr.length)];
    [str addAttribute:NSFontAttributeName value:headFont range:NSMakeRange(0,headStr.length)];
    [str addAttribute:NSFontAttributeName value:lastFont range:NSMakeRange(headStr.length, lastStr.length)];
    return str;
}

+ (NSMutableAttributedString *)sh_getNewColorStr:(NSString *)headStr
                                        headFont:(UIFont *)headFont
                                       headColor:(UIColor *)headColor
                                       middleStr:(NSString *)middleStr
                                      middleFont:(UIFont *)middleFont
                                     middleColor:(UIColor *)middleColor
                                         footStr:(NSString *)footStr
                                        footFont:(UIFont *)footFont
                                       footColor:(UIColor *)footColor {
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@%@%@",headStr,middleStr,footStr]];
    [str addAttribute:NSForegroundColorAttributeName value:headColor range:NSMakeRange(0,headStr.length)];
    [str addAttribute:NSForegroundColorAttributeName value:middleColor range:NSMakeRange(headStr.length, middleStr.length)];
    [str addAttribute:NSForegroundColorAttributeName value:footColor range:NSMakeRange(headStr.length+middleStr.length, footStr.length)];

    [str addAttribute:NSFontAttributeName value:headFont range:NSMakeRange(0,headStr.length)];
    [str addAttribute:NSFontAttributeName value:middleFont range:NSMakeRange(headStr.length, middleStr.length)];
    [str addAttribute:NSFontAttributeName value:footFont range:NSMakeRange(headStr.length+middleStr.length, footStr.length)];
    return str;
}


#pragma mark - HUD
+ (MBProgressHUD *)sh_showBlackLoadingHudToView:(UIView *)view {
    return [self sh_showBlackLoadingHudToView:view text:@""];
}

+ (MBProgressHUD *)sh_showBlackDefaultLoadingHudToView:(UIView *)view {
    return [self sh_showBlackLoadingHudToView:view text:@""];
}

+ (MBProgressHUD *)sh_showBlackLoadingHudToView:(UIView *)view text:(NSString *)text {
    [MBProgressHUD hideAllHUDsForView:view animated:NO];
    if (view == nil) {
        view = [UIApplication sharedApplication].keyWindow;
    }
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.bezelView.layer.cornerRadius = 13.0;
    hud.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
    hud.bezelView.color = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.8];
    hud.margin = 16.0;
    hud.horizontalMargin = 16.0;
    //hud.bezelView.blurEffectStyle = UIBlurEffectStyleDark; 这句代码有bug，等待mb修复，替代方案以下
    UIView *firstView = [hud.bezelView.subviews firstObject];
    if ([firstView isKindOfClass:[UIVisualEffectView class]]) {
        UIVisualEffectView *effectView = (UIVisualEffectView *)firstView;
        effectView.effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    }
    
    hud.contentColor = [UIColor whiteColor];
    hud.mode = MBProgressHUDModeCustomView;
    MSHudLoadingView *custom = [[MSHudLoadingView alloc] init];
    custom.activityIndicator.color = hud.contentColor;
    hud.customView = custom;
    hud.label.text = text;
    hud.label.font = MSUIConfiguration.sh_assistFont;
    hud.minSize = CGSizeMake(100, 100);
    return hud;
}

+ (MBProgressHUD *)sh_showWhiteLoadingHudToView:(UIView *)view text:(NSString *)text {
    [MBProgressHUD hideAllHUDsForView:view animated:NO];
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.userInteractionEnabled = NO;
    hud.bezelView.layer.cornerRadius = 13.0;
    hud.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
    hud.bezelView.color = [UIColor colorWithRed:1 green:1 blue:1 alpha:0.8];
    hud.margin = 16.0;
    hud.horizontalMargin = 16.0;
    //    hud.contentColor = [UIColor whiteColor];
    hud.mode = MBProgressHUDModeCustomView;
    MSHudLoadingView *custom = [[MSHudLoadingView alloc] init];
    custom.activityIndicator.color = hud.contentColor;
    hud.customView = custom;
    hud.label.text = text;
    hud.label.font = MSUIConfiguration.sh_assistFont;
    hud.minSize = CGSizeMake(100, 100);
    return hud;
}

+ (MBProgressHUD *)sh_showBlackToastHudToView:(UIView *)view text:(NSString *)text {
    return [self sh_showBlackToastHudToView:view text:text duration:1.5 position:MBProgressHUD_Position_Bottom];
}

+ (MBProgressHUD *)sh_showBlackToastHudToView:(UIView *)view text:(NSString *)text duration:(CGFloat)duration {
    return [self sh_showBlackToastHudToView:view text:text duration:duration position:MBProgressHUD_Position_Bottom];
}



+ (MBProgressHUD *)sh_showBlackToastHudToView:(UIView *)view text:(NSString *)text duration:(CGFloat)duration position:(MBProgressHUD_Position)position {
    if (!view) {
        return nil;
    }
    if (text.length == 0) {
        return nil;
    }
    [MBProgressHUD hideAllHUDsForView:view animated:NO];
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:NO];
    hud.userInteractionEnabled = NO;
    hud.bezelView.layer.cornerRadius = 12.0f;
    hud.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
    hud.bezelView.color = HUDCommonBackgroundColor;

    //hud.bezelView.blurEffectStyle = UIBlurEffectStyleDark; 这句代码有bug，等待mb修复，替代方案以下
    UIView *firstView = [hud.bezelView.subviews firstObject];
    if ([firstView isKindOfClass:[UIVisualEffectView class]]) {
        UIVisualEffectView *effectView = (UIVisualEffectView *)firstView;
        effectView.effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    }
    CGFloat maxTextWidth = SCREEN_WIDTH * 0.8;
    CGFloat minTextHeight = 20;
    CGFloat detailLabelHeight = 0;
    CGFloat detailLabelWidth = 0;
    //先计算宽度
    CGSize size = CGSizeMake(0, MAXFLOAT);
    NSDictionary *dic = @{NSFontAttributeName:[UIFont systemFontOfSize:15 weight:UIFontWeightRegular]};
    CGRect rect = [text boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:dic context:nil];
    CGFloat textWidth = rect.size.width;
    
    if (textWidth < maxTextWidth) {
        detailLabelWidth = textWidth + 10;
        detailLabelHeight = minTextHeight;

    }else{
        detailLabelWidth = maxTextWidth;
        size = CGSizeMake(maxTextWidth, 0);
        rect = [text boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:dic context:nil];
        detailLabelHeight = rect.size.height;
    }
    
    [hud.detailsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
         make.height.equalTo(@(detailLabelHeight));
        make.width.equalTo(@(detailLabelWidth));
    }];
    
//    CGFloat textHeight = [text boundingRectWithSize:CGSizeMake(textWidth,0) options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading | NSStringDrawingTruncatesLastVisibleLine attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:15 weight:UIFontWeightRegular]} context:nil].size.width;
    
//    CGSize size = CGSizeMake(textWidth, 0);
//    NSDictionary *dic = @{NSFontAttributeName:[UIFont systemFontOfSize:15 weight:UIFontWeightRegular]};
//    CGRect rect = [text boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:dic context:nil];
//    CGFloat textHeight = rect.size.height;
//    CGFloat textHeight0 = [self getWidthWithText:text Width:textWidth height:0 font:15];
//    CGSize textSize1 = [text sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15 weight:UIFontWeightRegular]}];
        
//    if (textWidth > (SCREEN_WIDTH  - 50)) {
//        [hud.detailsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
//            // make.width.equalTo(@(SCREEN_WIDTH - 66));
//        }];
//    }else{
//        [hud.detailsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
//             make.height.equalTo(@(textHeight));
//            make.width.equalTo(@(textWidth));
//        }];
//    }
    
    hud.contentColor = [UIColor whiteColor];
    hud.mode = MBProgressHUDModeText;
    hud.margin = 11.0;  //上下间距
    hud.horizontalMargin = 16.0; //左右间距
    hud.detailsLabel.text = text;
    hud.detailsLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightRegular];
    hud.detailsLabel.numberOfLines = 0;
    CGFloat offsetY = 0;
    switch (position) {
        case MBProgressHUD_Position_Bottom:{
            CGFloat tabBarBottomHeight = 0;
            if ( ([UIScreen mainScreen].bounds.size.width == 375 && [UIScreen mainScreen].bounds.size.height == 812) ||
                ([UIScreen mainScreen].bounds.size.width == 414 && [UIScreen mainScreen].bounds.size.height == 896) ) {
                tabBarBottomHeight =  34;
            }else{
                tabBarBottomHeight = 0;
            }
            offsetY = view.frame.size.height/2 - tabBarBottomHeight - [self getBottomDistanceWithView:view];
            //证明键盘正在弹起
//            NSLog(@"keybbbFrame:%@",NSStringFromCGRect([MSUIKeyboardMonitor sharedInstance].keyboardFrame));
            if ([MSUIKeyboardMonitor sharedInstance].keyboardFrame.origin.y < SCREEN_HEIGHT) {
                offsetY -= [MSUIKeyboardMonitor sharedInstance].keyboardFrame.size.width;
            }
            hud.offset = CGPointMake(0, offsetY);
            
        }
            break;

        case MBProgressHUD_Position_Center:
            hud.center = view.center;
            break;

        case MBProgressHUD_Position_Top:{
            CGFloat statusHeight = 0;
            if ( ([UIScreen mainScreen].bounds.size.width == 375 && [UIScreen mainScreen].bounds.size.height == 812) ||
                ([UIScreen mainScreen].bounds.size.width == 414 && [UIScreen mainScreen].bounds.size.height == 896) ) {
                statusHeight = 44;
            }else{
                statusHeight  =  20;
            }
            offsetY = -view.frame.size.height/2 + statusHeight + [self sh_bottomDistance];
            hud.offset = CGPointMake(0, offsetY);
        }
            break;

        default:
            break;
    }
    
    hud.alpha = 0;
    [UIView animateWithDuration:0.5 animations:^{
        UIView * v = hud.bezelView;
        v.frame = CGRectMake(v.frame.origin.x, v.frame.origin.y - 20, v.frame.size.width, v.frame.size.height);
        hud.alpha = 1;
    }];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(duration * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [UIView animateWithDuration:0.5 animations:^{
            hud.alpha = 0;
        } completion:^(BOOL finished) {
            if (finished) {
                [hud hideAnimated:NO afterDelay:0];
            }
        }];
    });
    
    return hud;
}

+ (MBProgressHUD *)sh_showBlackToastHudToView:(UIView *)view text:(NSString *)text withImgName:(UIImage *)img {
    return  [self sh_showBlackToastHudToView:view text:text withImgName:img position:MBProgressHUD_Position_Center duration:1.5];
}

// 显示toast img + 文字
+ (MBProgressHUD *)sh_showBlackToastHudToView:(UIView *)view text:(NSString *)text withImgName:(UIImage *)img position:(MBProgressHUD_Position)position duration:(CGFloat)duration {
    if (!view) {
        return nil;
    }
    if (text.length == 0) {
        return nil;
    }
    [MBProgressHUD hideAllHUDsForView:view animated:NO];
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:NO];
    hud.userInteractionEnabled = NO;
    hud.bezelView.layer.cornerRadius = 13.0;
    hud.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
    hud.bezelView.color = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.8];

    //hud.bezelView.blurEffectStyle = UIBlurEffectStyleDark; 这句代码有bug，等待mb修复，替代方案以下
    UIView *firstView = [hud.bezelView.subviews firstObject];
    if ([firstView isKindOfClass:[UIVisualEffectView class]]) {
        UIVisualEffectView *effectView = (UIVisualEffectView *)firstView;
        effectView.effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    }
    
    hud.contentColor = [UIColor whiteColor];
    UIImageView *imgView = UIImageView.new;
    imgView.frame = CGRectMake(0, 0, 37, 37);
    imgView.image = img;
    hud.mode = MBProgressHUDModeCustomView;
    hud.customView = imgView;
    hud.margin = 11.0;
    hud.horizontalMargin = 16.0;
    hud.detailsLabel.text = text;
    hud.minSize = CGSizeMake(100, 100);
    hud.detailsLabel.font = MSUIConfiguration.sh_summaryFont;
    CGFloat offsetY = 0;
    switch (position) {
        case MBProgressHUD_Position_Bottom:{
            CGFloat tabBarBottomHeight = 0;
            if ( ([UIScreen mainScreen].bounds.size.width == 375 && [UIScreen mainScreen].bounds.size.height == 812) ||
                ([UIScreen mainScreen].bounds.size.width == 414 && [UIScreen mainScreen].bounds.size.height == 896) ) {
                tabBarBottomHeight =  34;
            }else{
                tabBarBottomHeight = 0;
            }
            offsetY = view.frame.size.height/2 - tabBarBottomHeight - [self getBottomDistanceWithView:view];
            hud.offset = CGPointMake(0, offsetY);
        }
            break;

        case MBProgressHUD_Position_Center:
            hud.center = view.center;
            break;

        case MBProgressHUD_Position_Top:{
            CGFloat statusHeight = 0;
            if ( ([UIScreen mainScreen].bounds.size.width == 375 && [UIScreen mainScreen].bounds.size.height == 812) ||
                ([UIScreen mainScreen].bounds.size.width == 414 && [UIScreen mainScreen].bounds.size.height == 896) ) {
                statusHeight = 44;
            }else{
                statusHeight  =  20;
            }
            offsetY = -view.frame.size.height/2 + statusHeight+ [self sh_bottomDistance];
            hud.offset = CGPointMake(0, offsetY);
        }
            break;

        default:
            break;
    }
    
    hud.alpha = 0;
    [UIView animateWithDuration:0.5 animations:^{
        UIView * v = hud.bezelView;
        v.frame = CGRectMake(v.frame.origin.x, v.frame.origin.y - 20, v.frame.size.width, v.frame.size.height);
        hud.alpha = 1;
    }];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(duration * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [UIView animateWithDuration:0.5 animations:^{
            hud.alpha = 0;
        } completion:^(BOOL finished) {
            if (finished) {
                [hud hideAnimated:NO afterDelay:0];
            }
        }];
    });
    
    return hud;
}


// 带进度的loading
+ (MBProgressHUD *)sh_showDeterminateToastHudToView:(UIView *)view text:(NSString *)text {
    [MBProgressHUD hideAllHUDsForView:view animated:NO];
    //圆形进度条
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.bezelView.layer.cornerRadius = 2.0;
    UIView *firstView = [hud.bezelView.subviews firstObject];
    if ([firstView isKindOfClass:[UIVisualEffectView class]]) {
        UIVisualEffectView *effectView = (UIVisualEffectView *)firstView;
        effectView.effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    }
    hud.mode = MBProgressHUDModeDeterminate;
    hud.contentColor = [UIColor whiteColor];
    hud.detailsLabel.text = text;
    hud.detailsLabel.font = MSUIConfiguration.sh_thirdLevelTitleFont;
    return hud;
}

+ (NSInteger)sh_hideAllHudForView:(UIView *)view animated:(BOOL)animated {
    if (view == nil) {
        view = [UIApplication sharedApplication].keyWindow;
    }
    return [MBProgressHUD hideAllHUDsForView:view animated:animated];
}

+ (UIViewController *)nextResponderViewController:(UIView *)view {
    //获取当前view的superView对应的控制器
    UIResponder *next = [view nextResponder];
    do {
        if ([next isKindOfClass:[UIViewController class]]) {
            return (UIViewController *)next;
        }
        next = [next nextResponder];
    } while (next != nil);
    return nil;
}

+ (CGFloat)getBottomDistanceWithView:(UIView *)view {
//    UIViewController *vc = [self nextResponderViewController:view];
//    NSString *className = NSStringFromClass(vc.class);
    CGFloat bottomDistance = 120;
//    if ([className isEqualToString:@"MSHomeViewController"] ||
//        [className isEqualToString:@"MSMineViewController"]) {
//        bottomDistance = 120 - 0;
//    }
    return bottomDistance;
}

+ (UIColor *)ms_colorWithHex:(UInt32)hex{
    return [self ms_colorWithHex:hex andAlpha:1];
}
+ (UIColor *)ms_colorWithHex:(UInt32)hex andAlpha:(CGFloat)alpha{
    return [UIColor colorWithRed:((hex >> 16) & 0xFF)/255.0
                           green:((hex >> 8) & 0xFF)/255.0
                            blue:(hex & 0xFF)/255.0
                           alpha:alpha];
}
+ (CGFloat)getWidthWithText:(NSString *)text Width:(CGFloat)width height:(CGFloat)height font:(CGFloat)font
{
    //内容宽度自适应
    CGSize size = CGSizeMake(width, height);
    NSDictionary *dic = @{NSFontAttributeName:[UIFont systemFontOfSize:font]};
    CGRect rect = [text boundingRectWithSize:size options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:dic context:nil];
    if (height == 0) {
        return rect.size.height;
    }else {
        return rect.size.width;
    }
}
@end
