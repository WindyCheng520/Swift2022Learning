//
//  MSUIConfiguration.h
//  BHSmartHome
//
//  Created by 邓立兵 on 2018/5/28.
//

#import <Foundation/Foundation.h>
#import <MBProgressHUD/MBProgressHUD.h>

typedef NS_ENUM(NSInteger, MBProgressHUD_Position) {
    MBProgressHUD_Position_Bottom,
    MBProgressHUD_Position_Center,
    MBProgressHUD_Position_Top,
};

#pragma mark - 一些常量
// 项目按钮或者输入框的圆角值，默认是2.0
UIKIT_EXTERN CGFloat const kMSBusinessCornerRadius;
// 项目按钮或者输入框的圆角值，默认是4.0
UIKIT_EXTERN CGFloat const kMSBusinessCornerRadius4;
// 项目按钮或者输入框的高度，默认是42.0
UIKIT_EXTERN CGFloat const kMSBusinessCommonViewHeight;
// 项目输入框上提示文本的高度，默认是34.0
UIKIT_EXTERN CGFloat const kMSBusinessCommonTipViewHeight;
// toast停留的时间(单位：秒)，默认是1.5
UIKIT_EXTERN CGFloat const kMSBusinessToastDuration;
// 对颜色变暗操作，通常用户button按下去颜色变化，模式是0.1
UIKIT_EXTERN CGFloat const kMSBusinessDarkeningValue;
// 项目按钮高度，默认是46.0
UIKIT_EXTERN CGFloat const kMSBusinessCommonButtonHeight;

@interface MSUIConfiguration : NSObject

#pragma mark - 颜色相关的信息
/**
 标题、列表、正文的颜色 #000000
 */
@property (nonatomic, strong, class) UIColor *sh_titleColor;

/**
 标题、列表、正文的浅黑颜色 #000000
 */
@property (nonatomic, strong, class) UIColor *sh_lightTitleColor;
/**
 摘要、标签文字颜色  #666666 深灰色
 */
@property (nonatomic, strong, class) UIColor *sh_summaryColor;

/**
 辅助文字颜色  #8A8A8F
 */
@property (nonatomic, strong, class) UIColor *sh_assistColor;

/**
 示意文字、按钮描边/强分割线颜色  #C7C7C7
 */
@property (nonatomic, strong, class) UIColor *sh_hintColor;

/**
 弱分割线颜色  #F2F2F2
 */
@property (nonatomic, strong, class) UIColor *sh_partingLineColor;

/**
 全局背景底色、标签底色块  #F9F9F9
 */
@property (nonatomic, strong, class) UIColor *sh_bgColor;

/**
 卡片、列表选项底色  #FFFFFF
 */
@property (nonatomic, strong, class) UIColor *sh_cardBgColor;

/**
 <辅助色> 重点突出、危险、紧急颜色(Red)  #FF3B30
 */
@property (nonatomic, strong, class) UIColor *sh_redColor;

/**
 <辅助色> 警告、注意(Orange)  #FF9500
 */
@property (nonatomic, strong, class) UIColor *sh_orangeColor;

/**
 <辅助色> 少用(Yellow)  #FFCC00
 */
@property (nonatomic, strong, class) UIColor *sh_yellowColor;

/**
 <辅助色> 安全、优先、完成(Green)  #4CD964
 */
@property (nonatomic, strong, class) UIColor *sh_greenColor;

/**
 <辅助色> 少用(Teal Blue)  #5BD2FF
 */
@property (nonatomic, strong, class) UIColor *sh_tealBlueColor;

/**
 <辅助色> 点缀色、强调、当前、链接(Blue)  #267AFF
 */
@property (nonatomic, strong, class) UIColor *sh_blueColor;

/**
 <辅助色> 少用(Purple)  #5856D6
 */
@property (nonatomic, strong, class) UIColor *sh_purpleColor;

/**
 <辅助色> 少用(浅黑色)  #303030
 */
@property (nonatomic, strong, class) UIColor *sh_darkColor;

/**
 <辅助色> 少用(浅黑色)  #4A4A4A
 */
@property (nonatomic, strong, class) UIColor *sh_4A4A4AColor;

/**
 卡片背景色 #F7F7F7
 */
@property (nonatomic, strong, class) UIColor *sh_cellBgColor;

#pragma mark - 字体相关信息（中文：苹方字体、英文：San Francisco）
/**
 超大字体 48px
 */
@property (nonatomic, strong, class) UIFont *sh_bigTitleFont;

/**
 一级标题(一级栏目、如服务、我的、标题文字) 28pt
 */
@property (nonatomic, strong, class) UIFont *sh_firstLevelTitleFont;

/**
 二级标题(智能-Tab标题、页面消息列表的标题“智能”) 18pt
 */
@property (nonatomic, strong, class) UIFont *sh_secondLevelTitleFont;

/**
 三级标题、列表选项、正文(二级页面顶部的标题文字、列表标题文字) 16pt
 */
@property (nonatomic, strong, class) UIFont *sh_thirdLevelTitleFont;

/**
 摘要、小号正文(一级大标题下的简述文字) 14pt
 */
@property (nonatomic, strong, class) UIFont *sh_summaryFont;

/**
 辅助、标签文字 12pt
 */
@property (nonatomic, strong, class) UIFont *sh_assistFont;

/**
 示意文字（底部导航栏示意文字） 10pt
 */
@property (nonatomic, strong, class) UIFont *sh_hintFont;

/**
 一些特殊的字体大小 20pt
 */
@property (nonatomic, strong, class) UIFont *sh_20SizeFont;

/**
 一些特殊的字体大小 36pt
 */
@property (nonatomic, strong, class) UIFont *sh_36SizeFont;

/**
 按钮标题 加粗16pt
 */
@property (nonatomic, strong, class) UIFont *sh_buttonTitleBoldFont;


+ (UIFont *)sh_pingFangSC_mediumFont:(NSInteger)fontSize;
+ (UIFont *)sh_pingFangSC_lightFont:(NSInteger)fontSize;


#pragma mark - 控件距离相关信息
/**
 项目的1pt的数值,@2x：0.5 @3x:0.333
 */
@property (nonatomic, assign, class) CGFloat sh_onePoint;
/**
 纵向：微小间距 4px
 */
@property (nonatomic, assign, class) CGFloat sh_verticalTinyDistance;

/**
 纵向：小号间距 8px
 */
@property (nonatomic, assign, class) CGFloat sh_verticalSmallDistance;

/**
 纵向：中间间距 12px
 */
@property (nonatomic, assign, class) CGFloat sh_verticalMiddleDistance;

/**
 纵向：大号间距 16px
 */
@property (nonatomic, assign, class) CGFloat sh_verticalBigDistance;

/**
 横向：小号间距 8px
 */
@property (nonatomic, assign, class) CGFloat sh_horizontalSmallDistance;

/**
 横向：中间间距 12px
 */
@property (nonatomic, assign, class) CGFloat sh_horizontalMiddleDistance;

/**
 横向：大号间距 16px
 */
@property (nonatomic, assign, class) CGFloat sh_horizontalBigDistance;

/**
 横向：超大号间距 24px
 */
@property (nonatomic, assign, class) CGFloat sh_horizontalHugeDistance;

/**
 距离屏幕最下的距离 36px
 */
@property (nonatomic, assign, class) CGFloat sh_bottomDistance;

/**
 距离屏幕最下的距离 24px
 */
@property (nonatomic, assign, class) CGFloat sh_bottomDistance_24;


#pragma mark - UI快速生成
+ (UIButton *)sh_createButtonWithFrame:(CGRect)frame
                                 title:(NSString *)title
                            titleColor:(UIColor *)titleColor
                                  font:(UIFont *)font;

+ (UITextField *)sh_createTextFieldWithFrame:(CGRect)frame
                                   leftSpace:(CGFloat)leftSpace
                                cornerRadius:(CGFloat)cornerRadius
                                 borderWidth:(CGFloat)borderWidth
                                 borderColor:(UIColor *)borderColor;

+ (UILabel *)sh_createLabelWithFrame:(CGRect)frame
                                text:(NSString *)text
                           textColor:(UIColor *)textColor
                                font:(UIFont *)font;




//注册登录输入框
+ (UITextField *)sh_createLoginTextFieldWithFrame:(CGRect)frame
                                      borderStyle:(UITextBorderStyle )borderStyle
                                             font:(UIFont *)font
                                      placeholder:(NSString *)placeholder
                                     keyboardType:(UIKeyboardType )keyboardType;

//传2个字符串以及样式 返回一个NSMutableAttributedString
+ (NSMutableAttributedString *)sh_getNewColorStr:(NSString *)headStr
                                        headFont:(UIFont *)headFont
                                       headColor:(UIColor *)headColor
                                         lastStr:(NSString *)lastStr
                                        lastFont:(UIFont *)lastFont
                                       lastColor:(UIColor *)lastColor;

//传3个字符串以及样式 返回一个NSMutableAttributedString
+ (NSMutableAttributedString *)sh_getNewColorStr:(NSString *)headStr
                                        headFont:(UIFont *)headFont
                                       headColor:(UIColor *)headColor
                                       middleStr:(NSString *)middleStr
                                      middleFont:(UIFont *)middleFont
                                     middleColor:(UIColor *)middleColor
                                         footStr:(NSString *)footStr
                                        footFont:(UIFont *)footFont
                                       footColor:(UIColor *)footColor;


#pragma mark - HUD
//只显示loading
+ (MBProgressHUD *)sh_showBlackLoadingHudToView:(UIView *)view;

//显示 “加载中” loading
+ (MBProgressHUD *)sh_showBlackDefaultLoadingHudToView:(UIView *)view;

//显示自定义的loading
+ (MBProgressHUD *)sh_showBlackLoadingHudToView:(UIView *)view text:(NSString *)text;

+ (MBProgressHUD *)sh_showWhiteLoadingHudToView:(UIView *)view text:(NSString *)text;

//显示toast提示，默认在底部
+ (MBProgressHUD *)sh_showBlackToastHudToView:(UIView *)view text:(NSString *)text;
+ (MBProgressHUD *)sh_showBlackToastHudToView:(UIView *)view text:(NSString *)text duration:(CGFloat)duration;
+ (MBProgressHUD *)sh_showBlackToastHudToView:(UIView *)view text:(NSString *)text duration:(CGFloat)duration position:(MBProgressHUD_Position)position;
// 显示toast img + 文字
+ (MBProgressHUD *)sh_showBlackToastHudToView:(UIView *)view text:(NSString *)text withImgName:(UIImage *)img position:(MBProgressHUD_Position)position duration:(CGFloat)duration;
// 显示中间 img + 文字 1.5S
+ (MBProgressHUD *)sh_showBlackToastHudToView:(UIView *)view text:(NSString *)text withImgName:(UIImage *)img;

+ (NSInteger)sh_hideAllHudForView:(UIView *)view animated:(BOOL)animated;

// 带进度的loading
+ (MBProgressHUD *)sh_showDeterminateToastHudToView:(UIView *)view text:(NSString *)text;

@end
