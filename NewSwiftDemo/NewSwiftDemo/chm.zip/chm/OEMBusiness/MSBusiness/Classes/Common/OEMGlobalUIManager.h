//
//  OEMGlobalUIManager.h
//  MSBusiness
//
//  Created by WindyCheng on 2022/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN


@interface OEMBusinessColor: NSObject

//品牌色：默认#267AFF
@property (nonatomic, strong) UIColor *brandColor;

//绿色：默认#01D28E
@property (nonatomic, strong) UIColor *greenColor;

//红色：默认#F35856
@property (nonatomic, strong) UIColor *redColor;

//橙色：默认#FF8F10
@property (nonatomic, strong) UIColor *orangeColor;

//白色：
@property (nonatomic, strong) UIColor *whiteColor;

//黑色：
@property (nonatomic, strong) UIColor *blackColor;


@end


@interface OEMLightModeLayoutColor: NSObject

//卡片背景色：默认#FFFFFF
@property (nonatomic, strong) UIColor *cardBackgroundColor;

//背景色：默认#F6F7FB
@property (nonatomic, strong) UIColor *backgroundColor;

//分割线颜色：默认#F0F0F0
@property (nonatomic, strong) UIColor *separatorColor;

//蒙版颜色：默认#000000 Alpha 0.6
@property (nonatomic, strong) UIColor *maskColor;


@end

@interface OEMDarkModeLayoutColor: NSObject

//卡片背景色：默认#1B1B1B
@property (nonatomic, strong) UIColor *cardBackgroundColor;

//背景色：默认#111111
@property (nonatomic, strong) UIColor *backgroundColor;

//分割线颜色：默认#303030
@property (nonatomic, strong) UIColor *separatorColor;

//蒙版颜色：默认#000000 Alpha 0.6
@property (nonatomic, strong) UIColor *maskColor;


@end



@interface OEMLightModeTextColor: NSObject
//主文本色：默认#212121
@property (nonatomic, strong) UIColor *mainTextColor;
//副文本色：默认#6C757D
@property (nonatomic, strong) UIColor *secondColor;
//弱文本色：默认#A7ACB1
@property (nonatomic, strong) UIColor *thirdColor;
//提示文本色：默认#D2D5D8
@property (nonatomic, strong) UIColor *tipsColor;
//主色：默认#267AFF
@property (nonatomic, strong) UIColor *mainColor;
//警告色：默认#F35856
@property (nonatomic, strong) UIColor *alertColor;
//主色浅：默认#FFFFFF
@property (nonatomic, strong) UIColor *mainLightColor;

@end


@interface OEMDarkModeTextColor: NSObject
//主文本色：默认#DEDEDE
@property (nonatomic, strong) UIColor *mainTextColor;
//副文本色：默认#899197
@property (nonatomic, strong) UIColor *secondColor;
//弱文本色：默认#52575B
@property (nonatomic, strong) UIColor *thirdColor;
//提示文本色：默认#373A3C
@property (nonatomic, strong) UIColor *tipsColor;
//主色：默认#267AFF
@property (nonatomic, strong) UIColor *mainColor;
//警告色：默认#F35856
@property (nonatomic, strong) UIColor *alertColor;
//主色浅：默认#FFFFFF
@property (nonatomic, strong) UIColor *mainLightColor;

@end





#define kBusiness  [OEMGlobalUIManager shareInstance].businessColor

#define kLightModeLayout  [OEMGlobalUIManager shareInstance].lightModeLayoutColor
#define kDarkModeLayoutColor  [OEMGlobalUIManager shareInstance].darkModeLayoutColor

#define kLightText  [OEMGlobalUIManager shareInstance].lightModeTextColor
#define kDarkText  [OEMGlobalUIManager shareInstance].darkModeTextColor

#define kRegularFont(x)  [UIFont fontWithName:@"PingFangSC-Regular" size:x]
#define kMediumFont(x)  [UIFont fontWithName:@"PingFangSC-Medium" size:x]

#define kSemiboldFont(x)  [UIFont fontWithName:@"PingFangSC-Semibold" size:x]

#define kSFProFont(x)   [UIFont fontWithName:@"SFProText-Medium" size:x]

#define kAlphaColor(color, alpha)  [[OEMGlobalUIManager shareInstance] alphaColor:(color) alpha:(alpha)];  




@interface OEMGlobalUIManager : NSObject

//业务色
@property (nonatomic, strong) OEMBusinessColor *businessColor;
//浅色布局
@property (nonatomic, strong) OEMLightModeLayoutColor *lightModeLayoutColor;
//深布局
@property (nonatomic, strong) OEMDarkModeLayoutColor *darkModeLayoutColor;
//浅色文字
@property (nonatomic, strong) OEMLightModeTextColor *lightModeTextColor;
//深色文字
@property (nonatomic, strong) OEMDarkModeTextColor *darkModeTextColor;


+(instancetype)shareInstance;

-(UIColor *)alphaColor:(UIColor *)color alpha:(CGFloat)alpha;

@end

NS_ASSUME_NONNULL_END
