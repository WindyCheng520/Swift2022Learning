//
//  MSRouterUrl.h
//  业务层的路由定义，统一定义在此
//
//  Created by yanghy on 20/5/14.
//  Copyright © 2020年 Midea. All rights reserved.
//

#ifndef MSRouterUrl_h
#define MSRouterUrl_h

//BH -> beautiful home
#define MSRouterScheme @"toshiba://"  //路由Scheme

//MSHome
#define MSRouterHomeIndex           MSRouterScheme @"home/index"          //首页

//MSHome
#define MSRouterHomeRootPage          MSRouterScheme @"home/RootPage"          //首页

//MSHome
#define MSRouterHtmlIndexTag                       @"home/html"           //html展示页
#define MSRouterHtmlIndex           MSRouterScheme MSRouterHtmlIndexTag           //html展示页

//MSMine
#define MSRouterMineIndex           MSRouterScheme @"mine/index"          //我的 首页

//MSLogin
#define MSRouterLoginIndex          MSRouterScheme @"login/index"         //登录页

//MSRegist
#define MSRouterRegistIndex          MSRouterScheme @"Regist/index"         //注册页

//MSLogin
#define MSRouterCountryIndex        MSRouterScheme @"login/country"       //国家选择页

//MSWeex
#define MSRouterWeexIndex           MSRouterScheme @"weex/index"          //weex页

//MSDevice
#define MSRouterDeviceIndex         MSRouterScheme @"device/index"        //配网 选择家电类型页

//MSDevice
#define MSRouterDeviceGuide         MSRouterScheme @"device/guide"        //配网指引页

//MSDevice
#define MSRouterDeviceWiFi          MSRouterScheme @"device/wifi"         //配网 wifi填写页

//MSDevice
#define MSRouterDeviceAuth          MSRouterScheme @"device/auth"         //配网 后确权页面

//MSDevice
#define MSRouterDeviceProgress        MSRouterScheme @"device/progress"        //配网进度页

//rn页面
#define MSRouterReactNativeIndex       MSRouterScheme @"reactnative/index" //rn页面


//MSMessageCenter
#define MSRouterMessageCenterIndex       MSRouterScheme @"messageCenter/index"        //消息列表页

//MSMessageCenter
#define MSRouterMessageCenterDetail       MSRouterScheme @"messageCenter/detail"        //消息列详情


//MSMine
#define MSRouterMineAlexa           MSRouterScheme @"mine/alexa"               //alexa页面

//MSMine
#define MSRouterMineGoogleAuth      MSRouterScheme @"mine/googleauth"               //google验证页面

//MSMine
#define MSRouterMineUploadLog      MSRouterScheme @"mine/uploadLog"               //上传日志

//MSDevice
#define MSRouterScanCode           MSRouterScheme @"device/scanCode"               //扫码页面

//MSDevice
#define MSRouterBLEDeviceGuide         MSRouterScheme @"bleDevice/guide"           //蓝牙配网指引页










#pragma mark - ====== ReactNative module name ======

#define MSReactNativeModuleNameDefine @"moduleName"

#define MSReactNativeViewProps @"MSReactNativeViewProps"

#define MSReactNativeInnerModule_usehelp @"usehelp"
#define MSReactNativeInnerModule_settings @"settings"
#define MSReactNativeInnerModule_profile @"profile"
#define MSReactNativeInnerModule_acplugin @"acplugin"
#define MSReactNativeInnerModule_e2plugin @"e2plugin"
#define MSReactNativeInnerModule_guide @"guide"
#define MSReactNativeInnerModule_mydevice @"mydevice"
#define MSReactNativeInnerModule_otaupdate @"otaupdate"

#define MSReactNativePlugin_0xE2_00A06882 @"OEM-ReactNative-0xE2-00A06882"

//对于部分RN插件状态栏颜色固定不变，即不跟随主题色变化的需求，这里定义一个列表
#define MSRNViewControllerStatusBarIgnoreThemeChange @[MSReactNativePlugin_0xE2_00A06882, MSReactNativeInnerModule_acplugin, MSReactNativeInnerModule_e2plugin]

#endif /* BHRouterUrl_h */
