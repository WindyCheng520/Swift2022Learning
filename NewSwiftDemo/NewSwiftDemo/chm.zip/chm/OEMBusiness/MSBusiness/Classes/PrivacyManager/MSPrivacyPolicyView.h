//
//  MSPrivacyPolicyView.h
//  MSHome
//
//  Created by 及时行乐 on 2020/6/28.
//

#import <UIKit/UIKit.h>
#import <OEMFoundation/HGAlertController.h>

typedef NS_ENUM(NSInteger, MSPrivacyPolicyViewType) {
    MSPrivacyPolicyViewType_First,    //首次弹框
    MSPrivacyPolicyViewType_Update      //更新弹框
};

@interface MSPrivacyPolicyView : UIView<HGAlertContentViewProtocol>

@property (nonatomic, copy) dispatch_block_t agreeBlock;
@property (nonatomic, copy) dispatch_block_t exitBlock;
@property (nonatomic, copy) dispatch_block_t privacyBlock;
@property (nonatomic, copy) dispatch_block_t softwareBlock;

- (instancetype)initWithType:(MSPrivacyPolicyViewType)type;

@end

