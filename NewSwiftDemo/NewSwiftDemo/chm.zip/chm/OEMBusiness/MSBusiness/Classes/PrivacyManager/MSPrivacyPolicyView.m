//
//  MSPrivacyPolicyView.m
//  MSHome
//
//  Created by 及时行乐 on 2020/6/28.
//

#import "MSPrivacyPolicyView.h"
#import "MSBusinessBundle.h"
#import <YYText/YYText.h>
#import "MSAppInfo.h"
@interface MSPrivacyPolicyView ()

@property (nonatomic, assign) CGSize contentSize;
@property (nonatomic, strong) HGLabel *titleLabel;
@property (nonatomic, strong) HGTextView *detailTextView;
@property (nonatomic, strong) HGButton *selectButton;
@property (nonatomic, strong) YYLabel *selectLabel;
@property (nonatomic, strong) HGButton *agreeButton;
@property (nonatomic, strong) HGButton *exitButton;
@property (nonatomic, assign) CGFloat selectTextHeight;
@property (nonatomic, copy)NSString * contentString;

@property (nonatomic, assign) MSPrivacyPolicyViewType type;


@end

@implementation MSPrivacyPolicyView
-(instancetype)initWithType:(MSPrivacyPolicyViewType)type{
    if (self = [super init]) {
        self.type = type;
        self.backgroundColor = [UIColor whiteColor];
        self.layer.cornerRadius = 16;
        
        NSString *title = @"";
        NSString *content = @"";
        switch (self.type) {
            case MSPrivacyPolicyViewType_First:{
                title = MSResourceString(@"privacy_page_title");
                NSString * appName = [MSAppInfo appName];
                content = [NSString stringWithFormat:MSResourceString(@"privacy_page_content"),appName];
                self.contentString = content;
            }
                break;
                
            case MSPrivacyPolicyViewType_Update:{
                title = MSResourceString(@"privacy_page_prompt_update");
                content = MSResourceString(@"privacy_page_terms_content_update");
                self.contentString = content;
            }
                break;
            default:
                break;
        }
               
        self.titleLabel = [HGLabel new];
        self.titleLabel.text = title;
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.textColor = RGB_HEX(0x000000);
        self.titleLabel.font = [UIFont systemFontOfSize:18 weight:UIFontWeightMedium];
        self.titleLabel.numberOfLines = 0;
        [self addSubview:self.titleLabel];
        
        self.detailTextView = [HGTextView new];
        self.detailTextView.editable = NO;

        [self addSubview:self.detailTextView];
        
        self.selectButton = [HGButton new];
        [self.selectButton setImage:MSResourceImage(@"ic_checkbox") forState:UIControlStateNormal];
        [self.selectButton setImage:MSResourceImage(@"ic_checkbox_s") forState:UIControlStateSelected];
        [self.selectButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:self.selectButton];
        
        self.selectLabel = [YYLabel new];
        self.selectLabel.numberOfLines = 0;
        [self addSubview:self.selectLabel];
        [self updateAttributedString];
        
        self.agreeButton = [HGButton new];
        [self.agreeButton setTitle:MSResourceString(@"privacy_page_button_agree") forState:UIControlStateNormal];
        [self.agreeButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
        self.agreeButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
        self.agreeButton.layer.cornerRadius = 22;
        self.agreeButton.backgroundColor = RGBA_HEX(0xEC1C24, 0.3f);
        self.agreeButton.enabled = NO;
        [self.agreeButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:self.agreeButton];
        
        self.exitButton = [HGButton new];
        [self.exitButton setTitleColor:RGB_HEX(0xEC1C24) forState:UIControlStateNormal];
        [self.exitButton setTitle:MSResourceString(@"privacy_page_button_exit") forState:UIControlStateNormal];
        self.exitButton.titleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
        [self.exitButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:self.exitButton];
        
        CGFloat titleHeight = [self getTextHeight:self.titleLabel.text textFont:self.titleLabel.font width:(SCREEN_WIDTH-20*2-16*2)];
        CGFloat contentHeight = 28+titleHeight+28+180+20+self.selectTextHeight+14+44+16+14+20;
        contentHeight = contentHeight > SCREEN_HEIGHT*0.9f ? SCREEN_HEIGHT*0.9f : contentHeight;
        self.contentSize = CGSizeMake(SCREEN_WIDTH-16*2, contentHeight);

        [self configureOEMTheme];
    }
    return self;
}

- (void)configureOEMTheme{
    [self configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.agreeButton configureThemeTag:OEMThemesTag_UIButton_Background];
    [self.exitButton configureThemeTag:OEMThemesTag_UIButton_TitleThemeColor];
    [self.titleLabel configure90TranslucentTrait];
    
    [self.detailTextView specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UITextView_Textcolor) : DarkThemeClearBackgroundButtonTitle
    } lightModeProperties:@{
        @(OEMThemesTag_UITextView_Textcolor) : LightThemeClearBackgroundButtonTitle
    }];
    [self.detailTextView configureThemeTag:OEMThemesTag_UITextView_Background];
    
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        [weakSelf updateAttributedString];
    } callImmidiately:YES];

}

- (void)updateAttributedString{
    UIColor * highLightTxtColor = DarkThemeNavigatorTextColor;
    UIColor * norTxtColor = LightThemeClearBackgroundButtonTitle;
    if (OEMThemeIsDarkMode) {
        highLightTxtColor = LightThemeNavigatorTextColor;
        norTxtColor = LightThemeTextFieldPlaceHolder;
    }
    NSString * appName = [MSAppInfo appName];
    NSString * title = [NSString stringWithFormat:MSResourceString(@"privacy_page_welcome"),appName];
    NSMutableAttributedString* detailString = [[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"%@%@",title,@"\n"] attributes:@{NSForegroundColorAttributeName:norTxtColor, NSFontAttributeName:[UIFont systemFontOfSize:13 weight:UIFontWeightMedium]}];
    [detailString appendAttributedString:[[NSAttributedString alloc] initWithString:self.contentString attributes:@{NSForegroundColorAttributeName:highLightTxtColor, NSFontAttributeName:[UIFont systemFontOfSize:13]}]];
    NSMutableParagraphStyle* paragraphStyle = [[NSMutableParagraphStyle alloc]init];
    paragraphStyle.paragraphSpacing = 8;
    paragraphStyle.lineSpacing = 5;
    [detailString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, detailString.length)];
    self.detailTextView.attributedText = detailString;
    
    NSString* selectString = MSResourceString(@"privacy_page_approve_content");
    NSRange privacyRange = [selectString rangeOfString:MSResourceString(@"privacy_page_privacy_terms_link")];
    NSRange softwareRange = [selectString rangeOfString:MSResourceString(@"privacy_page_protocol_link")];
    NSMutableAttributedString* selectAttributedString = [[NSMutableAttributedString alloc]initWithString:selectString attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:13], NSForegroundColorAttributeName:norTxtColor}];
    [selectAttributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, selectAttributedString.length)];
    WEAK_SELF;
    [selectAttributedString yy_setTextHighlightRange:privacyRange color:highLightTxtColor backgroundColor:[UIColor clearColor] tapAction:^(UIView * _Nonnull containerView, NSAttributedString * _Nonnull text, NSRange range, CGRect rect) {
        safeCallBlock(weak_self.privacyBlock);
    }];
    [selectAttributedString yy_setTextHighlightRange:softwareRange color:highLightTxtColor backgroundColor:[UIColor clearColor] tapAction:^(UIView * _Nonnull containerView, NSAttributedString * _Nonnull text, NSRange range, CGRect rect) {
        safeCallBlock(weak_self.softwareBlock);
    }];
    self.selectLabel.attributedText = selectAttributedString;
    self.selectTextHeight =  [YYTextLayout layoutWithContainerSize:CGSizeMake(SCREEN_SCALE_WIDTH(343)-20*2-20-8, MAXFLOAT) text:selectAttributedString].textBoundingSize.height;
}



-(void)layoutSubviews{
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(20);
        make.trailing.mas_equalTo(-20);
        make.top.mas_equalTo(28);
    }];
    [self.detailTextView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(20);
        make.trailing.mas_equalTo(-20);
        make.top.equalTo(self.titleLabel.mas_bottom).offset(28);
        make.height.mas_equalTo(180);
    }];
    [self.selectButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(20);
        make.size.mas_equalTo(CGSizeMake(20, 20));
        make.top.equalTo(self.selectLabel.mas_top);
    }];
    [self.selectLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.selectButton.mas_trailing).offset(8);
        make.trailing.mas_equalTo(-20);
        make.top.equalTo(self.detailTextView.mas_bottom).offset(20);
        make.height.mas_equalTo(self.selectTextHeight);
    }];
    [self.agreeButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self).offset(14);
        make.trailing.equalTo(self).offset(-14);
        make.top.equalTo(self.selectLabel.mas_bottom).offset(14);
        make.height.mas_equalTo(44);
    }];
    [self.exitButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(14);
        make.centerX.equalTo(self);
        make.top.equalTo(self.agreeButton.mas_bottom).offset(16);
    }];
    
}


-(void)clickButton:(UIButton*)sender{
    if (sender == self.selectButton) {
        sender.selected = !sender.isSelected;
        if (sender.isSelected) {
            self.agreeButton.backgroundColor = RGB_HEX(0xEC1C24);
            self.agreeButton.enabled = YES;
            /*
            self.agreeButton.layer.shadowColor = RGBA_HEX(0xEC1C24, 0.25f).CGColor;
            self.agreeButton.layer.shadowOffset = CGSizeMake(0,2);
            self.agreeButton.layer.shadowOpacity = 1;
            self.agreeButton.layer.shadowRadius = 10;
            self.agreeButton.layer.shadowPath = [UIBezierPath bezierPathWithRect:self.agreeButton.bounds].CGPath;
            */
            
        }else{
            self.agreeButton.backgroundColor = RGBA_HEX(0xEC1C24, 0.3f);
            self.agreeButton.enabled = NO;
            /*
            self.agreeButton.layer.shadowOpacity = 0;
             */
        }
    }else if (sender == self.agreeButton){
        safeCallBlock(self.agreeBlock);
        
    }else if (sender == self.exitButton){
        safeCallBlock(self.exitBlock);
        
    }
    
}


#pragma mark private

-(CGFloat)getTextHeight:(NSString *)text textFont:(UIFont *)font width:(CGFloat)width
{
    CGFloat height = [text boundingRectWithSize:CGSizeMake(width,CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:font} context:nil].size.height;
    return ceil(height);
}


@end
