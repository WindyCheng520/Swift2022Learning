//
//  MSPrivacyResult.h
//  MSBusiness
//
//  Created by pactera on 2020/11/21.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSErrorDomain const MSBusinessErrorDomain;

@interface MSPrivacyResult : NSObject

@property (nonatomic, assign) NSInteger update;
@property (nonatomic, copy) NSString *privateVersion;

@end

