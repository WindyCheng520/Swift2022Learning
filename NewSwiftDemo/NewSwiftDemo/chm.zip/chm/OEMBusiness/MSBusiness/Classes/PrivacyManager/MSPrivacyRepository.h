//
//  MSPrivacyRepository.h
//  MSBusiness
//
//  Created by pactera on 2020/11/21.
//

#import <Foundation/Foundation.h>
#import "MSBusinessError.h"
#import "MSPrivacyResult.h"

typedef void(^MSPrivacyRepositorySuccessBlock)(void);
typedef void(^MSPrivacyRepositoryFailureBlock)(MSBusinessError *error);
typedef void(^MSPrivacyRepositoryPrivacyUpdateSuccessBlock)(MSPrivacyResult* result);


@interface MSPrivacyRepository : NSObject

//检查隐私协议是否有更新
+ (void)checkPrivacyUpdateWithSuccess:(MSPrivacyRepositoryPrivacyUpdateSuccessBlock)success failure:(MSPrivacyRepositoryFailureBlock)failure;

//更新用户同意的隐私协议版本号
+ (void)privacyUpdateWithVersion:(NSString *)version Success:(MSPrivacyRepositorySuccessBlock)success failure:(MSPrivacyRepositoryFailureBlock)failure;

@end

