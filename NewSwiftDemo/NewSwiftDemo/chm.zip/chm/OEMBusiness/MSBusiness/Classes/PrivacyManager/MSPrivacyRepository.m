//
//  MSPrivacyRepository.m
//  MSBusiness
//
//  Created by pactera on 2020/11/21.
//

#import "MSPrivacyRepository.h"
#import <MSBusiness/BusinessRequestManager.h>
#import <MSBusiness/BusinessResponse.h>
#import <MSBusiness/MSAppInfo.h>
#import "MJExtension.h"

#define MSBusiness_CheckPrivacyUpdate      @"/v1/user/privacy/authorize/get"
#define MSBusiness_PrivacyUpdate           @"/v1/user/privacy/authorize"


@implementation MSPrivacyRepository

+ (void)checkPrivacyUpdateWithSuccess:(MSPrivacyRepositoryPrivacyUpdateSuccessBlock)success failure:(MSPrivacyRepositoryFailureBlock)failure {
    NSDictionary *paras = @{};
    
    [self POST:MSBusiness_CheckPrivacyUpdate parameters:paras success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            MSPrivacyResult *result = [MSPrivacyResult mj_objectWithKeyValues:res.data];
            safeCallBlock(success, result);
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSBusinessErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
    
}

+ (void)privacyUpdateWithVersion:(NSString *)version Success:(MSPrivacyRepositorySuccessBlock)success failure:(MSPrivacyRepositoryFailureBlock)failure {
    NSMutableDictionary *paras = @{}.mutableCopy;
    [paras setValue:version forKey:@"privateVersion"];
    
    [self POST:MSBusiness_PrivacyUpdate parameters:[paras copy] success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            safeCallBlock(success);
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSBusinessErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}

+ (NSURLSessionDataTask *_Nullable)POST:(NSString *_Nullable)URLString parameters:(NSDictionary *_Nullable)parameters success:(BusinessRequestManagerSuccess _Nullable )success failure:(BusinessRequestManagerFailure _Nullable )failure {
    return [[BusinessRequestManager sharedInstance] POST:URLString parameters:parameters cache:nil success:^(NSURLSessionTask * _Nonnull httpbase, id  _Nonnull responseObject) {
        safeCallBlock(success, httpbase, responseObject);
    } failure:^(NSURLSessionTask * _Nonnull httpbase, NSError * _Nonnull error) {
        safeCallBlock(failure, httpbase, error);
    }];
}


@end
