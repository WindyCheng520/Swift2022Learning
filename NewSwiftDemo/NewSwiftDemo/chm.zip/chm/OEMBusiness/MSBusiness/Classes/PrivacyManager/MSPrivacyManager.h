//
//  MSPrivacyManager.h
//  MSBusiness
//
//  Created by pactera on 2020/11/21.
//

#import <Foundation/Foundation.h>


@interface MSPrivacyManager : NSObject

+ (instancetype)shareManager;

//检查隐私协议是否有更新
- (void)checkPrivacyUpdate;

//弹框提示
- (void)showPrivacyUpdateAlertControllerWithPageName:(NSString *)pageName sourceController:(UIViewController *)sourceController;

//判断是否有更新
- (BOOL)privacyNeedUpdate;

@end

