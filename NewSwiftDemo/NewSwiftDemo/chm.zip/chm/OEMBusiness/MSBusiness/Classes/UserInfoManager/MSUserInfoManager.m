//
//  MSUserInfoManager.m
//  MSBusiness
//
//  Created by pactera on 2020/12/29.
//  用户信息管理类

#import "MSUserInfoManager.h"
#import "MSUserDefaultTools.h"
#import <MJExtension/MJExtension.h>
#import <OEMFoundation/OEMMacros.h>

static NSString* const MSMideaCloudAccessTokenKey = @"MSMideaCloudAccessTokenKey";
static NSString* const MSMideaCloudRandomDataKey = @"MSMideaCloudRandomDataKey";
static NSString* const MSUserAccountKey = @"MSUserAccountKey";
static NSString* const MSMasAccessTokenKey = @"MSMasAccessTokenKey";
static NSString* const MSMasTokenPwdKey = @"MSMasTokenPwdKey";
static NSString* const MSUserUidKey = @"MSUserUidKey";
static NSString* const MSUserNicknameKey = @"MSUserNicknameKey";
//是否是苹果登录的标志为位
static NSString* const MSIOTOEMUserAppleSignInTagKey = @"MSIOTOEMUserAppleSignInTagKey";
static NSString* const MSIOTOEMUserAppleSignContextKey = @"MSIOTOEMUserAppleSignContextKey";

@interface MSUserInfoManager ()

@property (nonatomic, strong) MSUserInfo *userInfoModel;
@property (nonatomic, strong) MSLoginInfo *loginInfoModel;
@property (nonatomic, assign) BOOL isLogin;

@end

@implementation MSUserInfoManager

+ (instancetype)shareManager {
    static MSUserInfoManager *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[MSUserInfoManager alloc] init];
        [manager getUserInfoFromLocal];
        [manager getLoginInfoFromLocal];
    });
    return manager;
}

#pragma mark - userinfo
- (void)getUserInfoFromLocal {
    self.userInfoModel = [MSUserInfo getUserInfoFromLocal];
}

- (void)updateUserInfoFromNetworkWithSuccess:(void(^)(void))success failure:(void(^)(MSBusinessError *error))failure {    
    @weakify(self)
    [MSUserInfoRepository getUserInfoWithSuccess:^(MSUserInfo *result) {
        @strongify(self)
        self.userInfoModel = [result copy];
        [MSUserInfo saveUserInfoToLocal:[result copy]];
        [self updateLoginInfoEmailWithUserInfoEmail:result.email];
        [self updateLoginInfoNicknameWithUserInfoNickname:result.nickName];
        safeCallBlock(success);
    } failure:^(MSBusinessError *error) {
        safeCallBlock(failure, error);
    }];
}

- (void)clearUserInfoData {
    [MSUserInfo clearUserInfoLocalData];
    self.userInfoModel = nil;
}

#pragma mark - login
- (BOOL)isLogin {
    return (self.loginInfoModel != nil) ? YES : NO;
}

- (void)getLoginInfoFromLocal {
    self.loginInfoModel = [MSLoginInfo getLoginInfoFromLocal];
#if AppStore_ENV==0
    NSNumber * num = [[NSUserDefaults standardUserDefaults] objectForKey:@"KSwitchToolsKey_UseExistedOtherDeviceLoginInfo_BOOL"];
    if (num && [num isKindOfClass:[NSNumber class]] && num.boolValue) {
        if (!self.loginInfoModel) {
            //这里吧userinfo给取出来
            NSString * string = [[NSUserDefaults standardUserDefaults] objectForKey:@"loginInfoModelJSONStringForSwitchTool_JSON"];
            if (![string isKindOfClass:[NSString class]] || [string length] <= 0 || [string rangeOfString:@"AccessToken"].location == NSNotFound) {
                return;
            }
            NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:[string dataUsingEncoding:NSUTF8StringEncoding] options:0 error:nil];
            if (!dic) {
                return;
            }
            MSLoginInfo * info = [MSLoginInfo mj_objectWithKeyValues:dic];
            if (info) {
                self.loginInfoModel = info;
            }
        }
    }
    
    //这里保存一下logininfo到userdefault
    NSString * json = [self.loginInfoModel mj_JSONString];
    [[NSUserDefaults standardUserDefaults] setObject:json ?:@"" forKey:@"loginInfoModelJSONStringForSwitchTool_JSON"];
#endif
}

- (void)saveLoginInfoDataWithModel:(MSLoginInfo *)loginInfo {
    self.loginInfoModel = [loginInfo copy];
    [MSLoginInfo saveLoginInfoToLocal:[loginInfo copy]];
}

- (void)updateLoginInfoEmailWithUserInfoEmail:(NSString *)email {
    if (![self.loginInfoModel.email isEqualToString:email]) {
        self.loginInfoModel.email = email;
        [MSLoginInfo saveLoginInfoToLocal:[self.loginInfoModel copy]];
    }
}

- (void)updateLoginInfoNicknameWithUserInfoNickname:(NSString *)nickname {
    if (![self.loginInfoModel.nickname isEqualToString:nickname]) {
        self.loginInfoModel.nickname = nickname;
        [MSLoginInfo saveLoginInfoToLocal:[self.loginInfoModel copy]];
    }
}

- (void)updateLoginInfoMasAccessTokenWithAccessToken:(NSString *)accessToken {
    if (![self.loginInfoModel.accessToken isEqualToString:accessToken]) {
        self.loginInfoModel.accessToken = accessToken;
        [MSLoginInfo saveLoginInfoToLocal:[self.loginInfoModel copy]];
    }
}

- (void)clearLoginInfoData {
    [MSLoginInfo clearLoginInfoLocalData];
    self.loginInfoModel = nil;
    [self cleanAppleSignInInfo];
}

//1.3.0之前的版本，登录信息是存在userdefault且没有加密，需要取出来加密存储
- (void)resultOldVersionLoginInfo {
}

- (BOOL)isAppleSignIn{
    NSString * uid = [[NSUserDefaults standardUserDefaults] valueForKey:MSIOTOEMUserAppleSignInTagKey];
    if (uid && [uid isKindOfClass:[NSString class]] && [uid length] > 0) {
        return true;
    }
    return false;
}

- (void)cleanAppleSignInInfo{
    [[NSUserDefaults standardUserDefaults] setValue:@"" forKey:MSIOTOEMUserAppleSignInTagKey];
}

- (void)saveAppleSignInTagAndContext:(NSDictionary *)context{
    //email仅仅用于客户端显示最新的apple uid关联的邮箱，不会同步到云端
    if (![context isKindOfClass:[NSDictionary class]]) {
        return;
    }
    NSString * uid = [context objectForKey:@"uid"];
    if (!uid || ![uid isKindOfClass:[NSString class]]) {
        return;;
    }
    
    [[NSUserDefaults standardUserDefaults] setValue:uid forKey:MSIOTOEMUserAppleSignInTagKey];
    NSString * contextkey = [self appleSignInContextWithUID:uid];
    NSDictionary * existedInfo = [[NSUserDefaults standardUserDefaults] valueForKey:contextkey];
    NSString * email = [context objectForKey:@"email"];
    if ((!email || ([email isKindOfClass:[NSString class]] && email.length == 0)) &&
        existedInfo &&
        [existedInfo isKindOfClass:[NSDictionary class]] &&
        [existedInfo objectForKey:@"email"]) {
        //email只在第一次授权的时候有值，所以只允许更新email（即相同Apple ID在系统解除绑定后，重新绑定时， 由分享邮箱改为隐藏邮箱或者由隐藏邮箱改为分享邮箱）
        NSMutableDictionary * dic = [[NSMutableDictionary alloc] initWithDictionary:context];
        [dic setValue:[existedInfo objectForKey:@"email"] ?: @"" forKey:@"email"];
        context = dic;
    }

    [[NSUserDefaults standardUserDefaults] setValue:context ?: @{} forKey:contextkey];
    [[NSUserDefaults standardUserDefaults] synchronize];

}

- (NSString *)appleSignInContextWithUID:(NSString *)uid{
    return [NSString stringWithFormat:@"%@_%@", MSIOTOEMUserAppleSignContextKey, uid];
}

- (NSString *)appleSignInEmail{
    if (self.isAppleSignIn) {
        NSDictionary * info = [self AppleSignInContext];
        if (info && [info isKindOfClass:[NSDictionary class]] && [info objectForKey:@"email"]) {
            return [info objectForKey:@"email"] ?: @"";
        }
    }
    return @"";
}

- (NSDictionary *)AppleSignInContext{
    NSString * uid =  [[NSUserDefaults standardUserDefaults] objectForKey:MSIOTOEMUserAppleSignInTagKey];
    if (uid && [uid isKindOfClass:[NSString class]]) {
        return [[NSUserDefaults standardUserDefaults] valueForKey:[self appleSignInContextWithUID:uid]];
    }
    return @{};
}

@end
