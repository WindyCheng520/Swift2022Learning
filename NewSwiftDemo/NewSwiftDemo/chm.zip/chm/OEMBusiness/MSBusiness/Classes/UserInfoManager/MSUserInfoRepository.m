//
//  MSUserInfoRepository.m
//  MSBusiness
//
//  Created by pactera on 2020/12/29.
//

#import "MSUserInfoRepository.h"
#import "BusinessRequestManager.h"
#import "BusinessResponse.h"
#import "MSAppInfo.h"
#import "MJExtension.h"
#import <OEMFoundation/HGFoundationMacros.h>

NSString *const MSUserInfoErrorDomain = @"MSUserInfoErrorDomain";

//获取用户个人信息
#define MSUserInfo_Get @"/v1/user/query"                 // @"/v1/user/info/get"

@implementation MSUserInfoRepository

+ (void)getUserInfoWithSuccess:(MSUserInfoRepositoryUserInfoSuccess)success failure:(MSUserInfoRepositoryFailureBlock)failure {
  //  NSMutableDictionary *iotData = [MSAppInfo getBaseIotData];
    NSDictionary* paras = @{};//[iotData copy];
    
    [self POST:MSUserInfo_Get parameters:paras success:^(NSURLSessionTask * _Nonnull httpbase, id  _Nonnull responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK){
            MSUserInfo *result = [MSUserInfo mj_objectWithKeyValues:res.data];
            safeCallBlock(success, result);
        }else{
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSUserInfoErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
    } failure:^(NSURLSessionTask * _Nonnull httpbase, NSError * _Nonnull error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
    
}

+ (NSURLSessionDataTask *_Nullable)POST:(NSString *_Nullable)URLString parameters:(NSDictionary *_Nullable)parameters success:(BusinessRequestManagerSuccess _Nullable )success failure:(BusinessRequestManagerFailure _Nullable )failure {
    return [[BusinessRequestManager sharedInstance] POST:URLString parameters:parameters cache:nil success:^(NSURLSessionTask * _Nonnull httpbase, id  _Nonnull responseObject) {
        safeCallBlock(success, httpbase, responseObject);
    } failure:^(NSURLSessionTask * _Nonnull httpbase, NSError * _Nonnull error) {
        safeCallBlock(failure, httpbase, error);
    }];
}


@end
