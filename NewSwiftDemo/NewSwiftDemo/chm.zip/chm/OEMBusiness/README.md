# MSBusiness

[![CI Status](https://img.shields.io/travis/yanghy2013@163.com/MSBusiness.svg?style=flat)](https://travis-ci.org/yanghy2013@163.com/MSBusiness)
[![Version](https://img.shields.io/cocoapods/v/MSBusiness.svg?style=flat)](https://cocoapods.org/pods/MSBusiness)
[![License](https://img.shields.io/cocoapods/l/MSBusiness.svg?style=flat)](https://cocoapods.org/pods/MSBusiness)
[![Platform](https://img.shields.io/cocoapods/p/MSBusiness.svg?style=flat)](https://cocoapods.org/pods/MSBusiness)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

MSBusiness is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'MSBusiness'
```

## Author

yanghy2013@163.com, yanghy22@midea.com

## License

MSBusiness is available under the MIT license. See the LICENSE file for more info.


从网站上下载多语言strings 文件， 放在Loc 文件目录下之后执行loc.py 脚本
