//
//  WMLineChartView.m
//  Weima
//
//  Created by Windy on 2018/4/23.
//  Copyright © 2018年 微马科技控股有限公司. All rights reserved.
//

#import "WMLineChartView.h"
#import "Weima-Bridging-Header.h"
#import "IntAxisValueFormatter.h"
#import "WMStepModel.h"
#import "WMRunChartModel.h"

@interface WMLineChartView () <ChartViewDelegate>

@property(nonatomic, strong)LineChartView *lineView;

@property(nonatomic, strong)UILabel *markY;

@end

@implementation WMLineChartView

- (instancetype)initWithFrame:(CGRect)frame{
    
    if (self = [super initWithFrame:frame] ) {
        
        [self layoutUI];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    if (self = [super initWithCoder:aDecoder]) {
        [self layoutUI];
    }
    return self;
}

- (void)layoutUI{
//   _lineView = [[LineChartView alloc] initWithFrame:self.frame];
    
    _lineView = [[LineChartView alloc] init];
    [self addSubview:self.lineView];
//    @weakify(self)
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
//        @strongify(self)
        make.left.top.right.bottom.mas_equalTo(0);
    }];
    
    _lineView.delegate = self;//设置代理
    _lineView.backgroundColor = ColorFF;
    _lineView.noDataText = @"暂无数据";
    _lineView.chartDescription.enabled = NO;
    
    // 1.设置交互样式
    _lineView.scaleYEnabled = NO;//Y轴缩放
    _lineView.doubleTapToZoomEnabled = NO;//取消双击缩放
    _lineView.pinchZoomEnabled = YES;
    _lineView.dragEnabled = YES;//启用拖拽图标
    //    _lineView.drawValueAboveBarEnabled = YES;
    _lineView.dragDecelerationEnabled = YES;//拖拽后是否有惯性效果
    _lineView.dragDecelerationFrictionCoef = 0.9;//拖拽后惯性效果的摩擦系数(0~1)，数值越小，惯性越不明显
    
    //描述及图例样式
    //[_lineView setDescriptionText:@""];
    _lineView.legend.enabled = NO;
    [_lineView animateWithXAxisDuration:1.0f];
    
    //X轴样式
    //    ChartXAxis *xAxis = self.lineView.xAxis;
    //    xAxis.axisLineWidth = 1.0/[UIScreen mainScreen].scale;//设置X轴线宽
    //    xAxis.labelPosition = XAxisLabelPositionBottom;//X轴的显示位置，默认是显示在上面的
    //    xAxis.drawGridLinesEnabled = NO;//不绘制网格线
    //    xAxis.spaceBetweenLabels = 4;//设置label间隔
    //    xAxis.labelTextColor = [self colorWithHexString:@"#057748"];//label文字颜色
    
    //Y轴样式
    _lineView.rightAxis.enabled = NO;   //不绘制右边轴
    ChartYAxis *leftAxis = _lineView.leftAxis;   //获取左边Y轴
    //Y轴label数量，数值不一定，如果forceLabelsEnabled等于YES, 则强制绘制制定数量的label, 但是可能不平均
   leftAxis.labelCount = 5; // 3
    leftAxis.forceLabelsEnabled = YES;  //不强制绘制指定数量的label
    
    //    leftAxis.isAxisMaxCustom
    leftAxis.axisMinimum = 0;//设置Y轴的最小值
    //    leftAxis.startAtZeroEnabled = YES;//从0开始绘制
    leftAxis.axisMaximum = 183;//设置Y轴的最大值     不用设置自动帮你算
    
    leftAxis.inverted = NO;//是否将Y轴进行上下翻转
    leftAxis.axisLineWidth = 1.0; ///[UIScreen mainScreen].scale; //Y轴线宽
    leftAxis.axisLineColor = ColorDB;//Y轴颜色
//    leftAxis.axisLineColor = [UIColor clearColor];
    leftAxis.drawGridLinesEnabled = NO;   //不绘制Y方向网格线
    leftAxis.labelPosition = YAxisLabelPositionOutsideChart;//label位置
    leftAxis.labelTextColor = Color99;//文字颜色
    leftAxis.labelFont = [UIFont systemFontOfSize:10.0f];//文字字体
    //    leftAxis.valueFormatter = [[IntAxisValueFormatter alloc] init];//设置y轴的数据格式
    NSNumberFormatter *rightAxisFormatter = [[NSNumberFormatter alloc] init];
    //    //负数的后缀
    //    rightAxisFormatter.negativeSuffix = @" %";
    //    //正数的后缀
    //    rightAxisFormatter.positiveSuffix = @" %";
    
    leftAxis.valueFormatter = [[ChartDefaultAxisValueFormatter alloc] initWithFormatter:rightAxisFormatter];
    
//    // 4.设置网格线样式
//    leftAxis.gridColor = [UIColor grayColor];//网格线颜色
//    leftAxis.gridLineDashLengths = @[@3.0f, @3.0f];//设置虚线样式的网格线
//    leftAxis.gridAntialiasEnabled = NO;//开启抗锯齿
//
    
    // = @" $";//数字后缀单位
    
    // 5.设置X轴样式
    ChartXAxis *xAxis = _lineView.xAxis;
    xAxis.axisLineWidth = 1.0;  /// [UIScreen mainScreen].scale;//设置X轴线宽
    xAxis.granularityEnabled = YES;  //设置重复的值不显示
    xAxis.drawGridLinesEnabled = NO;  //不绘制X方向网格线
    //    xAxis.gridColor = [UIColor greenColor];
//    xAxis.spaceMin = 4;  //崩溃？ 设置label间隔
    xAxis.labelWidth =  1; //
    xAxis.labelPosition = XAxisLabelPositionBottom;//设置x轴数据在底部
    
    xAxis.labelTextColor = Color99; //文字颜色
    xAxis.axisLineColor = ColorDB;//X轴颜色
    
//    _lineView.maxVisibleCount = 30;//设置能够显示的数据数量
//    xAxis.labelCount = 30;

    
    
    //    5.添加限制线
    //    限制线可以添加多条, 在这里只添加一条做演示, 代码如下:
//    ChartLimitLine *limitLine = [[ChartLimitLine alloc] initWithLimit:80 label:@"限制线"];
//    limitLine.lineWidth = 4;
//    limitLine.lineColor = [UIColor greenColor];
//    limitLine.lineDashLengths = @[@5.0f, @5.0f];//虚线样式
//    limitLine.labelPosition = ChartLimitLabelPositionRightTop;//位置
//    limitLine.valueTextColor = [self colorWithHexString:@"#057748"];//label文字颜色
//    limitLine.valueFont = [UIFont systemFontOfSize:12];//label字体
//    [leftAxis addLimitLine:limitLine];//添加到Y轴上
//    leftAxis.drawLimitLinesBehindDataEnabled = YES;//设置限制线绘制在折线图的后面
    
    
    //    6.设置折线图描述及图例样式
    //    当有多条折线显示在图表上时, 通常需要一个'图例'来说明每一条折线的名称或者代表的含义, 这时候就要进行图例的设置, 主要代码如下:
    //    self.lineView.chartDescription.description = @"折线图";
    //
    //    [self.lineView setDescriptionTextColor:[UIColor darkGrayColor]];
    
    
    self.lineView.legend.form = ChartLegendFormLine;//图例的样式
    self.lineView.legend.formSize = 30;//图例中线条的长度
    self.lineView.legend.textColor = [UIColor darkGrayColor];//图例文字颜色
    
//    ChartMarkerView *markerY = [[ChartMarkerView alloc]init];
//    markerY.offset = CGPointMake(-999, -8);
//    markerY.chartView = _lineView;
//    _lineView.marker = markerY;
//    [markerY addSubview:self.markY];
//        self.markY = markerY;
//    self.lineView.data = [self setData];
    
    BalloonMarker *marker = [[BalloonMarker alloc]
                             initWithColor: [UIColor colorWithWhite:180/255. alpha:1.0]
                             font: [UIFont systemFontOfSize:12.0]
                             textColor:ColorFF6300
                             insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0)];
    marker.chartView = _lineView;
    marker.minimumSize = CGSizeMake(80.f, 40.f);
    _lineView.marker = marker;
    
}

//懒加载
- (UILabel *)markY{
    if (!_markY) {
        _markY = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 35, 25)];
        _markY.font = [UIFont systemFontOfSize:15.0];
        _markY.textAlignment = NSTextAlignmentCenter;
        _markY.text =@"";
        _markY.textColor = [UIColor whiteColor];
        _markY.backgroundColor = [UIColor grayColor];
    }
    return _markY;
}

- (void)setCommonArray:(NSArray *)commonArray{
    _commonArray = commonArray;
    useWeakSelf
    dispatch_async(dispatch_get_main_queue(), ^{
        weakSelf.lineView.data  = [weakSelf setData];
    });
}

- (LineChartData *)setData{
    
    NSInteger xVals_count = 33;//X轴上要显示多少条数据
    double maxYVal = 175;//Y轴的最大值
    
    //X轴上面需要显示的数据
  __block  NSMutableArray *xVals = [[NSMutableArray alloc] init];
//    for (int i = 0; i < xVals_count; i++) {
//        [xVals addObject: [NSString stringWithFormat:@"%d",i]];
//    }
    //    _lineView.xAxis.valueFormatter = [[Date1ValueFormatter alloc] initWithArr:xVals];
    
    //对应Y轴上面需要显示的数据
  __block  NSMutableArray *yVals = [[NSMutableArray alloc] init];
    
    [self.commonArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//        WMStepModel *entity = (WMStepModel *)obj;
        WMRunChartModel *entity = (WMRunChartModel *)obj;
        [xVals addObject: entity.minute];
       
    if(self.type == StepType){
        //步频
        ChartDataEntry *entry = [[ChartDataEntry alloc] initWithX:idx y:entity.step];
        [yVals addObject:entry];
    }else{
        //步福
        ChartDataEntry *entry = [[ChartDataEntry alloc] initWithX:idx y:entity.stride];
        [yVals addObject:entry];
    }
    }];
//    for (int i = 0; i < xVals_count; i++) {
//        double mult = maxYVal + 1;
//        int a = (double)(arc4random_uniform(mult));
//        ChartDataEntry *entry = [[ChartDataEntry alloc] initWithX:i y:a];
//        [yVals addObject:entry];
//    }
    
    LineChartDataSet *set1 = nil;
    if (_lineView.data.dataSetCount > 0) {
        LineChartData *data = (LineChartData *)_lineView.data;
        set1 = (LineChartDataSet *)data.dataSets[0];
        set1.values = yVals;
        //        set1.valueFormatter = [[SetValueFormatter alloc] initWithArr:yVals];
        return data;
    }else{
        //创建LineChartDataSet对象
        set1 = [[LineChartDataSet alloc] initWithValues:yVals label:@"lineName"];
        
        //设置折线的样式
        set1.lineWidth = 1.0;//折线宽度
        set1.drawValuesEnabled = NO;//在拐点处显示数据
        //        set1.valueFormatter = [[SetValueFormatter alloc] initWithArr:yVals];
        set1.valueColors = @[[UIColor redColor]];//折线拐点处显示数据的颜色
        [set1 setColor:ColorFF6300]; //折线颜色 RGB(219, 150, 38)
        //        set1.drawSteppedEnabled = NO;//是否开启绘制阶梯样式的折线图
        //折线拐点样式
        set1.drawCirclesEnabled = NO;//是否绘制拐点
        set1.mode = LineChartModeCubicBezier;   //平滑曲线  LineChartModeLinear
        
        //        set1.circleRadius = 4.0f;//拐点半径
        //        set1.circleColors = @[[UIColor redColor], [UIColor greenColor]];//拐点颜色
        //        //拐点中间的空心样式
        //        set1.drawCircleHoleEnabled = YES;//是否绘制中间的空心
        //        set1.circleHoleRadius = 2.0f;//空心的半径
        //        set1.circleHoleColor = [UIColor blackColor];//空心的颜色
        
        NSArray *gradientColors = @[
                                    (id)[ChartColorTemplates colorFromString:@"#FFFFFF"].CGColor,
                                    (id)[ChartColorTemplates colorFromString:@"#FF6300"].CGColor
                                    ];
        
//        NSArray *gradientColors = @[
//                                    (id)[ChartColorTemplates colorFromString:@"#FF4D483E"].CGColor,
//                                    (id)[ChartColorTemplates colorFromString:@"#FF2F2F2F"].CGColor
//                                    ];
        
        CGGradientRef gradientRef = CGGradientCreateWithColors(nil, (CFArrayRef)gradientColors, nil);
        set1.fillAlpha = 1.0f;//透明度
        set1.fill = [ChartFill fillWithLinearGradient:gradientRef angle:90.0f];//赋值填充颜色对象
        set1.drawFilledEnabled = YES;//是否填充颜色
        CGGradientRelease(gradientRef);//释放gradientRef
        
        //点击选中拐点的交互样式
        set1.highlightEnabled = YES;//选中拐点,是否开启高亮效果(显示十字线)
        set1.highlightColor = [self colorWithHexString:@"#c83c23"]; //点击选中拐点的十字线的颜色
        set1.highlightLineWidth = 0.5 / [UIScreen mainScreen].scale; //十
        set1.highlightLineDashLengths = @[@5, @5];  //十字线的虚线样式
        
        //将 LineChartDataSet 对象放入数组中
        NSMutableArray *dataSets = [[NSMutableArray alloc] init];
        [dataSets addObject:set1];
        
        //添加第二个LineChartDataSet对象
        
        //        NSMutableArray *yVals2 = [[NSMutableArray alloc] init];
        //        for (int i = 0; i <  xVals_count; i++) {
        //            double mult = maxYVal + 1;
        //            double val = (double)(arc4random_uniform(mult));
        //            ChartDataEntry *entry = [[ChartDataEntry alloc] initWithX:i y:val];
        //            [yVals2 addObject:entry];
        //        }
        //        LineChartDataSet *set2 = [set1 copy];
        //        set2.values = yVals2;
        //        set2.drawValuesEnabled = NO;
        //        [set2 setColor:[UIColor blueColor]];
        //
        //        [dataSets addObject:set2];
        
        //创建 LineChartData 对象, 此对象就是lineChartView需要最终数据对象
        LineChartData *data = [[LineChartData alloc] initWithDataSets:dataSets];
        [data setValueFont:[UIFont fontWithName:@"HelveticaNeue-Light" size:11.f]];//文字字体
        [data setValueTextColor:[UIColor blackColor]];//文字颜色
        
        //        NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
        //        //自定义数据显示格式
        //        [formatter setNumberStyle:NSNumberFormatterDecimalStyle];
        //        [formatter setPositiveFormat:@"#0.0"];
        //        [data setValueFormatter:formatter];
        
        return data;
    }
}

- (void)chartValueSelected:(ChartViewBase * _Nonnull)chartView entry:(ChartDataEntry * _Nonnull)entry highlight:(ChartHighlight * _Nonnull)highlight {
    
//    _markY.text = [NSString stringWithFormat:@"%ld",(NSInteger)entry.y];//改变选中的数据时候，label的值跟着变化
//    //将点击的数据滑动到中间
//    [_lineView centerViewToAnimatedWithXValue:entry.x yValue:entry.y axis:[_lineView.data getDataSetByIndex:highlight.dataSetIndex].axisDependency duration:1.0];
}

- (void)chartValueNothingSelected:(ChartViewBase * _Nonnull)chartView {
    
    
}


//将十六进制颜色转换为 UIColor 对象
- (UIColor *)colorWithHexString:(NSString *)color{
    NSString *cString = [[color stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    // String should be 6 or 8 characters
    if ([cString length] < 6) {
        return [UIColor clearColor];
    }
    // strip "0X" or "#" if it appears
    if ([cString hasPrefix:@"0X"])
        cString = [cString substringFromIndex:2];
    if ([cString hasPrefix:@"#"])
        cString = [cString substringFromIndex:1];
    if ([cString length] != 6)
        return [UIColor clearColor];
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    //r
    NSString *rString = [cString substringWithRange:range];
    //g
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    //b
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    return [UIColor colorWithRed:((float) r / 255.0f) green:((float) g / 255.0f) blue:((float) b / 255.0f) alpha:1.0f];
}


@end
