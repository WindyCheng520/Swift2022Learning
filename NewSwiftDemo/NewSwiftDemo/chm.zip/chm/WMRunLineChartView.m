//
//  WMRunLineChartView.m
//  Weima
//
//  Created by William Yin on 2018/9/1.
//  Copyright © 2018年 微马科技控股有限公司. All rights reserved.
//

#import "WMRunLineChartView.h"
#import "Weima-Bridging-Header.h"
#import "IntAxisValueFormatter.h"
#import "WMStepModel.h"
#import "WMRunChartModel.h"

@interface WMRunLineChartView () <ChartViewDelegate>

@property(nonatomic, strong)LineChartView *lineView;
@property(nonatomic, strong)UILabel *markY;

@end

@implementation WMRunLineChartView

- (instancetype)initWithFrame:(CGRect)frame{
    
    if (self = [super initWithFrame:frame] ) {
        
        [self layoutUI];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    if (self = [super initWithCoder:aDecoder]) {
        [self layoutUI];
    }
    return self;
}

- (void)layoutUI{
    
    _lineView = [[LineChartView alloc] init];
    [self addSubview:self.lineView];
    
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.top.right.bottom.mas_equalTo(0);
    }];
    
    _lineView.delegate = self;//设置代理
    _lineView.chartDescription.enabled = NO;
    _lineView.backgroundColor = ColorFF;
    _lineView.noDataText = @"暂无数据";
    
    [_lineView setScaleEnabled:YES];
    _lineView.drawGridBackgroundEnabled = NO;
    
    // 1.设置交互样式
    _lineView.scaleYEnabled = NO;//Y轴缩放
    _lineView.doubleTapToZoomEnabled = NO;//取消双击缩放
    _lineView.pinchZoomEnabled = YES;
    _lineView.dragEnabled = YES;//启用拖拽图标
    //    _lineView.drawValueAboveBarEnabled = YES;
    _lineView.dragDecelerationEnabled = YES;//拖拽后是否有惯性效果
    _lineView.dragDecelerationFrictionCoef = 0.9;//拖拽后惯性效果的摩擦系数(0~1)，数值越小，惯性越不明显
    
    //描述及图例样式
    //[_lineView setDescriptionText:@""];
    _lineView.legend.enabled = NO;
    [_lineView animateWithXAxisDuration:1.0f];
    
    //Y轴样式
    _lineView.rightAxis.enabled = NO;   //不绘制右边轴
    ChartYAxis *leftAxis = _lineView.leftAxis;   //获取左边Y轴
    //Y轴label数量，数值不一定，如果forceLabelsEnabled等于YES, 则强制绘制制定数量的label, 但是可能不平均
    leftAxis.labelCount = 5; // 3
    leftAxis.forceLabelsEnabled = YES;  //不强制绘制指定数量的label
    leftAxis.axisMinimum = 0;//设置Y轴的最小值
    
    leftAxis.inverted = NO;//是否将Y轴进行上下翻转
    leftAxis.axisLineWidth = 1.0; ///[UIScreen mainScreen].scale; //Y轴线宽
    leftAxis.axisLineColor = ColorDB;//Y轴颜色
    //    leftAxis.axisLineColor = [UIColor clearColor];
    leftAxis.drawGridLinesEnabled = NO;   //不绘制Y方向网格线
    leftAxis.labelPosition = YAxisLabelPositionOutsideChart;//label位置
    leftAxis.labelTextColor = Color99;//文字颜色
    leftAxis.labelFont = [UIFont systemFontOfSize:10.0f];//文字字体
    
    NSNumberFormatter *rightAxisFormatter = [[NSNumberFormatter alloc] init];
    leftAxis.valueFormatter = [[ChartDefaultAxisValueFormatter alloc] initWithFormatter:rightAxisFormatter];
    
    // 5.设置X轴样式
    ChartXAxis *xAxis = _lineView.xAxis;
    xAxis.axisLineWidth = 1.0;  /// [UIScreen mainScreen].scale;//设置X轴线宽
    xAxis.granularityEnabled = YES;  //设置重复的值不显示
    xAxis.drawGridLinesEnabled = NO;  //不绘制X方向网格线
    //    xAxis.gridColor = [UIColor greenColor];
    //    xAxis.spaceMin = 4;  //崩溃？ 设置label间隔
    xAxis.labelWidth =  1; //
    xAxis.labelPosition = XAxisLabelPositionBottom;//设置x轴数据在底部
    
    xAxis.labelTextColor = Color99; //文字颜色
    xAxis.axisLineColor = ColorDB;//X轴颜色
    
    self.lineView.legend.form = ChartLegendFormLine;//图例的样式
    self.lineView.legend.formSize = 30;//图例中线条的长度
    self.lineView.legend.textColor = [UIColor darkGrayColor];//图例文字颜色
    
    
//    ChartMarkerView *markerY = [[ChartMarkerView alloc]init];
//    markerY.offset = CGPointMake(-999, -8);
//    markerY.chartView = _lineView;
//    _lineView.marker = markerY;
    //    [markerY addSubview:self.markY];
    //    self.markY = markerY;
    //    self.lineView.data = [self setData];
    
    BalloonMarker *marker = [[BalloonMarker alloc]
                             initWithColor: [UIColor colorWithWhite:180/255. alpha:1.0]
                             font: [UIFont systemFontOfSize:12.0]
                             textColor:ColorFF6300
                             insets: UIEdgeInsetsMake(8.0, 8.0, 20.0, 8.0)];
    marker.chartView = _lineView;
    marker.minimumSize = CGSizeMake(80.f, 40.f);
    _lineView.marker = marker;
    
}

//懒加载
- (UILabel *)markY{
    if (!_markY) {
        _markY = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 35, 25)];
        _markY.font = [UIFont systemFontOfSize:15.0];
        _markY.textAlignment = NSTextAlignmentCenter;
        _markY.text =@"";
        _markY.textColor = [UIColor whiteColor];
        _markY.backgroundColor = [UIColor grayColor];
    }
    return _markY;
}

- (void)setCommonArray:(NSArray *)commonArray{
    _commonArray = commonArray;
    useWeakSelf
    dispatch_async(dispatch_get_main_queue(), ^{
        [weakSelf setData];
    });
}

- (void)setData{

    //X轴上面需要显示的数据
    __block  NSMutableArray *xVals = [[NSMutableArray alloc] init];
    //对应Y轴上面需要显示的数据
    NSMutableArray *yVals1 = [[NSMutableArray alloc] init];
    NSMutableArray *yVals2 = [[NSMutableArray alloc] init];
    NSMutableArray *yVals3 = [[NSMutableArray alloc] init];
    
    [self.commonArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        WMRunChartModel *entity = (WMRunChartModel *)obj;
        [xVals addObject:entity.minute];
        
        if (self.type == GroundType) { //着地方式
            [yVals1 addObject:[[ChartDataEntry alloc] initWithX:idx y:entity.frontFoot]];
            [yVals2 addObject:[[ChartDataEntry alloc] initWithX:idx y:entity.middleFoot]];
            [yVals3 addObject:[[ChartDataEntry alloc] initWithX:idx y:entity.backFoot]];
        }else if (self.type == FlippingType) { // 翻转类型
            [yVals1 addObject:[[ChartDataEntry alloc] initWithX:idx y:entity.neiFan]];
            [yVals2 addObject:[[ChartDataEntry alloc] initWithX:idx y:entity.normalFan]];
            [yVals3 addObject:[[ChartDataEntry alloc] initWithX:idx y:entity.waiFan]];
        }
    }];
    
    LineChartDataSet *set1 = nil, *set2 = nil, *set3 = nil;
    
    if (_lineView.data.dataSetCount > 0)
    {
        set1 = (LineChartDataSet *)_lineView.data.dataSets[0];
        set2 = (LineChartDataSet *)_lineView.data.dataSets[1];
        set3 = (LineChartDataSet *)_lineView.data.dataSets[2];
        set1.values = yVals1;
        set2.values = yVals2;
        set3.values = yVals3;
        [_lineView.data notifyDataChanged];
        [_lineView notifyDataSetChanged];
    }
    else
    {
        //创建LineChartDataSet对象
        set1 = [[LineChartDataSet alloc] initWithValues:yVals1 label:@"lineName1"];
        //设置折线的样式
        set1.lineWidth = 1.0;//折线宽度
        set1.drawValuesEnabled = NO;//在拐点处显示数据
        set1.valueColors = @[[UIColor redColor]];//折线拐点处显示数据的颜色
        [set1 setColor:ColorForRGB(@"#7EC903")]; //折线颜色 RGB(219, 150, 38)
        //折线拐点样式
        set1.drawCirclesEnabled = NO;//是否绘制拐点
        
        NSArray *gradientColors1 = @[
                                     (id)[ChartColorTemplates colorFromString:@"#FFFFFF"].CGColor,
                                     (id)[ChartColorTemplates colorFromString:@"#FF6300"].CGColor
                                    ];
        CGGradientRef gradientRef1 = CGGradientCreateWithColors(nil, (CFArrayRef)gradientColors1, nil);
        set1.fillAlpha = 0.6f;//透明度
        set1.fill = [ChartFill fillWithLinearGradient:gradientRef1 angle:90.0f];//赋值填充颜色对象
        set1.drawFilledEnabled = NO;//是否填充颜色
        CGGradientRelease(gradientRef1);//释放gradientRef
        
        //点击选中拐点的交互样式
        set1.highlightEnabled = YES;//选中拐点,是否开启高亮效果(显示十字线)
        set1.highlightColor = [self colorWithHexString:@"#c83c23"]; //点击选中拐点的十字线的颜色
        set1.highlightLineWidth = 0.5 / [UIScreen mainScreen].scale; //十
        set1.highlightLineDashLengths = @[@5, @5];  //十字线的虚线样式
        
        set1.mode = LineChartModeCubicBezier; //平滑曲线   LineChartModeLinear
        
        set2 = [[LineChartDataSet alloc] initWithValues:yVals2 label:@"lineName2"];
        //设置折线的样式
        set2.lineWidth = 1.0;//折线宽度
        set2.drawValuesEnabled = NO;//在拐点处显示数据
        set2.valueColors = @[[UIColor redColor]];//折线拐点处显示数据的颜色
        [set2 setColor:ColorForRGB(@"#F5A623")]; //折线颜色 RGB(219, 150, 38)
        //折线拐点样式
        set2.drawCirclesEnabled = NO;//是否绘制拐点
        
        NSArray *gradientColors2 = @[
                                     (id)[ChartColorTemplates colorFromString:@"#FFFFFF"].CGColor,
                                     (id)[ChartColorTemplates colorFromString:@"#FF6300"].CGColor
                                     ];
        CGGradientRef gradientRef2 = CGGradientCreateWithColors(nil, (CFArrayRef)gradientColors2, nil);
        set2.fillAlpha = 0.6f;//透明度
        set2.fill = [ChartFill fillWithLinearGradient:gradientRef2 angle:90.0f];//赋值填充颜色对象
        set2.drawFilledEnabled = NO;//是否填充颜色
        CGGradientRelease(gradientRef2);//释放gradientRef
        
        //点击选中拐点的交互样式
        set2.highlightEnabled = YES;//选中拐点,是否开启高亮效果(显示十字线)
        set2.highlightColor = [self colorWithHexString:@"#c83c23"]; //点击选中拐点的十字线的颜色
        set2.highlightLineWidth = 0.5 / [UIScreen mainScreen].scale; //十
        set2.highlightLineDashLengths = @[@5, @5];  //十字线的虚线样式
        
        set2.mode = LineChartModeCubicBezier;   //平滑曲线  LineChartModeLinear
        
        set3 = [[LineChartDataSet alloc] initWithValues:yVals3 label:@"lineName3"];
        //设置折线的样式
        set3.lineWidth = 1.0;//折线宽度
        set3.drawValuesEnabled = NO;//在拐点处显示数据
        set3.valueColors = @[[UIColor redColor]];//折线拐点处显示数据的颜色
        [set3 setColor:ColorFF6300]; //折线颜色 RGB(219, 150, 38)
        //折线拐点样式
        set3.drawCirclesEnabled = NO;//是否绘制拐点
        
        NSArray *gradientColors3 = @[
                                     (id)[ChartColorTemplates colorFromString:@"#FFFFFF"].CGColor,
                                     (id)[ChartColorTemplates colorFromString:@"#FF6300"].CGColor
                                     ];
        CGGradientRef gradientRef3 = CGGradientCreateWithColors(nil, (CFArrayRef)gradientColors3, nil);
        set3.fillAlpha = 0.6f;//透明度
        set3.fill = [ChartFill fillWithLinearGradient:gradientRef3 angle:90.0f];//赋值填充颜色对象
        set3.drawFilledEnabled = NO;//是否填充颜色
        CGGradientRelease(gradientRef3);//释放gradientRef
        
        //点击选中拐点的交互样式
        set3.highlightEnabled = YES;//选中拐点,是否开启高亮效果(显示十字线)
        set3.highlightColor = [self colorWithHexString:@"#c83c23"]; //点击选中拐点的十字线的颜色
        set3.highlightLineWidth = 0.5 / [UIScreen mainScreen].scale; //十
        set3.highlightLineDashLengths = @[@5, @5];  //十字线的虚线样式
        
        set3.mode = LineChartModeCubicBezier;   //平滑曲线  LineChartModeLinear
    
        //将 LineChartDataSet 对象放入数组中
        NSMutableArray *dataSets = [[NSMutableArray alloc] init];
        [dataSets addObject:set1];
        [dataSets addObject:set2];
        [dataSets addObject:set3];
    
        //创建 LineChartData 对象, 此对象就是lineChartView需要最终数据对象
        LineChartData *data = [[LineChartData alloc] initWithDataSets:dataSets];
        [data setValueFont:[UIFont fontWithName:@"HelveticaNeue-Light" size:11.f]];//文字字体
        [data setValueTextColor:[UIColor blackColor]];//文字颜色
        
        _lineView.data = data;
    }
}

- (void)chartValueSelected:(ChartViewBase * _Nonnull)chartView entry:(ChartDataEntry * _Nonnull)entry highlight:(ChartHighlight * _Nonnull)highlight {
    
    //    _markY.text = [NSString stringWithFormat:@"%ld",(NSInteger)entry.y];//改变选中的数据时候，label的值跟着变化
    //    //将点击的数据滑动到中间
    //    [_lineView centerViewToAnimatedWithXValue:entry.x yValue:entry.y axis:[_lineView.data getDataSetByIndex:highlight.dataSetIndex].axisDependency duration:1.0];
}

- (void)chartValueNothingSelected:(ChartViewBase * _Nonnull)chartView {
    
    
}


//将十六进制颜色转换为 UIColor 对象
- (UIColor *)colorWithHexString:(NSString *)color{
    NSString *cString = [[color stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    // String should be 6 or 8 characters
    if ([cString length] < 6) {
        return [UIColor clearColor];
    }
    // strip "0X" or "#" if it appears
    if ([cString hasPrefix:@"0X"])
        cString = [cString substringFromIndex:2];
    if ([cString hasPrefix:@"#"])
        cString = [cString substringFromIndex:1];
    if ([cString length] != 6)
        return [UIColor clearColor];
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    //r
    NSString *rString = [cString substringWithRange:range];
    //g
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    //b
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    return [UIColor colorWithRed:((float) r / 255.0f) green:((float) g / 255.0f) blue:((float) b / 255.0f) alpha:1.0f];
}


@end
