//
//  CGXPageCollectionHorizontalRowModel.m
//  CGXPageCollectionView-OC
//
//  Created by CGX on 2020/6/06.
//  Copyright © 2020 CGX. All rights reserved.
//

#import "CGXPageCollectionHorizontalRowModel.h"

@implementation CGXPageCollectionHorizontalRowModel
- (void)initializeData
{
    [super initializeData];

}
@end
