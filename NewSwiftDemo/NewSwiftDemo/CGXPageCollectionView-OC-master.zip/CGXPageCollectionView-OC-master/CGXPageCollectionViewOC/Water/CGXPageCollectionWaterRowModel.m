//
//  CGXPageCollectionWaterRowModel.m
//  CGXPageCollectionView-OC
//
//  Created by CGX on 2020/6/06.
//  Copyright © 2020 CGX. All rights reserved.
//

#import "CGXPageCollectionWaterRowModel.h"

@implementation CGXPageCollectionWaterRowModel
- (void)initializeData
{
    [super initializeData];
    self.cellHeight = 100;
}
@end
