//
//  CGXPageCollectionGeneralRowModel.m
//  CGXPageCollectionView-OC
//
//  Created by CGX on 2020/6/06.
//  Copyright © 2020 CGX. All rights reserved.
//

#import "CGXPageCollectionGeneralRowModel.h"

@implementation CGXPageCollectionGeneralRowModel

- (void)initializeData
{
    [super initializeData];
}
@end
