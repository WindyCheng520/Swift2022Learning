//
//  CGXPageCollectionTagsRowModel.m
//  CGXPageCollectionView-OC
//
//  Created by CGX on 2020/6/06.
//  Copyright © 2020 CGX. All rights reserved.
//

#import "CGXPageCollectionTagsRowModel.h"

@implementation CGXPageCollectionTagsRowModel
- (void)initializeData
{
    [super initializeData];
    self.cellHeight = 100;
     self.cellWidth = 50;
}
@end
