//
//  CGXPageCollectionIrregularView.h
//  CGXPageCollectionView-OC
//
//  Created by CGX on 2020/6/06.
//  Copyright © 2020 CGX. All rights reserved.
//

#import "CGXPageCollectionBaseView.h"
#import "CGXPageCollectionIrregularLayout.h"
#import "CGXPageCollectionIrreguarSectionModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface CGXPageCollectionIrregularView : CGXPageCollectionBaseView

@end

NS_ASSUME_NONNULL_END
