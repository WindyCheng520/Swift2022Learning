//
//  ToBAuthAdapter.swift
//  MSBusiness
//
//  Created by Neil 韦学宁 on 2022/2/16.
//

import Foundation
import OEMFoundation
import MSBusiness
//let clientId = "8990073d748a1315c2ccdf47350d11f2"
//let clientSecret = "6dff9cfcd9366967bf451ebaa7e45a7d"
//let authURL = "https://dev-us.dollin.net"

//let clientId = "27f4b81c33dc9ec36ac2b258ca8b1c1b"
//let clientSecret = "6u3i5kg3ioo3pe3hx2v1aq1mu4zxirc7"
var clientId : String = ""
var clientSecret : String = ""
let authURL = "https://dev-us.dollin.net"

@objc
public class ToBAuthInfo: NSObject{
    @objc public var isLogin: Bool = false
    @objc public var uid: String = ""
    @objc public var adsId: String = ""
    @objc public var adsDomain: String = ""
    @objc public var adsPort: Int = 0
    
    func cleanInfo() {
        self.isLogin = false
        self.adsDomain = ""
        self.adsId = ""
        self.adsPort = 0
    }
}

let ToBAuthAdapterDomain = "com.ToBAuthAdapterDomain.domain"

@objc
public class ToBAuthAdapter: NSObject{
    
    @objc
    public static let adapter = ToBAuthAdapter()
    
    @objc
    public var authInfo = ToBAuthInfo()
    
    public override init() {
        super.init()
        NotificationCenter.default.addObserver(self, selector: #selector(onOEMUserLoginSuccess), name: NSNotification.Name.mideaLoginSuccess, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(onOEMUserLogout), name: NSNotification.Name.mideaQuitLogin, object: nil)
        serviceInitialize()
    }
    
    func serviceInitialize(){
        //初始化依赖
        MSUserInfoManager.share()
        DispatchQueue.main.async {
            guard MSUserInfoManager.share().isLogin else{
                return
            }
            if !self.configureAfterLogin(){
                //如果oem本地有缓存oem的token，但tob没缓存tob的OAuth，则触发一次请求
                self.onOEMUserLoginSuccess()
            }
        }
    }
    
    @objc func onOEMUserLoginSuccess() {
        self.updateToBAuth { isSuccess, data, error in
        }
    }
    
    @objc func onOEMUserLogout() {
        self.configureAfterLogout()
    }
    
    
    /// 提供外部接口，重新获取ToB鉴权token
    /// - Parameter completion: 结果回调
    @objc public func updateToBAuth(_ completion:@escaping (_ isSuccess: Bool, _ data: [String: Any]?, _ error: Error?) -> Void){
        // 登陆成功更新clientID 和 host
        guard let cid = MSAppInfo.msClientId(), let csecret = MSAppInfo.msClientSecret() else{
            completion(false, nil, NSError(domain: ToBAuthAdapterDomain, code: -1, userInfo: [NSLocalizedFailureErrorKey:"not support ms config: clientId, clientSecret is nil"]))
            return
        }
        clientId = cid
        clientSecret = csecret
        
        let host = MSAppInfo.mucBaseUrl()
        let baserServiceImpl = BusinessSwiftBridge.sharedInstance() as? BaseServiceProtocol
        BaseService.initService(clientId: clientId, clientSecret: clientSecret, authURL: host!, serviceImpl: baserServiceImpl)
        //ObjC的不支持可选链条，小心崩溃
        guard let mgr = MSUserInfoManager.share(),
              let m = mgr.loginInfoModel,
              let uid = m.uid else{
                  //OEM体系用户未登录直接返回失败
                  completion(false, nil, NSError(domain: ToBAuthAdapterDomain, code: -1, userInfo: [NSLocalizedFailureErrorKey:"error logic, oem user not login"]))
                  return
              }
        BaseService.updateOpenID(uid, signType: OEMSignType.tob2_0) {[weak self] isSuccess, error in
            guard let ws = self else {
                return
            }
            var data : [String: Any]? = nil
            if isSuccess {
                let result = ws.configureAfterLogin()
                if result{
                    let host = MSAppInfo.mucBaseUrl()
                    let countryCode = MSAppInfo.countryCode()
                    data = [kOEMMSmartNetAccessClientIDKey:clientId,kOEMMSmartNetAccessClientSecretKey:clientSecret,kOEMMSmartNetAccessHostKey:host ?? authURL ,kOEMMSmartNetAccessUidKey:MSUserInfoManager.share().loginInfoModel.uid ?? "",kOEMMSmartNetAccessCountryCodeKey:countryCode ?? "",kOEMMSmartNetAccessAuthDataKey:BaseService.getAuthData() ?? NSData.init()]
                }

            }else{
                ws.configureAfterLogout()
            }
            completion(isSuccess, data, error)
        }
    }
}

extension ToBAuthAdapter{
    
    //登录成功后初始化MS配网
    func configureAfterLogin() -> Bool{
        guard let _ = BaseService.getAccessToken() else{
            return false
        }
        
        self.authInfo.isLogin = true
        self.authInfo.uid = MSUserInfoManager.share().loginInfoModel.uid
//        [HGInternationalization sharedInstance].currentCountry.code
        let host = MSAppInfo.mucBaseUrl()
        let countryCode = MSAppInfo.countryCode()
        let notiParam:[String:Any] = [kOEMMSmartNetAccessClientIDKey:clientId,kOEMMSmartNetAccessClientSecretKey:clientSecret,kOEMMSmartNetAccessHostKey:host ?? authURL ,kOEMMSmartNetAccessUidKey:self.authInfo.uid,kOEMMSmartNetAccessCountryCodeKey:countryCode ?? "",kOEMMSmartNetAccessAuthDataKey:BaseService.getAuthData() ?? NSData.init()]
        NotificationCenter.default.post(name:NSNotification.Name.init(rawValue: kOEMDidGetToBAccessTokenNotification), object: notiParam)
        BusinessRequestManager.sharedInstance()?.configure(toBAuthInfo: clientSecret, clientId: clientId, accessToken: BaseService.getAccessToken())
        guard let d = BaseService.getAuthData(),
              let m = try? JSONSerialization.jsonObject(with: d, options: []) as? [String: Any],
              let dMap = m["data"] as? [String: Any] else{
                  //有token就ok了，data字段中的附属信息可有可无
            return true
        }
        
        if let adsId = dMap["adsId"] as? String{
            self.authInfo.adsId = adsId
        }
        
        if let adsDomain = dMap["adsDomain"] as? String{
            self.authInfo.adsDomain = adsDomain
        }
        
        if let adsPort = dMap["adsPort"] as? Int{
            self.authInfo.adsPort = adsPort
        }
        return true
    }
    
    func configureAfterLogout(){
        self.authInfo.cleanInfo()
        BaseService.cleanOpenID()
    }
}
