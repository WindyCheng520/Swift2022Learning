//
//  MSDeviceResource.h
//  MSDevice
//
//  Created by syp on 2020/6/17.
//

#import <OEMFoundation/OEMBundle.h>
#import <OEMFoundation/HGLocalizationResource.h>

#define MSCurrentBundle [MSDeviceBundle currentBundle]

#define OEMStringBundle [MSDeviceBundle strBundle]

#define MSResourceString(key) [HGLocalizationResource localizedStringForKey:key table:nil inBundle:OEMStringBundle]
#define MSResourceImage(imageName) [HGLocalizationResource localizedImageForImageName:imageName inBundle:MSCurrentBundle]

@interface MSDeviceBundle : OEMBundle

@end

