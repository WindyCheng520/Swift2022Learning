//  
//  MSSsidPasswordRepository.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/20
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <Foundation/Foundation.h>


@interface MSSsidPasswordRepository : NSObject

+ (NSString *)fetchPasswordWithSsid:(NSString *)ssid;

+ (void)saveSsid:(NSString *)ssid password:(NSString *)password;

@end
