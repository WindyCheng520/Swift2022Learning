//  
//  MSAddDeviceCloudRepository.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/16
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <Foundation/Foundation.h>
#import <MSBusiness/MSBusinessError.h>
#import "MSAddDeviceTypes.h"

typedef void(^MSCloudRepositorySuccessBlock)(NSDictionary *result);
typedef void(^MSCloudRepositoryFailureBlock)(MSBusinessError *error);

@interface MSAddDeviceCloudRepository : NSObject


//用户绑定家电 appliance/user/bind（单用户）
+ (void)activeDeviceWithWiFiMac:(NSString *)wifiMac
                     deviceName:(NSString *)deviceName
                     deviceType:(NSString *)deviceType
                      deviceSn8:(NSString *)deviceSn8
                firmwareVersion:(NSString *)firmwareVersion
                        success:(MSCloudRepositorySuccessBlock)success
                        failure:(MSCloudRepositoryFailureBlock)failure;

//查询配网（绑定结果）
+ (void)queryDeviceBindResultWithThingCode:(NSString *)thingCode
                                   success:(void (^)(NSArray *list))success
                                   failure:(MSCloudRepositoryFailureBlock)failure;

//获取配网指引
+ (void)fetchAddDeviceGuideContentWithDeviceType:(NSString *)deviceType
                                           model:(NSString *)model
                                       guideType:(NSString *)guideType
                                     subCategory:(NSString *)subCategory
                                         success:(void (^)(NSArray *list))success
                                         failure:(MSCloudRepositoryFailureBlock)failure;



+ (void)requestCountryChannelRetrieveWithCountryCode:(NSString *)countryCode
                                             success:(void (^)(NSArray<MSCountryChannelResult *> *result))success
                                             failure:(void (^)(MSBusinessError *error))failure;

+ (NSArray<MSCountryChannelResult *> *)fetchCountryChannelRetrieve;

+ (void)refreshApplianceTypeNameSuccess:(void (^)(NSArray<MSDeviceTypeResult *> *result))success
                                failure:(void (^)(MSBusinessError *error))failure;

+ (NSString *)fetchApplianceTypeNameWithCategory:(NSString *)category;

+ (void)modifyApplianceInfoWithApplicanceId:(NSString *)applianceId
                              applianceName:(NSString *)name
                                    success:(void (^)(void))success
                                    failure:(void (^)(MSBusinessError *error))failure;

////修改设备名称
//+ (void)modifyApplianceInfoWiththingId:(NSString *)thingId
//                         applianceName:(NSString *)name
//                               success:(void (^)(void))success
//                               failure:(void (^)(MSBusinessError *error))failure;

//修改设备名称
+ (void)modifyApplianceInfoWiththingCode:(NSString *)thingCode
                           applianceName:(NSString *)name
                                 success:(void (^)(void))success
                                 failure:(void (^)(MSBusinessError *error))failure;


//获取配网成功的设备的确权信息
+ (void)fetchApplianceAuthStatusWithApplianceCode:(NSString *)applianceCode success:(void(^)(MSDeviceAuthStatusResult *result))success failure:(MSCloudRepositoryFailureBlock)failure;

//让设备进入待确权状态
+ (void)confirmApplianceAuthStatusWithApplianceCode:(NSString *)applianceCode success:(void(^)(void))success failure:(MSCloudRepositoryFailureBlock)failure;

//通过系统时区ID获取城市ID （冬夏令时）
+ (void)fetchApplianceCityCodeWithSuccess:(void(^)(MSApplianceCityCodeResult *result))success failure:(MSCloudRepositoryFailureBlock)failure;

//获取本地存储的城市ID
+ (MSApplianceCityCodeResult *)getApplianceCityCodeFromLocal;

+ (void)reportAddDeviceFailure:(NSDictionary *)deviceInfo;

@end
