//  
//  MSAddDeviceCloudRepository.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/16
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSAddDeviceCloudRepository.h"
#import <MSBusiness/BusinessRequestManager.h>
#import <MSBusiness/BusinessResponse.h>
#import <MSBusiness/MSAppInfo.h>
#import "MJExtension.h"
#import <MSBusiness/MideaSecurity.h>
#import <OEMBluetooth/MSOEMBLECommon.h>
#import <MSBusiness/MSUserInfoManager.h>
#import "MSDeviceAuthResult.h"



//后确权设备确权状态查询
#define MSAddDevice_AuthGet          @"/v1/appliance/auth/get"

//后确权设备确权
#define MSAddDevice_AuthConfirm      @"/v1/appliance/auth/confirm"

//获取设备的地区ID
#define MSAddDevice_AreaGet          @"/v1/dst/appliance/area/get"

//绑定设备到用户名下
#define MSAddDevice_BindUser         @"/v1/appliance/user/bind"


//通知Alexa 更新设备(信息）
#define MSAddDevice_NotifyAlexa       @"/v1/voice/sync"

//添加设备失败上报 http://confluence.msmart.com/pages/viewpage.action?pageId=84661356
#define MSAddDevice_ReportConfigureFailure       @"/v1/oemTimer/network"


#define MSAddDevice_ReportConfigureFailure       @"/v1/oemTimer/network"


//查询配网（绑定结果/绑定列表）
#define MSAddDevice_BindList      @"/v1/appliance/binder/list/"


//获取配网指引
#define MSAddDevice_GuideContent      @"/v1/product/guidance/get"
//http://confluence.msmart.com/pages/viewpage.action?pageId=84648695




@implementation MSAddDeviceCloudRepository

//查询配网（绑定结果/绑定列表）
+ (void)queryDeviceBindResultWithThingCode:(NSString *)thingCode
                                   success:(void (^)(NSArray *list))success
                                   failure:(MSCloudRepositoryFailureBlock)failure{
    NSString *url = [NSString stringWithFormat:@"%@%@", MSAddDevice_BindList, thingCode];
    
    MSUserInfoManager *manger = [MSUserInfoManager shareManager];
    NSString  *uid = manger.loginInfoModel.uid? : @"";
    NSDictionary *dict = @{@"relType":@"0",
                     @"showUserInfo": @"0",
                           @"uids":@[uid]};
    
    [self POST:url parameters:dict
       success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            NSArray *array = res.data;
            safeCallBlock(success, array);
        }else{
            safeCallBlock(success, @[]);
        }
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}

//获取配网指引
+ (void)fetchAddDeviceGuideContentWithDeviceType:(NSString *)deviceType
                                           model:(NSString *)model
                                       guideType:(NSString *)guideType
                                     subCategory:(NSString *)subCategory
                                         success:(void (^)(NSArray *list))success
                                         failure:(MSCloudRepositoryFailureBlock)failure{
    NSString *languageCode = [MSAppInfo currentLanguageCode];
    NSDictionary *dict = @{@"deviceType":deviceType,
                            @"model": model,
                           @"guideType":guideType,
                           @"subCategory":subCategory,
                           @"language":languageCode};
    
    [self POST:MSAddDevice_GuideContent parameters:dict
       success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            NSArray *array = res.data;
            if (array.count > 0) {
                NSArray *result = [MSDeviceAuthResult mj_objectArrayWithKeyValuesArray:array];
                safeCallBlock(success, result);
            }else{
                safeCallBlock(success, @[]);
            }
          
        }else{
            safeCallBlock(success, @[]);
        }
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
    
}


//用户绑定家电 appliance/user/bind（单用户）
+ (void)activeDeviceWithWiFiMac:(NSString *)wifiMac
                     deviceName:(NSString *)deviceName
                     deviceType:(NSString *)deviceType
                      deviceSn8:(NSString *)deviceSn8
                firmwareVersion:(NSString *)firmwareVersion
                        success:(MSCloudRepositorySuccessBlock)success
                        failure:(MSCloudRepositoryFailureBlock)failure{
 
    NSString *type = [NSString stringWithFormat:@"0x%@", deviceType];
    NSDictionary *param = @{@"thingCode": wifiMac?:@"",
                            @"thingName": deviceName?:@"",
                            @"deviceType":type,
                            @"model":deviceSn8?:@"",
                            @"firmwareVersion":firmwareVersion?:@""};
    [self POST:MSAddDevice_BindUser parameters:param success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            NSDictionary *data = res.data;
            
            safeCallBlock(success, data);
            [self notifyAlexaUpdateDeviceInfo];
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSAddDeviceErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
            NSDictionary * failure = @{
                MSOEMBLE_Property_Body: ComposeBLEConfigFailure(firmwareVersion,
                                                                wifiMac,
                                                                deviceSn8,
                                                                AddBLEDeviceReportFailureCode_ModelDisFail)
            };
            if (res.code == 95302 || res.code == 95303) {
                //保持原样
            }else{
                NSString * component = ComposeBLEConfigFailure(firmwareVersion,
                                                               wifiMac,
                                                               deviceSn8,
                                                               AddBLEDeviceReportFailureCode_Unknow);
                component = [component stringByAppendingFormat:@"(code:%ld,msg:%@)", (long)res.code, res.msg];
                failure = @{
                    MSOEMBLE_Property_Body: component
                };
            }
            
            [self reportAddDeviceFailure:failure];
        }
        
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
    
}



+ (void)requestCountryChannelRetrieveWithCountryCode:(NSString *)countryCode success:(void (^)(NSArray<MSCountryChannelResult *> *result))success failure:(void (^)(MSBusinessError *error))failure {
    return;
    NSString *api = @"/v1/appliance/country/channel/retrieve";
    NSMutableDictionary *iotData = @{}; 
    [iotData setValue:(countryCode ? : @"") forKey:@"countryCode"];
    [self POST:api parameters:iotData success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            NSArray *modelArray = res.data[@"countryCodeListResp"];
            NSArray *result = [MSCountryChannelResult mj_objectArrayWithKeyValuesArray:modelArray];
            safeCallBlock(success, result);
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSAddDeviceErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}

+ (NSArray<MSCountryChannelResult *> *)fetchCountryChannelRetrieve {
    NSArray<MSCountryChannelResult *> *result = [MSCountryChannelResult bg_findAll:nil];
    return result;
}

+ (void)refreshApplianceTypeNameSuccess:(void (^)(NSArray<MSDeviceTypeResult *> *result))success failure:(void (^)(MSBusinessError *error))failure {
    return;
    NSString *api = @"/v1/appliance/device/getTypeList";    //@"/v1/appliance/type/list/get";
    
    NSMutableDictionary *iotData = @{};   //[MSAppInfo getBaseIotData];
  //  [iotData setValue:@"0xFF" forKey:@"applianceType"];
    [self GET:api parameters:iotData success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            NSArray *modelArray = res.data;
            NSArray *result = [MSDeviceTypeResult mj_objectArrayWithKeyValuesArray:modelArray];
            safeCallBlock(success, result);
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSAddDeviceErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
        
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}

+ (NSString *)fetchApplianceTypeNameWithCategory:(NSString *)category {
    if ([category hasPrefix:@"0x"]) {
        category = [category stringByReplacingOccurrencesOfString:@"0x"
                                                  withString:@""];
    }
    NSString *where = [NSString stringWithFormat:@"where %@=%@", bg_sqlKey(@"category"), bg_sqlValue(category)];
   // NSArray<MSDeviceTypeResult *> *resultArray = [MSDeviceTypeResult bg_find:nil where:where];
    NSArray<MSDeviceProductResult *> *resultArray = [MSDeviceProductResult bg_find:nil where:where];   //[MSDeviceProductResult bg_findAll:nil];
    if (resultArray.count) {
        MSDeviceProductResult *result = [resultArray firstObject];
        return result.typeName;
    } else {
        return @"";
    }
}

+ (void)modifyApplianceInfoWithApplicanceId:(NSString *)applianceId applianceName:(NSString *)name success:(void (^)(void))success failure:(void (^)(MSBusinessError *error))failure {
    NSString *api = @"/v1/appliance/info/modify";
    
    NSMutableDictionary *iotData = @{};
    [iotData setValue:applianceId forKey:@"applianceId"];
    [iotData setValue:name forKey:@"applianceName"];
    [self POST:api parameters:iotData success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            safeCallBlock(success);
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSAddDeviceErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
        
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}


+ (void)modifyApplianceInfoWiththingCode:(NSString *)thingCode
                           applianceName:(NSString *)name
                                 success:(void (^)(void))success
                                 failure:(void (^)(MSBusinessError *error))failure{
    NSString *api = @"/v1/appliance/name/update";
    NSMutableDictionary *iotData = @{}.mutableCopy;
    [iotData setValue:thingCode forKey:@"thingCode"];
    [iotData setValue:name forKey:@"thingName"];
    [self POST:api parameters:iotData success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            safeCallBlock(success);
            [self notifyAlexaUpdateDeviceInfo];
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSAddDeviceErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
        
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}



+ (void)fetchApplianceAuthStatusWithApplianceCode:(NSString *)applianceCode success:(void(^)(MSDeviceAuthStatusResult *result))success failure:(MSCloudRepositoryFailureBlock)failure {
    NSMutableDictionary *iotData = @{};
    [iotData setValue:applianceCode?:@"" forKey:@"applianceCode"];
    
    [self POST:MSAddDevice_AuthGet parameters:iotData success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {            
            MSDeviceAuthStatusResult *result = [MSDeviceAuthStatusResult mj_objectWithKeyValues:res.data];
            safeCallBlock(success, result);
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSAddDeviceErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
    
}

+ (void)confirmApplianceAuthStatusWithApplianceCode:(NSString *)applianceCode success:(void (^)(void))success failure:(MSCloudRepositoryFailureBlock)failure {
    NSMutableDictionary *iotData = @{};
    [iotData setValue:applianceCode?:@"" forKey:@"applianceCode"];
    
    [self POST:MSAddDevice_AuthConfirm parameters:iotData success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            safeCallBlock(success);
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSAddDeviceErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}

+ (void)fetchApplianceCityCodeWithSuccess:(void (^)(MSApplianceCityCodeResult *))success failure:(MSCloudRepositoryFailureBlock)failure {
    NSMutableDictionary *iotData = @{};
    NSString *cityCode = [NSTimeZone systemTimeZone].name;
    [iotData setValue:cityCode ?: @"" forKey:@"cityCode"];
    
    [self POST:MSAddDevice_AreaGet parameters:iotData success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            MSApplianceCityCodeResult *result = [MSApplianceCityCodeResult mj_objectWithKeyValues:res.data];
            safeCallBlock(success, result);

            //存入数据库
            if (result) {
                [MSApplianceCityCodeResult bg_clear:nil];
                [result bg_save];
            }
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSAddDeviceErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}

+ (MSApplianceCityCodeResult *)getApplianceCityCodeFromLocal {
    return [MSApplianceCityCodeResult bg_findAll:nil].firstObject;
}

+ (void)reportAddDeviceFailure:(NSDictionary *)deviceInfo{;
    //埋点型需求，忽略上报结果
    if (!deviceInfo || ![deviceInfo isKindOfClass:[NSDictionary class]]) {
        return;
    }
    [self POST:MSAddDevice_ReportConfigureFailure parameters:deviceInfo success:^(NSURLSessionTask *httpbase, id responseObject) {
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
    }];
    /*
    [[BusinessRequestManager sharedInstance] requestMethod:MSRequestMethodPost URLString:MSAddDevice_ReportConfigureFailure httpBody:data configurationHandler:^(MSRequestManagerConfig * _Nullable configuration) {
        configuration.baseURL = [MSAppInfo mucBaseUrl];
    } cache:nil success:^(NSURLSessionTask *httpbase, id responseObject) {
        //
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        //
    }];
     */
}


//静默调用
+(void)notifyAlexaUpdateDeviceInfo{
    NSDictionary *param = @{};
    [self POST:MSAddDevice_NotifyAlexa
    parameters:param
       success:^(NSURLSessionTask *httpbase, id responseObject) {
    }
       failure:^(NSURLSessionTask *httpbase, NSError *error) {
    }];
}


+ (void)POST:(NSString *_Nullable)URLString parameters:(NSDictionary *_Nullable)parameters success:(BusinessRequestManagerSuccess _Nullable )success failure:(BusinessRequestManagerFailure _Nullable )failure
{
    NSData * data = nil;
    if (parameters) {
        data = [NSJSONSerialization dataWithJSONObject:parameters options:0 error:nil];
    }
    BusinessRequest * req = [BusinessRequest new];
    if ([URLString isEqualToString:MSAddDevice_BindUser]){
        req.requestTimeout = 30;
    }
    [[BusinessRequestManager sharedInstance] requestMethod:BusinessRequestMethodPost URLString:URLString httpBody:data request:req httpHeader:nil cache:nil success:^(NSURLSessionTask * _Nullable httpbase, id  _Nullable responseObject) {
        safeCallBlock(success, httpbase, responseObject);
    } failure:^(NSURLSessionTask * _Nullable httpbase, NSError * _Nullable error) {
        safeCallBlock(failure, httpbase, error);
    }];
}


+ (NSURLSessionDataTask *_Nullable)GET:(NSString *_Nullable)URLString parameters:(NSDictionary *_Nullable)parameters success:(BusinessRequestManagerSuccess _Nullable )success failure:(BusinessRequestManagerFailure _Nullable )failure
{
    return [[BusinessRequestManager sharedInstance] GET:URLString parameters:parameters cache:nil success:^(NSURLSessionTask * _Nonnull httpbase, id  _Nonnull responseObject) {
        safeCallBlock(success, httpbase, responseObject);
    } failure:^(NSURLSessionTask * _Nonnull httpbase, NSError * _Nonnull error) {
        safeCallBlock(failure, httpbase, error);
    }];
}

@end
