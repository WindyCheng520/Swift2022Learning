//  
//  MSAddDeviceRepository.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/8
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <Foundation/Foundation.h>
#import <MSBusiness/MSBusinessError.h>
#import "MSAddDeviceTypes.h"

typedef void(^MSAddDeviceRepositoryTypeSuccessBlock)(NSArray<MSDeviceProductResult *> *result);
typedef void(^MSAddDeviceRepositoryModelSuccessBlock)(NSArray<MSDeviceModelResult *> *result);
typedef void(^MSAddDeviceRepositoryConnectInfoSuccessBlock)(MSDeviceConnectResult *result);
typedef void(^MSAddDeviceRepositoryConfirmInfoSuccessBlock)(MSDeviceAuthResult *result);
typedef void(^MSAddDeviceRepositoryFailureBlock)(MSBusinessError *error);

@interface MSAddDeviceDCPRepository : NSObject

+ (void)fetchTypeListSuccess:(MSAddDeviceRepositoryTypeSuccessBlock)success failure:(MSAddDeviceRepositoryFailureBlock)failure;

+ (void)fetchIotProductWithParas:(NSDictionary *)paras success:(MSAddDeviceRepositoryModelSuccessBlock)success failure:(MSAddDeviceRepositoryFailureBlock)failure;

+ (void)fetchIotConnectInfoWithParas:(NSDictionary *)paras success:(MSAddDeviceRepositoryConnectInfoSuccessBlock)success failure:(MSAddDeviceRepositoryFailureBlock)failure;

+ (void)fetchIotConfirmInfoWithParas:(NSDictionary *)paras success:(MSAddDeviceRepositoryConfirmInfoSuccessBlock)success failure:(MSAddDeviceRepositoryFailureBlock)failure;

+ (void)getDeviceMQTTCertWithDeviceType:(NSString *)deviceType
                              thingCode:(NSString *)thingCode
                                 success:(void (^)(id result))success
                                failure:(void (^)(NSError * error))failure;
@end
