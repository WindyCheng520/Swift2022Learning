//  
//  MSSsidPasswordRepository.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/20
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSSsidPasswordRepository.h"
#import "MSWifiPasswordResult.h"
#import <MSBusiness/NSObject+BGModel.h>

@implementation MSSsidPasswordRepository

+ (NSString *)fetchPasswordWithSsid:(NSString *)ssid {
    return [MSWifiPasswordResult getWifiPasswordWithSsid:ssid];
//    NSString* where1 = [NSString stringWithFormat:@"where %@=%@",bg_sqlKey(@"wifiSsid"),bg_sqlValue(ssid)];
//    NSArray<MSWifiPasswordResult *> *resultArray = [MSWifiPasswordResult bg_find:nil where:where1];
//    if (resultArray.count) {
//        MSWifiPasswordResult *model = [resultArray lastObject];
//        return model.wifiPassword;
//    } else {
//        return nil;
//    }
}

+ (void)saveSsid:(NSString *)ssid password:(NSString *)password {
    [MSWifiPasswordResult saveWifiPasswordWithSsid:ssid password:password];
//    MSWifiPasswordResult *model = [MSWifiPasswordResult new];
//    model.wifiSsid = ssid;
//    model.wifiPassword = password;
//    [model bg_saveOrUpdate];
}

@end
