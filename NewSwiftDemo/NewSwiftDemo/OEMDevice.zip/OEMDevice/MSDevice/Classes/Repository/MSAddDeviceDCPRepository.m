//  
//  MSAddDeviceRepository.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/8
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSAddDeviceDCPRepository.h"
#import <MSBusiness/BusinessRequestManager.h>
#import <MSBusiness/BusinessResponse.h>
#import <MSBusiness/MSAppInfo.h>
#import "MJExtension.h"
#import <OEMFoundation/HGInternationalization.h>
#import <MSBusiness/MSDeviceAuthResult.h>




//获取品类列表
#define MSAddDevice_GetTypeList                @"/v1/product/category/devicetype/list"  

//获取产品信息
#define MSAddDevice_GetIotProduct              @"api-product/app/getIotProduct"

//获取配网指引
#define MSAddDevice_GetIotConnectInfo          @"api-product/app/getIotConnectinfo"

//获取后确权指引
#define MSAddDevice_GetIotConfirminfo          @"api-product/app/getIotConfirminfo"

#define MSAddDevice_get_AWS_IOT_device_cert_get      @"/certificate/create/cert"

#define MSAddDevice_get_AWS_IOT_device_cert_post      @"v1/certificate/create/thing/cert"


@implementation MSAddDeviceDCPRepository

+ (void)fetchTypeListSuccess:(MSAddDeviceRepositoryTypeSuccessBlock)success failure:(MSAddDeviceRepositoryFailureBlock)failure {
    
    [self POST:MSAddDevice_GetTypeList parameters:@{} success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            NSArray *result = [MSDeviceProductResult mj_objectArrayWithKeyValuesArray:res.data];
            NSMutableArray *tempArray = [NSMutableArray array];
            for (MSDeviceProductResult *object in result) {
                NSString *category = object.category;
                if ([category hasPrefix:@"0x"]) {
                    category = [category stringByReplacingOccurrencesOfString:@"0x" withString:@""];
                    object.category = category;
                    [tempArray addObject:object];
                }else{
                    [tempArray addObject:object];
                }
            }
            safeCallBlock(success, tempArray.copy);
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSAddDeviceErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
    } failure:^(NSURLSessionTask * _Nonnull httpbase, NSError * _Nonnull error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}


+ (void)fetchIotProductWithParas:(NSDictionary *)paras success:(MSAddDeviceRepositoryModelSuccessBlock)success failure:(MSAddDeviceRepositoryFailureBlock)failure {
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[self getMasPublicParamsToDCP]];
    [dic setValuesForKeysWithDictionary:paras];
    
    [self POST:MSAddDevice_GetIotProduct parameters:dic success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            NSDictionary *data = res.data;
            NSArray *list = data[@"list"];
            NSArray *result = [MSDeviceModelResult mj_objectArrayWithKeyValuesArray:list];
            safeCallBlock(success, result);
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSAddDeviceErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}

+ (void)fetchIotConnectInfoWithParas:(NSDictionary *)paras success:(MSAddDeviceRepositoryConnectInfoSuccessBlock)success failure:(MSAddDeviceRepositoryFailureBlock)failure {
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[self getMasPublicParamsToDCP]];
    [dic setValuesForKeysWithDictionary:paras];
    [self POST:MSAddDevice_GetIotConnectInfo parameters:dic success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            MSDeviceConnectResult *result = [MSDeviceConnectResult mj_objectWithKeyValues:res.data];
            safeCallBlock(success, result);
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSAddDeviceErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}

+ (void)fetchIotConfirmInfoWithParas:(NSDictionary *)paras success:(MSAddDeviceRepositoryConfirmInfoSuccessBlock)success failure:(MSAddDeviceRepositoryFailureBlock)failure {
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithDictionary:[self getMasPublicParamsToDCP]];
    [dic setValuesForKeysWithDictionary:paras];
    [self POST:MSAddDevice_GetIotConfirminfo parameters:dic success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            MSDeviceAuthResult *result = [MSDeviceAuthResult mj_objectWithKeyValues:res.data];
            safeCallBlock(success, result);
        } else {
            MSBusinessError *e = [MSBusinessError errorWithDomain:MSAddDeviceErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
    
}

+ (NSURLSessionDataTask *_Nullable)POST:(NSString *_Nullable)URLString parameters:(NSDictionary *_Nullable)parameters success:(BusinessRequestManagerSuccess _Nullable )success failure:(BusinessRequestManagerFailure _Nullable )failure {
    return [[BusinessRequestManager sharedInstance] POST:URLString parameters:parameters cache:nil success:^(NSURLSessionTask * _Nonnull httpbase, id  _Nonnull responseObject) {
        safeCallBlock(success, httpbase, responseObject);
    } failure:^(NSURLSessionTask * _Nonnull httpbase, NSError * _Nonnull error) {
        safeCallBlock(failure, httpbase, error);
    }];
}


+ (NSURLSessionDataTask *_Nullable)GET:(NSString *_Nullable)URLString parameters:(NSDictionary *_Nullable)parameters success:(BusinessRequestManagerSuccess _Nullable )success failure:(BusinessRequestManagerFailure _Nullable )failure {
    return [[BusinessRequestManager sharedInstance] GET:URLString parameters:parameters cache:nil success:^(NSURLSessionTask * _Nonnull httpbase, id  _Nonnull responseObject) {
        safeCallBlock(success, httpbase, responseObject);
    } failure:^(NSURLSessionTask * _Nonnull httpbase, NSError * _Nonnull error) {
        safeCallBlock(failure, httpbase, error);
    }];
}


+ (NSDictionary *)getMasPublicParamsToDCP {
    
    NSString *languageCode = [[HGInternationalization sharedInstance] convertSystemLanguangeCodeToUnifyLanguangeCode:HGCurrentLanguage.code];
    NSString *appVersion = [MSAppInfo appShortVersion];
    NSString *country = HGCurrentCountry.code;
    
    NSDictionary *params = @{@"language":StringOf(languageCode),
                             @"appVersion":StringOf(appVersion),
                             @"country":StringOf(country)};
    return params;
}

//+ (void)getDeviceMQTTCertWithDeviceType:(NSString *)deviceType
//                              thingCode:(NSString *)thingCode
//                                 success:(void (^)(id result))success
//                                failure:(void (^)(NSError * error))failure{
//    deviceType = [deviceType stringByReplacingOccurrencesOfString:@"0x" withString:@""];
//    deviceType = [deviceType stringByReplacingOccurrencesOfString:@"0X" withString:@""];
//    NSString * url = [NSString stringWithFormat:@"%@/midea_%@_%@", MSAddDevice_get_AWS_IOT_device_cert_get, deviceType, thingCode];
//    [self GET:url parameters:nil success:^(NSURLSessionTask * _Nullable httpbase, id  _Nonnull responseObject) {
//        NSMutableDictionary * map = [NSMutableDictionary dictionaryWithDictionary:responseObject ?: @{}];
//        [map removeObjectForKey:@"httpStatusCode"];
//        safeCallBlock(success, map);
//    } failure:^(NSURLSessionTask * _Nullable httpbase, NSError * _Nonnull error) {
//        safeCallBlock(failure, error);
//    }];
//}

+ (void)getDeviceMQTTCertWithDeviceType:(NSString *)deviceType
                              thingCode:(NSString *)thingCode
                                 success:(void (^)(id result))success
                                failure:(void (^)(NSError * error))failure{
    NSString * param = [NSString stringWithFormat:@"%@_%@",[MSAppInfo getEvnPrefix], thingCode];
    [self POST:MSAddDevice_get_AWS_IOT_device_cert_post parameters:@{
        @"thingName":param,
    } success:^(NSURLSessionTask * _Nullable httpbase, id  _Nonnull responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            NSMutableDictionary * map = [NSMutableDictionary dictionaryWithDictionary:responseObject ?: @{}];
            [map removeObjectForKey:@"httpStatusCode"];
            safeCallBlock(success, map);
        } else {
            NSError *e = [NSError errorWithDomain:MSAddDeviceErrorDomain code:res.code userInfo:nil];
            safeCallBlock(failure, e);
        }
    } failure:^(NSURLSessionTask * _Nullable httpbase, NSError * _Nonnull error) {
        safeCallBlock(failure, error);
    }];
}

@end
