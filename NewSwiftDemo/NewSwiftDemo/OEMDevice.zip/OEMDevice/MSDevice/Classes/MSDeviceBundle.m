//
//  MSDeviceResource.m
//  MSDevice
//
//  Created by syp on 2020/6/17.
//

#import "MSDeviceBundle.h"

@implementation MSDeviceBundle

+(NSBundle *)strBundle{
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *bundlePath = [bundle.resourcePath stringByAppendingPathComponent:@"MSBusiness.bundle"];
    return [NSBundle bundleWithPath:bundlePath];
}

+ (NSBundle *)currentBundle {
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *bundlePath = [bundle.resourcePath stringByAppendingPathComponent:@"MSDevice.bundle"];
    return [NSBundle bundleWithPath:bundlePath];
}

@end
