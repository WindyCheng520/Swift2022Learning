//
//  MSApplianceCityCodeResult.m
//  MSDevice
//
//  Created by midea on 2021/3/1.
//

#import "MSApplianceCityCodeResult.h"
#import <MJExtension/MJExtension.h>

@implementation MSApplianceCityCodeResult

MJExtensionCodingImplementation

- (id)copyWithZone:(NSZone *)zone {
    id obj = [[[self class] allocWithZone:zone] init];
    [self.class mj_enumerateProperties:^(MJProperty *property, BOOL *stop) {
        id value = [self valueForKey:property.name];
        [obj setValue:value forKey:property.name];
    }];
    return obj;
}

@end
