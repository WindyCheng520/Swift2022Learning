//
//  MSApplianceCityCodeResult.h
//  MSDevice
//
//  Created by midea on 2021/3/1.
//

#import <Foundation/Foundation.h>
#import <MSBusiness/NSObject+BGModel.h>

NS_ASSUME_NONNULL_BEGIN

@interface MSApplianceCityCodeResult : NSObject<BGProtocol, NSCoding, NSCopying>

@property (nonatomic, copy) NSString *cityId;

@end

NS_ASSUME_NONNULL_END
