//  
//  MSWifiPasswordModel.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/22
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSWifiPasswordResult.h"
#import <MSBusiness/MideaSecurity.h>
#import <MJExtension/MJExtension.h>

@implementation MSWifiPasswordResult

MJExtensionCodingImplementation

- (id)copyWithZone:(NSZone *)zone {
    id obj = [[[self class] allocWithZone:zone] init];
    [self.class mj_enumerateProperties:^(MJProperty *property, BOOL *stop) {
        id value = [self valueForKey:property.name];
        [obj setValue:value forKey:property.name];
    }];
    return obj;
}

+ (NSArray* _Nonnull)bg_uniqueKeys {
    return @[@"wifiSsid"];
}

+ (void)saveWifiPasswordWithSsid:(NSString *)ssid password:(NSString *)password {
    if (ssid && password) {
        MSWifiPasswordResult *model = [MSWifiPasswordResult new];
        model.wifiSsid = [ssid copy];
        model.wifiPassword = [password copy];
        
        model.isSecurity = YES;
        model.wifiSsid = [MideaSecurity saveSensitiveDataToLocal:model.wifiSsid];
        model.wifiPassword = [MideaSecurity saveSensitiveDataToLocal:model.wifiPassword];
        [model bg_saveOrUpdate];
    }
}

+ (NSString *)getWifiPasswordWithSsid:(NSString *)ssid {
    ssid = [MideaSecurity saveSensitiveDataToLocal:ssid];
    NSString* where = [NSString stringWithFormat:@"where %@=%@",bg_sqlKey(@"wifiSsid"),bg_sqlValue(ssid)];
    NSArray<MSWifiPasswordResult *> *resultArray = [MSWifiPasswordResult bg_find:nil where:where];
    if (resultArray.count) {
        MSWifiPasswordResult *model = [resultArray lastObject];
        if (model.isSecurity) {
            model.wifiPassword = [MideaSecurity getSensitiveDataFromLocal:model.wifiPassword];
        }
        return model.wifiPassword;
    } else {
        return nil;
    }
}

+ (NSArray<MSWifiPasswordResult *> *)getAllWifiPasswordResultDataFromLocal {
    NSArray *resultArray = [MSWifiPasswordResult bg_findAll:nil];
    return resultArray;
}

+ (void)saveAllWifiPasswordResult:(NSArray<MSWifiPasswordResult *> *)resultArray {
    [MSWifiPasswordResult bg_clear:nil];
    
    if (resultArray.count > 0) {
        NSMutableArray *saveArray = [NSMutableArray array];
        for (MSWifiPasswordResult *resultItem in resultArray) {
            MSWifiPasswordResult *result = [resultItem copy];
            result.isSecurity = YES;
            result.wifiSsid = [MideaSecurity saveSensitiveDataToLocal:result.wifiSsid];
            result.wifiPassword = [MideaSecurity saveSensitiveDataToLocal:result.wifiPassword];
            [saveArray addObject:result];
        }
        [MSWifiPasswordResult bg_saveOrUpdateArray:saveArray];
    }
}

@end
