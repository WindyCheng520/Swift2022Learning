//  
//  MSDeviceTypeResult.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/8/4
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSDeviceTypeResult.h"

@implementation MSDeviceTypeResult

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{
             @"tId" : @"id",
             @"name": @"typeName",
             @"type": @"category"
             };
}

@end
