//  
//  MSDeviceTypeResult.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/8/4
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <Foundation/Foundation.h>
#import <MSBusiness/NSObject+BGModel.h>


@interface MSDeviceTypeResult : NSObject<BGProtocol>

@property (nonatomic, copy) NSString *imgUrl;   //品类图

@property (nonatomic, copy) NSString *des;

@property (nonatomic, copy) NSString *tId;

@property (nonatomic, copy) NSString *name;       //品类名
@property (nonatomic, copy) NSString *typeName;   //品类名

@property (nonatomic, copy) NSString *category;  //品类
@property (nonatomic, copy) NSString *type;


@property (nonatomic, copy) NSString *appOrder;    //序号



@end
