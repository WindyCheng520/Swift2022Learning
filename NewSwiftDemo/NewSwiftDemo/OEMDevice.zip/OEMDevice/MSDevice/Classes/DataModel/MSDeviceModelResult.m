//  
//  MSDeviceModelResult.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/10
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSDeviceModelResult.h"

@implementation MSDeviceModelResult

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{
             @"iotId" : @"id"
             };
}

@end
