//  
//  MSDeviceModelResult.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/10
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <Foundation/Foundation.h>

@interface MSDeviceModelResult : NSObject

@property (nonatomic, copy) NSString *category;

@property (nonatomic, copy) NSString *categoryName;

@property (nonatomic, copy) NSString *code;

@property (nonatomic, copy) NSString *iotId;

@property (nonatomic, copy) NSString *productId;

@property (nonatomic, copy) NSString *productImg;

@property (nonatomic, copy) NSString *productName;

@property (nonatomic, copy) NSString *sourceSystem;

@property (nonatomic, copy) NSString *visibleSort;

@end
