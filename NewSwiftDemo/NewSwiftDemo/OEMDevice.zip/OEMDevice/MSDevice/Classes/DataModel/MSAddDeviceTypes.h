//  
//  MSAddDeviceTypes.h
//  Pods
//   
//  Created by 李 燕强 on 2020/7/8
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <Foundation/Foundation.h>
#import <MSBusiness/MSDeviceProductResult.h>
#import "MSDeviceModelResult.h"
#import <MSBusiness/MSDeviceConnectResult.h>
#import "MSCountryChannelResult.h"
#import "MSDeviceTypeResult.h"
#import <MSBusiness/MSDeviceAuthStatusResult.h>
#import "MSDeviceAuthResult.h"
#import "MSApplianceCityCodeResult.h"

FOUNDATION_EXPORT NSErrorDomain const MSAddDeviceErrorDomain;

