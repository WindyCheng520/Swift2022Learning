//  
//  MSCountryChannelResult.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/8/3
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <Foundation/Foundation.h>
#import <MSBusiness/NSObject+BGModel.h>

@interface MSCountryChannelResult : NSObject<BGProtocol>

//channelCounts = 11;
//channelNum = 1;
//country = "\U7f8e\U56fd";
//countryCode = US;
//createTime = "Wed Apr 15 18:22:21 UTC 2020";
//dfs = 0;
//maxTransferPower = 30;


@property (nonatomic, copy) NSString *channelCounts;
@property (nonatomic, copy) NSString *channelNum;
@property (nonatomic, copy) NSString *country;
@property (nonatomic, copy) NSString *countryCode;
@property (nonatomic, copy) NSString *createTime;
@property (nonatomic, copy) NSString *dfs;
@property (nonatomic, copy) NSString *maxTransferPower;


@end
