//  
//  MSWifiPasswordModel.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/22
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <Foundation/Foundation.h>
#import <MSBusiness/BGFMDB.h>

@interface MSWifiPasswordResult : NSObject<BGProtocol, NSCoding, NSCopying>

@property (nonatomic, copy) NSString *wifiSsid;
@property (nonatomic, copy) NSString *wifiPassword;

@property (nonatomic, assign) NSString *hasVerify;   //已验证过密码正确（已配网成功过一次）

/********以下不是接口返回数据*******/
@property (nonatomic, assign) BOOL isSecurity; //1.3.0版本开始数据有加密操作，为了兼容旧版本添加此字段标识数据是否有加密


+ (void)saveWifiPasswordWithSsid:(NSString *)ssid password:(NSString *)password;
+ (NSString *)getWifiPasswordWithSsid:(NSString *)ssid;
+ (NSArray<MSWifiPasswordResult *> *)getAllWifiPasswordResultDataFromLocal;
+ (void)saveAllWifiPasswordResult:(NSArray<MSWifiPasswordResult *> *)resultArray;


@end
