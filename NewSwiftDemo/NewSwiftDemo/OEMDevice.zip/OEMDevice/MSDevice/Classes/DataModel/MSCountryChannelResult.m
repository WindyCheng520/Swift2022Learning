//  
//  MSCountryChannelResult.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/8/3
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSCountryChannelResult.h"

@implementation MSCountryChannelResult

@end
