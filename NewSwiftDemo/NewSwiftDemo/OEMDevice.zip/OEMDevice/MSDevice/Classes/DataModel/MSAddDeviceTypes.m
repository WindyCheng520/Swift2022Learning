//  
//  MSAddDeviceTypes.m
//  Pods
//   
//  Created by 李 燕强 on 2020/7/8
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSAddDeviceTypes.h"

NSString *const MSAddDeviceErrorDomain = @"MSAddDeviceErrorDomain";

