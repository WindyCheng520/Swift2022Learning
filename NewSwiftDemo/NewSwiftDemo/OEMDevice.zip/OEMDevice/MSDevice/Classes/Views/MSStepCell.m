//  
//  MSStepCell.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/14
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSStepCell.h"
#import <OEMTheme/UILabel+OEMThemes.h>
#import <MSBusiness/OEMGlobalUIManager.h>

@implementation MSStepCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.backgroundColor = [UIColor whiteColor];
        
        self.backView = [HGView new];
        self.backView.backgroundColor = [UIColor clearColor];
        [self.contentView addSubview:self.backView];

        self.loadView = [LOTAnimationView animationNamed:@""];

        [self.backView addSubview:self.loadView];
        
        self.stepLabel = [HGLabel new];
        self.stepLabel.textColor = RGB_HEX(0x000000);
        self.stepLabel.font = kRegularFont(14);
        [self.backView addSubview:self.stepLabel];
        
        [self makeConstraints];
        
        [self configureOEMTheme];
    }
    return self;
}

- (void)configureOEMTheme{
    [self.contentView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.stepLabel configure40TranslucentTrait];
}

- (void)makeConstraints {
    
    [self.backView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self.contentView);
    }];
    
    [self.loadView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(0);
        make.centerY.mas_equalTo(self.backView.mas_centerY);
        make.top.mas_equalTo(0);
        make.bottom.mas_equalTo(0);
        make.size.mas_equalTo(CGSizeMake(20, 20));
    }];
    
    [self.stepLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(self.loadView.mas_trailing).offset(5);
        make.centerY.mas_equalTo(self.backView.mas_centerY);
        make.trailing.mas_equalTo(0);
    }];
}


@end
