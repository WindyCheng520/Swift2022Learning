//
//  MSChooseDeviceTypeHeadView.h
//  MSDevice
//
//  Created by midea on 2021/3/31.
//

#import <UIKit/UIKit.h>
#import <MSBusiness/MSAutoFindResult.h>

typedef NS_ENUM(NSInteger, MSChooseDeviceTypeHeadViewType) {
    MSChooseDeviceTypeHeadViewTypeScanning,             //扫描中，还未发现设备
    MSChooseDeviceTypeHeadViewTypeUnauthorized,         //蓝牙未授权
    MSChooseDeviceTypeHeadViewTypeTurnOff,              //蓝牙未打开
    MSChooseDeviceTypeHeadViewType15Timeout,            //扫描15s仍未发现设备
    MSChooseDeviceTypeHeadViewTypeFindDevice            //扫描发现了设备
};

@class MSChooseDeviceTypeHeadView;
@protocol MSChooseDeviceTypeHeadViewDelegate <NSObject>

- (void)headView:(MSChooseDeviceTypeHeadView *)headView didSelectItemWithModel:(MSAutoFindResult *)result;
- (void)headViewDidClickHelpButton:(MSChooseDeviceTypeHeadView *)headView;
- (void)headViewDidLongPressHelpButton:(MSChooseDeviceTypeHeadView *)headView;
- (void)headViewDidClickToOpenBluetooth:(MSChooseDeviceTypeHeadView *)headView;
- (void)headViewDidClickToAuthorizeBluetooth:(MSChooseDeviceTypeHeadView *)headView;
- (void)headViewNeedUpdateHeight:(MSChooseDeviceTypeHeadView *)headView;

@end

@interface MSChooseDeviceTypeHeadView : UICollectionReusableView

@property (nonatomic, weak) id<MSChooseDeviceTypeHeadViewDelegate> delegate;

- (void)refreshHeadViewWithType:(MSChooseDeviceTypeHeadViewType)type dataArray:(NSArray<MSAutoFindResult *> *)dataArray;
- (void)viewWillDisappear;
- (CGFloat)viewHeight;


@end

@interface MSChooseDeviceTypeHeadCell : UICollectionViewCell

@property (nonatomic, strong) HGImageView *imageView;
@property (nonatomic, strong) HGLabel *nameLabel;

- (void)refreshDataWithCategory:(NSString*)category dcpImageUrl:(NSString *)dcpImageUrl name:(NSString *)name;

@end

