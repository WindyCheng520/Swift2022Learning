//
//  MSGuideView.m
//  MSDevice
//
//  Created by WindyCheng on 2022/1/1.
//

#import "MSGuideView.h"
#import <OEMTheme/OEMHGCollectionViewCell.h>
#import <SDWebImage/UIImageView+WebCache.h>
#import <OEMTheme/UILabel+OEMThemes.h>
#import "MSDeviceBundle.h"
#import "UIImage+OEMDeviceExtensions.h"

@implementation  MSGuideEntity

@end


@interface MSGuideCell : HGTableViewCell
@property (nonatomic, strong) HGImageView *imageViews;       //图片
@property (nonatomic, strong) HGLabel *contentLabel;         //内容
@property (nonatomic, strong) MSGuideEntity *entity;

@property (nonatomic, strong) UIImage *defaultImage;
@end


@implementation MSGuideCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.userInteractionEnabled = NO;
        self.backgroundColor = [UIColor clearColor];
        self.contentView.backgroundColor = [UIColor clearColor];

        self.imageViews = [HGImageView new];
        self.imageViews.contentMode = UIViewContentModeScaleAspectFill;
        self.imageViews.backgroundColor = [UIColor clearColor];
        self.imageViews.layer.cornerRadius = 12.0;
        self.imageViews.clipsToBounds = YES;
        [self.contentView addSubview:self.imageViews];
        
        
        self.contentLabel = [HGLabel new];
        self.contentLabel.textColor = RGBA_HEX(0x000000,0.6);
        self.contentLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
        self.contentLabel.textAlignment = NSTextAlignmentLeft;
        self.contentLabel.numberOfLines = 0;
        [self.contentLabel sizeToFit];
        [self.contentView addSubview:self.contentLabel];
   
        [self makeConstraints];
        [self configureOEMTheme];
  
    }
    return self;
}

- (UIImage *)defaultImage {
    if (!_defaultImage) {
        _defaultImage = [UIImage imageWithColor:RGB_HEX(0xF9F9F9)];
    }
    return _defaultImage;
}


- (void)configureOEMTheme{
    [self configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.contentView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.contentLabel configure90TranslucentTrait];
}

- (void)makeConstraints {
    [self.imageViews mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.contentView).offset(16);
        make.trailing.equalTo(self.contentView).offset(-16);
        make.top.equalTo(self.contentView).offset(16);
        make.height.mas_equalTo(184);
    }];
    
    [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.imageViews.mas_bottom).offset(14);
        make.leading.equalTo(self.contentView).offset(16);
        make.trailing.equalTo(self.contentView).offset(-16);
        make.bottom.equalTo(self.contentView).offset(-2);
    }];
}

-(void)setEntity:(MSGuideEntity *)entity{
    _entity = entity;
    [self.imageViews sd_setImageWithURL:[NSURL URLWithString:_entity.guideURL] placeholderImage:self.defaultImage];
    
    NSString *string = _entity.guideContent;
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = 5;
    paragraphStyle.paragraphSpacing = 16;
    NSMutableAttributedString *mutableString = [[NSMutableAttributedString alloc] initWithString:string attributes:@{NSParagraphStyleAttributeName : paragraphStyle, NSFontAttributeName :  [UIFont systemFontOfSize:14 weight:UIFontWeightMedium]/*, NSForegroundColorAttributeName : RGB_HEX(0x000000)*/}];
    self.contentLabel.attributedText = mutableString;
}


@end


@interface MSGuideView () <UITableViewDelegate, UITableViewDataSource>

@property(nonatomic, strong)HGTableView *tableView;


@end



@implementation MSGuideView


- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
    
        [self setupUI];
    }
    return self;
}

-(void)setupUI{
    self.tableView = [[HGTableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.estimatedRowHeight = 300;
  //  self.tableView.backgroundColor = [UIColor whiteColor];
    [self.tableView registerClass:[MSGuideCell class] forCellReuseIdentifier:NSStringFromClass([MSGuideCell class])];
    self.tableView.allowsSelection = NO;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.scrollEnabled = YES;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self addSubview:self.tableView];
    [self makeConstraints];
    [self configureOEMTheme];
    
}


-(void)setDataArray:(NSArray *)dataArray{
    _dataArray = dataArray;
    [self.tableView reloadData];
}

- (void)configureOEMTheme{
   [self configureThemeTag:OEMThemesTag_UIView_Background];
   [self.tableView configureThemeTag:OEMThemesTag_UIView_Foreground];
}

#pragma mark - UI
- (void)makeConstraints {
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.leading.trailing.equalTo(self);
        make.bottom.mas_equalTo(0);
    }];
}


#pragma mark - UITableView datasource and delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    MSGuideCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([MSGuideCell class]) forIndexPath:indexPath];
    MSGuideEntity *entity = self.dataArray[indexPath.row];
    cell.entity = entity;
    return cell;
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return CGFLOAT_MIN;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *sectionView = [[UIView alloc] init];
    return sectionView;
}


//- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
//    return 500;
//}
//
//- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
//    UIView *sectionView = [[UIView alloc] init];
//    return sectionView;
//}






@end

