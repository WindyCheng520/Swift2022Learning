//
//  OEMAddDeviceButton.m
//  MSDevice
//
//  Created by WindyCheng on 2022/3/14.
//

#import "OEMAddDeviceButton.h"
#import <MSBusiness/OEMGlobalUIManager.h>
#import <OEMTheme/UILabel+OEMThemes.h>
#import "MSDeviceBundle.h"

@interface OEMAddDeviceButton ()
@end

@implementation OEMAddDeviceButton


- (instancetype)initWithFrame:(CGRect)frame
                         type:(ConnectType)type{
    if (self = [super initWithFrame:frame]) {
        self.type = type;
        self.clipsToBounds = YES;
        self.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
        self.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        NSString *buttonTitle = @"";
        
        switch (type) {
            case ConnectTypeBLE:
                buttonTitle = MSResourceString(@"common_button_title_go_to_ble");
                break;
            case ConnectTypeAP:
                buttonTitle = MSResourceString(@"common_button_title_go_to_ap");
                break;
            case ConnectTypeBLE2:
                buttonTitle = MSResourceString(@"connect_wifi_page_ble_connect_try_button");
                break;
            case ConnectTypeAP2:
                buttonTitle = MSResourceString(@"connect_wifi_page_ap_connect_try_button");
                break;
                
            default:
                buttonTitle = MSResourceString(@"common_button_title_go_to_ble");
                break;
        }
        
        [self setTitle:buttonTitle forState:UIControlStateNormal];
        self.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 10);
        self.titleLabel.font = kRegularFont(14);
        [self setTitleColor:kBusiness.brandColor forState:UIControlStateNormal];
        //self.backgroundColor = kBusiness.brandColor;
    }
    return self;
}

-(void)setType:(ConnectType)type{
    _type = type;
    NSString *buttonTitle = @"";
    
    switch (type) {
        case ConnectTypeBLE:
            buttonTitle = MSResourceString(@"common_button_title_go_to_ble");
            break;
        case ConnectTypeAP:
            buttonTitle = MSResourceString(@"common_button_title_go_to_ap");
            break;
        case ConnectTypeBLE2:
            buttonTitle = MSResourceString(@"connect_wifi_page_ble_connect_try_button");
            break;
        case ConnectTypeAP2:
            buttonTitle = MSResourceString(@"connect_wifi_page_ap_connect_try_button");
            break;
            
        default:
            buttonTitle = MSResourceString(@"common_button_title_go_to_ble");
            break;
    }
    [self setTitle:buttonTitle forState:UIControlStateNormal];
}


@end
