//  
//  MSSetAndConnectDeviceShowWifiCell.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/13
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <OEMFoundation/HGUIKit.h>
#import <YYText/YYText.h>

@protocol MSSetAndConnectDeviceShowWifiCellDelegate <NSObject>

- (void)passwordDidCopy;

@end

@interface MSSetAndConnectDeviceShowWifiCell : HGTableViewCell

@property (nonatomic, strong) HGImageView *wifiIconImageView;
@property (nonatomic, strong) HGLabel *wifiLabel;
@property (nonatomic, strong) HGImageView *passwordIconImageView;
@property (nonatomic, strong) YYLabel *passwordLabel;
@property (nonatomic, strong) HGButton *pasteButton;

@property (nonatomic, copy) NSString *passwordString;
@property (nonatomic, assign) CGFloat passwordLabelHeight;

@property (nonatomic, weak) id<MSSetAndConnectDeviceShowWifiCellDelegate> delegate;

@end
