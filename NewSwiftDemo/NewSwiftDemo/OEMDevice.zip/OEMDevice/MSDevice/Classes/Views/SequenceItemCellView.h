//
//  SequenceItemCellView.h
//  MSLogin
//
//  Created by Neil 韦学宁 on 2021/7/15.
//

#import <OEMFoundation/HGView.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, SequenceItemType) {
    SequenceItemType_Number,
    SequenceItemType_Dot,
};

@interface SequenceItemCellView : HGView

@property(nonatomic, strong)UILabel *contentLabel;

@property(nonatomic, strong)UILabel *indexItemLabel;

@property(nonatomic, strong)UIView *dotView;

@property(nonatomic, strong)UIImageView * questionMark;

//不显示的按钮
@property(nonatomic, strong)UIButton * questionMarkButton;



@property(nonatomic, copy)os_block_t onQuestionMarkTap;

- (CGFloat)getExpectedHeigt;

- (void)setText:(NSString *)text index:(NSInteger)index type:(SequenceItemType)type enableQuestionMark:(BOOL)enableQuestionMark;

@end

NS_ASSUME_NONNULL_END
