//
//  MSGuideView.h
//  MSDevice
//
//  Created by WindyCheng on 2022/1/1.
//


#import <OEMFoundation/HGUIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MSGuideEntity : NSObject
@property (nonatomic, copy) NSString *guideURL;              //图片
@property (nonatomic, copy) NSString *guideContent;         //内容
@end

@interface MSGuideView : HGView

@property(nonatomic, strong)NSArray *dataArray;

@end

NS_ASSUME_NONNULL_END

