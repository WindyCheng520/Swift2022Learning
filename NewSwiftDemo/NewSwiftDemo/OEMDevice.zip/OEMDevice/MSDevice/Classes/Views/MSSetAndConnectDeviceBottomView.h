//  
//  MSSetAndConnectDeviceBottomView.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/13
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <OEMFoundation/HGUIKit.h>


@interface MSSetAndConnectDeviceBottomView : HGView

@property (nonatomic, strong) HGButton *selectButton;
@property (nonatomic, strong) HGButton *nextButton;

@property (nonatomic, copy) dispatch_block_t clickNextBlock;

@end
