//
//  MSChooseDeviceTypeCountView.m
//  MSDevice
//
//  Created by midea on 2021/3/31.
//

#import "MSChooseDeviceTypeCountView.h"
#import "MSDeviceBundle.h"

@interface MSChooseDeviceTypeCountView ()

@property (nonatomic, strong) HGImageView *iconImageView;
@property (nonatomic, strong) HGLabel *countLabel;
@property (nonatomic, assign) NSInteger count;

@end


@implementation MSChooseDeviceTypeCountView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
        self.iconImageView = [HGImageView new];
        self.iconImageView.image = MSResourceImage(@"add_ic_scan");
        [self addSubview:self.iconImageView];
        
        self.countLabel = [HGLabel new];
        self.countLabel.backgroundColor = RGB_HEX(0xEC1C24);
        self.countLabel.textAlignment = NSTextAlignmentCenter;
        self.countLabel.textColor = RGB_HEX(0xffffff);
        self.countLabel.font = [UIFont systemFontOfSize:10];
        self.countLabel.layer.cornerRadius = 8;
        self.countLabel.layer.masksToBounds = YES;
        [self addSubview:self.countLabel];
        
        CGSize size = [self getViewSize];
        self.frame = CGRectMake(0, 0, size.width, size.height);
        [self makeConstraints];
        
    }
    return self;
}

- (void)makeConstraints {
    self.iconImageView.frame = CGRectMake(0, (self.frame.size.height - 20) / 2, 20, 20);
}

- (void)updateCountWithNumber:(NSInteger)number {
    if (self.count == number) {
        return;
    }
    self.count = number;
    self.countLabel.hidden = self.count <= 0;
    
    if (number > 0) {
        NSString *str = @"";
        if (number > 99) {
            str = @"99+";
        } else {
            str = [NSString stringWithFormat:@"%ld",number];
        }
        
        CGFloat countWidth = [self getCountWidthWithStr:str];
        self.countLabel.text = str;
        self.countLabel.frame = CGRectMake(10, self.frame.size.height / 2 - 16, countWidth, 16);
    }
}

- (CGSize)getViewSize {
    CGFloat countWidth = [self getCountWidthWithStr:@"99+"];
    return CGSizeMake(countWidth + 10, 44);
}

- (CGFloat)getCountWidthWithStr:(NSString *)str {
    CGFloat countWidth = ceil([str boundingRectWithSize:CGSizeMake(MAXFLOAT, 16) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : self.countLabel.font} context:nil].size.width + 6);
    countWidth = MAX(countWidth, 16);
    return countWidth;
}

@end
