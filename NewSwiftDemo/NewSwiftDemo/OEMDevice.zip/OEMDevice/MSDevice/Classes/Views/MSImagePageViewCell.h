//
//  MSImagePageViewCell.h
//  MSDevice
//
//  Created by caiws on 2020/8/12.
//

#import <OEMFoundation/HGUIKit.h>
//#import <SDWebImage/FLAnimatedImageView+WebCache.h>
#import <FLAnimatedImage/FLAnimatedImage.h>

NS_ASSUME_NONNULL_BEGIN

@interface MSImagePageViewCell : HGCollectionViewCell

@property (nonatomic, strong) FLAnimatedImageView *iconImageView;

@end

NS_ASSUME_NONNULL_END
