//
//  MSImagePageView.h
//  MSDevice
//
//  Created by caiws on 2020/8/12.
//

#import <OEMFoundation/HGUIKit.h>


@interface MSImagePageView : HGView

- (instancetype)initWithFrame:(CGRect)frame urlStringList:(NSArray <NSString *>*)urlStringList;

- (instancetype)initWithFrame:(CGRect)frame urlStringList:(NSArray <NSString *>*)urlStringList defaultImageColor:(UIColor *)defaultImageColor;

- (instancetype)initWithFrame:(CGRect)frame imageList:(NSArray <UIImage *>*)imageList defaultImageColor:(UIColor *)defaultImageColor;

@end

