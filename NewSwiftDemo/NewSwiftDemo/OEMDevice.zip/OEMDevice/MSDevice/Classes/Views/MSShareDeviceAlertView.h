//
//  MSShareDeviceAlertView.h
//  MSDevice
//
//  Created by WindyCheng on 2021/11/24.
//

#import <OEMFoundation/HGView.h>
#import <UIKit/UIKit.h>
#import <OEMFoundation/HGView.h>

NS_ASSUME_NONNULL_BEGIN

@interface MSShareDeviceAlertView : HGView

@property (nonatomic, copy) dispatch_block_t clickAgreeBlock;
@property (nonatomic, copy) dispatch_block_t clickCancelBlock;

- (instancetype)initWithFrame:(CGRect)frame
                         type:(NSString *)type
                         name:(NSString *)name
             parentController:(UIViewController *)parentController;

- (void)show;

- (void)dismiss;

@end

NS_ASSUME_NONNULL_END
