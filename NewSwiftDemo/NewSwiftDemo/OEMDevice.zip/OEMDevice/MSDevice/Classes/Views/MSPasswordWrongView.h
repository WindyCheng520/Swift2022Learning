//
//  MSPasswordWrongView.h
//  MSDevice
//
//  Created by pactera on 2020/11/24.
//

#import <OEMFoundation/HGUIKit.h>


@interface MSPasswordWrongView : HGView

@property (nonatomic, copy) void(^clickRetryBlock)(NSString *password);

- (instancetype)initWithWifiName:(NSString *)wifiName password:(NSString *)password;
- (void)show;
- (void)showWithSuperview:(UIView *)superview;
- (void)dismiss;


@end

