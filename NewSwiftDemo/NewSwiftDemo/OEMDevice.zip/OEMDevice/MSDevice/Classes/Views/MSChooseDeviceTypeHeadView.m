//
//  MSChooseDeviceTypeHeadView.m
//  MSDevice
//
//  Created by midea on 2021/3/31.
//

#import "MSChooseDeviceTypeHeadView.h"
#import <YYText/YYText.h>
#import "MSDeviceBundle.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import <MSBusiness/OEMGlobalUIManager.h>
#import <OEMTheme/UILabel+OEMThemes.h>

#define MSChooseDeviceTypeHeadViewGradientSize CGSizeMake(24, 96)

@interface MSChooseDeviceTypeHeadView ()<UICollectionViewDataSource, UICollectionViewDelegate>

@property (nonatomic, strong) HGView *lineView;
@property (nonatomic, strong) HGImageView *indicatorImageView;
@property (nonatomic, strong) HGLabel *titleLabel;
@property (nonatomic, strong) HGButton *helpButton;
@property (nonatomic, strong) HGCollectionView *collectionView;
@property (nonatomic, strong) YYLabel *noticeLabel;
@property (nonatomic, strong) YYLabel *noticeLabel1;

@property (nonatomic, strong) HGImageView *rightMaskView;

@property (nonatomic, strong) NSArray *dataArray;
@property (nonatomic, assign) MSChooseDeviceTypeHeadViewType type;
@property (nonatomic, assign) BOOL isAnimation;

@property (nonatomic, strong) CAGradientLayer * moreDeviceGradientLayer;

@property (nonatomic, strong) HGButton *retryButton;

@property (nonatomic, copy) NSString *retryTitle;

@end

@implementation MSChooseDeviceTypeHeadView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        [self configSubviews];
        [self configureOEMTheme];
    }
    return self;
}

- (void)configSubviews {
    self.lineView = [HGView new];
    self.lineView.backgroundColor = RGB(250, 250, 250);
    [self addSubview:self.lineView];
    
    self.indicatorImageView = [HGImageView new];
    self.indicatorImageView.image = MSResourceImage(@"add_ic_scanning");
    [self addSubview:self.indicatorImageView];
    
    //正在扫描附近设备/扫描到几台设备
    self.titleLabel = [HGLabel new];
    self.titleLabel.textColor = RGB_HEX(0x000000);
    self.titleLabel.font =  kRegularFont(14);
    self.titleLabel.numberOfLines = 0;
    self.titleLabel.textAlignment = NSTextAlignmentLeft;
    [self addSubview:self.titleLabel];
    
    self.helpButton = [HGButton new];
    [self.helpButton setImage:MSResourceImage(@"add_ic_help") forState:UIControlStateNormal];
    [self.helpButton addTarget:self action:@selector(clickHelpButton) forControlEvents:UIControlEventTouchUpInside];
    UILongPressGestureRecognizer * longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(onHelpButtonLongPress)];
    longPress.minimumPressDuration = 3;
    [self.helpButton addGestureRecognizer:longPress];
    self.helpButton.enlargeTouchAreaInsets = UIEdgeInsetsMake(5, 5, 5, 5);
    [self addSubview:self.helpButton];
    

    //扫描中
    self.noticeLabel = [YYLabel new];
    self.noticeLabel.numberOfLines = 0;
   // self.noticeLabel.preferredMaxLayoutWidth = SCREEN_WIDTH - 96;
    self.noticeLabel.font = kRegularFont(14);   //[UIFont systemFontOfSize:12 weight:UIFontWeightMedium];
    self.noticeLabel.hidden = YES;
    [self addSubview:self.noticeLabel];
    
    
    
    //扫描中（实际）
    self.noticeLabel1 = [YYLabel new];
    self.noticeLabel1.numberOfLines = 0;
    self.noticeLabel1.preferredMaxLayoutWidth = SCREEN_WIDTH - 96;
    self.noticeLabel1.font = kRegularFont(14);
    [self addSubview:self.noticeLabel1];
    
    
    self.retryButton = [HGButton new];
    
    self.retryButton.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
    self.retryButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    self.retryButton.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.retryTitle = MSResourceString(@"config_fail_page_connect_try_again");
    [self.retryButton setTitle:self.retryTitle forState:UIControlStateNormal];
    [self.retryButton addTarget:self action:@selector(clickButton) forControlEvents:UIControlEventTouchUpInside];
    self.retryButton.layer.borderColor = kDarkText.mainColor.CGColor;
    self.retryButton.layer.borderWidth = 1.0;
    self.retryButton.titleEdgeInsets = UIEdgeInsetsMake(5, 10, 5, 10);
    self.retryButton.titleLabel.font = kRegularFont(14);
    [self.retryButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
    self.retryButton.backgroundColor = RGB_HEX(0xFFFFFF);
    self.retryButton.layer.cornerRadius = 14.5;
    self.retryButton.hidden = YES;
    [self addSubview:self.retryButton];
    
    self.collectionView = [[HGCollectionView alloc]initWithFrame:CGRectZero collectionViewLayout:[self collectionViewLayout]];
    [self.collectionView registerClass:[MSChooseDeviceTypeHeadCell class] forCellWithReuseIdentifier:NSStringFromClass([MSChooseDeviceTypeHeadCell class])];
    self.collectionView.backgroundColor = [UIColor clearColor];
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;
    self.collectionView.showsHorizontalScrollIndicator = NO;
    [self addSubview:self.collectionView];
    
    self.rightMaskView = [HGImageView new];
    //self.rightMaskView.image = MSResourceImage(@"device_zhezhao");
    [self addSubview:self.rightMaskView];
    
    [self makeConstraints];
    [self configureOEMTheme];

}

- (void)configureOEMTheme{
    [self configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.lineView configureThemeTag:OEMThemesTag_UIView_Foreground];
  //  [self.titleLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
    [self.helpButton configureThemeTag:OEMThemesTag_UIButton_TitleThemeColor];
    
    
    [self.titleLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.secondColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.secondColor
    }];
    
//    [self.noticeLabel specialPropertiesForDarkMode:@{
//        @(OEMThemesTag_UILabel_TextColor) : kDarkText.thirdColor
//    } lightModeProperties:@{
//        @(OEMThemesTag_UILabel_TextColor) : kLightText.thirdColor
//    }];
    
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        [weakSelf addGradientLayer];
    } callImmidiately:YES];
    
    
    [self.retryButton specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : kBusiness.brandColor
    } lightModeProperties:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : kBusiness.brandColor
    }];
    
    [self.retryButton specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIButton_Background) : kDarkModeLayoutColor.cardBackgroundColor
    } lightModeProperties:@{
        @(OEMThemesTag_UIButton_Background) : kLightModeLayout.cardBackgroundColor
    }];
}


- (void)addGradientLayer{
    if (self.moreDeviceGradientLayer) {
        [self.moreDeviceGradientLayer removeFromSuperlayer];
        self.moreDeviceGradientLayer = nil;
    }
    CAGradientLayer *colorLayer = [CAGradientLayer layer];
    [self.rightMaskView.layer insertSublayer:colorLayer atIndex:0];
    NSArray * color = @[(__bridge id)RGBA_HEX(0xFFFFFF, 1.0).CGColor,
                        (__bridge id)RGBA_HEX(0xFFFFFF, 0.6).CGColor,
                        (__bridge id)RGBA_HEX(0xFFFFFF, 0.0).CGColor];
    
    if (OEMThemeIsDarkMode) {
        color = @[(__bridge id)RGBA_HEX(0x1A1A1A, 1.0).CGColor,
                  (__bridge id)RGBA_HEX(0x1A1A1A, 0.6).CGColor,
                  (__bridge id)RGBA_HEX(0x1A1A1A, 0.0).CGColor];

    }
    colorLayer.colors = color;
    colorLayer.locations  = @[@(0.0), @(0.5), @(1.0)];
    colorLayer.startPoint = CGPointMake(0, 0.5);
    colorLayer.endPoint   = CGPointMake(1, 0.5);
    self.moreDeviceGradientLayer = colorLayer;
}
- (void)makeConstraints {
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.top.mas_equalTo(0);
        make.height.mas_equalTo(1);
    }];
    [self.indicatorImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(20, 20));
        make.leading.mas_equalTo(16);
        make.top.mas_equalTo(16);
    }];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.indicatorImageView.mas_trailing).offset(8);
        make.trailing.equalTo(self.helpButton.mas_leading).offset(-12);
        make.centerY.equalTo(self.indicatorImageView);
        make.height.mas_equalTo(16);
    }];
    [self.helpButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(16, 16));
        make.trailing.mas_equalTo(-16);
        make.centerY.equalTo(self.indicatorImageView);
    }];
    [self.noticeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(48);
        make.trailing.mas_equalTo(-48);
        make.bottom.equalTo(self);
        make.height.mas_equalTo(128);
    }];
    
    [self.noticeLabel1 mas_makeConstraints:^(MASConstraintMaker *make) {
      //  make.top.mas_equalTo(self.titleLabel.mas_bottom).offset(20);
        make.leading.mas_equalTo(16);
        make.trailing.mas_equalTo(-16);
        make.centerY.equalTo(self).offset(10);
      //  make.bottom.equalTo(self);
        
    }];
    
    
    CGFloat w = (SCREEN_WIDTH);
    CGRect labelTitleSize = [self.retryTitle boundingRectWithSize:CGSizeMake(w -32, 29)
                                                          options:NSStringDrawingUsesLineFragmentOrigin
                                                       attributes:@{NSFontAttributeName:kRegularFont(14)} context:nil];
    CGFloat width = labelTitleSize.size.width + 30;
    if (width <= 90) {
        width = 90;
    }else{
        width = width + 0;
    }
    [self.retryButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.noticeLabel1.mas_bottom).offset(5);
//        make.leading.equalTo(self.backView).offset(16);
//        make.trailing.equalTo(self.backView).offset(-16);
        make.centerX.equalTo(self);
        make.width.mas_equalTo(width);
        make.height.mas_equalTo(29);
    }];
    
    
    [self.collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.indicatorImageView.mas_bottom).offset(32);
        make.leading.trailing.mas_equalTo(0);
        make.height.mas_equalTo(84);
    }];
    [self.rightMaskView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.trailing.bottom.mas_equalTo(0);
        make.size.mas_equalTo(MSChooseDeviceTypeHeadViewGradientSize);
    }];
    
}

- (UICollectionViewFlowLayout *)collectionViewLayout {
    UICollectionViewFlowLayout *viewLayout = [[UICollectionViewFlowLayout alloc] init];
    viewLayout.sectionInset = UIEdgeInsetsMake(0, 16, 0, 16);
    viewLayout.itemSize = CGSizeMake(80, 44 + 4 + 24 + 12);
    viewLayout.minimumLineSpacing = 16;
    viewLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    return viewLayout;
}

#pragma mark - UICollectionViewDataSource/UICollectionViewDelegate
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    MSChooseDeviceTypeHeadCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([MSChooseDeviceTypeHeadCell class]) forIndexPath:indexPath];
    
    if (self.dataArray.count > indexPath.item) {
        MSAutoFindResult *result = self.dataArray[indexPath.item];
    DDLogDeviceInfo(@"设备广播---%@", result.bleAdvDict);
        [cell refreshDataWithCategory:result.deviceType dcpImageUrl:result.dcpImageUrl name:result.cloudName];
    }
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if (self.dataArray.count > indexPath.item) {
        MSAutoFindResult *result = self.dataArray[indexPath.item];
        if (self.delegate && [self.delegate respondsToSelector:@selector(headView:didSelectItemWithModel:)]) {
            [self.delegate headView:self didSelectItemWithModel:result];
        }
    }
    
}

#pragma mark - refresh
- (void)refreshHeadViewWithType:(MSChooseDeviceTypeHeadViewType)type dataArray:(NSArray<MSAutoFindResult *> *)dataArray {
    self.dataArray = dataArray;
    self.type = type;
    self.retryButton.hidden = YES;
    
    switch (type) {
        case MSChooseDeviceTypeHeadViewTypeScanning:{
            [self startScanAnimation];
            self.titleLabel.text = MSResourceString(@"add_device_page_device_scanning_nearby");
            self.collectionView.hidden = YES;
            self.noticeLabel.hidden = YES;
            self.noticeLabel.text = MSResourceString(@"add_device_page_device_scanning");
            self.noticeLabel.textAlignment = NSTextAlignmentCenter;
            self.noticeLabel.textColor = RGB_HEX(0x999999);
            
            self.noticeLabel1.hidden = NO;
            self.noticeLabel1.text = MSResourceString(@"add_device_page_device_scanning");
            self.noticeLabel1.textAlignment = NSTextAlignmentCenter;
            self.noticeLabel1.textColor = RGB_HEX(0x999999);
        }
            break;
            
        case MSChooseDeviceTypeHeadViewTypeUnauthorized:{
            [self stopScanAnimation];
            self.titleLabel.text = MSResourceString(@"add_device_page_scan_nearby");
            self.collectionView.hidden = YES;
            self.noticeLabel.hidden = YES;
            self.noticeLabel.attributedText = [self getAttributeNoticeStringWithType:type];
            self.noticeLabel.textAlignment = NSTextAlignmentCenter;
            self.noticeLabel.textColor = RGB_HEX(0x999999);
            
            self.noticeLabel1.hidden = NO;
            self.noticeLabel1.attributedText = [self getAttributeNoticeStringWithType:type];
            self.noticeLabel1.textAlignment = NSTextAlignmentCenter;
            self.noticeLabel1.textColor = RGB_HEX(0x999999);
        }
            break;
            
        case MSChooseDeviceTypeHeadViewTypeTurnOff:{
            [self stopScanAnimation];
            self.titleLabel.text = MSResourceString(@"add_device_page_scan_nearby");
            self.collectionView.hidden = YES;
            self.noticeLabel.hidden = YES;
            self.noticeLabel.attributedText = [self getAttributeNoticeStringWithType:type];
            self.noticeLabel.textAlignment = NSTextAlignmentCenter;
            self.noticeLabel.textColor = RGB_HEX(0x999999);
            
            
            self.noticeLabel1.hidden = NO;
            self.noticeLabel1.attributedText = [self getAttributeNoticeStringWithType:type];
            self.noticeLabel1.textAlignment = NSTextAlignmentCenter;
            self.noticeLabel1.textColor = RGB_HEX(0x999999);
        }
            break;
            
        case MSChooseDeviceTypeHeadViewTypeFindDevice:{
            [self startScanAnimation];
            self.titleLabel.text = [NSString stringWithFormat:MSResourceString(@"add_device_page_scan_result"), [NSNumber numberWithInteger:self.dataArray.count]];
            self.collectionView.hidden = NO;
            [self.collectionView reloadData];
            self.noticeLabel.hidden = YES;
            self.noticeLabel1.hidden = YES;
        }
            break;
            
        case MSChooseDeviceTypeHeadViewType15Timeout:{
            [self startScanAnimation];
            self.titleLabel.text = MSResourceString(@"add_device_page_device_scanning_nearby");
            self.collectionView.hidden = YES;
            self.noticeLabel.hidden = YES;
            if (self.dataArray.count == 0) {
                self.retryButton.hidden = NO;
            }
            self.noticeLabel.text = MSResourceString(@"add_device_page_scan_no_result");  //"如果长时间未扫描设备，请重新打开此页面。"
            self.noticeLabel.textAlignment = NSTextAlignmentCenter;
            self.noticeLabel.textColor = RGB_HEX(0x999999);
            
            
            self.noticeLabel1.hidden = NO;
            self.noticeLabel1.text = MSResourceString(@"add_device_page_scan_no_result");  //"如果长时间未扫描设备，请重新打开此页面。"
            self.noticeLabel1.textAlignment = NSTextAlignmentCenter;
            self.noticeLabel1.textColor = RGB_HEX(0x999999);
        }
            break;
            
        default:
            break;
    }

    //高度变化时，回调刷新
    CGFloat height = [self viewHeight];
   // if (height != self.frame.size.height) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(headViewNeedUpdateHeight:)]) {
            [self.delegate headViewNeedUpdateHeight:self];
        }
   // }
}

- (void)viewWillDisappear {
    [self stopScanAnimation];
}

- (NSMutableAttributedString *)getAttributeNoticeStringWithType:(MSChooseDeviceTypeHeadViewType)type {
    NSString *title = @"";
    if (type == MSChooseDeviceTypeHeadViewTypeUnauthorized) {
        title = [NSString stringWithFormat:@"%@", MSResourceString(@"add_device_page_ble_not_auth_tip")];
    } else if (type == MSChooseDeviceTypeHeadViewTypeTurnOff) {
        title = [NSString stringWithFormat:@"%@", MSResourceString(@"add_device_page_ble_turn_on_tip")];
    }
    
    //UIColor hightLightColor = RGB_HEX(0xEC1C24);
    UIColor *hightLightColor =  kBusiness.brandColor; //CommonThemeColor;  //
    UIColor *normalColor = RGB_HEX(0x999999);
    
//    if (OEMThemeIsDarkMode) {
//        normalColor  =  kDarkText.thirdColor;
//    }else{
//        normalColor = kLightText.thirdColor;
//    }
    
    NSMutableAttributedString *noticeString = [[NSMutableAttributedString alloc] initWithString:title attributes:@{NSForegroundColorAttributeName : normalColor}];
    NSMutableAttributedString *openString = [[NSMutableAttributedString alloc] initWithString:MSResourceString(@"add_device_page_to_system_setting") attributes:@{NSForegroundColorAttributeName : hightLightColor}];
    @weakify(self)
    [openString yy_setTextHighlightRange:NSMakeRange(0, MSResourceString(@"add_device_page_to_system_setting").length) color:hightLightColor backgroundColor:[UIColor clearColor] tapAction:^(UIView * _Nonnull containerView, NSAttributedString * _Nonnull text, NSRange range, CGRect rect) {
        @strongify(self);
        if (type == MSChooseDeviceTypeHeadViewTypeUnauthorized) {
            if (self.delegate && [self.delegate respondsToSelector:@selector(headViewDidClickToAuthorizeBluetooth:)]) {
                [self.delegate headViewDidClickToAuthorizeBluetooth:self];
            }
        } else if (type == MSChooseDeviceTypeHeadViewTypeTurnOff) {
            if (self.delegate && [self.delegate respondsToSelector:@selector(headViewDidClickToOpenBluetooth:)]) {
                [self.delegate headViewDidClickToOpenBluetooth:self];
            }
        }
    }];
    [noticeString appendAttributedString:openString];
    
    return noticeString;
}

- (void)startScanAnimation {
    if (!self.isAnimation) {
        self.isAnimation = YES;
        CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
        animation.fromValue = [NSNumber numberWithFloat:0.f];
        animation.toValue = [NSNumber numberWithFloat:M_PI *2];
        animation.duration = 1;
        animation.autoreverses = NO;
        animation.fillMode = kCAFillModeForwards;
        animation.repeatCount = MAXFLOAT;
        [animation setRemovedOnCompletion:NO];
        [self.indicatorImageView.layer addAnimation:animation forKey:nil];
    }
}

- (void)stopScanAnimation {
    if (self.isAnimation) {
        self.isAnimation = NO;
        [self.indicatorImageView.layer removeAllAnimations];
    }
}

- (CGFloat)viewHeight {
    if (self.titleLabel.text.length > 0) {
        CGFloat titleHeight = ceil([self.titleLabel.text boundingRectWithSize:CGSizeMake(SCREEN_WIDTH - (16 + 20 + 8 + 12 + 16 + 16), MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : self.titleLabel.font} context:nil].size.height);
        titleHeight = MAX(titleHeight, 16);
        return 18 + titleHeight + 128;
    } else {
        return 165;
    }
}

#pragma mark - event
- (void)clickHelpButton {
    if (self.delegate && [self.delegate respondsToSelector:@selector(headViewDidClickHelpButton:)]) {
        [self.delegate headViewDidClickHelpButton:self];
    }
}

- (void)onHelpButtonLongPress{
    if (self.delegate && [self.delegate respondsToSelector:@selector(headViewDidLongPressHelpButton:)]) {
        [self.delegate headViewDidLongPressHelpButton:self];
    }
}

-(void)clickButton{
    self.retryButton.hidden = YES;
    [self refreshHeadViewWithType:MSChooseDeviceTypeHeadViewTypeScanning dataArray:@[]];
}


@end


@implementation MSChooseDeviceTypeHeadCell

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.imageView = [HGImageView new];
        self.imageView.contentMode = UIViewContentModeScaleAspectFill;
        self.imageView.clipsToBounds = YES;
        [self.contentView addSubview:self.imageView];
        
        self.nameLabel = [HGLabel new];
        self.nameLabel.textColor = RGB_HEX(0x666666);
        self.nameLabel.textAlignment = NSTextAlignmentCenter;
        self.nameLabel.font =   [UIFont systemFontOfSize:10 weight:UIFontWeightRegular]; //[UIFont fontWithName:@"SF Pro" size:10]; //kSFProFont(5); //
        self.nameLabel.numberOfLines = 2;
        [self.contentView addSubview:self.nameLabel];
        [self makeConstraints];
        [self configureOEMTheme];
        
    }
    return self;
}


- (void)configureOEMTheme{
    [self.contentView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.nameLabel configure60TranslucentTrait];
    
//    [self.nameLabel specialPropertiesForDarkMode:@{
//        @(OEMThemesTag_UILabel_TextColor) : kDarkText.secondColor
//    } lightModeProperties:@{
//        @(OEMThemesTag_UILabel_TextColor) : kLightText.secondColor
//    }];
}


- (void)makeConstraints {
    [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(44, 44));
        make.top.mas_equalTo(0);
        make.centerX.equalTo(self.contentView);
    }];
    [self.nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.imageView.mas_bottom).offset(4);
        make.leading.trailing.mas_equalTo(0);
    }];
}

- (void)refreshDataWithCategory:(NSString*)category dcpImageUrl:(NSString *)dcpImageUrl name:(NSString *)name {
    
    if (dcpImageUrl.length > 0) {
        [self.imageView sd_setImageWithURL:[NSURL URLWithString:dcpImageUrl] placeholderImage:[UIImage imageNamed:@"pic_category_default"]];
    } else {
        if ([category hasPrefix:@"0x"]) {
            category = [category stringByReplacingOccurrencesOfString:@"0x" withString:@""];
        }
        NSString *imageName = [NSString stringWithFormat:@"pic_%@", category];
        self.imageView.image = [UIImage imageNamed:imageName] ?: [UIImage imageNamed:@"pic_category_default"];
    }
        
    self.nameLabel.text = name;
}

@end
