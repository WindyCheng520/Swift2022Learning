//  
//  MSChooseDeviceModelCell.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/11
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSChooseDeviceModelCell.h"
#import "MSDeviceBundle.h"

@implementation MSChooseDeviceModelCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.backgroundColor = [UIColor whiteColor];
        
        self.lineView = [HGView new];
        self.lineView.backgroundColor = RGB_HEX(0xF2F2F2);
        [self.contentView addSubview:self.lineView];
        
        self.iconImageView = [HGImageView new];
        [self.contentView addSubview:self.iconImageView];
        self.iconImageView.contentMode = UIViewContentModeScaleAspectFill;
        self.iconImageView.clipsToBounds = YES;
        
        self.titleLabel = [HGLabel new];
        self.titleLabel.textColor = RGB_HEX(0x000000);
        self.titleLabel.font = [UIFont systemFontOfSize:16];
        self.titleLabel.numberOfLines = 3;
        [self.contentView addSubview:self.titleLabel];
        
        self.rightArrowImageView = [HGImageView new];
        [self.contentView addSubview:self.rightArrowImageView];
        self.rightArrowImageView.image = MSResourceImage(@"ic_list_go");
        
        [self makeConstraints];
    }
    return self;
}

- (void)makeConstraints {
    [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(16);
        make.size.mas_equalTo(CGSizeMake(80, 80));
        make.centerY.equalTo(self);
    }];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.iconImageView.mas_trailing).offset(16);
        make.trailing.equalTo(self.rightArrowImageView.mas_leading).offset(-16);
        make.centerY.equalTo(self);
    }];
    [self.rightArrowImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.trailing.equalTo(self).offset(-16);
        make.size.mas_equalTo(CGSizeMake(16, 16));
        make.centerY.equalTo(self);
    }];
}

- (void)setIndexPath:(NSIndexPath *)indexPath {
    _indexPath = indexPath;
    
    
    if (indexPath.row == 0) {
        self.lineView.frame = CGRectMake(0, 0, SCREEN_WIDTH, 0.5f);
    }else{
        self.lineView.frame = CGRectMake(16+80+16, 0, SCREEN_WIDTH, 0.5f);
    }
}

@end
