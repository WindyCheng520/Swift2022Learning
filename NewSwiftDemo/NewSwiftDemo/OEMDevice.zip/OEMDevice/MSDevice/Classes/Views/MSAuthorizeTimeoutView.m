//
//  MSAuthorizeTimeoutView.m
//  MSDevice
//
//  Created by pactera on 2020/11/24.
//  后确权超时弹框

#import "MSAuthorizeTimeoutView.h"
#import "MSDeviceBundle.h"


@interface MSAuthorizeTimeoutView ()

@property (nonatomic, strong) HGView *backView;
@property (nonatomic, strong) HGImageView *iconImageView;
@property (nonatomic, strong) HGTextView *titleTextView;
@property (nonatomic, strong) HGButton *continueButton;
@property (nonatomic, strong) HGButton *quiteButton;
@property (nonatomic, strong) HGImageView *maskView;  //渐变遮罩

@end

@implementation MSAuthorizeTimeoutView

- (instancetype)init {
    if (self = [super init]) {
        self.backgroundColor = RGBA_HEX(0x000000, 0.4f);
        self.frame = [UIScreen mainScreen].bounds;
        
        self.backView = [HGView new];
        self.backView.backgroundColor = RGBA_HEX(0xffffff, 1.f);
        self.backView.layer.cornerRadius = 16.f;
        [self addSubview:self.backView];
        
        self.iconImageView = [HGImageView new];
        self.iconImageView.image = MSResourceImage(@"pic_no_setup");
        [self.backView addSubview:self.iconImageView];
        
        self.titleTextView = [HGTextView new];
        self.titleTextView.textColor = RGB_HEX(0x000000);
        self.titleTextView.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
        self.titleTextView.editable = NO;
        self.titleTextView.text = MSResourceString(@"connect_authorize_timeout");
        self.titleTextView.textAlignment = NSTextAlignmentCenter;
        [self.backView addSubview:self.titleTextView];
        self.titleTextView.textContainerInset = UIEdgeInsetsMake(0, 0, 0, 0);
        self.titleTextView.textContainer.lineFragmentPadding = 0;
        
        self.continueButton = [HGButton new];
        [self.continueButton setTitle:MSResourceString(@"connect_restart_set") forState:UIControlStateNormal];
        [self.continueButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
        self.continueButton.titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
        self.continueButton.layer.cornerRadius = 22;
        self.continueButton.backgroundColor = RGB_HEX(0xEC1C24);
        [self.continueButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
        [self.backView addSubview:self.continueButton];
        
        self.quiteButton = [HGButton new];
        [self.quiteButton setTitleColor:RGB_HEX(0xEC1C24) forState:UIControlStateNormal];
        [self.quiteButton setTitle:MSResourceString(@"connect_notnow_set") forState:UIControlStateNormal];
        self.quiteButton.titleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
        [self.quiteButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
        [self.backView addSubview:self.quiteButton];
        
        self.maskView = [HGImageView new];
//        self.maskView.image = [HGImage createGradientColorImageWithColors:@[RGBA_HEX(0x00ffff, 1), RGBA_HEX(0xffffff, 1)] gradientType:HGGradientTypeTopToBottom imgSize:CGSizeMake(238, 40)];
        self.maskView.image = MSResourceImage(@"jianbianzz");
        [self.backView addSubview:self.maskView];
        
        [self makeContstraints];
    }
    return self;
}

- (void)makeContstraints {
    CGFloat margin = 16;
    CGFloat backWidth = 270;
    CGFloat titleHeight = ceil([self.titleTextView.text boundingRectWithSize:CGSizeMake(backWidth-margin*2, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : self.titleTextView.font} context:nil].size.height);
    BOOL isShowMask = titleHeight > 160;
    titleHeight = MIN(titleHeight, 160);
    
    [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(146, 100));
        make.top.equalTo(self.backView).offset(24);
        make.centerX.equalTo(self.backView);
    }];
    [self.titleTextView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.iconImageView.mas_bottom).offset(16);
        make.leading.equalTo(self.backView).offset(margin);
        make.trailing.equalTo(self.backView).offset(-margin);
        make.height.mas_equalTo(titleHeight);
    }];
    [self.continueButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleTextView.mas_bottom).offset(24);
        make.leading.equalTo(self.backView).offset(margin);
        make.trailing.equalTo(self.backView).offset(-margin);
        make.height.mas_equalTo(44);
    }];
    [self.quiteButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.backView).offset(margin);
        make.trailing.equalTo(self.backView).offset(-margin);
        make.height.mas_equalTo(14);
        make.top.equalTo(self.continueButton.mas_bottom).offset(16);
    }];
    if (isShowMask) {
        [self.maskView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leading.equalTo(self.backView).offset(margin);
            make.trailing.equalTo(self.backView).offset(-margin);
            make.height.mas_equalTo(40);
            make.bottom.equalTo(self.titleTextView.mas_bottom);
        }];
    } else {
        self.maskView.hidden = YES;
    }
    [self.backView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(backWidth);
        make.center.equalTo(self);
        make.height.mas_equalTo(24+100+16+titleHeight+24+44+16+14+20);
    }];
}

#pragma mark - click event
- (void)clickButton:(HGButton *)sender {
    if (sender == self.continueButton) {
        [self dismiss];
        safeCallBlock(self.clickContinueBlock);
    } else if (sender == self.quiteButton) {
        [self dismiss];
        safeCallBlock(self.clickQuiteBlock);
    }
}

#pragma mark - show selector
- (void)show {
    self.alpha = 0;
    self.backView.alpha = 0;
    self.backView.transform = CGAffineTransformMakeScale(1.2, 1.2);
    UIWindow* keyWindow = [UIApplication sharedApplication].keyWindow;
    [keyWindow addSubview:self];
    [UIView animateWithDuration:0.3 animations:^{
        self.backView.transform = CGAffineTransformMakeScale(1, 1);
        self.alpha = 1;
        self.backView.alpha = 1;
    } completion:nil];
}

- (void)showWithSuperview:(UIView *)superview {
    if (!superview) {
        superview = [UIApplication sharedApplication].keyWindow;
    }
    self.alpha = 0;
    self.backView.alpha = 0;
    self.backView.transform = CGAffineTransformMakeScale(1.2, 1.2);
    [superview addSubview:self];
    [UIView animateWithDuration:0.3 animations:^{
        self.backView.transform = CGAffineTransformMakeScale(1, 1);
        self.alpha = 1;
        self.backView.alpha = 1;
    } completion:nil];
}
 
- (void)dismiss {
    [self removeFromSuperview];
}


@end
