//  
//  MSChooseDeviceTypeCell.m
//  Pods
//   
//  Created by 李 燕强 on 2020/7/11
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSChooseDeviceTypeCell.h"
#import "MSDeviceBundle.h"
#import <MSBusiness/OEMGlobalUIManager.h>

@interface MSChooseDeviceTypeCell ()

@end

@implementation MSChooseDeviceTypeCell

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        
        self.imageView = [HGImageView new];
        self.imageView.contentMode = UIViewContentModeScaleAspectFill;
        self.imageView.clipsToBounds = YES;
        [self.contentView addSubview:self.imageView];
        
        self.nameLabel = [HGLabel new];
        self.nameLabel.textColor = RGB_HEX(0x000000);
        self.nameLabel.font = kRegularFont(10);
        self.nameLabel.textAlignment = NSTextAlignmentCenter;
        self.nameLabel.numberOfLines = 3;
        [self.contentView addSubview:self.nameLabel];
        
        [self makeConstraints];
        
        [self configureOEMTheme];
    }
    return self;
}

- (void)configureOEMTheme{
    [self.nameLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
    [self configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.contentView configureThemeTag:OEMThemesTag_UIView_Foreground];
    
    [self.nameLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.secondColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.secondColor
    }];
}

- (void)makeConstraints {
    
    [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(56, 56));
        make.top.equalTo(self.contentView).offset(31.5);
        make.centerX.equalTo(self.contentView);
    }];
    
    [self.nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.imageView.mas_bottom).offset(12);
        make.leading.equalTo(self.contentView).offset(11);
        make.trailing.equalTo(self.contentView).offset(-11);
    }];
    
}

+ (CGSize)cellSize {
    //CGFloat cellWidth =  floor((HG_SCREEN_WIDTH - 1 * 2) / 3.0);
    CGFloat cellWidth =  floor((HG_SCREEN_WIDTH) / 3.0);
    // 计算三行高度
    CGRect rect = [@"1\n1\n1" boundingRectWithSize:CGSizeMake(cellWidth - 11 * 2, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : [UIFont systemFontOfSize:10]} context:nil];
    CGFloat textHeight = ceil(rect.size.height);
    CGFloat cellHeight = 31.5 + 56 + 12 + textHeight + 15;
    return CGSizeMake(cellWidth, cellHeight);
}

@end

@implementation MSChooseDeviceTypeCellHeadView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        
        self.titleLabel = [HGLabel new];
        self.titleLabel.textColor = RGB_HEX(0x000000);
        self.titleLabel.font = kMediumFont(16);
        self.titleLabel.textAlignment = NSTextAlignmentLeft;
        [self addSubview:self.titleLabel];
        
        [self makeConstraints];
        
        [self configureOEMTheme];
    }
    return self;
}

- (void)configureOEMTheme{
    [self.titleLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
    [self configureThemeTag:OEMThemesTag_UIView_Foreground];
    
    [self.titleLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.mainTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.mainTextColor
    }];
}

- (void)makeConstraints {
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(16);
        make.top.bottom.mas_equalTo(0);
        make.trailing.mas_equalTo(-16);
    }];
}




@end
