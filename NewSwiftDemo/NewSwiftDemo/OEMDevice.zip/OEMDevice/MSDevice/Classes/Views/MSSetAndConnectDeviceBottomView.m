//  
//  MSSetAndConnectDeviceBottomView.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/13
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSSetAndConnectDeviceBottomView.h"
#import "MSDeviceBundle.h"

@implementation MSSetAndConnectDeviceBottomView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
        self.selectButton = [HGButton new];
        [self.selectButton setTitle:MSResourceString(@"connect_completed_setps") forState:UIControlStateNormal];
        [self.selectButton setTitleColor:RGB_HEX(0x666666) forState:UIControlStateNormal];
        self.selectButton.titleLabel.font = [UIFont systemFontOfSize:14];
        [self.selectButton setImage:MSResourceImage(@"ic_checkbox") forState:UIControlStateNormal];
        [self.selectButton setImage:MSResourceImage(@"ic_checkbox_s") forState:UIControlStateSelected];
        self.selectButton.style = HGButtonStyleLeftImageRightTitle;
        self.selectButton.span = 6;
        [self.selectButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:self.selectButton];
        
        self.nextButton = [HGButton new];
        [self.nextButton setTitle:MSResourceString(@"connect_wifi_page_next") forState:UIControlStateNormal];
        [self.nextButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
        self.nextButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
        self.nextButton.layer.cornerRadius = 22;
        self.nextButton.backgroundColor = RGBA_HEX(0xEC1C24, 0.3);
        self.nextButton.enabled = NO;
        [self addSubview:self.nextButton];
        [self.nextButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
        
        [self makeContstraints];
        
    }
    return self;
}

- (void)makeContstraints {
    [self.nextButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(30);
        make.trailing.mas_equalTo(-30);
        make.bottom.mas_equalTo(-30);
        make.height.mas_equalTo(44);
    }];
    [self.selectButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(30);
        make.trailing.mas_equalTo(-30);
        make.bottom.equalTo(self.nextButton.mas_top).offset(-16);
        make.height.mas_equalTo(25);
    }];
}

- (void)clickButton:(UIButton*)sender {
    if (sender == self.selectButton) {
        sender.selected = !sender.isSelected;
        if (sender.isSelected) {
            self.nextButton.backgroundColor = RGBA_HEX(0xEC1C24, 1);
            self.nextButton.enabled = YES;
            self.nextButton.layer.shadowColor = RGBA_HEX(0xEC1C24, 0.25f).CGColor;
            self.nextButton.layer.shadowOffset = CGSizeMake(0,2);
            self.nextButton.layer.shadowOpacity = 1;
            self.nextButton.layer.shadowRadius = 10;
            self.nextButton.layer.shadowPath = [UIBezierPath bezierPathWithRect:CGRectMake(0, 0, SCREEN_WIDTH-30*2, 44)].CGPath;
            
        }else{
            self.nextButton.backgroundColor = RGBA_HEX(0xEC1C24, 0.3);
            self.nextButton.enabled = NO;
            self.nextButton.layer.shadowOpacity = 0;

        }
    }else if (sender == self.nextButton){
        
        safeCallBlock(self.clickNextBlock);
    }
}

@end
