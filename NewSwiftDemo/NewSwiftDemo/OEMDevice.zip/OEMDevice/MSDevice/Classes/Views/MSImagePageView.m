//
//  MSImagePageView.m
//  MSDevice
//
//  Created by caiws on 2020/8/12.
//

#import "MSImagePageView.h"
#import "MSImagePageViewCell.h"
//#import <SDWebImage/FLAnimatedImageView+WebCache.h>
#import <SDWebImage/UIImageView+WebCache.h>
#import <FLAnimatedImage/FLAnimatedImage.h>
#import "UIImage+OEMDeviceExtensions.h"

@interface MSImagePageView () <UICollectionViewDataSource,UICollectionViewDelegate>
@property (nonatomic, copy) NSArray *urlList;
@property (nonatomic, strong) UICollectionViewFlowLayout *flowLayout;
@property (nonatomic, strong) UICollectionView *mainView;
@property (nonatomic, strong) HGButton *pageIndexView;
@property (nonatomic, assign) NSInteger currentIndex;
@property (nonatomic, strong) UIImage *defaultImage;
@property (nonatomic, strong) UIColor *defaultImageColor;

@property (nonatomic, copy) NSArray *imageList;

@end

@implementation MSImagePageView

- (instancetype)initWithFrame:(CGRect)frame urlStringList:(NSArray<NSString *> *)urlStringList
{
    if (self = [super initWithFrame:frame]) {
        self.urlList = urlStringList;
        [self setupUI];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame
                    imageList:(NSArray <UIImage *>*)imageList
            defaultImageColor:(UIColor *)defaultImageColor{
    if (self = [super initWithFrame:frame]) {
        self.imageList = imageList;
        self.defaultImageColor = defaultImageColor;
        [self setupUI];
    }
    return self;
}



- (instancetype)initWithFrame:(CGRect)frame urlStringList:(NSArray<NSString *> *)urlStringList defaultImageColor:(UIColor *)defaultImageColor {
    if (self = [super initWithFrame:frame]) {
        self.urlList = urlStringList;
        self.defaultImageColor = defaultImageColor;
        [self setupUI];
    }
    return self;
}

- (void)setupUI
{
    self.flowLayout = [[UICollectionViewFlowLayout alloc] init];
    self.flowLayout.minimumLineSpacing = 0;
    self.flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    self.flowLayout.itemSize = self.bounds.size;
    
    self.mainView = [[UICollectionView alloc] initWithFrame:self.bounds collectionViewLayout:self.flowLayout];
    self.mainView.backgroundColor = [UIColor clearColor];
    self.mainView.pagingEnabled = YES;
    self.mainView.showsHorizontalScrollIndicator = NO;
    self.mainView.showsVerticalScrollIndicator = NO;
    self.mainView.bounces = NO;
    [self.mainView registerClass:[MSImagePageViewCell class] forCellWithReuseIdentifier:NSStringFromClass(MSImagePageViewCell.class)];
    self.mainView.dataSource = self;
    self.mainView.delegate = self;
    self.mainView.scrollsToTop = NO;
    [self addSubview:self.mainView];
    
    self.pageIndexView = [HGButton new];
    self.pageIndexView.titleLabel.font = [UIFont systemFontOfSize:12];
    self.pageIndexView.userInteractionEnabled = NO;
    self.pageIndexView.backgroundColor = RGBA_HEX(0x000000,0.4);
    self.pageIndexView.contentEdgeInsets = UIEdgeInsetsMake(5, 8, 5, 8);
    [self addSubview:self.pageIndexView];
    self.pageIndexView.hidden = self.urlList.count <= 1;
}

- (UIImage *)defaultImage {
    if (!_defaultImage) {
        if (self.defaultImageColor) {
            _defaultImage = [UIImage imageWithColor:self.defaultImageColor];
        } else {
            _defaultImage = [UIImage imageWithColor:RGB_HEX(0xF9F9F9)];
        }
    }
    return _defaultImage;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    _flowLayout.itemSize = self.frame.size;
    _mainView.frame = self.bounds;
    [self layoutIndexView];
}

- (void)setCurrentIndex:(NSInteger)currentIndex
{
    if (_currentIndex == currentIndex) {
        return;
    }
    _currentIndex = currentIndex;
    [self layoutIndexView];
}

- (void)layoutIndexView
{
    NSString *title = [NSString stringWithFormat:@"%zd / %zd",self.currentIndex + 1,self.urlList.count];
    [self.pageIndexView setTitle:title forState:UIControlStateNormal];
    [self.pageIndexView sizeToFit];
    CGFloat w = self.pageIndexView.frame.size.width;
    CGFloat h = self.pageIndexView.frame.size.height;
    CGFloat x = self.frame.size.width - 16 - w - 12;
    CGFloat y = self.frame.size.height - 12 - h;
    self.pageIndexView.frame = CGRectMake(x, y, w, h);
    self.pageIndexView.layer.cornerRadius = h / 2;
}

#pragma mark - UICollectionViewDataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.urlList.count > 0? self.urlList.count: self.imageList.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    MSImagePageViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass(MSImagePageViewCell.class) forIndexPath:indexPath];
    if (self.urlList.count > 0) {
        [cell.iconImageView sd_setImageWithURL:[NSURL URLWithString:self.urlList[indexPath.item]] placeholderImage:self.defaultImage];
    }else{
        cell.iconImageView.image = self.imageList[indexPath.item];
    }
   
    return cell;
}

#pragma mark - scrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    int index = 0;
    if (_flowLayout.scrollDirection == UICollectionViewScrollDirectionHorizontal) {
        index = (_mainView.contentOffset.x + _flowLayout.itemSize.width * 0.5) / _flowLayout.itemSize.width;
    } else {
        index = (_mainView.contentOffset.y + _flowLayout.itemSize.height * 0.5) / _flowLayout.itemSize.height;
    }
    self.currentIndex = index;
}


@end
