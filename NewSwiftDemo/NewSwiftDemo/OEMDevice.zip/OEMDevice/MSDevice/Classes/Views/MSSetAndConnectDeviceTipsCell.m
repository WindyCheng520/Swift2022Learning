//  
//  MSSetAndConnectDeviceTipsCell.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/13
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSSetAndConnectDeviceTipsCell.h"
#import "MSDeviceBundle.h"

@implementation MSSetAndConnectDeviceTipsCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        self.numberLabel = [HGLabel new];
        self.numberLabel.backgroundColor = RGB_HEX(0x8A8A8F);
        self.numberLabel.layer.cornerRadius = 9;
        self.numberLabel.layer.masksToBounds = YES;
        self.numberLabel.textColor = RGB_HEX(0xFFFFFF);
        self.numberLabel.font = [UIFont systemFontOfSize:12];
        self.numberLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:self.numberLabel];
//        self.numberLabel.text = @"8";
        
        self.titleLabel = [HGLabel new];
        self.titleLabel.textColor = RGB_HEX(0x000000);
        self.titleLabel.font = [UIFont systemFontOfSize:16];
        self.titleLabel.numberOfLines = 0;
        [self.contentView addSubview:self.titleLabel];
//        self.titleLabel.text = MSResourceString(@"connect_has_emitter_wifi");
        
        [self makeContstraints];
        
    }
    return self;
}

- (void)makeContstraints {
    [self.numberLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(16);
        make.top.equalTo(self.contentView);
        make.size.mas_equalTo(CGSizeMake(18, 18));
    }];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.numberLabel.mas_trailing).offset(12);
        make.trailing.mas_equalTo(-16);
        make.top.equalTo(self.contentView);
        make.bottom.equalTo(self.contentView).offset(-16);
    }];
    
}

@end
