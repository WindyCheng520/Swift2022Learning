//  
//  MSChooseDeviceModelCell.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/11
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <OEMFoundation/HGUIKit.h>


@interface MSChooseDeviceModelCell : HGTableViewCell

@property (nonatomic, strong) NSIndexPath *indexPath;

@property (nonatomic, strong) HGImageView *iconImageView;
@property (nonatomic, strong) HGLabel *titleLabel;
@property (nonatomic, strong) HGImageView *rightArrowImageView;
@property (nonatomic, strong) HGView *lineView;

@end


