//  
//  MSSetAndConnectDeviceTipsCell.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/13
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <OEMFoundation/HGUIKit.h>

@interface MSSetAndConnectDeviceTipsCell : HGTableViewCell

@property (nonatomic, strong) HGLabel *numberLabel;
@property (nonatomic, strong) HGLabel *titleLabel;

@end
