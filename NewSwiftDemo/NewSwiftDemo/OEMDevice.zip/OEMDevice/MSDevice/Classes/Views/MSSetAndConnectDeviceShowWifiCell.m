//  
//  MSSetAndConnectDeviceShowWifiCell.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/13
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSSetAndConnectDeviceShowWifiCell.h"
#import "MSDeviceBundle.h"
#import <MSBusiness/OEMGlobalUIManager.h>
#import <OEMTheme/UILabel+OEMThemes.h>
#import <OEMFoundation/OEMMacros.h>

@implementation MSSetAndConnectDeviceShowWifiCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        self.wifiIconImageView = [HGImageView new];
        self.wifiIconImageView.image = MSResourceImage(@"network_ic_wifi");
        [self.contentView addSubview:self.wifiIconImageView];
        
        self.wifiLabel = [HGLabel new];
        self.wifiLabel.textColor = RGB_HEX(0xFF8225);
        self.wifiLabel.font = kMediumFont(23);
        self.wifiLabel.numberOfLines = 0;
        self.wifiLabel.textAlignment = NSTextAlignmentLeft;
        [self.wifiLabel sizeToFit];
        [self.contentView addSubview:self.wifiLabel];
        self.wifiLabel.text = @"";
        
        self.passwordIconImageView = [HGImageView new];
        self.passwordIconImageView.image = MSResourceImage(@"network_ic_password");
        [self.contentView addSubview:self.passwordIconImageView];
        
        self.passwordString = @"12345678";
        self.pasteButton = [HGButton new];
        UIColor *color = kDarkText.mainColor;
        NSString *title = [NSString stringWithFormat:@" %@", MSResourceString(@"ap_connect_page_tips_copy")];
        CGRect labelTitleSize = [title boundingRectWithSize:CGSizeMake(150, 20)
                                                               options:NSStringDrawingUsesLineFragmentOrigin
                                                            attributes:@{NSFontAttributeName:kMediumFont(12)} context:nil];
        CGFloat width = labelTitleSize.size.width;
        
        if (width < 63) {
            width = 63;
        }else{
            width = width + 30;
        }
        self.pasteButton.frame = CGRectMake(0, 0, width, 20);
        [self.pasteButton setTitle:title forState:UIControlStateNormal];   //connect_copy
        [self.pasteButton setTitleColor:color forState:UIControlStateNormal];
        self.pasteButton.titleLabel.font = kMediumFont(12);
        [self.pasteButton setImage:MSResourceImage(@"nerwork_ic_copy") forState:UIControlStateNormal];
        [self.pasteButton addTarget:self action:@selector(clickCopyButton) forControlEvents:UIControlEventTouchUpInside];
        self.pasteButton.style = HGButtonStyleLeftImageRightTitle;
        self.pasteButton.span = 2;
        self.pasteButton.backgroundColor =  [[OEMGlobalUIManager shareInstance] alphaColor:kLightText.mainColor alpha:0.1];
        self.pasteButton.layer.cornerRadius = 10;
        
        self.passwordLabel = [YYLabel new];
        self.passwordLabel.numberOfLines = 0;
        self.passwordLabel.textAlignment = NSTextAlignmentLeft;
        [self.contentView addSubview:self.passwordLabel];
        
        UIColor *color1 = [UIColor clearColor];
        NSMutableAttributedString *passwordAttributedString = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@   ",self.passwordString] attributes:@{NSForegroundColorAttributeName:color1, NSFontAttributeName: kMediumFont(23)}];
        
        [passwordAttributedString appendAttributedString:[NSAttributedString yy_attachmentStringWithContent:self.pasteButton contentMode:UIViewContentModeCenter attachmentSize:self.pasteButton.frame.size alignToFont:[UIFont boldSystemFontOfSize:23] alignment:YYTextVerticalAlignmentCenter]];
        self.passwordLabel.attributedText = passwordAttributedString;
        self.passwordLabelHeight = [YYTextLayout layoutWithContainerSize:CGSizeMake(SCREEN_WIDTH-46-24-12-16, MAXFLOAT) text:passwordAttributedString].textBoundingSize.height;
        self.passwordLabel.numberOfLines = 0;
     //   self.passwordLabel.textAlignment = NSTextAlignmentLeft;
        
        
        [self makeContstraints];
        [self configureOEMTheme];
    }
    return self;
}



- (void)configureOEMTheme{
    [self configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.contentView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.wifiLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.mainTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.mainTextColor
    }];
    
    
    [self.passwordLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.mainTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.mainTextColor
    }];
    
    __weak typeof(self)weakSelf = self;
    [self registerTraitDidChangeCallback:^{
        [weakSelf updatPassword];
    } callImmidiately:YES];
}

-(void)updatPassword{
    
    UIColor *color = [UIColor clearColor];
    if (OEMThemeIsDarkMode) {
        color = kDarkText.mainTextColor;
    }else{
        color = kLightText.mainTextColor;
    }
  

    if (isRTL()) {
        NSMutableAttributedString *pastButtonString = [NSAttributedString yy_attachmentStringWithContent:self.pasteButton contentMode:UIViewContentModeCenter attachmentSize:self.pasteButton.frame.size alignToFont:kMediumFont(23) alignment:YYTextVerticalAlignmentCenter].mutableCopy;
        
        NSMutableAttributedString* passwordAttributedString = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"   %@   ",self.passwordString] attributes:@{NSForegroundColorAttributeName:color, NSFontAttributeName: kMediumFont(23)}];
        
        [pastButtonString appendAttributedString:passwordAttributedString];
        self.passwordLabel.attributedText = pastButtonString;
        self.passwordLabelHeight = [YYTextLayout layoutWithContainerSize:CGSizeMake(SCREEN_WIDTH- 32, MAXFLOAT) text:pastButtonString].textBoundingSize.height;
        self.passwordLabel.numberOfLines = 0;
        self.passwordLabel.textAlignment = NSTextAlignmentLeft;
    }else{
        
        NSMutableAttributedString* passwordAttributedString = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@   ",self.passwordString] attributes:@{NSForegroundColorAttributeName:color, NSFontAttributeName: kMediumFont(23)}];
    
        [passwordAttributedString appendAttributedString:[NSAttributedString yy_attachmentStringWithContent:self.pasteButton contentMode:UIViewContentModeCenter attachmentSize:self.pasteButton.frame.size alignToFont:kMediumFont(23) alignment:YYTextVerticalAlignmentCenter]];
        self.passwordLabel.attributedText = passwordAttributedString;
        self.passwordLabelHeight = [YYTextLayout layoutWithContainerSize:CGSizeMake(SCREEN_WIDTH- 32, MAXFLOAT) text:passwordAttributedString].textBoundingSize.height;
        self.passwordLabel.numberOfLines = 0;
        self.passwordLabel.textAlignment = NSTextAlignmentLeft;
    }
}

- (void)makeContstraints {
    [self.wifiIconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(16);
        make.size.mas_equalTo(CGSizeMake(24, 24));
        make.top.equalTo(self.contentView).offset(6);
    }];
    [self.wifiLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.wifiIconImageView.mas_trailing).offset(12.5);
        make.trailing.equalTo(self.contentView).offset(-16);
        //make.centerY.equalTo(self.wifiIconImageView);
        make.top.equalTo(self.contentView);
        make.bottom.equalTo(self.passwordLabel.mas_top).offset(-16);
    }];
    
    [self.passwordLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.passwordIconImageView.mas_trailing).offset(12.5);
        make.trailing.equalTo(self.contentView).offset(-16);
      //  make.centerY.equalTo(self.passwordIconImageView);
        make.bottom.equalTo(self.contentView).offset(-28);
        make.height.mas_equalTo(self.passwordLabelHeight);
    }];
    
    [self.passwordIconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(16);
        make.size.mas_equalTo(CGSizeMake(24, 24));
        make.top.equalTo(self.passwordLabel).offset(4);
    }];
  
    
}

- (void)clickCopyButton {
    if (![self.passwordLabel.text isEqualToString:@""]) {
        UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
         NSString *password = self.passwordLabel.text;
        if (password.length > 0) {
            NSRange subRange= NSMakeRange(0, 8);
            NSString *subString = [password substringWithRange:subRange];
            pasteboard.string = subString;
        }
        
        if (isRTL()){
            pasteboard.string = @"12345678";
        }
    }
    
    if ([self.delegate respondsToSelector:@selector(passwordDidCopy)]) {
        [self.delegate passwordDidCopy];
    }
}


@end
