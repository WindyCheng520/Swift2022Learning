//  
//  MSStepCell.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/14
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <OEMFoundation/HGUIKit.h>
#import <Lottie/LOTAnimationView.h>


@interface MSStepCell : HGTableViewCell

@property (nonatomic, strong) HGView *backView;

@property (nonatomic, strong) LOTAnimationView *loadView;

@property (nonatomic, strong) HGLabel *stepLabel;



@end


