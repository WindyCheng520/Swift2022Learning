//
//  SequenceITemCellView.m
//  MSLogin
//
//  Created by Neil 韦学宁 on 2021/7/15.
//

#import "SequenceItemCellView.h"
#import "MSDeviceBundle.h"
#import <MSBusiness/OEMGlobalUIManager.h>

@interface SequenceItemCellView()


@end

#define SequenceItemCellViewQuestionMarkWidth (16)

#define SequenceItemCellViewTxtLeading (16)

#define SequenceItemCellViewTxtTrailing (16)

#define SICQuestionMarkPadding (8)

@implementation SequenceItemCellView

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self initSubViews];
    }
    return self;
}

- (void)initSubViews{
    
    self.contentLabel = [UILabel new];
    self.contentLabel.numberOfLines = 0;
    self.contentLabel.font = kRegularFont(14);
    self.contentLabel.textAlignment = NSTextAlignmentLeft;
    self.contentLabel.backgroundColor = [UIColor clearColor];
    [self addSubview:self.contentLabel];
//
//    self.indexItemLabel = [UILabel new];
//    self.indexItemLabel.numberOfLines = 0;
//    self.indexItemLabel.font = kRegularFont(14);
//    self.indexItemLabel.textAlignment = NSTextAlignmentCenter;
//    self.indexItemLabel.backgroundColor = [UIColor clearColor];
//    self.indexItemLabel.layer.cornerRadius = 19 * 0.5;
//    self.indexItemLabel.layer.borderWidth = 0.5;
//    self.indexItemLabel.layer.masksToBounds = YES;
//    [self addSubview:self.indexItemLabel];
    
    self.dotView = [UIView new];
    self.dotView.layer.masksToBounds = YES;
    self.dotView.layer.cornerRadius = 6 * 0.5;
    [self addSubview:self.dotView];
    
    self.questionMark = [UIImageView new];
    self.questionMark.image = MSResourceImage(@"device_question_mark");
    [self addSubview:self.questionMark];
    
    self.questionMarkButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.questionMarkButton addTarget:self action:@selector(onButton) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:self.questionMarkButton];
    self.questionMarkButton.backgroundColor = [UIColor clearColor];
    
//    [self.indexItemLabel mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(self.indexItemLabel.superview).offset(2);
//        make.leading.equalTo(self.indexItemLabel.superview).offset(16);
//        make.size.mas_equalTo(CGSizeMake(19, 19));
//    }];
    
    [self.dotView mas_makeConstraints:^(MASConstraintMaker *make) {
      //  make.trailing.equalTo(self);
        make.leading.equalTo(self).offset(32);
        make.centerY.equalTo(self);
        make.size.mas_equalTo(CGSizeMake(6, 6));
    }];
    
    [self.questionMark mas_makeConstraints:^(MASConstraintMaker *make) {
        make.trailing.equalTo(self.questionMark.superview).offset(-30);
        make.centerY.equalTo(self);
        make.size.mas_equalTo(CGSizeMake(SequenceItemCellViewQuestionMarkWidth, SequenceItemCellViewQuestionMarkWidth));
    }];
    
    [self.questionMarkButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(30, 30));
        make.center.equalTo(self.questionMark);
    }];
    
    [self configureOEMTheme];
    self.backgroundColor = [UIColor clearColor];
}

- (void)onButton{
    if (self.onQuestionMarkTap) {
        self.onQuestionMarkTap();
    }
}

- (void)configureOEMTheme{
    [self configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.contentLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
    [self.indexItemLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
   // self.dotView.backgroundColor = ComoonThemeDotBackground;
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        if (OEMThemeIsDarkMode) {
            weakSelf.indexItemLabel.layer.borderColor = DarkThemeClearBackgroundButtonTitle.CGColor;
            weakSelf.dotView.backgroundColor = kDarkText.thirdColor;
        }else{
            weakSelf.dotView.backgroundColor = kLightText.thirdColor;
            weakSelf.indexItemLabel.layer.borderColor = LightThemeClearBackgroundButtonTitle.CGColor;
        }
    } callImmidiately:YES];
}

+ (CGFloat)textHeightWithString:(NSString *)string width:(CGFloat)width{
    UIFont * font = [UIFont systemFontOfSize:14];
    return [self boundingRectWithSize:CGSizeMake(width, MAXFLOAT) font:font lineSpacing:0 string:string].height;
    /*
    CGSize size = [string boundingRectWithSize:CGSizeMake(SCREEN_WIDTH - 43 - 16, MAXFLOAT) font:font lineSpacing:font.lineHeight];
    return size.height;
     */
}

- (CGFloat)getExpectedHeigt{
    CGFloat width = SCREEN_WIDTH;
    
    //文本leading
    width -= SequenceItemCellViewTxtLeading;
    
    //文本traling
    width -= SequenceItemCellViewTxtTrailing;
    
    if (!self.questionMark.hidden) {
        //icon width
        width -= SequenceItemCellViewQuestionMarkWidth;
        //padding between label and question mark
        width -= SICQuestionMarkPadding;
    }
    return [[self class] textHeightWithString:self.contentLabel.text width:width];
}

- (void)setText:(NSString *)text index:(NSInteger)index type:(SequenceItemType)type enableQuestionMark:(BOOL)enableQuestionMark{
    self.contentLabel.text = text;

 //   self.indexItemLabel.text = [NSString stringWithFormat:@"%ld", (long)index];
    if (type == SequenceItemType_Number) {
        self.indexItemLabel.hidden = NO;
        self.dotView.hidden = YES;
        self.contentLabel.text = [NSString stringWithFormat:@"%ld、%@", (long)index, text];
    }else{
        self.contentLabel.text = text;
        self.indexItemLabel.hidden = YES;
        self.dotView.hidden = NO;
    }
    if (enableQuestionMark) {
        self.questionMark.hidden = NO;
    }else{
        self.questionMark.hidden = YES;
    }
    
    [self.contentLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentLabel.superview);
       
        CGFloat traling = SequenceItemCellViewTxtTrailing;
        if (enableQuestionMark) {
            traling = SequenceItemCellViewTxtTrailing +
            SequenceItemCellViewQuestionMarkWidth +
            SICQuestionMarkPadding;
            make.leading.equalTo(self.contentLabel.superview).offset(46);
        }else{
            make.leading.equalTo(self.contentLabel.superview).offset(SequenceItemCellViewTxtLeading);
        }
        make.trailing.equalTo(self.contentLabel.superview).offset(-traling);
    }];
}

+ (CGSize)boundingRectWithSize:(CGSize)size font:(UIFont*)font lineSpacing:(CGFloat)lineSpacing string:(NSString *)string
{
    NSMutableAttributedString *attributeString = [[NSMutableAttributedString alloc] initWithString:string];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = lineSpacing;
    [attributeString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, string.length)];
    [attributeString addAttribute:NSFontAttributeName value:font range:NSMakeRange(0, string.length)];
    NSStringDrawingOptions options = NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading;
    CGRect rect = [attributeString boundingRectWithSize:size options:options context:nil];
    return rect.size;
    
}

@end
