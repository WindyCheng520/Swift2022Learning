//
//  MSAPAutoConnectWiFiView.m
//  MSDevice
//
//  Created by pactera on 2021/2/8.
//

#import "MSAPAutoConnectWiFiView.h"
#import "MSDeviceBundle.h"

@interface MSAPAutoConnectWiFiView ()

@property (nonatomic, strong) HGView *backView;
@property (nonatomic, strong) HGButton *deleteButton;
@property (nonatomic, strong) HGImageView *iconImageView;
@property (nonatomic, strong) HGLabel *titleLabel;
@property (nonatomic, strong) HGLabel *subtitleLabel;
@property (nonatomic, strong) HGButton *retryButton;

@property (nonatomic, copy) NSString *wifiName;

@end


@implementation MSAPAutoConnectWiFiView

#pragma mark - life cycle
- (instancetype)initWithWiFiName:(NSString *)wifiName {
    if (self = [super init]) {
        self.wifiName = wifiName;
        [self configSubviews];
        
    }
    return self;
}

#pragma mark - UI
- (void)configSubviews {
    self.backgroundColor = RGBA_HEX(0x000000, 0.3f);
    self.frame = [UIScreen mainScreen].bounds;
    
    self.backView = [HGView new];
    self.backView.backgroundColor = RGBA_HEX(0xffffff, 1.f);
    [self addSubview:self.backView];
    
    self.deleteButton = [HGButton new];
    [self.deleteButton setImage:MSResourceImage(@"ic_popup_close") forState:UIControlStateNormal];
    [self.deleteButton addTarget:self action:@selector(clickDeleteButton) forControlEvents:UIControlEventTouchUpInside];
    [self.backView addSubview:self.deleteButton];
    
    self.iconImageView = [HGImageView new];
    self.iconImageView.image = MSResourceImage(@"ic_network_WiFi");
    [self.backView addSubview:self.iconImageView];
    
    self.titleLabel = [HGLabel new];
    self.titleLabel.textColor = RGB_HEX(0x000000);
    self.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    self.titleLabel.text = [NSString stringWithFormat:MSResourceString(@"auto_connect_retry_title"), self.wifiName];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.numberOfLines = 0;
    [self.backView addSubview:self.titleLabel];
    
    self.subtitleLabel = [HGLabel new];
    self.subtitleLabel.textColor = RGB_HEX(0x999999);
    self.subtitleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightRegular];
    self.subtitleLabel.text = MSResourceString(@"auto_connect_retry_subtitle");
    self.subtitleLabel.textAlignment = NSTextAlignmentCenter;
    self.subtitleLabel.numberOfLines = 0;
    [self.backView addSubview:self.subtitleLabel];
    
    self.retryButton = [HGButton new];
    [self.retryButton setBackgroundColor:RGB_HEX(0xEC1C24)];
    [self.retryButton setTitle:MSResourceString(@"config_fail_page_connect_try_again") forState:UIControlStateNormal];
    [self.retryButton setTitleColor:RGB_HEX(0xffffff) forState:UIControlStateNormal];
    self.retryButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    [self.retryButton addTarget:self action:@selector(clickRetryButton) forControlEvents:UIControlEventTouchUpInside];
    self.retryButton.layer.cornerRadius = 22;
    self.retryButton.layer.masksToBounds = YES;
    [self.backView addSubview:self.retryButton];
    
    [self makeConstraints];
    
}

- (void)makeConstraints {
    CGFloat margin = 48;
    CGFloat titleHeight = ceil([self.titleLabel.text boundingRectWithSize:CGSizeMake(SCREEN_WIDTH - margin * 2, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : self.titleLabel.font} context:nil].size.height);
    CGFloat subtitleHeight = ceil([self.subtitleLabel.text boundingRectWithSize:CGSizeMake(SCREEN_WIDTH - margin * 2, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : self.subtitleLabel.font} context:nil].size.height);
    
    [self.deleteButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.trailing.top.equalTo(self.backView);
        make.size.mas_equalTo(CGSizeMake(14 + 16 * 2, 14 + 16 * 2));
    }];
    [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.backView).offset(48);
        make.size.mas_equalTo(CGSizeMake(72, 72));
        make.centerX.equalTo(self.backView);
    }];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.iconImageView.mas_bottom).offset(16);
        make.leading.equalTo(self.backView).offset(margin);
        make.trailing.equalTo(self.backView).offset(-margin);
        make.height.mas_equalTo(titleHeight);
    }];
    [self.subtitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleLabel.mas_bottom).offset(12);
        make.leading.equalTo(self.backView).offset(margin);
        make.trailing.equalTo(self.backView).offset(-margin);
        make.height.mas_equalTo(subtitleHeight);
    }];
    [self.retryButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.subtitleLabel.mas_bottom).offset(32);
        make.size.mas_equalTo(CGSizeMake(200, 44));
        make.centerX.equalTo(self.backView);
    }];
    CGFloat backHeight = 48 + 72 + 16 + titleHeight + 12 + subtitleHeight + 32 + 44 + 48 + kSafeAreaBottom;
    [self.backView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.bottom.equalTo(self);
        make.height.mas_equalTo(backHeight);
    }];
    
    [self setViewLayerWithDirection:UIRectCornerTopLeft | UIRectCornerTopRight andLayerView:self.backView andCornerRadii:CGSizeMake(16, 16) andRect:CGRectMake(0, 0, SCREEN_WIDTH, backHeight)];

}

#pragma mark - event
- (void)clickRetryButton {
    safeCallBlock(self.didClickRetry);
    [self dismiss];
}

- (void)clickDeleteButton {
    safeCallBlock(self.didClickDelete);
    [self dismiss];
}

#pragma mark - private methods
//为view添加圆角  cornerRadii圆角尺寸
- (void)setViewLayerWithDirection:(UIRectCorner)corner andLayerView:(UIView*)view andCornerRadii:(CGSize)cornerRadii andRect:(CGRect)rect {
//    CGRect rect = CGRectMake(0, 0, self.frame.size.width, view.frame.size.height);
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:rect byRoundingCorners:corner cornerRadii:cornerRadii];
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = rect;
    maskLayer.path = maskPath.CGPath;
    view.layer.mask = maskLayer;
}

#pragma mark - setter/getter
- (void)showWithSuperview:(UIView *)superview {
    if (!superview) {
        superview = [UIApplication sharedApplication].keyWindow;
    }
    self.alpha = 0;
    self.backView.alpha = 0;
    [superview addSubview:self];
    [UIView animateWithDuration:0.3 animations:^{
        self.alpha = 1;
        self.backView.alpha = 1;
    } completion:nil];
}
 
- (void)dismiss {
    [self removeFromSuperview];
}

@end
