//
//  MSAuthorizeTimeoutView.h
//  MSDevice
//
//  Created by pactera on 2020/11/24.
//

#import <OEMFoundation/HGUIKit.h>


@interface MSAuthorizeTimeoutView : HGView

@property (nonatomic, copy) void(^clickContinueBlock)(void);
@property (nonatomic, copy) void(^clickQuiteBlock)(void);


- (void)show;
- (void)showWithSuperview:(UIView *)superview;
- (void)dismiss;

@end

