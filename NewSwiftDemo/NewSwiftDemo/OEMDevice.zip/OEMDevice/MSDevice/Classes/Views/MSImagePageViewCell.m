//
//  MSImagePageViewCell.m
//  MSDevice
//
//  Created by caiws on 2020/8/12.
//

#import "MSImagePageViewCell.h"

@implementation MSImagePageViewCell

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self setupUI];
    }
    return self;
}

- (void)setupUI {
    self.iconImageView = [FLAnimatedImageView new];
    self.iconImageView.layer.cornerRadius = 12;
    self.iconImageView.layer.masksToBounds = YES;
    self.iconImageView.contentMode = UIViewContentModeScaleAspectFill;
//    self.iconImageView.backgroundColor = RGB_HEX(0xF9F9F9);
    [self.contentView addSubview:self.iconImageView];
}

//- (CGFloat)right
//{
//    return self.frame.size.width + self.frame.origin.x;
//}
- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat margin = 0; //左右间距
    CGFloat right = self.contentView.frame.size.width + self.contentView.frame.origin.x;
    CGFloat width = right - margin * 2;
    CGFloat height = self.contentView.frame.size.height;
    self.iconImageView.frame = CGRectMake(margin, 0, width, height);
}

@end
