//
//  OEMAddDeviceButton.h
//  MSDevice
//
//  Created by WindyCheng on 2022/3/14.
//

#import <UIKit/UIKit.h>
#import <OEMFoundation/HGUIKit.h>

NS_ASSUME_NONNULL_BEGIN

//配网方式
typedef NS_ENUM(NSInteger, ConnectType) {
     ConnectTypeBLE = 1,          //  尝试设备蓝牙配网连接
     ConnectTypeAP = 2,           //  尝试设备AP配网连接
     ConnectTypeBLE2 = 3,         //  蓝牙配网连接
     ConnectTypeAP2 = 4,          //  AP配网连接
};

@interface OEMAddDeviceButton : HGButton

@property(nonatomic, assign)ConnectType type;


- (instancetype)initWithFrame:(CGRect)frame
                         type:(ConnectType)type;

@end

NS_ASSUME_NONNULL_END
