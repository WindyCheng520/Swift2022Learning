//
//  MSAPAutoConnectWiFiView.h
//  MSDevice
//
//  Created by pactera on 2021/2/8.
//

#import <OEMFoundation/HGView.h>

NS_ASSUME_NONNULL_BEGIN

@interface MSAPAutoConnectWiFiView : HGView

@property (nonatomic, copy) void(^didClickRetry)(void);
@property (nonatomic, copy) void(^didClickDelete)(void);

- (instancetype)initWithWiFiName:(NSString *)wifiName;
- (void)showWithSuperview:(UIView *)superview;

@end

NS_ASSUME_NONNULL_END
