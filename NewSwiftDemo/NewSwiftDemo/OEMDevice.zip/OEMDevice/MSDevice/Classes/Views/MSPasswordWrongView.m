//
//  MSPasswordWrongView.m
//  MSDevice
//
//  Created by pactera on 2020/11/24.
//  配网的wifi密码错误弹框

#import "MSPasswordWrongView.h"
#import "MSDeviceBundle.h"
#import <MSBusiness/MSUIConfiguration.h>
#import <OEMTheme/MSInputView_Private.h>
#import <OEMTheme/UILabel+OEMThemes.h>

@interface MSPasswordWrongView ()<MSInputViewDelegate>

@property (nonatomic, copy) NSString *wifiName;
@property (nonatomic, copy) NSString *password;

@property (nonatomic, strong) HGView *backView;
@property (nonatomic, strong) HGLabel *titleLabel;
@property (nonatomic, strong) HGLabel *detailLabel;
@property (nonatomic, strong) MSInputView *wifiInputView;
@property (nonatomic, strong) MSInputView *passwordInputView;
@property (nonatomic, strong) HGButton *retryButton;

@end

@implementation MSPasswordWrongView

- (instancetype)initWithWifiName:(NSString *)wifiName password:(NSString *)password {
    if (self = [super init]) {
        self.wifiName = wifiName;
        self.password = password;
        
        self.backgroundColor = RGBA_HEX(0x000000, 0.4f);
        self.frame = [UIScreen mainScreen].bounds;
        
        self.backView = [HGView new];
        self.backView.backgroundColor = RGBA_HEX(0xffffff, 1.f);
        self.backView.layer.cornerRadius = 16.f;
        [self addSubview:self.backView];
        
        self.titleLabel = [HGLabel new];
        self.titleLabel.textColor = RGB_HEX(0x000000);
        self.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.numberOfLines = 0;
        [self.backView addSubview:self.titleLabel];
        self.titleLabel.text = MSResourceString(@"add_device_process_page_wifi_password_wrong");
        
        
        self.detailLabel = [HGLabel new];
        self.detailLabel.textColor = RGB_HEX(0x8a8a8f);
        self.detailLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightRegular];
        self.detailLabel.textAlignment = NSTextAlignmentCenter;
        self.detailLabel.numberOfLines = 0;
        [self.backView addSubview:self.detailLabel];
        self.detailLabel.text = MSResourceString(@"add_device_process_page_makesure_password_right");
        
        self.wifiInputView = [MSInputView new];
        [self.wifiInputView setFont:[UIFont systemFontOfSize:16 weight:UIFontWeightBold]];
        [self.wifiInputView setTextColor:RGB_HEX(0x999999)];
      //  self.wifiInputView.backgroundColor = RGB_HEX(0xfafafa);
        self.wifiInputView.text = self.wifiName;
        [self.backView addSubview:self.wifiInputView];
        self.wifiInputView.delegate = self;
        
        self.passwordInputView = [MSInputView new];
        [self.passwordInputView setRightImage:MSResourceImage(@"ic_input_view")];
        [self.passwordInputView setFont:[UIFont systemFontOfSize:16 weight:UIFontWeightBold]];
        [self.passwordInputView setTextColor:RGB_HEX(0x000000)];
        self.passwordInputView.secureTextEntry = YES;
        WEAK_SELF;
        self.passwordInputView.clickRightButtonBlock = ^{
            STRONG_SELF;
            if (self.passwordInputView.isSecureTextEntry) {
                self.passwordInputView.secureTextEntry = NO;
                [self.passwordInputView setRightImage:MSResourceImage(@"ic_input_view_s")];
            } else {
                self.passwordInputView.secureTextEntry = YES;
                [self.passwordInputView setRightImage:MSResourceImage(@"ic_input_view")];
            }
        };
        self.passwordInputView.placeholder = MSResourceString(@"connect_wifi_page_wifi_password_tip");
        [self.backView addSubview:self.passwordInputView];
        self.passwordInputView.text = self.password;
        
        self.retryButton = [HGButton new];
        [self.retryButton setTitle:MSResourceString(@"config_fail_page_connect_try_again") forState:UIControlStateNormal];
        [self.retryButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
        self.retryButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
        self.retryButton.layer.cornerRadius = 22;
        self.retryButton.backgroundColor = RGB_HEX(0xEC1C24);
        [self.backView addSubview:self.retryButton];
        [self.retryButton addTarget:self action:@selector(clickButton) forControlEvents:UIControlEventTouchUpInside];
        
        [self makeContstraints];
        [self configureOEMTheme];
    }
    return self;
}


- (void)configureOEMTheme{
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    [self.backView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.retryButton configureThemeTag:OEMThemesTag_UIButton_Background];
    [self.titleLabel configure90TranslucentTrait];
    [self.detailLabel configure40TranslucentTrait];
    [self.wifiInputView.textField configureThemeTag:OEMThemesTag_UITextField_Textcolor];
    [self.passwordInputView.textField configureThemeTag:OEMThemesTag_UITextField_Textcolor];

}

- (void)makeContstraints {
    CGFloat margin = 16;
    CGFloat backWidth = 270;
    CGFloat titleHeight = ceil([self.titleLabel.text boundingRectWithSize:CGSizeMake(backWidth-margin*2, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : self.titleLabel.font} context:nil].size.height);
    CGFloat detailHeight = ceil([self.detailLabel.text boundingRectWithSize:CGSizeMake(backWidth-margin*2, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : self.detailLabel.font} context:nil].size.height);
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.backView).offset(24);
        make.leading.equalTo(self.backView).offset(margin);
        make.trailing.equalTo(self.backView).offset(-margin);
        make.height.mas_equalTo(titleHeight);
    }];
    [self.detailLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleLabel.mas_bottom).offset(8);
        make.leading.equalTo(self.backView).offset(margin);
        make.trailing.equalTo(self.backView).offset(-margin);
        make.height.mas_equalTo(detailHeight);
    }];
    [self.wifiInputView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.detailLabel.mas_bottom).offset(24);
        make.leading.equalTo(self.backView).offset(margin);
        make.trailing.equalTo(self.backView).offset(-margin);
        make.height.mas_equalTo(44);
    }];
    [self.passwordInputView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.wifiInputView.mas_bottom).offset(12);
        make.leading.equalTo(self.backView).offset(margin);
        make.trailing.equalTo(self.backView).offset(-margin);
        make.height.mas_equalTo(44);
    }];
    [self.retryButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.passwordInputView.mas_bottom).offset(24);
        make.leading.equalTo(self.backView).offset(margin);
        make.trailing.equalTo(self.backView).offset(-margin);
        make.height.mas_equalTo(44);
    }];
    [self.backView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(backWidth);
        make.center.equalTo(self);
        make.height.mas_equalTo(24+titleHeight+8+detailHeight+24+44+12+44+24+44+24);
    }];
}

#pragma mark - click event
- (void)clickButton {
    if (self.passwordInputView.text.length > 0 && self.passwordInputView.text.length < 8) {
        [MSUIConfiguration sh_showBlackToastHudToView:self text:MSResourceString(@"connect_wifi_password_length")];
        return;
    }
    [self dismiss];
    safeCallBlock(self.clickRetryBlock, self.passwordInputView.text?:@"");
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self endEditing:YES];
}

#pragma mark - MSInputViewDelegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    return NO;
}

#pragma mark - show selector
- (void)show {
    self.alpha = 0;
    self.backView.alpha = 0;
    self.backView.transform = CGAffineTransformMakeScale(1.2, 1.2);
    UIWindow* keyWindow = [UIApplication sharedApplication].keyWindow;
    [keyWindow addSubview:self];
    [UIView animateWithDuration:0.3 animations:^{
        self.backView.transform = CGAffineTransformMakeScale(1, 1);
        self.alpha = 1;
        self.backView.alpha = 1;
    } completion:nil];
}

- (void)showWithSuperview:(UIView *)superview {
    if (!superview) {
        superview = [UIApplication sharedApplication].keyWindow;
    }
    self.alpha = 0;
    self.backView.alpha = 0;
    self.backView.transform = CGAffineTransformMakeScale(1.2, 1.2);
    [superview addSubview:self];
    [UIView animateWithDuration:0.3 animations:^{
        self.backView.transform = CGAffineTransformMakeScale(1, 1);
        self.alpha = 1;
        self.backView.alpha = 1;
    } completion:nil];
}
 
- (void)dismiss {
    [UIView animateWithDuration:0.3 animations:^{
        self.alpha = 0;
        self.backView.alpha = 0;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}



@end
