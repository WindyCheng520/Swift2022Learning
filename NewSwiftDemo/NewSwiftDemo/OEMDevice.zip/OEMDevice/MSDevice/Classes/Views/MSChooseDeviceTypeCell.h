//  
//  MSChooseDeviceTypeCell.h
//  Pods
//   
//  Created by 李 燕强 on 2020/7/11
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <OEMFoundation/HGUIKit.h>

@interface MSChooseDeviceTypeCell : HGCollectionViewCell

@property (nonatomic, strong) HGImageView *imageView;
@property (nonatomic, strong) HGLabel *nameLabel;

+ (CGSize)cellSize;

@end

@interface MSChooseDeviceTypeCellHeadView : UICollectionReusableView

@property (nonatomic, strong) HGLabel *titleLabel;


@end
