//
//  MSChooseDeviceTypeCountView.h
//  MSDevice
//
//  Created by midea on 2021/3/31.
//

#import <OEMFoundation/HGControl.h>


@interface MSChooseDeviceTypeCountView : HGControl

- (void)updateCountWithNumber:(NSInteger)number;

@end

