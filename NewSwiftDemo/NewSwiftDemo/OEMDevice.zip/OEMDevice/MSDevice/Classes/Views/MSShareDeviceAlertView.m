//
//  MSShareDeviceAlertView.m
//  MSDevice
//
//  Created by WindyCheng on 2021/11/24.
//

#import "MSShareDeviceAlertView.h"
#import "MSDeviceBundle.h"
#import <OEMTheme/UILabel+OEMThemes.h>

#import <MSBusiness/MSDeviceProtocol.h>
#import <MSBusiness/MSDeviceProductResult.h>
#import <SDWebImage/UIImageView+WebCache.h>


@interface MSShareDeviceAlertView ()

@property (nonatomic, assign) CGSize contentSize;

@property (nonatomic, strong) HGView *backView;       //容器
@property (nonatomic, strong) HGLabel *contentLabel;  //内容

@property (nonatomic, strong) HGImageView *iconView;
@property (nonatomic, strong) HGLabel *nameLabel;      //名称

@property (nonatomic, strong) HGButton *agreeButton;  //同意按钮
@property (nonatomic, strong) HGButton *cancelButton; //取消按钮

@property (nonatomic, strong) UIViewController *controller;



@property (nonatomic, copy) NSString *type;      //品类
@property (nonatomic, copy) NSString *name;      //名字
@property (nonatomic, copy)NSString *imgUrl;      //图标url

@end



@implementation MSShareDeviceAlertView

- (instancetype)init {
    if (self = [super init]) {
        self.backgroundColor = RGBA_HEX(0x000000, 0.65f);
        self.frame = [UIScreen mainScreen].bounds;
        [self configSubviews];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame
                         type:(NSString *)type
                         name:(NSString *)name
             parentController:(UIViewController *)parentController{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = RGBA_HEX(0x000000, 0.65f);
        self.frame =  frame;
        self.type = type;
        self.name = name;
        self.controller = parentController;
        [self configSubviews];
    }
    return self;
}


-(void)setType:(NSString *)type{
    _type = type;
    id<MSDeviceProtocol> deviceService = [OEMRouter getServiceInstance:@protocol(MSDeviceProtocol)];
    if (deviceService) {
        NSArray *dataArray = [deviceService fetchApplianceTypeFromDCP];
        [dataArray enumerateObjectsUsingBlock:^(MSDeviceProductResult *obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([type hasSuffix:obj.category]) {
                self.imgUrl = obj.imgUrl;
                *stop = YES;
                 return;
            }
        }];
    }
}


- (void)configSubviews{
    self.backView = [HGView new];
    self.backView.backgroundColor = RGBA_HEX(0xffffff, 0.9f);
    self.backView.layer.cornerRadius = 13.f;
    [self addSubview:self.backView];
    
    self.contentLabel = [HGLabel new];
    self.contentLabel.font =  [UIFont fontWithName:@"SF Pro" size:16]; 
    self.contentLabel.textColor = RGB_HEX(0x000000);
    self.contentLabel.text = MSResourceString(@"scan_page_accept_share_tips");    //"If you agree to invitation,you will get the control right of the device.Do you agree?"
    self.contentLabel.textAlignment = NSTextAlignmentCenter;
    self.contentLabel.numberOfLines = 0;
    [self.contentLabel sizeToFit];
    [self.backView addSubview:self.contentLabel];
    
    
    self.iconView = [HGImageView new];
    self.iconView.contentMode = UIViewContentModeScaleAspectFill;
    self.iconView.backgroundColor = [UIColor clearColor];
    [self.backView addSubview:self.iconView];
    
    if(self.imgUrl.length > 0){
        [self.iconView sd_setImageWithURL:[NSURL URLWithString:self.imgUrl] placeholderImage:[UIImage imageNamed:@"pic_category_default"]];
    }else{
        NSString *category = self.type;
        if ([category hasPrefix:@"0x"]) {
            category = [category stringByReplacingOccurrencesOfString:@"0x" withString:@""];
        }
        NSString *imageName = [NSString stringWithFormat:@"pic_%@", category];
        self.iconView.image = [UIImage imageNamed:imageName]?: [UIImage imageNamed:@"pic_category_default"];
    }
    self.nameLabel = [HGLabel new];
    self.nameLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    self.nameLabel.textColor = RGB_HEX(0x000000);
    self.nameLabel.text = self.name;
    self.nameLabel.textAlignment = NSTextAlignmentCenter;
    self.nameLabel.numberOfLines = 0;
    [self.nameLabel sizeToFit];
    [self.backView addSubview:self.nameLabel];
    
    
    
    self.agreeButton = [HGButton new];
    self.agreeButton.layer.cornerRadius = 22;
    self.agreeButton.clipsToBounds = YES;
    [self.agreeButton setTitle:MSResourceString(@"scan_page_title_agree") forState:UIControlStateNormal];
    self.agreeButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    [self.agreeButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
    self.agreeButton.backgroundColor = RGB_HEX(0x267AFF);
    [self.agreeButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.backView addSubview:self.agreeButton];
    
    
    
    self.cancelButton = [HGButton new];
    [self.cancelButton setTitle:MSResourceString(@"scan_page_title_cancel") forState:UIControlStateNormal];
    self.cancelButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    [self.cancelButton setTitleColor:RGB_HEX(0xFF222A) forState:UIControlStateNormal];
    [self.cancelButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.backView addSubview:self.cancelButton];

    [self makeConstraints];
    [self configureOEMTheme];
}

- (void)configureOEMTheme{
  //  [self configureThemeTag:OEMThemesTag_UIView_Background];
    [self.backView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.contentLabel configure90TranslucentTrait];
    [self.nameLabel configure90TranslucentTrait];
    [self.cancelButton configureThemeTag:OEMThemesTag_UIButton_TitleTraitColor];
    [self.contentLabel configure90TranslucentTrait];
}

- (void)makeConstraints{
    [self.backView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(312);
       // make.height.mas_equalTo(408);
        make.center.equalTo(self);
    }];
    
    [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.backView).offset(36);
        make.leading.equalTo(self.backView).offset(36);
        make.trailing.equalTo(self.backView).offset(-36);
    }];
    
    [self.iconView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentLabel.mas_bottom).offset(18);
        make.centerX.mas_equalTo(self.backView);
        make.width.mas_equalTo(129);
        make.height.mas_equalTo(129);
    }];
    
    [self.nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.iconView.mas_bottom).offset(8);
        make.leading.equalTo(self.backView).offset(36);
        make.trailing.equalTo(self.backView).offset(-36);
       // make.height.mas_equalTo(18);
    }];
    
    [self.agreeButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.nameLabel.mas_bottom).offset(24);
        make.centerX.mas_equalTo(self.backView);
        make.width.mas_equalTo(146);
        make.height.mas_equalTo(44);
    }];
    
    [self.cancelButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.equalTo(self.backView);
        make.height.mas_equalTo(30);
        make.top.equalTo(self.agreeButton.mas_bottom).offset(23);
    }];
    
    
    [self.backView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.cancelButton.mas_bottom).offset(36);
    }];
}



- (void)clickButton:(UIButton *)sender{
    if (sender == self.agreeButton) {
        safeCallBlock(self.clickAgreeBlock);
    }else{
        safeCallBlock(self.clickCancelBlock);
    }
    [self dismiss];
}

- (void)show{
    self.alpha = 0;
    self.backView.alpha = 0;
    self.backView.transform = CGAffineTransformMakeScale(1.2, 1.2);
    [self.controller.navigationController.view addSubview:self];
    [UIView animateWithDuration:0.3 animations:^{
        self.backView.transform = CGAffineTransformMakeScale(1, 1);
        self.alpha = 1;
        self.backView.alpha = 1;
    } completion:nil];
}
 
- (void)dismiss{
    [self removeFromSuperview];
}



@end
