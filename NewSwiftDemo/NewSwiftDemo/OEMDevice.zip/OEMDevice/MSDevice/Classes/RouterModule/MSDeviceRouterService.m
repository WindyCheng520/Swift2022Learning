//  
//  MSDeviceRouterService.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/20
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSDeviceRouterService.h"
#import <MSBusiness/NSObject+BGModel.h>
#import "MSAddDeviceCloudRepository.h"
#import <OEMFoundation/HGInternationalization.h>
#import "MSCountryChannelResult.h"
#import "MSAddDeviceDCPRepository.h"
#import "MSSsidPasswordRepository.h"
#import <MSBusiness/MSNotificationConst.h>
#import <MSDevice/MSDevice-Swift.h>
@DOFService(MSDeviceProtocol, MSDeviceRouterService)
@implementation MSDeviceRouterService

//刷新国家信道
- (void)refreshCountryChannelRetrieveSuccess:(void (^)(void))success failure:(void (^)(MSBusinessError *error))failure {
    NSString *country = HGCurrentCountry.code;
    [MSAddDeviceCloudRepository requestCountryChannelRetrieveWithCountryCode:country success:^(NSArray<MSCountryChannelResult *> *result) {
        [MSCountryChannelResult bg_clear:nil];
        if (result.count) {
            [MSCountryChannelResult bg_saveOrUpdateArray:result];
        }
        
        safeCallBlock(success);
    } failure:^(MSBusinessError *error) {
        safeCallBlock(failure, error);
    }];
}

//刷新品类名称、云平台
- (void)refreshApplianceTypeNameSuccess:(void (^)(void))success failure:(void (^)(MSBusinessError *error))failure {
   // return;
    [MSAddDeviceCloudRepository refreshApplianceTypeNameSuccess:^(NSArray<MSDeviceTypeResult *> *result) {
        [MSDeviceTypeResult bg_clear:nil];
        if (result.count) {
            [MSDeviceTypeResult bg_saveOrUpdateArray:result];
        }
        safeCallBlock(success);
    } failure:^(MSBusinessError *error) {
        safeCallBlock(failure, error);
    }];
}

//从本地查询指定品类的名称
- (NSString *)fetchApplianceTypeNameWithCategory:(NSString *)category {
    return [MSAddDeviceCloudRepository fetchApplianceTypeNameWithCategory:category];
}

//通过sn8获取产品信息
- (void)fetchIotConnectInfoWithSN8:(NSString *)sn8 success:(void (^)(MSDeviceConnectResult *result))success failure:(void (^)(MSBusinessError *error))failure {
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setValue:sn8?:@"" forKey:@"code"];
    [MSAddDeviceDCPRepository fetchIotProductWithParas:dic success:^(NSArray<MSDeviceModelResult *> *result) {
        if (result.count) {
            MSDeviceModelResult *model = [result firstObject];
            NSMutableDictionary *param = [NSMutableDictionary dictionary];
            [param setValue:model.iotId forKey:@"iotProductId"];
            [param setValue:model.productId forKey:@"productId"];
            [MSAddDeviceDCPRepository fetchIotConnectInfoWithParas:param success:^(MSDeviceConnectResult *result) {
                safeCallBlock(success, result);
            } failure:^(MSBusinessError *error) {
                safeCallBlock(failure, error);
            }];
        } else {
            safeCallBlock(success, nil);
        }
    } failure:^(MSBusinessError *error) {
        safeCallBlock(failure, error);
    }];
}

//获取本地存储的wifi名称对应的密码
- (NSString *)fetchPasswordWithSsid:(NSString *)ssid {
    return [MSSsidPasswordRepository fetchPasswordWithSsid:ssid];
}

//修改设备名称
- (void)modifyApplianceInfoWithApplicanceId:(NSString *)applianceId applianceName:(NSString *)name success:(void (^)(void))success failure:(void (^)(MSBusinessError *error))failure {
    
    [MSAddDeviceCloudRepository modifyApplianceInfoWithApplicanceId:applianceId applianceName:name success:success failure:failure];
}

//获取品类列表、dcp
- (void)refreshApplianceTypeFromDCPSuccess:(void (^)(void))success failure:(void (^)(MSBusinessError *error))failure {
    [MSAddDeviceDCPRepository fetchTypeListSuccess:^(NSArray<MSDeviceProductResult *> *result) {
        [MSDeviceProductResult bg_clear:nil];
        if (result.count) {
            [MSDeviceProductResult bg_saveOrUpdateArray:result];
        }
        safeCallBlock(success);
        [[NSNotificationCenter defaultCenter] postNotificationName:kMideaDCPDidUpdateApplianceTypeDataNotification object:nil userInfo:nil];
    } failure:^(MSBusinessError *error) {
        safeCallBlock(failure, error);
    }];
}

//从本地读取品类列表、dcp
- (NSArray<MSDeviceProductResult *> *)fetchApplianceTypeFromDCP {
    NSArray<MSDeviceProductResult *> *results = [MSDeviceProductResult bg_findAll:nil];
    return results;
}

//获取地区id（冬夏令时）
- (void)fetchApplianceCityCodeWithSuccess:(void (^)(void))success failure:(void (^)(MSBusinessError * _Nonnull))failure {
    
    [MSAddDeviceCloudRepository fetchApplianceCityCodeWithSuccess:^(MSApplianceCityCodeResult *result) {
        safeCallBlock(success);
    } failure:^(MSBusinessError *error) {
        safeCallBlock(failure, error);
    }];
    
}

-(BOOL)isAvailable:(MSOEMCBPeripheral *)per{
    return [MSAddDeviceTools isAvailableWithPer:per];
}

- (void)needsUpdateToBAuth:(void (^)(BOOL isSuccess, NSDictionary * data, NSError * error))completion{
    [ToBAuthAdapter.adapter updateToBAuth:completion];
}



@end
