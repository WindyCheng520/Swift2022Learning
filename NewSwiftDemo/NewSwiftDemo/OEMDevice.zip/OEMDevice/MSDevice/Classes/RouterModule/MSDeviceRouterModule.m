//
//  MSDeviceRouterModule.m
//  AFNetworking
//
//  Created by yanghy on 2020/5/14.
//

#import "MSDeviceRouterModule.h"
#import <DolphinRouter/OEMRouter.h>
#import <MSBusiness/MSRouterUrl.h>
#import "MSDeviceRouterService.h"
#import "MSAddDeviceCloudRepository.h"
#import <MSBusiness/MSNotificationConst.h>
#import "MSWifiPasswordResult.h"
#import "MSAddDeviceDCPRepository.h"
#import <MSDevice/MSDevice-Swift.h>
#import <OEMBluetooth/OEMMSNetAccessManager.h>
#import <OEMFoundation/OEMCustomize.h>

@DOFModule(MSDeviceRouterModule)
@interface MSDeviceRouterModule()<OEMModuleProtocol>

@end

@implementation MSDeviceRouterModule

- (NSInteger)modulePriority {
    return 2;
}

- (void)modInit:(OEMContext *)context {
    [OEMRouter registerWithURL:MSRouterDeviceIndex toClass:@"MSChooseDeviceTypeViewController"];
    [OEMRouter registerWithURL:MSRouterDeviceGuide toClass:@"MSAddDeviceGuideViewController"];
    [OEMRouter registerWithURL:MSRouterDeviceWiFi toClass:@"MSConnectWiFiViewController"];
    [OEMRouter registerWithURL:MSRouterDeviceAuth toClass:@"MSAuthorizeViewController"];
    
    [OEMRouter registerWithURL:MSRouterDeviceProgress toClass:@"MSAddDeviceProgressViewController"];
    [OEMRouter registerWithURL:MSRouterScanCode toClass:@"OEMScanCodeViewController"];
    
    [OEMRouter registerWithURL:MSRouterBLEDeviceGuide toClass:@"MSBLEGuideViewController"];
    
    //存量设备开关(默认打开）
    BOOL needToBAndMSmartSdk = YES;
    if ([OEMCustomize getEncryptedStringValueWithKey:@"msClientId"] == nil
        || [OEMCustomize getEncryptedStringValueWithKey:@"msClientSecret"] == nil) {
        needToBAndMSmartSdk = NO;
    }
    if (needToBAndMSmartSdk) {
        //初始化 MS配网SDK
        [OEMMSNetAccessManager shareManager];
        //优先初始化ToB对象
        [ToBAuthAdapter adapter];
    }
    
    [self refreshApplianceTypeName];
  //  [self refreshCountryChannelRetrieve];
    [self refreshApplianceTypeFromDCP];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self resolveOldVersionWifiPasswordLocalData];
    });
   
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(currentCountryDidUpdate) name:MSInternationalizationDidUpdateCountryNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(currentLanguageDidUpdate) name:MSInternationalizationDidUpdateLanguageNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidLoginSuccess) name:kMideaLoginSuccessNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getDeviceMqttMsg:) name:kMideaNotifyFetchDeviceMQTTCerNotification object:nil];
}

- (void)currentCountryDidUpdate {
   // [self refreshCountryChannelRetrieve]; //去除国家信道刷新
}

- (void)currentLanguageDidUpdate {
    [self refreshApplianceTypeName];
    [self refreshApplianceTypeFromDCP];
}

- (void)userDidLoginSuccess {
    [self refreshApplianceTypeName];
    [self refreshApplianceTypeFromDCP];
}

- (void)getDeviceMqttMsg:(NSNotification *)notification{
    if (notification.object == nil || ![notification.object isKindOfClass:[NSDictionary class]]) {
        return;
    }
    NSDictionary * obj = notification.object;
    NSString * deviceType = [obj objectForKey:@"deviceType"];
    NSString * thingCode = [obj objectForKey:@"thingCode"];
    [MSAddDeviceDCPRepository getDeviceMQTTCertWithDeviceType:deviceType thingCode:thingCode success:^(id result) {
        [[NSNotificationCenter defaultCenter] postNotificationName:kMideaNotifyDeviceMQTTCerResultNotification object:result userInfo:nil];
    } failure:^(NSError *error) {
        [[NSNotificationCenter defaultCenter] postNotificationName:kMideaNotifyDeviceMQTTCerResultNotification object:error userInfo:nil];
    }];
}

- (void)refreshCountryChannelRetrieve {
    //刷新国家信道
    [[MSDeviceRouterService new] refreshCountryChannelRetrieveSuccess:^{
       
    } failure:^(MSBusinessError * _Nonnull error) {
       
    }];
}

- (void)refreshApplianceTypeName {
    [[MSDeviceRouterService new] refreshApplianceTypeNameSuccess:^ {
        
    } failure:^(MSBusinessError * _Nonnull error) {
        
    }];
}

- (void)refreshApplianceTypeFromDCP {
    [[MSDeviceRouterService new] refreshApplianceTypeFromDCPSuccess:^{
        
    } failure:^(MSBusinessError * _Nonnull error) {
        
    }];
    
}

- (void)resolveOldVersionWifiPasswordLocalData {
    NSArray *localArray = [MSWifiPasswordResult getAllWifiPasswordResultDataFromLocal];
    if (localArray.count > 0) {
        BOOL hasSecurity = NO;
        for (MSWifiPasswordResult *result in localArray) {
            if (result.isSecurity) {
                hasSecurity = YES;
                break;
            }
        }
        if (!hasSecurity) {
            [MSWifiPasswordResult bg_drop:nil];
            [MSWifiPasswordResult saveAllWifiPasswordResult:localArray];
        }
    }
}

@end
