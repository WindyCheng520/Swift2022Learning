//  
//  MSDeviceRouterService.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/20
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <Foundation/Foundation.h>
#import <DolphinRouter/OEMRouter.h>
#import <MSBusiness/MSDeviceProtocol.h>
#import <MSBusiness/MSDeviceConnectResult.h>
#import "MSAddDeviceTypes.h"


NS_ASSUME_NONNULL_BEGIN

@interface MSDeviceRouterService : OEMRouterBaseService <MSDeviceProtocol>

- (void)refreshCountryChannelRetrieveSuccess:(void (^)(void))success failure:(void (^)(MSBusinessError *error))failure;

- (void)refreshApplianceTypeNameSuccess:(void (^)(void))success failure:(void (^)(MSBusinessError *error))failure;

- (NSString *)fetchApplianceTypeNameWithCategory:(NSString *)category;

- (void)fetchIotConnectInfoWithSN8:(NSString *)sn8 success:(void (^)(MSDeviceConnectResult *result))success failure:(void (^)(MSBusinessError *error))failure;

- (NSString *)fetchPasswordWithSsid:(NSString *)ssid;

- (void)modifyApplianceInfoWithApplicanceId:(NSString *)applianceId applianceName:(NSString *)name success:(void (^)(void))success failure:(void (^)(MSBusinessError *error))failure;

- (void)refreshApplianceTypeFromDCPSuccess:(void (^)(void))success failure:(void (^)(MSBusinessError *error))failure;

- (NSArray<MSDeviceProductResult *> *)fetchApplianceTypeFromDCP;

- (void)fetchApplianceCityCodeWithSuccess:(void(^)(void))success failure:(void (^)(MSBusinessError *error))failure;


@end

NS_ASSUME_NONNULL_END
