//
//  OEMScanCodeViewController.h
//  MSDevice
//
//  Created by WindyCheng on 2021/11/3.
//

#import <MSBusiness/MVPViewController.h>
#import "OEMScanCodePresenter.h"

NS_ASSUME_NONNULL_BEGIN

@interface OEMScanCodeViewController : MVPViewController<OEMScanCodePresenter *><OEMScanCodeModelViewProtocol>

/**
 扫描结果，如果扫描失败或者识别不出二维码，info 为空
 */
@property (nonatomic, copy) void (^scanCodeCallBack)(NSString *info, NSError *error);

@end

NS_ASSUME_NONNULL_END
