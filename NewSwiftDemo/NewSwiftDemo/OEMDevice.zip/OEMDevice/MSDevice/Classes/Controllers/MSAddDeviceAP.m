//  
//  MSAddDeviceAP.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/16
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSAddDeviceAP.h"
#import <OEMFoundation/OEMMacros.h>
#import "MSAddDeviceCloudRepository.h"
#import "MSDeviceBundle.h"

#import <OEMFoundation/HGInternationalization.h>
#import <OEMBluetooth/MSOEMDeviceManager.h>
#import <MSBusiness/MSUserInfoManager.h>
#import <MSBusiness/MSAppInfo.h>
#import <NetworkExtension/NEHotspotConfigurationManager.h>
#import <OEMFoundation/OEMDeviceTool.h>

//static const NSInteger MSAPPasswordWrongCode = 114090;
//static const NSInteger MSAPWiFiWrongCode = 114122;

//UI步骤
typedef NS_ENUM(NSInteger, MSAPStepType) {
    MSAPStepTypeNetPrepare = 0,
    MSAPStepTypeDeviceNetworking,
    MSAPStepTypeBindAccount
};

//实际进度步骤
typedef NS_ENUM(NSInteger, MSAddApDeviceStage) {
    MSAddApDeviceStageConnectAP ,//APP连接设备热点 10S
    MSAddApDeviceStageSetWiFiInfo ,//APP与模组建立连接+传输信息至设备 12S
    MSAddApDeviceStageBindUser ,//绑定到家庭2S
};

@interface MSAddDeviceAP ()

/// 进度条定时器
@property (nonatomic, strong) dispatch_source_t timer;

@property (nonatomic, assign) MSAPStepType currentStep;

@property (nonatomic, assign) MSAddApDeviceStage addDeviceStage;

@property (nonatomic, assign) NSInteger progressCounter;

@property (nonatomic, assign) BOOL haveSuspend;


///随机数
@property (nonatomic, copy) NSString *randomCode;
///udp版本
@property (nonatomic, copy) NSString *udpVersion;

/// 是否重试 第一次绑定失败后 增加一次绑定操作
@property (nonatomic, assign) BOOL isRetry;

@end

@implementation MSAddDeviceAP

#pragma mark - MSAddDeviceProtocol

@synthesize msDelegete = _msDelegete;
@synthesize msConnectType = _msConnectType;
@synthesize deviceCategory = _deviceCategory;
@synthesize wifiSsid = _wifiSsid;
@synthesize wifiBssid = _wifiBssid;
@synthesize deviceSsid = _deviceSsid;
@synthesize wifiPassword = _wifiPassword;
@synthesize deviceSn = _deviceSn;
@synthesize deviceSubType = _deviceSubType;
@synthesize deviceId = _deviceId;
@synthesize deviceName = _deviceName;
@synthesize productCode = _productCode;
@synthesize productId = _productId;
@synthesize deviceMac = _deviceMac;
@synthesize peripheral = _peripheral;
@synthesize countryChannel = _countryChannel;

@synthesize thingCode = _thingCode;
@synthesize deviceSn8 = _deviceSn8;
@synthesize deviceType = _deviceType;

- (void)msAddDeviceCancel {
    [self destroyTimer];
    [[MSOEMDeviceManager sharedManager] stopConfigureDevice];
    if ([self.msDelegete respondsToSelector:@selector(msAddDeviceCancel:)]) {
        [self.msDelegete msAddDeviceCancel:self];
    }
}

- (void)msAddDeviceStart {
    self.progressCounter = 0;
    self.currentStep = MSAPStepTypeNetPrepare;
    self.addDeviceStage = MSAddApDeviceStageConnectAP;
    
    CGFloat perSec = 0.15; //0.22
    
    if ([self.msDelegete respondsToSelector:@selector(msAddDeviceStart:)]) {
        [self.msDelegete msAddDeviceStart:self];
    }
    
    self.isRetry = YES;
    [self msConnectDevice];
    
    
    self.haveSuspend = NO;
    @weakify(self)
    self.timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0));
    dispatch_source_set_timer(self.timer, DISPATCH_TIME_NOW, perSec * NSEC_PER_SEC, 0 * NSEC_PER_SEC);
    dispatch_source_set_event_handler(self.timer, ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            @strongify(self)
            if(!self) return;
            self.progressCounter ++;
            if (self.progressCounter == 25 && self.addDeviceStage == MSAddApDeviceStageConnectAP) {
                [self suspendTimer];
            }
            
            if (self.progressCounter == 90 && self.addDeviceStage == MSAddApDeviceStageSetWiFiInfo) {
                //等于90的时候，需要暂停定时功能
                [self suspendTimer];
            }
            
            if (self.progressCounter > 95 && self.addDeviceStage == MSAddApDeviceStageBindUser) {
                //等于90的时候，需要暂停定时功能
                [self suspendTimer];
            }
            
            // 更新UI进度
            [self refreshStep];
            
        });
    });
    
    dispatch_resume(self.timer);
}

- (NSArray<NSString *> *)msAddDeviceStepTitles {
    return @[
        MSResourceString(@"add_device_process_page_step_device_preparing"),
        MSResourceString(@"add_device_process_page_step_device_access_network"),
        MSResourceString(@"add_device_process_page_step_account_binding")
    ];
}

#pragma mark - Other

- (void)refreshStep {
    if ([self.msDelegete respondsToSelector:@selector(msAddDeviceRefresh:progress:step:)]) {
        [self.msDelegete msAddDeviceRefresh:self progress:self.progressCounter step:self.currentStep];
    }
}

- (void)suspendTimer {
    if (self.timer && !self.haveSuspend) {
        self.haveSuspend = YES;
        dispatch_suspend(self.timer);
    }
}

- (void)resumeTimer {
    CGFloat perSec = 0.22;
    
    if (!self.timer) return;
    if (self.haveSuspend) {
        //如果已经暂停了定时功能，这个时候需要重新启动定时器
        dispatch_resume(self.timer);
        self.haveSuspend = NO;
    }
    dispatch_source_set_timer(self.timer, DISPATCH_TIME_NOW, perSec * NSEC_PER_SEC, 0 * NSEC_PER_SEC);
}

- (void)msConnectDevice {
    
    MSUserInfoManager *manger = [MSUserInfoManager shareManager];
    NSString  *accessToken = manger.loginInfoModel.accessToken;
    NSString *url = [MSAppInfo mucBaseUrl];
    NSString *countryCode = [HGInternationalization sharedInstance].currentCountry.code;
    NSString *mqttBroker = [MSAppInfo awsEndPoint];
    @weakify(self)
    DDLogDeviceInfo(@"step 1: start AP connect:deviceSsid=%@, wifiSsid=%@, wifiPassword=%@, wifiBssid=%@",self.deviceSsid, self.wifiSsid, self.wifiPassword, self.wifiBssid);
    [[MSOEMDeviceManager sharedManager] startConfigWithDeviceSSID:self.deviceSsid
                                                      routerBSSID:self.wifiBssid
                                                       routerSSID:self.wifiSsid
                                                   routerPassword:self.wifiPassword
                                                      accessToken:accessToken
                                                              url:url
                                                      countryCode:countryCode
                                                       mqttBroker:mqttBroker
                                                         extraDic:self.countryChannel
                                                    connectUpdate:^(MSOEMDeviceConfigStepType status) {
        if(status == MSOEMDeviceConfigStepTypeWriteWiFiConfigurationOld || status == MSOEMDeviceConfigStepTypeWriteWiFiConfigurationNew ){
            DDLogDeviceInfo(@"step 1.1:  ap connect success");
            if (self.progressCounter > 25) {  //防止配网过程中，SDK返回之前的步骤，导致进度条回退
                return;
            }
            self.addDeviceStage = MSAddApDeviceStageSetWiFiInfo;
            self.currentStep = MSAPStepTypeDeviceNetworking;
            self.progressCounter = 25;
            [self refreshStep];
            [self resumeTimer];
        }
        
        if (status == MSOEMDeviceConfigStepTypeFindDeviceInLAN || status == MSOEMDeviceConfigStepTypeHasCheckedOKCloud ){
            DDLogDeviceInfo(@"step 2.1: net config success ");
            if (self.progressCounter > 75) {  //防止配网过程中，SDK返回之前的步骤，导致进度条回退
                return;
            }
            self.addDeviceStage = MSAddApDeviceStageBindUser;
            self.currentStep = MSAPStepTypeBindAccount;
            self.progressCounter = 75;
            [self refreshStep];
            [self resumeTimer];
        }
    }
                                                       completion:^(NSError * _Nonnull error, NSDictionary * _Nonnull dict) {
        @strongify(self)
        if (error.code == 0) {
            DDLogDeviceInfo(@"step 2.3 AP: active device success: %@", error);
                [self updateStepTwoWithProgressCounter:100 dict:dict];
                if ([self.msDelegete respondsToSelector:@selector(msAddDeviceSuccess:)]) {
                    [self.msDelegete msAddDeviceSuccess:self];
                }
        }else {
            
            if (error.userInfo && [error.userInfo isKindOfClass:[NSDictionary class]]){
               //sdk失败或接口绑定失败
               NSError * jsonErr = nil;
               NSData * data = [NSJSONSerialization dataWithJSONObject:error.userInfo options:0 error:&jsonErr];
               if (data && !jsonErr) {
                   NSString * str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                   if (str) {
                       NSString * fversion = [dict objectForKey:MSOEMBLE_Property_FirmwareVersion];
                       NSString * mac = [dict objectForKey:MSOEMBLE_Property_WIFIMac];
                       NSString * sn8 = [dict objectForKey:MSOEMBLE_Property_SN8];
                       NSString * component = ComposeBLEConfigFailure(fversion,
                                                                      mac,
                                                                      sn8,
                                                                      error.code);
                       NSString *parma = [NSString stringWithFormat:@"wifi==%@,wifiBBSID==%@,deviceSSID==%@,password==%@", self.wifiSsid, self.wifiBssid,self.deviceSsid, self.wifiPassword];
                       component = [component stringByAppendingFormat:@"(code:%ld,msg:%@)//%@//", (long)error.code, str, parma];
                       NSDictionary * failure = @{
                           MSOEMBLE_Property_Body: component
                       };
                       [MSAddDeviceCloudRepository reportAddDeviceFailure:failure];
                   }
               }
           }
            [self connectToPreWiFi];
            DDLogDeviceInfo(@"step 2.3: ap connect fail: %@", error);
            if ([self.msDelegete respondsToSelector:@selector(msAddDeviceFaild:error:)]) {
                [self.msDelegete msAddDeviceFaild:self error:error];
            }
        }
    }];
    
}

//回连路由
-(void)connectToPreWiFi{
    
    NSString *currntwifiSsid = [OEMDeviceTool currentWifiSSID];
    if ([currntwifiSsid isEqualToString:self.deviceSsid]) {
        // 创建将要连接的WIFI配置实例
        NEHotspotConfiguration *hotspotConfig = [[NEHotspotConfiguration alloc] initWithSSID:self.wifiSsid
                                                                                  passphrase:self.wifiPassword   //@"HKsmart2004" //
                                                                                       isWEP:NO];
        
      //  WEAKSELF
        // 开始连接 (调用此方法后系统会自动弹窗确认)
        [[NEHotspotConfigurationManager sharedManager] applyConfiguration:hotspotConfig
                                                        completionHandler:^(NSError * _Nullable error) {
            DDLogDeviceInfo(@"回连路由-------%@", error);
            if (error){
                if (error.code == NEHotspotConfigurationErrorAlreadyAssociated ) {//13:  已连接
                    DDLogDeviceInfo(@"回连路由-------已连接");
                }else if (error.code == NEHotspotConfigurationErrorUserDenied){ //7:  用户点击取消连接
                 //   取消 iOS 11 系统层级弹框  "Dollin Smart"想要加入无线局域网“wifi名”吗？   “取消”    （右边按钮 ”加入“）
                    DDLogDeviceInfo(@"回连路由-------用户取消连接失败");
                }else{//其它：例如试图加入一个不存在的wifi，无报错无弹框
                    DDLogDeviceInfo(@"回连路由-------连接失败");
                }
            }else{
                if([currntwifiSsid isEqualToString:self.wifiSsid]){
                DDLogDeviceInfo(@"用户允许加入无线局域网后回连路由-------成功");  //弹框： 用户点击 “加入”后，连接成功
                }else{
                    // iOS 11 系统层级弹框 无法加入网络“wifi名”      好， (wifi 密码错误等原因,密码错误会改变手机连接wifi的密码)
                    DDLogDeviceInfo(@"wifi已连接上，连接的不是代码指定的wifi");
                }
            }
        }];
   }

}



-(void)updateStepTwoWithProgressCounter:(NSInteger)progressCounter
                                   dict:(NSDictionary *)dict{
    self.addDeviceStage = MSAddApDeviceStageBindUser;
    self.currentStep = MSAPStepTypeBindAccount;
    self.progressCounter = progressCounter;
    self.deviceType = dict[@"deviceType"];
//    self.deviceSn8 = dict[@"deviceSn8"];
//    self.firmwareVersion = dict[@"firmwareVersion"];
    self.thingCode = dict[@"wifiMac"];
    [self refreshStep];
    [self resumeTimer];
}


- (void)msRetryAddDeviceWithNewPassword {
    if (self.progressCounter < 90) {
        [self resumeTimer];
    }
//    NSDictionary *dic = @{kMSSDKConfigRouterPassword:self.wifiPassword};
//    [[MSmartDeviceManager sharedManager] resumeConfigWithDic:dic];
    DDLogDeviceInfo(@"step 2.2: retry ap wifi password");
}


- (void)destroyTimer {
    DDLogDeviceInfo(@"AP destroyTimer");
    if (_timer) {
        if (_haveSuspend) {
            dispatch_resume(_timer);
            _haveSuspend = NO;
        }
        dispatch_source_cancel(_timer);
        _timer = nil;
    }
}

- (void)dealloc {
    [self destroyTimer];
    DDLogDeviceInfo(@"AP dealloc");
}

@end
