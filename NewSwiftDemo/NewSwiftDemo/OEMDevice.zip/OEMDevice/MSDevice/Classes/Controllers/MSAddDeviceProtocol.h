//
//  MSAddDeviceProt.h
//  Pods
//
//  Created by 邓立兵 on 2017/9/13.
//
//

#import <Foundation/Foundation.h>
//#import <MSmartOverseaSDK/MSOEMCBPeripheral.h>
#import  <OEMBluetooth/MSOEMCBPeripheral.h>


typedef NS_ENUM(NSInteger, MSConnectType) {
    MSConnectTypeNone = 0,
    MSConnectTypeAP = 1,
    MSConnectTypeBLE = 2
};


@protocol MSAddDeviceDelegate;

@protocol MSAddDeviceProtocol <NSObject>

@property (nonatomic, weak) id <MSAddDeviceDelegate> msDelegete;
@property (nonatomic, assign) MSConnectType msConnectType;

@property (nonatomic, strong) NSString *deviceCategory;
@property (nonatomic, strong) NSString *deviceSsid;
@property (nonatomic, strong) NSString *deviceSn;
@property (nonatomic, strong) NSString *deviceSubType;
@property (nonatomic, strong) NSString *deviceName;
@property (nonatomic, strong) NSString *deviceId;

@property (nonatomic ,strong) NSString *wifiBssid;
@property (nonatomic, strong) NSString *wifiSsid;
@property (nonatomic, strong) NSString *wifiPassword;
//@property (nonatomic, strong) MSOEMCBPeripheral *peripheral;

@property (nonatomic, strong) NSString *productCode;  //产品代码，通过这个值可以拿到对应唯一的设备型号（用户家电上报）
@property (nonatomic, strong) NSString *productId;    //产品型号

@property (nonatomic, strong) NSString *deviceMac;             //蓝牙mac 地址


@property (nonatomic, copy) NSString *firmwareVersion;        //固件版本
@property(nonatomic,copy) NSString *thingCode;                //wifi模块 mac地址
@property(nonatomic, copy) NSString *deviceSn8;               //设备sn8
@property(nonatomic, copy) NSString *deviceType;              //品类




@property (nonatomic, strong) MSOEMCBPeripheral *peripheral;

@property (nonatomic, strong) NSDictionary *countryChannel;


- (void)msAddDeviceStart;
- (void)msAddDeviceCancel;
- (void)msRetryAddDeviceWithNewPassword;
- (NSArray <NSString *> *)msAddDeviceStepTitles;
- (void)destroyTimer;

@end



@protocol MSAddDeviceDelegate <NSObject>

@optional

/**
 配网过程的步骤回调，负责告诉业务层当前的配网进度，用于刷新配网页面，业务层可以不考虑

 @param addDeviceModule 配网模块
 @param progress 当前配网的进度值 0-100%
 @param stepType 当前配网的第几步
 */
- (void)msAddDeviceRefresh:(id <MSAddDeviceProtocol>)addDeviceModule progress:(NSInteger)progress step:(NSInteger)step;


/**
 配网成功回调，⚠️ 只表明配网成功，不包含激活、绑定、鉴权等业务操作，这些步骤需要业务断自行处理

 @param addDeviceModule 配网模块
 */
- (void)msAddDeviceSuccess:(id <MSAddDeviceProtocol>)addDeviceModule;


/**
 配网失败回调，具体看error信息

 @param addDeviceModule 配网模块
 @param error 错误信息
 */
- (void)msAddDeviceFaild:(id <MSAddDeviceProtocol>)addDeviceModule error:(NSError *)error;

/**
 配网取消
 
 @param addDeviceModule 配网模块
 */
- (void)msAddDeviceCancel:(id <MSAddDeviceProtocol>)addDeviceModule;

/**
 配网开始
 
 @param addDeviceModule 配网模块
 */
- (void)msAddDeviceStart:(id <MSAddDeviceProtocol>)addDeviceModule;

@end
