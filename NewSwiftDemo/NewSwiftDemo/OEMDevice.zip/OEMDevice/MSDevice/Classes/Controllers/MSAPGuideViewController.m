//  
//  MSAddDeviceGuideViewController.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/13
//  Copyright © 2020 Midea. All rights reserved.
//  AP配网操作指引页面
   

#import "MSAPGuideViewController.h"
#import "MSSetAndConnectDeviceBottomView.h"
#import "MSDeviceBundle.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "MSConnnectAPViewController.h"
#import <OEMFoundation/OEMMacros.h>
#import <OEMFoundation/HGUIKit.h>
#import "MSImagePageView.h"
#import "MSAddDeviceProgressViewController.h"

@interface MSAPGuideViewController ()<UITextViewDelegate>

@property (nonatomic, copy) NSString *connectTypeDesc;

@property (nonatomic, strong) MSImagePageView *imagePageView;
@property (nonatomic, strong) HGTextView *textView;
@property (nonatomic, strong) MSSetAndConnectDeviceBottomView *bottomView;

@end

@implementation MSAPGuideViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        self.textView = [HGTextView new];
        self.bottomView = [MSSetAndConnectDeviceBottomView new];
        
    }
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
        
//    self.title = MSResourceString(@"connect_set_device");
    
    NSMutableArray *imageURLs = [NSMutableArray new];
    if (self.auxi) {
        [imageURLs addObject:self.connectInfo.auxiConnectTypeUrl ?: @""];
    } else {
        [imageURLs addObject:self.connectInfo.mainConnectTypeUrl ?: @""];
        if (self.connectInfo.mainConnectTypeUrlB.length > 0) {
            [imageURLs addObject:self.connectInfo.mainConnectTypeUrlB];
        }
        if (self.connectInfo.mainConnectTypeUrlC.length > 0) {
            [imageURLs addObject:self.connectInfo.mainConnectTypeUrlC];
        }
    }
    
    self.connectTypeDesc = self.auxi?self.connectInfo.auxiConnectTypeDesc:self.connectInfo.mainConnectTypeDesc;
    
    self.imagePageView = [[MSImagePageView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 210) urlStringList:imageURLs.copy];
    [self.view addSubview:self.imagePageView];
    [self.view addSubview:self.textView];
    
    [self.view addSubview:self.bottomView];
    
    @weakify(self)
    self.bottomView.clickNextBlock = ^{
        @strongify(self)
        if (@available(iOS 13.0, *)) {
            MSAddDeviceProgressViewController *vc = [MSAddDeviceProgressViewController new];
            vc.connectInfo = self.connectInfo;
            vc.isAPFirstPage = YES;
            [self.navigationController pushViewController:vc animated:YES];
        } else {
            MSConnnectAPViewController *vc = [MSConnnectAPViewController new];
            vc.connectInfo = self.connectInfo;
            [self.navigationController pushViewController:vc animated:YES];
        }
                
    };
    
    self.textView.delegate = self;
    [self.textView setEditable:YES];
    NSMutableParagraphStyle* paragraphStyle = [[NSMutableParagraphStyle alloc]init];
    paragraphStyle.lineSpacing = 5;
    //    paragraphStyle.paragraphSpacing = 16;
    NSMutableAttributedString *mutableString = [[NSMutableAttributedString alloc]initWithString:self.connectTypeDesc attributes:@{NSParagraphStyleAttributeName : paragraphStyle, NSFontAttributeName : [UIFont systemFontOfSize:16], NSForegroundColorAttributeName : RGB_HEX(0x000000)}];
    self.textView.attributedText = mutableString;
    [self makeContstraints];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    NSString *category = self.connectInfo.category ?: @"";
    if (self.connectInfo.category.length > 0 && ![self.connectInfo.category hasPrefix:@"0x"]) {
        category = [NSString stringWithFormat:@"0x%@", self.connectInfo.category];
    }

}

- (void)makeContstraints {
    [self.imagePageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.view);
        make.trailing.equalTo(self.view);
        make.top.mas_equalTo(STATUSBAR_HEIGHT+44);
        make.height.mas_equalTo(SCREEN_SCALE_WIDTH(210));
    }];
    
    [self.textView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.view.mas_leading).offset(16);
        make.trailing.equalTo(self.view.mas_trailing).offset(-16);
        make.bottom.equalTo(self.bottomView.mas_top);
        make.top.equalTo(self.imagePageView.mas_bottom).offset(24);
    }];
    
    [self.bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.bottom.equalTo(self.view);
        make.height.mas_equalTo(126);
    }];
}

- (void)leftBarButtonClick:(UIButton *)button {
    [self.navigationController popViewControllerAnimated:YES];

}

#pragma mark - UITextViewDelegate
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView {
    return NO;
}


@end
