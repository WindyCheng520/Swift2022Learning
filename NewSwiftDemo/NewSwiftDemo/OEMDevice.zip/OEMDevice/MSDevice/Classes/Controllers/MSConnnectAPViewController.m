//  
//  MSConnnectAPViewController.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/14
//  Copyright © 2020 Midea. All rights reserved.
//  AP配网，操作指引，连接指定WiFi页面
   

#import "MSConnnectAPViewController.h"
#import "MSDeviceBundle.h"
#import "MSSetAndConnectDeviceShowWifiCell.h"
#import "MSSetAndConnectDeviceTipsCell.h"
#import <OEMFoundation/OEMDeviceTool.h>
#import <OEMFoundation/HGUIKit.h>
#import "MSAddDeviceProgressViewController.h"
#import <MSBusiness/MSSystemPermissionManager.h>
#import <MSBusiness/OEMGlobalUIManager.h>
#import <OEMTheme/UILabel+OEMThemes.h>

#import <MSBusiness/MideaTool.h>
#import <MSBusiness/MSRouterUrl.h>
#import <MSBusiness/MSDeviceProtocol.h>
#import <OEMFoundation/OEMDeviceTool.h>
#import <MSBusiness/MSRouterUrl.h>
#import <MSBusiness/MSLocationManager.h>
#import <OEMBluetooth/MSOEMDeviceManager.h>
#import <MSDevice/MSDevice-Swift.h>
#import <MSBusiness/MSBusiness-Swift.h>

#import "OEMAPConnectFailViewController.h"

#import "MSBLEGuideViewController.h"



static NSString *const MSSetAndConnectDeviceTipsCellIdentifier = @"MSSetAndConnectDeviceTipsCellIdentifier";
static NSString *const MSSetAndConnectDeviceShowWifiCellIdentifier = @"MSSetAndConnectDeviceShowWifiCellIdentifier";



static NSString *const kOemAp = @"iotap_xx_xxxx";

static NSString *const kNetAp = @"net_xx_xxxx";


@interface MSConnnectAPViewController ()<UITableViewDelegate, UITableViewDataSource, MSSetAndConnectDeviceShowWifiCellDelegate>

@property (nonatomic, strong) HGImageView *iconImageView; //wifi 连接指示图

@property (nonatomic, strong) HGTableView *tableView;

@property (nonatomic, strong) HGLabel *titleLabel;

@property (nonatomic, strong) HGLabel *faiTipsLabel;




@property(strong, nonatomic)HGView *bottomView;
@property(strong, nonatomic)HGView *containerView;
@property(strong, nonatomic)HGButton *checkButton;
@property(strong, nonatomic)HGLabel *tipsLabel;
@property(strong, nonatomic)HGButton *confirmButton;



@property(strong, nonatomic)HGButton *faiButton;  //找不到wifi


@end

@implementation MSConnnectAPViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        self.iconImageView = [HGImageView new];
        self.tableView = [HGTableView new];
        self.titleLabel = [HGLabel new];
        self.faiTipsLabel = [HGLabel new];
        
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidBecomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
   // [self applicationDidBecomeActive:nil];
    NSString * imageStr = @"";
    if([self.connectInfo.deviceSsid hasPrefix:@"iotap"]){
        imageStr = @"iotap_ssid";
    }else if ([self.connectInfo.deviceSsid hasPrefix:@"net"]){
        imageStr = @"net_ssid";
        
    }else{
        imageStr = @"iotap_net";
    }
    if (isRTL()) {
        imageStr = [NSString stringWithFormat:@"%@_rtl",imageStr];
    }
    self.iconImageView.image = MSResourceImage(imageStr);

}


- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIApplicationDidBecomeActiveNotification object:nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.title = MSResourceString(@"ap_connect_page_title");

    [self.view addSubview:self.iconImageView];
  

    self.iconImageView.layer.cornerRadius = 16;
    self.iconImageView.layer.masksToBounds = YES;
    
    
    self.faiTipsLabel.font =  kRegularFont(14);   //[UIFont systemFontOfSize:(14.0 *((SCREEN_WIDTH - 32.0)/343.0))];
    self.faiTipsLabel.textColor = RGB_HEX(0x000000);
    self.faiTipsLabel.numberOfLines = 0;
    [self.faiTipsLabel sizeToFit];
    self.faiTipsLabel.textAlignment = NSTextAlignmentCenter;
    NSString *tips =  @"";   // @"没有找到你的设备网络，请尝试重新连接";
    self.faiTipsLabel.text = tips;
    self.faiTipsLabel.hidden = YES;
    [self.view addSubview:self.faiTipsLabel];
    
    self.titleLabel.font =  kRegularFont(15);   //[UIFont systemFontOfSize:(14.0 *((SCREEN_WIDTH - 32.0)/343.0))];
    self.titleLabel.textColor = RGB_HEX(0x000000);
    self.titleLabel.numberOfLines = 0;
    [self.titleLabel sizeToFit];
    self.titleLabel.textAlignment = NSTextAlignmentLeft;
    NSString *ssidName =  MSResourceString(@"ap_connect_page_tips"); //@"设备已发出WiFi信号，请到手机系统设置页连上此WIFI，连接成功后请返回此页面。";
    self.titleLabel.text = ssidName;
    [self.view addSubview:self.titleLabel];
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.scrollEnabled = YES;
    [self.tableView registerClass:[MSSetAndConnectDeviceTipsCell class] forCellReuseIdentifier:MSSetAndConnectDeviceTipsCellIdentifier];
    
    [self.tableView registerClass:[MSSetAndConnectDeviceShowWifiCell class] forCellReuseIdentifier:MSSetAndConnectDeviceShowWifiCellIdentifier];
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 64;
    [self.view addSubview:self.tableView];
    
    

    self.bottomView = [[HGView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 120)];
    self.bottomView.backgroundColor = [UIColor whiteColor];
    //self.bottomView.layer.cornerRadius = 12.0;
    [self.view addSubview:self.bottomView];
    
    self.containerView = [HGView new];
    self.containerView.backgroundColor = [UIColor clearColor];
    [self.bottomView addSubview:self.containerView];
    
    self.checkButton = [HGButton new];
    self.checkButton.layer.cornerRadius = 9.0;
    self.checkButton.clipsToBounds = YES;
    [self.checkButton setImage:MSResourceImage(@"ic_checkbox") forState:UIControlStateNormal];
    [self.checkButton setImage:MSResourceImage(@"ic_checkbox_s") forState:UIControlStateSelected];
    [self.checkButton addTarget:self action:@selector(checkClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.containerView addSubview:self.checkButton];
    
    
    self.tipsLabel = [HGLabel new];
    self.tipsLabel.font = kRegularFont(14);    // [UIFont systemFontOfSize:13 weight:UIFontWeightRegular];
    self.tipsLabel.textAlignment = NSTextAlignmentLeft;
    self.tipsLabel.backgroundColor = [UIColor clearColor];
    self.tipsLabel.text =  MSResourceString(@"ble_guide_page_complete");
    self.tipsLabel.textColor = RGBA_HEX(0x000000, 0.9);
    self.tipsLabel.numberOfLines = 1;
    [self.tipsLabel sizeToFit];
    [self.containerView addSubview:self.tipsLabel];
//    self.tipsLabel.hidden = YES;
//    self.checkButton.hidden = YES;
    
    self.confirmButton = [HGButton new];
    self.confirmButton.backgroundColor = RGB_HEX(0x267AFF);
    [self.confirmButton setTitle:MSResourceString(@"ble_guide_page_next") forState:UIControlStateNormal];
    self.confirmButton.titleLabel.font = kRegularFont(18);
    self.confirmButton.enabled = NO;
    self.confirmButton.layer.cornerRadius = 22.0;
    self.confirmButton.clipsToBounds = YES;
    [self.confirmButton addTarget:self action:@selector(confirmClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.bottomView addSubview:self.confirmButton];
    
    
    
    self.faiButton = [HGButton new];
   
    self.faiButton.titleLabel.textAlignment = NSTextAlignmentCenter;
    NSString *buttonTitle = MSResourceString(@"ap_connect_page_tips_no_ap");  //@"找不到WiFi";
    [self.faiButton setTitle:buttonTitle forState:UIControlStateNormal];
    self.faiButton.titleLabel.font = kRegularFont(16);
    [self.faiButton setTitleColor:kBusiness.brandColor forState:UIControlStateNormal];
    [self.faiButton addTarget:self action:@selector(failClick) forControlEvents:UIControlEventTouchUpInside];
    self.faiButton.hidden = YES;
    [self.view addSubview:self.faiButton];
    

    
    [self makeContstraints];
    [self configureOEMTheme];
    
}



- (void)configureOEMTheme{
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    [self.view configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.tableView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.bottomView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.tipsLabel configure40TranslucentTrait];
    [self.confirmButton configureThemeTag:OEMThemesTag_UIView_Main_Color];
    [self.confirmButton configureThemeTag:OEMThemesTag_UIButton_Background];
    [self.confirmButton configureThemeTag:OEMThemesTag_UIButton_AttributedTraitColor];
    
    
    [self.faiTipsLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.thirdColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.thirdColor
    }];
    
    
    [self.titleLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.mainTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.mainTextColor
    }];
    
    
    [self.tipsLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.thirdColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.thirdColor
    }];
    
    
    
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        [weakSelf setNavButton];
    } callImmidiately:YES];
}

- (void)setNavButton{
    if (OEMThemeIsDarkMode) {
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_dm")];
    }else{
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_lg")];
    }
}




- (void)makeContstraints {
    
    [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.view).offset(16);
        make.trailing.equalTo(self.view).offset(-16);
        make.top.mas_equalTo(20);
        make.height.mas_equalTo(192 * ((SCREEN_WIDTH - 32.0) / 343.0));
    }];
    
    
    [self.faiTipsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.iconImageView.mas_bottom).offset(15);
        make.leading.equalTo(self.view).offset(16);
        make.trailing.equalTo(self.view).offset(-16);
    }];
    
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.faiTipsLabel.mas_bottom).offset(4);
        make.leading.equalTo(self.view).offset(16);
        make.trailing.equalTo(self.view).offset(-16);
    }];
    
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.equalTo(self.view);
        make.bottom.equalTo(self.view).offset(-160);
        make.top.equalTo(self.titleLabel.mas_bottom).offset(20);
    }];
    
    
    [self.faiButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.equalTo(self.view);
        make.height.mas_equalTo(25);
        make.bottom.equalTo(self.view).offset(-49);
    }];
    

    [self.bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.bottom.equalTo(self.view);
        make.height.mas_equalTo(160);
    }];
    
    
    [self.confirmButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.bottomView.mas_bottom).offset(-44);
        make.leading.mas_equalTo(self.bottomView.mas_leading).offset(16);
        make.trailing.mas_equalTo(self.bottomView.mas_trailing).offset(-16);
        make.height.mas_equalTo(44);
    }];
    
    CGFloat tipsLabelWidth  = [self.tipsLabel.text sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14 weight:UIFontWeightRegular]}].width;
    [self.containerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.confirmButton.mas_top).offset(-17);
        make.centerX.equalTo(self.bottomView);
        make.height.mas_equalTo(18);
        make.width.mas_equalTo(tipsLabelWidth + 28);
    }];
    
    
    [self.checkButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.containerView.mas_top).offset(0);
        make.leading.mas_equalTo(self.containerView.mas_leading).offset(0);
        make.height.mas_equalTo(18);
        make.width.mas_equalTo(18);
    }];
    
    [self.tipsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(self.checkButton.mas_trailing).offset(7.5);
        make.height.mas_equalTo(17);
        make.centerY.equalTo(self.checkButton);
    }];
}




-(void)checkClick:(UIButton *)sender{
    sender.selected = !sender.selected;
    if (sender.selected) {
        self.confirmButton.backgroundColor = RGBA_HEX(0xEC1C24 ,1);
        self.confirmButton.enabled = YES;
     } else {
        self.confirmButton.backgroundColor = RGBA_HEX(0xEC1C24 ,0.3);
        self.confirmButton.enabled = NO;
    }
}

-(void)confirmClick:(UIButton *)sender{
    if (!self.checkButton.selected) {
        return;
    }
    
    if(![[MSLocationManager shareManager] checkLocationForCurrentWiFi]) return;
    
    
    if ([MSOEMDeviceManager sharedManager].isMSSmartSDKInited){
        [[MSSystemPermissionManager shareManager] jumpToSystemSettingPage];
    }else{
        
        [[ToBAuthAdapter adapter] updateToBAuth:^(BOOL success, NSDictionary<NSString *,id> * _Nullable dict, NSError * _Nullable error) {
            if (success) {
                //跳转系统连接wifi页面
                [[MSSystemPermissionManager shareManager] jumpToSystemSettingPage];
            }else{
                //if ([BusinessNetWorkTools isNetworkUnreachable]) {
                    [self toastText:[MSBusinessError networkDisconnectTips]];
             //   }
            }
        }];
    }

}


- (void)leftBarButtonClick:(UIButton *)button {
    [self.navigationController popViewControllerAnimated:YES];
    
}

#pragma mark - UITableViewDelegate, UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    MSSetAndConnectDeviceShowWifiCell *cell = [tableView dequeueReusableCellWithIdentifier:MSSetAndConnectDeviceShowWifiCellIdentifier forIndexPath:indexPath];
    NSString *ssidName = [self fetchDeviceSSID];
    cell.wifiLabel.text = ssidName;
    cell.delegate = self;
    return cell;

}


-(NSString *)fetchDeviceSSID{
    NSString *deviceType = self.connectInfo.category;
    deviceType = [[deviceType stringByReplacingOccurrencesOfString:@"0x" withString:@""] lowercaseString];
    NSString *or =  MSResourceString(@"ap_connect_page_or");
    NSString *tips2 = [NSString stringWithFormat:@"net_%@_xxxx", deviceType];
    NSString *tips1 = [NSString stringWithFormat:@"iotap_%@_xxxx", deviceType];  //暂时无oem的设备
    if(self.connectInfo.deviceSsid.length > 0){
        return self.connectInfo.deviceSsid.lowercaseString;
    }else{
        return [NSString stringWithFormat:@"%@ %@ %@", tips1,or, tips2];
    }
}


#pragma mark - notice

- (void)applicationDidBecomeActive:(NSNotification *)notice {
    NSString *wifiSsid = [OEMDeviceTool currentWifiSSID];
    if ([self isRightDeviceWifi]) {
        MSAddDeviceProgressViewController *dest = [MSAddDeviceProgressViewController new];
        
        //test--------------------------
//        self.connectInfo = [[MSDeviceConnectResult alloc] init];
//        self.connectInfo.wifiSsid = @"OEM_solutions_libo";
//        self.connectInfo.wifiPassword = @"test123456";
//        self.connectInfo.wifiBssid = @"00:00:00:00:00:00";
//        self.connectInfo.mode = @"0";
//        self.connectInfo.category = @"AC";
//        self.connectInfo.deviceName = @"空调";
        //test---------------------------
        dest.connectInfo = self.connectInfo;
        dest.connectInfo.deviceSsid = wifiSsid;
//        dest.connectInfo.deviceConnectType = MSDeviceConnectTypeAP;
//        dest.connectInfo.mode = @"0";
        dest.connectInfo.wifiBssid = self.connectInfo.wifiBssid;
       
       // deviceSsid = "net_ac_6580";
      //  [配网SDK  配网设备热点deviceSsid= net_ac_6580, wifiSsid = OEM_solutions_libo,  wifiPassword = test123456, wifiBssid = 00:00:00:00:00:00 //成功
        [self.navigationController pushViewController:dest animated:YES];
    }else{//没连接到正确的设备热点
        
        NSString *tips = MSResourceString(@"ap_connect_page_search_fail_tips");  //   @"没有找到你的设备网络，请尝试重新连接";
        self.faiTipsLabel.text = tips;
        self.faiTipsLabel.hidden = NO;
        [self.titleLabel mas_updateConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.faiTipsLabel.mas_bottom).offset(20);
        }];
        
        self.faiButton.hidden = NO;
        self.containerView.hidden = YES;
        [self.confirmButton setTitle:MSResourceString(@"ap_connect_page_re_search") forState:UIControlStateNormal];
        [self.bottomView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.view).offset(-50);
            make.height.mas_equalTo(110);
        }];
    }
}


-(void)failClick{

    OEMAPConnectFailViewController *dest = [[OEMAPConnectFailViewController alloc] init];
    dest.modalPresentationStyle =  UIModalPresentationOverFullScreen;
    WEAKSELF
//    dest.cancelBlock = ^{
//      
//    };

    dest.setBlock = ^{
        [weakSelf popToGuideViewController];
    };
    [self presentViewController:dest animated:NO completion:nil];
}


-(void)popToGuideViewController{
    __block MSBLEGuideViewController *guide = [[MSBLEGuideViewController alloc] init];
   // self.connectInfo.deviceConnectType = MSDeviceConnectTypeRetry;
    NSArray<UIViewController *> *vcas = [self.navigationController viewControllers];
    [vcas enumerateObjectsUsingBlock:^(UIViewController *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj isKindOfClass:MSBLEGuideViewController.class]) {
            guide = (MSBLEGuideViewController *)obj;
            *stop = YES;
        }
    }];
    
    
    if (guide) {
       // guide.connectInfo = self.connectInfo;
        [self.navigationController popToViewController:guide animated:YES];
    }
}

    


-(BOOL)isRightDeviceWifi{
    NSString *wifiSsid = [OEMDeviceTool currentWifiSSID];
    BOOL isRight = NO;
    NSString *deviceType = self.connectInfo.category;
    deviceType = [[deviceType stringByReplacingOccurrencesOfString:@"0x" withString:@""] lowercaseString];
    NSString *tips1 = [NSString stringWithFormat:@"net_%@", deviceType];
    NSString *tips2 = [NSString stringWithFormat:@"iotap_%@", deviceType];  //暂时无oem的设备
    if(self.connectInfo.deviceSsid.length > 0 && [wifiSsid isEqualToString:self.connectInfo.deviceSsid.lowercaseString]){
        return  YES;
    }
    
    if ([wifiSsid hasPrefix:tips1] || [wifiSsid hasPrefix:tips2]) {
        isRight = YES;
    }
    return isRight;
}

#pragma mark - MSSetAndConnectDeviceShowWifiCellDelegate

- (void)passwordDidCopy {
    if ([self respondsToSelector:@selector(toastText:)]) {
        [self toastText:MSResourceString(@"ap_connect_page_tips_copy_success")];// "复制成功";
    }
}


@end
