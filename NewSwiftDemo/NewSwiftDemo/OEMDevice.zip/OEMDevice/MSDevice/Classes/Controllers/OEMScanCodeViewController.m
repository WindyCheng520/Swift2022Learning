//
//  OEMScanCodeViewController.m
//  MSDevice
//
//  Created by WindyCheng on 2021/11/3.
//

#import "OEMScanCodeViewController.h"
#import <BHCodeScan/BHCodeScanCore.h>
#import "MSDeviceBundle.h"
#import <OEMTheme/OEMHGAlertController.h>


#import <OEMFoundation/UIButton+OEMExtension.h>
#import <MSBusiness/MSUIConfiguration.h>
#import <MSBusiness/MSDeviceConnectResult.h>
#import <MSBusiness/MSRouterUrl.h>

#import <MSBusiness/MSDeviceProtocol.h>
#import <MSBusiness/MideaTool.h>
#import <OEMFoundation/OEMDeviceTool.h>
#import <MSBusiness/MSMessageCenterProtocol.h>
#import <MSBusiness/MSBusinessError.h>
#import <MSBusiness/MSSystemPermissionManager.h>


#import "MSBLEGuideViewController.h"
#import "MSShareDeviceAlertView.h"
#import <MSBusiness/OEMCommomAlertViewController.h>

#import "MSConnectWiFiViewController.h"

#import <MSBusiness/OEMGlobalUIManager.h>
#import <TZImagePickerController/TZImagePickerController.h>
#import <OEMFoundation/HGInternationalization.h>
#import <OEMFoundation/OEMCustomize.h>
#import <MSBusiness/MSAppInfo.h>





#define SCANSPACEOFFSET 0.15f
#define SCREENBOUNDS self.view.bounds
#define SCREENWIDTH CGRectGetWidth(self.view.bounds)
#define SCREENHEIGHT CGRectGetHeight(self.view.bounds)



@interface OEMScanCodeViewController ()<UINavigationControllerDelegate,UIImagePickerControllerDelegate, AVCaptureVideoDataOutputSampleBufferDelegate,TZImagePickerControllerDelegate>

@property (nonatomic, strong) HGView *navBackgrouView;
@property (nonatomic, strong) HGLabel *titleLabel;      //标题
@property (nonatomic, strong) UIButton *leftButton;


@property (nonatomic, strong) BHCodeScanCore *scanCore;

@property (nonatomic, assign) CGRect scanRect;
@property (nonatomic,strong) CAShapeLayer * maskLayer;
@property (nonatomic,strong) CAShapeLayer * shadowLayer;
@property (nonatomic,strong) CAShapeLayer * scanRectLayer;
@property (nonatomic,strong) CAShapeLayer * scanLineLayer;


@property (nonatomic,strong) HGButton *photoButton;

@end

@implementation OEMScanCodeViewController

-(void)dealloc{
    NSLog(@"OEMScanCodeViewController dealloc");
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = MSResourceString(@"scan_page_title");
   
  
    self.canRightSlideBack = NO;
    self.presenter = [[OEMScanCodePresenter alloc] initWithView:self];
    _scanCore = [[BHCodeScanCore alloc] init];
    _scanCore.isTMFOn = YES;
    //支持的扫码类型，默认二维码
    _scanCore.validScanCode = BHValidScanCode_QRCode;
    _scanCore.bhAutoScale = YES;
    _scanCore.containerView =  self.view;
   // _scanCore.sampleBufferDelegate = self;
    [_scanCore setInterestWithRect:self.scanRect];
    
    __weak typeof(self) wself = self;
    NSError *error = nil;
    _scanCore.result = ^ (NSString *string) {
        DDLogDeviceInfo(@"扫描结果----------%@", string);
        if (wself.scanCodeCallBack) {
            wself.scanCodeCallBack(string, error);
        }
    };
    
    [self setupUI];
    [self loadData];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(willEnterForeground) name:UIApplicationWillEnterForegroundNotification object:nil];
    [self handleQRcode];
    [self configureOEMTheme];
}


- (void)configureOEMTheme{
 //  [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    [self.view configureThemeTag:OEMThemesTag_UIView_Background];

    WEAKSELF
    [self registerTraitDidChangeCallback:^{
       //[weakSelf setNavButton];
    } callImmidiately:YES];
    
    
    
    UIStatusBarStyle light = UIStatusBarStyleDefault;
    if (@available(iOS 13.0, *)) {
      light = UIStatusBarStyleDarkContent;
    }
    
  

    [self specialPropertiesForDarkMode:@{
    @(OEMThemesTag_UIViewController_BasedStatusBarAppearance): @(light)
    } lightModeProperties:@{
        @(OEMThemesTag_UIViewController_BasedStatusBarAppearance):@(UIStatusBarStyleLightContent)
    }];

}

- (void)setNavButton{
    if (OEMThemeIsDarkMode) {
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_dm")];
    }else{
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_lg")];
    }
}



- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = YES;
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if (authStatus == AVAuthorizationStatusRestricted || authStatus == AVAuthorizationStatusDenied){
       // WEAKSELF;
        HGAlertAction *cancelAction = [HGAlertAction actionWithTitle:MSResourceString(@"scan_page_camera_alert_refuse")
                                                               style:HGAlertActionStyleCancel
                                                              action:^{
          //  [weakSelf.navigationController popViewControllerAnimated:YES];
          
        }];
        
        NSString * title = [NSString stringWithFormat:MSResourceString(@"scan_page_camera_alert_title"), [MSAppInfo appName]];
        NSString *message = MSResourceString(@"scan_page_camera_alert_content");
        HGAlertAction *confirmAction = [HGAlertAction actionWithTitle:MSResourceString(@"scan_page_camera_alert_agree")
                                                               action:^{
            [[MSSystemPermissionManager shareManager] jumpToSystemAppSettingPage];

        }];
        HGAlertController *alertController = [OEMHGAlertController alertControllerWithTitle:title
                                                                                    message:message
                                                                                    actions:@[cancelAction, confirmAction]];
        [alertController show];
    } else {
        [self start];
    }
}


- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.navigationController.navigationBar.hidden = NO;
    [self stop];
}



-(void)leftButtonClick:(UIButton *)sender{
    [self.navigationController popViewControllerAnimated:YES];
}



- (void)loadData {
    if (![self.scanCore validateCamera]) {
        if (self.scanCodeCallBack){
            NSString *result = nil;
            NSError *error = [NSError errorWithDomain:@"没有权限" code:-1 userInfo:nil];
            self.scanCodeCallBack(result, error);
        }
    }
}



- (void)start{
    if ([_scanCore validateCamera]){
        if(_scanLineLayer && _scanLineLayer.speed == 0){
            CFTimeInterval pausedTime = [self.scanLineLayer timeOffset];
            _scanLineLayer.speed = 1.0;
            _scanLineLayer.timeOffset = 0.0;
            _scanLineLayer.beginTime = 0.0;
            CFTimeInterval timeSincePause = [_scanLineLayer convertTime:CACurrentMediaTime() fromLayer:nil] - pausedTime;
            _scanLineLayer.beginTime = timeSincePause;
        }
        [_scanCore startSession];
    }
}

- (void)stop{
    //暂停扫描动画
    if(_scanLineLayer && _scanLineLayer.speed != 0){
        CFTimeInterval pausedTime = [_scanLineLayer convertTime:CACurrentMediaTime() fromLayer:nil];
        _scanLineLayer.speed = 0.0;
        _scanLineLayer.timeOffset = pausedTime;
    }
    [_scanCore stopSession];
}



#pragma mark - action methods
- (void)photoAction:(UIButton *)sender {
    
    TZImagePickerController *imagePickerVc = [[TZImagePickerController alloc] initWithMaxImagesCount:1 columnNumber:4 delegate:self pushPhotoPickerVc:YES];
    imagePickerVc.isSelectOriginalPhoto = YES;
    imagePickerVc.allowTakePicture = YES;
    imagePickerVc.allowTakeVideo = YES;
    imagePickerVc.preferredLanguage = HGCurrentLanguage.code;
    imagePickerVc.iconThemeColor = [UIColor colorWithRed:31 / 255.0 green:185 / 255.0 blue:34 / 255.0 alpha:1.0];
    imagePickerVc.showPhotoCannotSelectLayer = YES;
    imagePickerVc.cannotSelectLayerColor = [[UIColor whiteColor] colorWithAlphaComponent:0.8];
    [imagePickerVc setPhotoPickerPageUIConfigBlock:^(UICollectionView *collectionView, UIView *bottomToolBar, UIButton *previewButton, UIButton *originalPhotoButton, UILabel *originalPhotoLabel, UIButton *doneButton, UIImageView *numberImageView, UILabel *numberLabel, UIView *divideLine) {
        [doneButton setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    }];
    imagePickerVc.allowPickingVideo = NO;
    imagePickerVc.allowPickingImage = YES;
    imagePickerVc.allowPickingOriginalPhoto = YES;
    imagePickerVc.allowPickingGif = NO;
    imagePickerVc.allowPickingMultipleVideo = NO;
    imagePickerVc.sortAscendingByModificationDate = YES;

    imagePickerVc.showSelectBtn = NO;
    imagePickerVc.allowCrop = NO;
    imagePickerVc.needCircleCrop = NO;
    if (@available(iOS 13.0, *)) {
        imagePickerVc.statusBarStyle = OEMThemeIsDarkMode ? UIStatusBarStyleDarkContent : UIStatusBarStyleLightContent;
    }
    imagePickerVc.showSelectedIndex = YES;
    __weak typeof(self) weakSelf = self;

    [imagePickerVc setDidFinishPickingPhotosWithInfosHandle:^(NSArray<UIImage *> *photos, NSArray *assets, BOOL isSelectOriginalPhoto, NSArray<NSDictionary *> *infos) {
        UIImage *image = photos.firstObject;
        NSString *result = nil;
        if (image) {
            result = [weakSelf disposeQrcode:image];
            DDLogDeviceInfo(@"扫描选择相册的图片结果: %@", result);
            if (result) {
                if (weakSelf.scanCodeCallBack) {
                    NSError *error = nil;
                   weakSelf.scanCodeCallBack(result, error);
                }
            }
            else { //没识别出结果（非二维码图片）
                [weakSelf showSanFailAlertView];
            }
        }
    }];

    imagePickerVc.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:imagePickerVc animated:YES completion:nil];
    
    
    
    
    
    
    
    
    
 
//        UIImagePickerController *mediaUI = [[UIImagePickerController alloc] init];
//        mediaUI.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
//        mediaUI.mediaTypes = [UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypeSavedPhotosAlbum];
//        mediaUI.allowsEditing = YES;
//        mediaUI.delegate = self;
//        mediaUI.modalPresentationStyle =  UIModalPresentationFullScreen;
//        [self presentViewController:mediaUI animated:YES completion:^{
//            // [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleDefault animated:YES];
//        }];
 
}


-(void)setupUI{
    

    [self setupScanRect];
    self.photoButton = [[HGButton alloc] init];
    self.photoButton.titleLabel.font =  [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
    [self.photoButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
    self.photoButton.backgroundColor =  RGBA_HEX(0xCCCCCC, 0.2f);
    [self.photoButton ms_setImagePosition:MSImagePositionLeft spacing:10];
    self.photoButton.layer.cornerRadius = 22.0;
    self.photoButton.clipsToBounds = YES;
    [self.photoButton setTitle:MSResourceString(@"scan_page_title_album") forState:UIControlStateNormal];
    [self.photoButton setImage:MSResourceImage(@"ic_24_album") forState:UIControlStateNormal];
    self.photoButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    [self.photoButton addTarget:self action:@selector(photoAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.photoButton];
    //计算button 的宽度和高度
    CGSize textSize1 = [self.photoButton.titleLabel.text sizeWithAttributes:@{NSFontAttributeName:self.photoButton.titleLabel.font}];
    CGFloat buttonW = textSize1.width + 20;
    if (buttonW < 108) {
        buttonW = 108;
    }
    
    [self.photoButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.view).offset(-54);
        make.centerX.equalTo(self.view);
        make.height.mas_equalTo(44);
        make.width.mas_equalTo(buttonW);
    }];
    
    
    self.navBackgrouView = [[HGView alloc] init];
    [self.view addSubview:self.navBackgrouView];
    
    
    UIImage *image = MSResourceImage(@"ic_nav_back_dm");
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setImage:image forState:UIControlStateNormal];
    button.frame = CGRectMake(0, 0, image.size.width, image.size.height);
    [button addTarget:self action:@selector(leftButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.navBackgrouView addSubview:button];
    self.leftButton = button;
    
    
    self.titleLabel = [HGLabel new];
    self.titleLabel.textColor = RGB_HEX(0xFFFFFF);
    self.titleLabel.font = kMediumFont(18);
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.text =  MSResourceString(@"scan_page_title");
    [self.navBackgrouView addSubview:self.titleLabel];
    
    
    [self.navBackgrouView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.top.trailing.equalTo(self.view);
        make.height.mas_equalTo(48 + (STATUSBAR_HEIGHT));//48 + 44，设计稿是iPhone X
    }];
    
    [self.leftButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.navBackgrouView.mas_leading).offset(16);
        make.bottom.equalTo(self.navBackgrouView.mas_bottom).offset(-11);
//        make.width.mas_equalTo(22);
//        make.height.mas_equalTo(22);
    }];
    
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.navBackgrouView.mas_top).offset((STATUSBAR_HEIGHT));
        make.leading.equalTo(self.navBackgrouView.mas_leading).offset(0);
        make.trailing.equalTo(self.navBackgrouView.mas_trailing).offset(0);
        make.bottom.equalTo(self.navBackgrouView.mas_bottom).offset(0);
    }];
    
}

/**
 *  配置扫描范围
 */
- (void)setupScanRect{
    [self.view.layer insertSublayer:self.shadowLayer atIndex:2];
    [self.view.layer addSublayer:self.scanRectLayer];
    CGFloat wOffset = 1 - 2 * SCANSPACEOFFSET;
    NSString *scanStr =  MSResourceString(@"scan_page_scan_tips");       // @"Scan the QR code to add device";
    UILabel *tipsLabel = [[HGLabel alloc] init];
    
    CGFloat beginX = CGRectGetMinX(self.scanRect);
    CGFloat beginY = CGRectGetMaxY(self.scanRect) + 14;
    CGFloat width = CGRectGetWidth(self.scanRect);
    CGFloat hight = 32;
    
   // tipsLabel.frame = CGRectMake((SCREENWIDTH) * (SCANSPACEOFFSET) + 24, self.scanRectLayer.frame.origin.y + self.scanRectLayer.frame.size.height + 14, wOffset * SCREENWIDTH, 28);
    tipsLabel.frame = CGRectMake(beginX, beginY, width, hight);
    tipsLabel.textAlignment = NSTextAlignmentCenter;
    tipsLabel.text = scanStr;
    tipsLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightMedium];
    tipsLabel.textColor = [UIColor whiteColor];
    tipsLabel.numberOfLines = 2;
  //  [tipsLabel sizeToFit];
    [self.view addSubview:tipsLabel];
}


/**
 *  扫描线
 *
 *  @return linelayer
 */
- (CAShapeLayer *)scanLineLayer{
    if (!_scanLineLayer) {
        CGRect scanLineRect = self.scanRect;
        scanLineRect.origin.x = 0;
        scanLineRect.origin.y = 3;
        scanLineRect.size.height = 50;

        _scanLineLayer = [[CAShapeLayer alloc] init];
        _scanLineLayer.frame = scanLineRect;
        _scanLineLayer.cornerRadius = 10;

        //深色区颜色
        UIColor *deepColor = UIColorFromRGBA(0x0071FF, 0.45);
        //浅色区颜色
        UIColor *lightColor = UIColorFromRGBA(0x0059FF, 0);

        CAGradientLayer *leftGradient = [CAGradientLayer layer];
        leftGradient.frame = CGRectMake(0, 0, scanLineRect.size.width, scanLineRect.size.height);
        leftGradient.colors = @[(id)lightColor.CGColor,(id)deepColor.CGColor];
        leftGradient.locations = [NSArray arrayWithObjects:[NSNumber numberWithFloat:0],[NSNumber numberWithFloat:1],nil];
        leftGradient.startPoint = CGPointMake(0.5, 0);//默认轴为: 0.5 0.0
        leftGradient.endPoint = CGPointMake(0.5, 1);//默认轴为: 0.5 1.0
        [_scanLineLayer addSublayer:leftGradient];
    }
    if (![_scanLineLayer animationForKey:@"positionAnimation"]) {
        CABasicAnimation *anima = [CABasicAnimation animationWithKeyPath:@"position"];
        anima.fromValue = [NSValue valueWithCGPoint:CGPointMake(_scanRect.size.width/2, 0)];
        anima.toValue = [NSValue valueWithCGPoint:CGPointMake(_scanRect.size.width/2, _scanRect.size.height - 25)];
        anima.duration = 2.5f;
        anima.autoreverses = NO;
        anima.repeatCount = 1000;
        [_scanLineLayer addAnimation:anima forKey:nil];

        CFTimeInterval pausedTime = [_scanLineLayer convertTime:CACurrentMediaTime() fromLayer:nil];
        _scanLineLayer.speed = 0.0;
        _scanLineLayer.timeOffset = pausedTime;
    }
    return _scanLineLayer;
}

/**
 *  扫描框
 */
- (CAShapeLayer *)scanRectLayer{
    if (!_scanRectLayer) {
        //外框
        CGRect scanRect = self.scanRect;
        scanRect.origin.x = 0;
        scanRect.origin.y = 0;
        CAShapeLayer *scanRectLayer = [CAShapeLayer layer];
        scanRectLayer.frame = _scanRect;
        scanRectLayer.path = [UIBezierPath bezierPathWithRect:scanRect].CGPath;
       // scanRectLayer.fillColor = [UIColor clearColor].CGColor;
        scanRectLayer.fillColor =  [UIColor colorWithWhite:0 alpha:0.60].CGColor; 
        scanRectLayer.strokeColor = RGBA_HEX(0xffffff, 0.6f).CGColor;
        scanRectLayer.masksToBounds = NO;
        _scanRectLayer = scanRectLayer;

        //扫描线
        [_scanRectLayer addSublayer:self.scanLineLayer];

        CGRect subRect = self.scanRect;
        subRect.origin.x = 0;
        subRect.origin.y = 0;
        float lineWithSpan = 1.3;
        CAShapeLayer *subRectLayer = [CAShapeLayer layer];
        subRectLayer.frame = subRect;
        CGMutablePathRef linePath = CGPathCreateMutable();
        subRectLayer.lineWidth = 3;
        subRectLayer.lineJoin = kCALineJoinRound;
        subRectLayer.strokeColor = [UIColor colorWithRed:61/255.0 green:165/255.0 blue:254/255.0 alpha:1].CGColor;

        subRect.origin.x = -2.5;
        subRect.origin.y = -2.5;
        subRect.size.width += 1;
        subRect.size.height += 1;
        CGFloat amend = 3.5;
        //左上角
        CGPathMoveToPoint(linePath,NULL,subRect.origin.x+lineWithSpan,subRect.origin.y);
        CGPathAddLineToPoint(linePath,NULL,subRect.origin.x+lineWithSpan,subRect.origin.y + 16);

        CGPathMoveToPoint(linePath,NULL,subRect.origin.x,subRect.origin.y +lineWithSpan);
        CGPathAddLineToPoint(linePath,NULL,subRect.origin.x + 16,subRect.origin.y+lineWithSpan);

        //左下角
        CGPathMoveToPoint(linePath,NULL,subRect.origin.x+ lineWithSpan,subRect.origin.y + subRect.size.height - 15);
        CGPathAddLineToPoint(linePath,NULL,subRect.origin.x +lineWithSpan,subRect.origin.y + subRect.size.height + amend);

        CGPathMoveToPoint(linePath,NULL,subRect.origin.x ,subRect.origin.y + subRect.size.height - lineWithSpan + amend);
        CGPathAddLineToPoint(linePath,NULL,subRect.origin.x+lineWithSpan +15,subRect.origin.y + subRect.size.height - lineWithSpan+amend);

        //右上角
        CGPathMoveToPoint(linePath,NULL,subRect.origin.x+ subRect.size.width - 15 + amend,subRect.origin.y+lineWithSpan);
        CGPathAddLineToPoint(linePath,NULL,subRect.origin.x + subRect.size.width + amend,subRect.origin.y +lineWithSpan);

        CGPathMoveToPoint(linePath,NULL,subRect.origin.x+ subRect.size.width-lineWithSpan + amend,subRect.origin.y);
        CGPathAddLineToPoint(linePath,NULL,subRect.origin.x + subRect.size.width-lineWithSpan + amend,subRect.origin.y + 15 + lineWithSpan);

        //右下角
        CGPathMoveToPoint(linePath,NULL,subRect.origin.x+ subRect.size.width -lineWithSpan + amend,subRect.origin.y+subRect.size.height-15+amend);
        CGPathAddLineToPoint(linePath,NULL,subRect.origin.x-lineWithSpan + subRect.size.width + amend,subRect.origin.y +subRect.size.height+amend);

        CGPathMoveToPoint(linePath,NULL,subRect.origin.x+ subRect.size.width - 15 + amend,subRect.origin.y + subRect.size.height-lineWithSpan+amend);
        CGPathAddLineToPoint(linePath,NULL,subRect.origin.x + subRect.size.width+amend,subRect.origin.y + subRect.size.height - lineWithSpan+amend);

        subRectLayer.path= linePath;
        CGPathRelease(linePath);
        [scanRectLayer addSublayer:subRectLayer];
    }
    return _scanRectLayer;
}

/**
 *  阴影层
 */
- (CAShapeLayer *)shadowLayer{
    if (!_shadowLayer) {
        _shadowLayer = [CAShapeLayer layer];
        _shadowLayer.path = [UIBezierPath bezierPathWithRect:SCREENBOUNDS].CGPath;
        _shadowLayer.fillColor = [UIColor colorWithWhite:0 alpha:0.60].CGColor;
        _shadowLayer.mask = self.maskLayer;
    }
    return _shadowLayer;
}

/**
 *  遮掩层
 */
- (CAShapeLayer *)maskLayer{
    if (!_maskLayer){
        _maskLayer = [self generateMaskLayerWithRect:self.view.bounds exceptRect:self.scanRect];
        _maskLayer.fillColor = [UIColor blackColor].CGColor;
    }
    return _maskLayer;
}

/**
 *  扫描范围
 */
- (CGRect)scanRect{
    if (CGRectEqualToRect(_scanRect,CGRectZero)){
        CGFloat wOffset = 1 - 2 * SCANSPACEOFFSET;
        _scanRect = CGRectMake((SCREENWIDTH) * (SCANSPACEOFFSET),
                               ((SCREENHEIGHT) - wOffset * (SCREENWIDTH) - kSafeAreaBottom - kSafeAreaTop - BHStatusBarHeight)/2 - 80 + 48 + STATUSBAR_HEIGHT,
                               wOffset * SCREENWIDTH,
                               wOffset * SCREENWIDTH);
    }
    return _scanRect;
}

/**
 *  生成空缺部分rect的layer
 */
- (CAShapeLayer *)generateMaskLayerWithRect:(CGRect)rect exceptRect:(CGRect)exceptRect{
    CAShapeLayer * maskLayer = [CAShapeLayer layer];
   // maskLayer.backgroundColor = [UIColor colorWithWhite:0 alpha:0.60].CGColor;
   
    if (!CGRectContainsRect(rect,exceptRect)) {
        return nil;
    }
    else if (CGRectEqualToRect(rect,CGRectZero)) {
        maskLayer.path = [UIBezierPath bezierPathWithRect:rect].CGPath;
        return maskLayer;
    }

    CGFloat boundsInitX = CGRectGetMinX(rect);
    CGFloat boundsInitY = CGRectGetMinY(rect);
    CGFloat boundsWidth = CGRectGetWidth(rect);
    CGFloat boundsHeight = CGRectGetHeight(rect);

    CGFloat minX = CGRectGetMinX(exceptRect);
    CGFloat maxX = CGRectGetMaxX(exceptRect);
    CGFloat minY = CGRectGetMinY(exceptRect);
    CGFloat maxY = CGRectGetMaxY(exceptRect);
    CGFloat width = CGRectGetWidth(exceptRect);

    /** 添加路径*/
    UIBezierPath *path = [UIBezierPath bezierPathWithRect:CGRectMake(boundsInitX,boundsInitY,minX,boundsHeight)];
    [path appendPath:[UIBezierPath bezierPathWithRect:CGRectMake(minX,boundsInitY,width,minY)]];
    [path appendPath:[UIBezierPath bezierPathWithRect:CGRectMake(maxX,boundsInitY,boundsWidth - maxX,boundsHeight)]];
    [path appendPath:[UIBezierPath bezierPathWithRect:CGRectMake(minX,maxY,width,boundsHeight - maxY)]];
    maskLayer.path = path.CGPath;
    return maskLayer;
}


#pragma mark - 二维码处理
- (void)handleQRcode{
    @weakify(self);
    self.scanCodeCallBack = ^(NSString *result, NSError *error) {
        @strongify(self);
        DDLogDeviceInfo(@"二维码处理-----------------------%@", result);
//        self.flashButton.selected = NO;
        if (result) {
            [self.presenter decodeQRCode:result];
        }else{ //扫码错误,扫描不到
            DDLogDeviceInfo(@"扫码错误,扫描不到");
        }
    };
}


#pragma mark - 通知相关
- (void)willEnterForeground {
   // if (flashButton) {
        AVCaptureDevice * device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
        if (device.torchMode == AVCaptureTorchModeOff) {
           // flashButton.selected = NO;
        }
   // }
}



- (void)presenter:(OEMScanCodePresenter *)presenter decodeQRCodeComplete:(NSDictionary *)dict{
    if (presenter.type == OEMCodeTypeBLE) {
        DDLogDeviceInfo(@"跳转蓝牙指引页----------%@", dict);
        MSDeviceConnectResult *connectInfo = [[MSDeviceConnectResult alloc] init];
        connectInfo.category = dict[@"category"];
        connectInfo.deviceConnectType = MSDeviceConnectTypeScanCode;
        connectInfo.deviceName = dict[@"typeName"];
        connectInfo.deviceImageUrl = dict[@"imgUrl"];
        connectInfo.deviceSn8 =  dict[@"deviceSN8"];
        connectInfo.mode = dict[@"mode"];
        connectInfo.deviceSsid = dict[@"ssid"];
     //   [OEMRouter handleURL: MSRouterBLEDeviceGuide withParams:@{@"connectInfo":connectInfo}];
        
        MSConnectWiFiViewController *connectWifiVC = [[MSConnectWiFiViewController alloc] init];
        connectWifiVC.connectInfo = connectInfo;
        [self.navigationController pushViewController:connectWifiVC animated:YES];
        
    }else if (presenter.type ==  OEMCodeTypeDeviceShare){
        DDLogDeviceInfo(@"接受分享----------%@", dict);
        //  {"requestCode":"CHJBHVVYTT7SGHJKL","deviceType":"0xAC","deviceName":"我的空调"}
        __block BOOL hasNull = NO; //坑爹：防崩处理
        [dict enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
            if (obj == [NSNull null]) {
                hasNull = YES;
                *stop = YES;
                 return;
            }
        }];
        
        if (hasNull) {
            [self toastText:MSResourceString(@"scan_page_wrong_photo_tips")];  
            return;
        }
        
        NSString *requestCode = dict[@"requestCode"];
        NSString *deviceType = dict[@"deviceType"];
        NSString *deviceName = dict[@"deviceName"];
        [self showShareViewWithRequestCode:requestCode deviceType:deviceType deviceName:deviceName];
    }else if (presenter.type ==  OEMCodeTypeMacAddress){
        [self showSanFailAlertView];
    }else{
        [self showSanFailAlertView];
//        [self toastText:MSResourceString(@"scan_page_wrong_photo_tips")]; //    @"QR Code cannot be recognized"];
//        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//            //需要延迟执行的代码
//            [self start];
//        });
        
    }
}



- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    UIImage *image = [info objectForKey:UIImagePickerControllerEditedImage];
    if (!image){
        image = [info objectForKey:UIImagePickerControllerOriginalImage];
    }

    NSString *result = nil;
    if (image) {
        result = [self disposeQrcode:image];
        DDLogDeviceInfo(@"扫描选择相册的图片结果: %@", result);
        if (result) {
            image = [info objectForKey:UIImagePickerControllerOriginalImage];
        }
        else { //没识别出结果（非二维码图片）
            [self showSanFailAlertView];
           // [self toastText:MSResourceString(@"scan_page_wrong_photo_tips")];   //@"Please select the correct QR code picture"
        }
    }
    WEAKSELF
    [picker dismissViewControllerAnimated:YES completion:^{
      //  [[UIApplication sharedApplication] setStatusBarStyle:self.statusBarStyle animated:YES];
        if (weakSelf.scanCodeCallBack) {
            NSError *error = nil;
           weakSelf.scanCodeCallBack(result, error);
        }
    }];
}

- (NSString *)disposeQrcode:(UIImage *)image {
    UIGraphicsBeginImageContext(image.size);
    [image drawInRect:CGRectMake(0, 0, image.size.width, image.size.height)];
    image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    NSString *result = [_scanCore imageDetectorWithImage:image];
    return result;
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    // WEAKSELF
    [picker dismissViewControllerAnimated:YES completion:^{
       //[[UIApplication sharedApplication] setStatusBarStyle:weakSelf.statusBarStyle animated:YES];
    }];
}


-(void)showShareViewWithRequestCode:(NSString *)requestCode deviceType:(NSString *)deviceType deviceName:(NSString *)deviceName {
    CGFloat topSpace = 0;
    MSShareDeviceAlertView *alertView = [[MSShareDeviceAlertView alloc] initWithFrame:CGRectMake(0, topSpace, SCREEN_WIDTH, SCREEN_HEIGHT - topSpace)
                                                                                 type:deviceType
                                                                                 name:deviceName
                                                                     parentController:self];
    WEAKSELF
    alertView.clickAgreeBlock = ^{
        [weakSelf acceptShareDeviceRequestCode:requestCode];
    };
    
    alertView.clickCancelBlock = ^{
        [weakSelf start];
    };
    [alertView show];
}

-(void)acceptShareDeviceRequestCode:(NSString *)requestCode{
    WEAKSELF
    id <MSMessageCenterProtocol>service = [OEMRouter getServiceInstance:@protocol(MSMessageCenterProtocol)];
    if ([service respondsToSelector:@selector(acceptDeviceShareWithRequestCode:success:failure:)]) {
        [service acceptDeviceShareWithRequestCode:requestCode
                                          success:^{
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
               
                [weakSelf toastText:MSResourceString(@"scan_page_add_successfully")];
          
            });
            [weakSelf.navigationController popToRootViewControllerAnimated:YES];
        }
                                          failure:^(MSBusinessError *error) {
            [weakSelf toastText:error.localizedDescription];
            [weakSelf start];
        }];
    }
}


-(void)showSanFailAlertView{
    [self stop];
    WEAKSELF
    NSString *leftTitle = MSResourceString(@"config_fail_page_connect_try_again");
    NSString *rightTitle = MSResourceString(@"scan_page_scan_fail_manual_add");
    OEMCommomAlertViewController *dest = [OEMCommomAlertViewController alertControllerWithTitle:MSResourceString(@"scan_page_scan_fail_title")
                                                                                        content:@""
                                                                                        buttons:@[leftTitle,rightTitle]
                                                                                  isMiddleTheme:NO];
    dest.leftBlock = ^{
        [weakSelf start];
    };
    
    dest.rightBlock = ^{
        [weakSelf.navigationController popViewControllerAnimated:YES];
    };
    [self presentViewController:dest animated:NO completion:nil];
}



@end
