//
//  MSChooseDeviceModelViewController.h
//  MSDevice
//
//  Created by 及时行乐 on 2020/6/23.
//

#import <MSBusiness/MVPViewController.h>
#import "MSChooseDeviceModelPresenter.h"


@interface MSChooseDeviceModelViewController : MVPViewController<MSChooseDeviceModelPresenter *><MSChooseDeviceModelViewProtocol>

@property (nonatomic, copy) NSString *typeId;

@property (nonatomic, copy) NSString *deviceImageUrl;  //设备配网过程中显示的图片，取选择家电类型时的图片url

@end

