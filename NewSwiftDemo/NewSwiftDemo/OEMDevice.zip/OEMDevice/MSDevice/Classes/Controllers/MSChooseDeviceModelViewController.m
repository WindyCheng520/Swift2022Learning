//
//  MSChooseDeviceModelViewController.m
//  MSDevice
//
//  Created by 及时行乐 on 2020/6/23.
//  选择设备型号页面

#import "MSChooseDeviceModelViewController.h"
#import "MSDeviceBundle.h"
#import "MSConnectWiFiViewController.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "MSDeviceModelResult.h"
#import <MSBusiness/MSDeviceConnectResult.h>
#import <MSBusiness/MSBLEManager.h>
#import "MSChooseDeviceModelCell.h"

static NSString *const MSChooseDeviceModelCellIdentifier     = @"MSChooseDeviceModelCellIdentifier";


@interface MSChooseDeviceModelViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) HGTableView *tableView;


@end

@implementation MSChooseDeviceModelViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.tableView = [HGTableView new];
        self.presenter = [[MSChooseDeviceModelPresenter alloc] initWithView:self];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = MSResourceString(@"connect_select_moel");
    self.view.backgroundColor = RGB(250, 250, 250);

    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.rowHeight = 112;
    self.tableView.showsVerticalScrollIndicator = NO;
    [self.tableView registerClass:[MSChooseDeviceModelCell class] forCellReuseIdentifier:MSChooseDeviceModelCellIdentifier];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:self.tableView];
    

    [self makeConstraints];
    
    [self.presenter fetchIotProductWithTypeId:self.typeId];
}

- (void)makeConstraints{
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
}

#pragma mark - UITableViewDelegate, UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.presenter.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MSChooseDeviceModelCell *cell = [tableView dequeueReusableCellWithIdentifier:MSChooseDeviceModelCellIdentifier forIndexPath:indexPath];
    MSDeviceModelResult *result = self.presenter.dataArray[indexPath.row];
    cell.indexPath = indexPath;
    [cell.iconImageView sd_setImageWithURL:[NSURL URLWithString:result.productImg] placeholderImage:[UIImage imageNamed:@"pic_category_default"]];
    
    NSMutableParagraphStyle *paragraphStyle = [NSMutableParagraphStyle new];
    paragraphStyle.lineSpacing = 5;
    paragraphStyle.lineBreakMode = NSLineBreakByTruncatingTail;
    NSAttributedString *str = [[NSAttributedString alloc]initWithString:result.productName ?: @"" attributes:@{NSParagraphStyleAttributeName : paragraphStyle}];
    cell.titleLabel.attributedText = str;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    MSDeviceModelResult *result = self.presenter.dataArray[indexPath.row];
//    [self.presenter fetchIotConnectInfoWithIotProductId:result.iotId productId:result.productId];
    
    [self.presenter requestDataAfterSelectedWithIotProductId:result.iotId productId:result.productId];
}

#pragma mark - MSChooseDeviceModelViewProtocol

- (void)presenterDidLoadData:(MSChooseDeviceModelPresenter *)presenter {
    [self.tableView reloadData];
}

- (void)presenter:(MSChooseDeviceModelPresenter *)presenter didLoadConnectInfo:(MSDeviceConnectResult *)connectInfo {
    
    if (connectInfo.mode.integerValue == 0) {
        //ap
        MSConnectWiFiViewController *connectWifiVC = [[MSConnectWiFiViewController alloc] init];
        connectWifiVC.connectInfo = connectInfo;
        connectWifiVC.connectInfo.deviceImageUrl = self.deviceImageUrl;
        connectWifiVC.connectInfo.deviceConnectType = MSDeviceConnectTypeManualSelect;
        [self.navigationController pushViewController:connectWifiVC animated:YES];
        
    } else if (connectInfo.mode.integerValue == 3) {
        //ble+wifi
        if ([[MSBLEManager shareManager] checkBluetoothAuthState] == MSBLEManagerTypeAuthorizedAndTurnOn) {
            MSConnectWiFiViewController *connectWifiVC = [[MSConnectWiFiViewController alloc] init];
            connectWifiVC.connectInfo = connectInfo;
            connectWifiVC.connectInfo.deviceImageUrl = self.deviceImageUrl;
            connectWifiVC.connectInfo.deviceConnectType = MSDeviceConnectTypeManualSelect;
            [self.navigationController pushViewController:connectWifiVC animated:YES];
        } else {
            [[MSBLEManager shareManager] showBluetoothAuthorAlert];
        }
        
    }
}

#pragma mark - Private


@end


