//  
//  MSAddDeviceBLE.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/31
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <Foundation/Foundation.h>
#import "MSAddDeviceProtocol.h"

@interface MSAddDeviceBLE : NSObject<MSAddDeviceProtocol>

@end

