//
//  MSConnectSuccessViewController.m
//  MSDevice
//
//  Created by 及时行乐 on 2020/6/23.
//  配网成功页面

#import "MSConnectSuccessViewController.h"
#import "MSDeviceBundle.h"
#import <MSBusiness/NSString+Toshiba.h>
#import "MSAuthorizeViewController.h"
#import <MSBusiness/MSHomeProtocol.h>
#import <MSBusiness/MSDeviceCardResult.h>
#import <OEMTheme/MSInputView_Private.h>
#import <OEMTheme/UILabel+OEMThemes.h>
#import <MSBusiness/OEMGlobalUIManager.h>

static const NSInteger textFieldTag = 1234;

@interface MSConnectSuccessViewController ()<MSInputViewDelegate>

@property (nonatomic, strong) HGImageView *iconImageView;
@property (nonatomic, strong) HGImageView *iconInnerView;  //内部小勾
@property (nonatomic, strong) HGLabel *titleLabel;
@property (nonatomic, strong) HGLabel *subtitleLabel;
@property (nonatomic, strong) HGLabel *deviceNameLabel;
@property (nonatomic, strong) MSInputView *nameInputView;
@property (nonatomic, strong) HGButton *sureButton;


@end

@implementation MSConnectSuccessViewController
- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        self.iconImageView = [HGImageView new];
        self.iconInnerView = [HGImageView new];
        self.titleLabel = [HGLabel new];
        self.subtitleLabel = [HGLabel new];
        self.deviceNameLabel = [HGLabel new];
        self.nameInputView = [MSInputView new];
        self.sureButton = [HGButton new];
        self.presenter = [[MSAddDeviceSuccessPresenter alloc] initWithView:self];
    }
    return self;
}

- (BOOL)navigationBarHidden {
    return YES;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
//    [self.navigationController setNavigationBarHidden:YES animated:YES];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.navigationController.interactivePopGestureRecognizer.enabled = YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.canRightSlideBack = NO;
    
    
    self.hiddenKeyboardWhenTap = YES;
    
  //  self.iconImageView.image = MSResourceImage(@"ic_n_hook");
    self.iconImageView.backgroundColor = RGB_HEX(0x01D28E);
    self.iconImageView.layer.cornerRadius = 30;
    self.iconImageView.clipsToBounds = YES;
    [self.view addSubview:self.iconImageView];
    
    self.iconInnerView.image = MSResourceImage(@"ic_n_hook");
    [self.iconImageView addSubview:self.iconInnerView];
    
    self.titleLabel.textColor = RGB_HEX(0x000000);
    self.titleLabel.font = kSemiboldFont(22);
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:self.titleLabel];
    self.titleLabel.text = MSResourceString(@"config_success_page_title");
    
    self.subtitleLabel.textColor = RGB_HEX(0x999999);
    self.subtitleLabel.font = kRegularFont(15);
    self.subtitleLabel.textAlignment = NSTextAlignmentCenter;
    self.subtitleLabel.numberOfLines = 0;
    [self.subtitleLabel sizeToFit];
    [self.view addSubview:self.subtitleLabel];
    self.subtitleLabel.text = [NSString stringWithFormat:MSResourceString(@"config_success_page_added_to_list"), self.applianceName];
    
    self.deviceNameLabel.textColor = RGB_HEX(0x999999);
    self.deviceNameLabel.font =  kRegularFont(14); // kSFProFont(14);
    self.deviceNameLabel.textAlignment = NSTextAlignmentLeft;
    self.deviceNameLabel.numberOfLines = 0;
    [self.view addSubview:self.deviceNameLabel];
    self.deviceNameLabel.text = MSResourceString(@"config_success_page_device_name");
    
    
    [self.nameInputView setRightImage:MSResourceImage(@"ic_Input_close")];
    [self.nameInputView setFont:kMediumFont(16)];
    [self.nameInputView setTextColor:RGB_HEX(0x000000)];
    self.nameInputView.text = self.applianceName;
    WEAK_SELF;
    self.nameInputView.clickRightButtonBlock = ^{
        STRONG_SELF;
        self.nameInputView.text = nil;
        [self.nameInputView setRightButtonHidden:YES];
        self.sureButton.backgroundColor = RGBA_HEX(0xEC1C24 ,0.3);
        self.sureButton.enabled = NO;
        self.sureButton.layer.shadowOpacity = 0;
    };
    self.nameInputView.delegate = self;
    [self.nameInputView setTextFieldTag:textFieldTag];
    self.nameInputView.placeholder = MSResourceString(@"config_success_page_device_input_tips");
    [self.view addSubview:self.nameInputView];
    
    [self.sureButton setTitle:MSResourceString(@"config_success_page_finished") forState:UIControlStateNormal];
    [self.sureButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
    self.sureButton.titleLabel.font = kRegularFont(18);
    self.sureButton.layer.cornerRadius = 22;
    self.sureButton.backgroundColor = RGB_HEX(0xEC1C24);
    [self.view addSubview:self.sureButton];
    [self.sureButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    
    [self makeConstraints];
    
    [self configureOEMTheme];
}

- (void)configureOEMTheme{
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    [self.view configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.sureButton configureThemeTag:OEMThemesTag_UIButton_Background];
    [self.titleLabel configure90TranslucentTrait];
    [self.subtitleLabel configure40TranslucentTrait];
    [self.deviceNameLabel configure40TranslucentTrait];
    [self.nameInputView.textField configureThemeTag:OEMThemesTag_UITextField_Textcolor];
    
    
    
    [self.titleLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.mainTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.mainTextColor
    }];
    
    
    [self.subtitleLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.secondColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.secondColor
    }];
    
    
    [self.deviceNameLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.secondColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.secondColor
    }];
    
    
    [self.nameInputView.textField specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UITextField_Textcolor) : kDarkText.mainTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UITextField_Textcolor) : kLightText.mainTextColor
    }];

//    
//    [self.sureButton specialPropertiesForDarkMode:@{
//        @(OEMThemesTag_UIButton_TitleThemeColor) : RGB_HEX(0xFFFFFF)
//    } lightModeProperties:@{
//        @(OEMThemesTag_UIButton_TitleThemeColor) : RGB_HEX(0xFFFFFF)
//    }];
    
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        [weakSelf setPlaceholderColor];
    } callImmidiately:YES];
}



-(void)setPlaceholderColor{
    if (OEMThemeIsDarkMode) {
        self.nameInputView.placeholderColor = kDarkText.tipsColor;
    }else{
        self.nameInputView.placeholderColor = kLightText.tipsColor;
    }
}


- (void)makeConstraints {
    [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(STATUSBAR_HEIGHT + 84);
        make.size.mas_equalTo(CGSizeMake(60, 60));
        make.centerX.equalTo(self.view);
    }];
    
    [self.iconInnerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(28, 28));
        make.centerX.equalTo(self.iconImageView);
        make.centerY.equalTo(self.iconImageView);
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.iconImageView.mas_bottom).offset(30);
        make.leading.mas_equalTo(16);
        make.trailing.mas_equalTo(-16);
        make.height.mas_equalTo(30);
    }];
    [self.subtitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleLabel.mas_bottom).offset(9);
        make.width.mas_equalTo(SCREEN_SCALE_WIDTH(280));
        make.centerX.equalTo(self.view);
    }];
    
    [self.deviceNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(35);
        make.top.equalTo(self.subtitleLabel.mas_bottom).offset(40);
        make.width.mas_equalTo(SCREEN_SCALE_WIDTH(280));
        make.centerX.equalTo(self.view);
    }];
    
    [self.nameInputView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.deviceNameLabel.mas_bottom).offset(8);
        make.leading.mas_equalTo(16);
        make.trailing.mas_equalTo(-16);
        make.height.mas_equalTo(44);
    }];
    
    [self.sureButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.nameInputView.mas_bottom).offset(80);
        make.leading.mas_equalTo(16);
        make.trailing.mas_equalTo(-16);
        make.height.mas_equalTo(44);
    }];
    
}

- (void)clickButton:(UIButton*)sender {
    
    if (self.nameInputView.text.length == 0 ) {
        [self toastText:MSResourceString(@"config_success_page_device_input_tips")];
        return;
    }
    
    if ([self.nameInputView.text isEqualToString:self.applianceName]) {

        [self.presenter changeDeviceNameWithThingCode:self.thingCode name:self.nameInputView.text];
    } else {
        if ([self.nameInputView.text isContainEmoji]) {
            [self toastText:MSResourceString(@"config_success_page_device_emoji")];  //"家电名称暂不支持表情";
        } else { //被改动了
            
            id <MSHomeProtocol>service = [OEMRouter getServiceInstance:@protocol(MSHomeProtocol)];
                    if ([service respondsToSelector:@selector(getLocalDeviceInfo)]) {
                        NSArray *array = [service getLocalDeviceInfo];
                        __block BOOL isSame = NO; //是否有同名
                        [array enumerateObjectsUsingBlock:^(MSDeviceCardResult *obj, NSUInteger idx, BOOL * _Nonnull stop) {
                            if ([self.nameInputView.text isEqualToString:obj.thingName]){
                                isSame = YES;
                                *stop = YES;
                                return;
                            }
                        }];
            
                        if (isSame) {
                            [self toastText:MSResourceString(@"config_success_page_device_duplicate")];  //"家电名称重复，请重新命名"
                            return;
                        }
                        [self.presenter changeDeviceNameWithThingCode:self.thingCode name:self.nameInputView.text];
                    }
        }
    }
    
    NSString *category = self.connectInfo.category ?: @"";
    if (self.connectInfo.category.length > 0 && ![self.connectInfo.category hasPrefix:@"0x"]) {
        category = [NSString stringWithFormat:@"0x%@", self.connectInfo.category];
    }
}

//我的设备页面，添加+配网成功也需要跳转到首页
- (void)popMethod {
    UIViewController *rootViewController = [UIApplication sharedApplication].keyWindow.rootViewController;
    if ([rootViewController isKindOfClass:[UITabBarController class]]) {
        UITabBarController *tabbarController = (UITabBarController *)rootViewController;
        if (tabbarController.selectedIndex != 0) {
            tabbarController.selectedIndex = 0;
            for (UIView *view in tabbarController.tabBar.subviews) {
                if (view.tag == 1001) {
                    view.hidden = NO;
                } else if (view.tag == 1002) {
                    view.hidden = YES;
                } else if (view.tag == 1003) {
                    view.hidden = YES;
                }
            }
        }
    }
    [self.navigationController popToRootViewControllerAnimated:YES];
}


- (NSString *)deleteSpaceString:(NSString *)string {
    NSCharacterSet *set = [NSCharacterSet whitespaceCharacterSet];
    return  [string stringByTrimmingCharactersInSet:set];
}

#pragma mark - MSInputViewDelegate
- (void)inputView:(MSInputView *)inputView didChangeText:(NSString *)text {
    NSString *string = [self deleteSpaceString:text];
    if (![string isEqualToString:@""]) {
        self.sureButton.backgroundColor = RGBA_HEX(0xEC1C24 ,1);
        self.sureButton.enabled = YES;
        [self.nameInputView setRightButtonHidden:NO];
        
        /*
        self.sureButton.layer.shadowColor = RGBA_HEX(0xEC1C24, 0.25f).CGColor;
        self.sureButton.layer.shadowOffset = CGSizeMake(0,2);
        self.sureButton.layer.shadowOpacity = 1;
        self.sureButton.layer.shadowRadius = 10;
        self.sureButton.layer.shadowPath = [UIBezierPath bezierPathWithRect:CGRectMake(0, 0, SCREEN_WIDTH-30*2, 44)].CGPath;
        */
    } else {
        self.sureButton.backgroundColor = RGBA_HEX(0xEC1C24 ,0.3);
        self.sureButton.enabled = NO;
        /*
        self.sureButton.layer.shadowOpacity = 0;
         */
        if ([text isEqualToString:@""]) {
            [self.nameInputView setRightButtonHidden:YES];
        } else {
            [self.nameInputView setRightButtonHidden:NO];
        }
    }
}

//设备名字长度限制60字符
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if (textField.tag == textFieldTag){
        NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
        NSInteger length = newString.length;//转换过的长度
        NSLog(@"%@------长度: %ld",newString,length);
        if (length > 60){
            return NO;
        }
        return YES;
    }else{
        return YES;
    }
}



- (void)textFieldDidEndEditing:(UITextField *)textField {
    if (textField.tag == textFieldTag) {
        [self.nameInputView setRightButtonHidden:YES];
    }
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    if (textField.tag == textFieldTag && ![self.nameInputView.text isEqualToString:@""]) {
        [self.nameInputView setRightButtonHidden:NO];
    }
}

#pragma mark - MSAddDeviceSuccessViewProtocol
- (void)presenter:(MSAddDeviceSuccessPresenter *)presenter didChangeDeviceName:(MSBusinessError *)error {
    if (error) {
        [self toastText:error.localizedDescription];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self popMethod];
        });
    } else {
        [self popMethod];
      //暂时屏蔽确权接口
      //  [self.presenter fetchApplianceAuthStatusWithApplianceCode:self.applianceId showLoading:NO];
    }
}

- (void)presenter:(MSAddDeviceSuccessPresenter *)presenter didFetchApplianceAuthStatus:(MSBusinessError *)error {
    if (error) {
        [self popMethod];
    } else {
        if (self.presenter.authType == 1 || self.presenter.authType == 2) {  //1待确权  2未确权
            //跳转到确权页面
            MSAuthorizeViewController * authVC = [[MSAuthorizeViewController alloc]init];
            authVC.enterType = 1;
            authVC.applianceId = self.applianceId;
            authVC.category = self.connectInfo.category;
            authVC.code = self.connectInfo.code;
            [self.navigationController pushViewController:authVC animated:YES];
        } else {
            //跳转到首页
            [self popMethod];
        }
    }
}

//- (void)changeDeviceNameSuccess:(MSAddDeviceSuccessPresenter *)presenter {
////    [self popMethod];
//    [self.presenter fetchApplianceAuthStatusWithApplianceCode:self.applianceId showLoading:NO];
//}

//- (void)fetchApplianceAuthStatusSuccess:(MSAddDeviceSuccessPresenter *)presenter {
//    if (self.presenter.authType == 1 || self.presenter.authType == 2) {  //1待确权  2未确权
//        //跳转到确权页面
//        MSAuthorizeViewController * authVC = [[MSAuthorizeViewController alloc]init];
//        authVC.enterType = 1;
//        authVC.applianceId = self.applianceId;
//        authVC.category = self.connectInfo.category;
//        authVC.code = self.connectInfo.code;
//        [self.navigationController pushViewController:authVC animated:YES];
//    } else {
//        //跳转到首页
//        [self popMethod];
//    }
//
//}

@end
