//
//  OEMAPConnectFailViewController.m
//  MSDevice
//
//  Created by WindyCheng on 2022/3/16.
//

#import "OEMAPConnectFailViewController.h"
#import "MSDeviceBundle.h"
#import <OEMTheme/UILabel+OEMThemes.h>
#import <MSBusiness/OEMGlobalUIManager.h>

@interface OEMAPConnectFailViewController ()
@property (nonatomic, strong) HGView *backView;          //容器
@property (nonatomic, strong) HGLabel *titleLabel;       //标题
@property (nonatomic, strong) HGImageView *imageView;
@property (nonatomic, strong) HGLabel *contentLabel;      //内容
@property (nonatomic, strong) HGButton *closeButton;
@property (nonatomic, strong) HGButton *leftButton;
@property (nonatomic, strong) HGButton *rightButton;

@property (nonatomic, copy)NSString *leftButtonTitle;


@property (nonatomic, copy)NSString *rightButtonTitle;


@end

@implementation OEMAPConnectFailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configSubviews];
    [self makeConstraints];
    [self configureOEMTheme];
}

-(void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:self.backView.bounds
                                                   byRoundingCorners:UIRectCornerTopLeft  | UIRectCornerTopRight
                                                         cornerRadii:CGSizeMake(20,20)];
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = self.backView.bounds;
    maskLayer.path = maskPath.CGPath;
    self.backView.layer.mask = maskLayer;
}


- (void)configSubviews{
    self.view.backgroundColor = [UIColor colorWithWhite:0 alpha:0.6];
    self.backView = [[HGView alloc] initWithFrame:CGRectMake(0, 0,  [[UIScreen mainScreen] bounds].size.width, 384)];
    self.backView.backgroundColor =  [UIColor redColor];   //RGBA_HEX(0xffffff, 1.0f);
   // self.backView.layer.cornerRadius = 20.f;
    [self.view addSubview:self.backView];
//    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:self.backView.bounds
//                                                   byRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight
//                                                         cornerRadii:CGSizeMake(10,10)];
//    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
//    maskLayer.frame = self.backView.bounds;
//    maskLayer.path = maskPath.CGPath;
//    self.backView.layer.mask = maskLayer;
    
    self.titleLabel = [HGLabel new];
    self.titleLabel.font = kSemiboldFont(16);
    self.titleLabel.textColor = RGB_HEX(0x000000);
    self.titleLabel.text = MSResourceString(@"ap_connect_page_tips_no_ap");   //@"找不到设备WiFi";
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.numberOfLines = 0;
    [self.titleLabel sizeToFit];
    [self.backView addSubview:self.titleLabel];
    
    
    self.closeButton = [HGButton new];
    [self.closeButton setImage:MSResourceImage(@"ico_tc_gb") forState:UIControlStateNormal];
    self.closeButton.backgroundColor = [UIColor clearColor];
    [self.closeButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.backView addSubview:self.closeButton];
    
    
    self.imageView = [HGImageView new];
    self.imageView.contentMode = UIViewContentModeScaleAspectFill;
    self.imageView.image = MSResourceImage(@"Box");
    self.imageView.backgroundColor = [UIColor clearColor];
    [self.backView addSubview:self.imageView];
    
    
    self.contentLabel = [HGLabel new];
    self.contentLabel.font = kSemiboldFont(16);
    self.contentLabel.textColor = RGB_HEX(0x000000);
    self.contentLabel.text =  MSResourceString(@"ap_connect_fail_title");  //    @"请确认是否按指引设置设备";
    self.contentLabel.textAlignment = NSTextAlignmentCenter;
    self.contentLabel.numberOfLines = 0;
    [self.contentLabel sizeToFit];
    [self.backView addSubview:self.contentLabel];
    
    
    self.leftButtonTitle = MSResourceString(@"add_device_process_page_cancel_button");
    
    self.leftButton = [HGButton new];
    self.leftButton.clipsToBounds = YES;
    self.leftButton.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
    self.leftButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    self.leftButton.titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.leftButton setTitle:self.leftButtonTitle forState:UIControlStateNormal];
    self.leftButton.backgroundColor = [UIColor clearColor];
    self.leftButton.layer.borderColor = kDarkText.mainColor.CGColor;
    self.leftButton.layer.borderWidth = 1.0;
    self.leftButton.titleEdgeInsets = UIEdgeInsetsMake(5, 10, 5, 10);
    self.leftButton.titleLabel.font = kRegularFont(18);
    [self.leftButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
    self.leftButton.backgroundColor = RGB_HEX(0xFFFFFF);
    [self.leftButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.backView addSubview:self.leftButton];
    

    self.rightButtonTitle = MSResourceString(@"ap_connect_fail_button_reset");   //   @"重新设置";
    self.rightButton = [HGButton new];
    self.rightButton.clipsToBounds = YES;
    self.rightButton.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
    self.rightButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    self.rightButton.titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.rightButton setTitle:self.rightButtonTitle forState:UIControlStateNormal];
    self.rightButton.titleEdgeInsets = UIEdgeInsetsMake(5, 10, 5, 10);
    self.rightButton.titleLabel.font = kRegularFont(18);
    [self.rightButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
    self.rightButton.backgroundColor = kBusiness.brandColor;
    [self.rightButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.backView addSubview:self.rightButton];
    
    
    [self makeConstraints];
    [self configureOEMTheme];
}

- (void)configureOEMTheme{
  //  [self configureThemeTag:OEMThemesTag_UIView_Background];
    [self.backView configureThemeTag:OEMThemesTag_UIView_Foreground];


    [self.titleLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.thirdColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.thirdColor
    }];
    
    [self.contentLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.mainTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.mainTextColor
    }];
    
    
    [self.leftButton specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : kBusiness.brandColor
    } lightModeProperties:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : kBusiness.brandColor
    }];
    
    [self.leftButton specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIButton_Background) : kDarkModeLayoutColor.cardBackgroundColor
    } lightModeProperties:@{
        @(OEMThemesTag_UIButton_Background) : kLightModeLayout.cardBackgroundColor
    }];
    
    
    [self.rightButton specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : RGB_HEX(0xFFFFFF)
    } lightModeProperties:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : RGB_HEX(0xFFFFFF)
    }];
    
    
    
}

- (void)makeConstraints{
    
    CGFloat width = SCREEN_WIDTH;
    
    [self.backView mas_makeConstraints:^(MASConstraintMaker *make) {
       // make.height.mas_equalTo(384);
        make.leading.equalTo(self.view);
        make.trailing.equalTo(self.view);
        make.bottom.equalTo(self.view);
    }];
    
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.backView).offset(30);
        make.leading.equalTo(self.backView).offset(40);
        make.trailing.equalTo(self.backView).offset(-40);
    }];
    
    [self.closeButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.trailing.equalTo(self.backView.mas_trailing).offset(-16);
        make.centerY.mas_equalTo(self.titleLabel);
        make.width.mas_equalTo(20);
        make.height.mas_equalTo(20);
    }];
    
    
    
    [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleLabel.mas_bottom).offset(35);
        make.centerX.mas_equalTo(self.backView);
    }];
    

    [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.imageView.mas_bottom).offset(38);
        make.leading.equalTo(self.backView).offset(24);
        make.trailing.equalTo(self.backView).offset(-24);
    }];

   
    
    CGFloat leftW = (width) * 0.5 - 53;
    CGRect leftLabelTitleSize = [self.leftButtonTitle boundingRectWithSize:CGSizeMake(leftW, 200)
                                                                   options:NSStringDrawingUsesLineFragmentOrigin
                                                                attributes:@{NSFontAttributeName:kRegularFont(18)} context:nil];
    CGFloat leftHeiht = leftLabelTitleSize.size.height;
    if (leftHeiht <= 44) {
        leftHeiht = 44;
    }else{
        leftHeiht = leftHeiht + 20;
    }
    
    
    
    CGFloat rightW = (width) * 0.5 - 53;
    CGRect rightLabelTitleSize = [self.rightButtonTitle boundingRectWithSize:CGSizeMake(rightW, 200)
                                                                     options:NSStringDrawingUsesLineFragmentOrigin
                                                                  attributes:@{NSFontAttributeName:kRegularFont(18)} context:nil];
    CGFloat rightHeiht = rightLabelTitleSize.size.height;
    if (rightHeiht <= 44) {
        rightHeiht = 44;
    }else{
        rightHeiht = rightHeiht + 20;
    }
    
    CGFloat commomHeight = MAX(leftHeiht, rightHeiht);
    self.leftButton.layer.cornerRadius = commomHeight * 0.5;
    [self.leftButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentLabel.mas_bottom).offset(30);
        make.leading.mas_equalTo(self.backView.mas_leading).offset(47.5);
        make.trailing.mas_equalTo(self.backView.mas_centerX).offset(-6);
        make.height.mas_equalTo(commomHeight);
    }];
    
    self.rightButton.layer.cornerRadius = commomHeight * 0.5;
    [self.rightButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentLabel.mas_bottom).offset(30);
        make.leading.mas_equalTo(self.backView.mas_centerX).offset(6);
        make.trailing.mas_equalTo(self.backView.mas_trailing).offset(-47.5);
        make.height.mas_equalTo(commomHeight);
    }];
   

    [self.backView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.leftButton.mas_bottom).offset(44);
    }];
    

}


-(void)clickButton:(UIButton*)sender{
    [self dismissViewControllerAnimated:NO completion:nil];
   if (sender == self.leftButton) {
       safeCallBlock(self.cancelBlock);
   }else if (sender == self.rightButton){
       safeCallBlock(self.setBlock);
   }else{}
}


@end
