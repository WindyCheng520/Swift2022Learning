//  
//  MSBLEGuideViewController.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/14
//  Copyright © 2020 Midea. All rights reserved.
//   
   
#import <MSBusiness/MVPViewController.h>
#import <MSBusiness/MSDeviceConnectResult.h>
#import "MSBLEScanPresenter.h"
#import "MSAuthorizePresenter.h"

@interface MSBLEGuideViewController : MVPViewController<MSAuthorizePresenter *><MSAuthorizeViewProtocol>

@property (nonatomic, strong) MSDeviceConnectResult *connectInfo;

@property (nonatomic, assign) BOOL auxi;


@end
