//
//  MSDeviceConnectNetGuildeViewController.m
//  MSDevice
//
//  Created by syp on 2020/6/23.
//  点击首页添加设备进入 配网指引页面

#import "MSDeviceConnectNetGuildeViewController.h"
#import "MSDeviceBundle.h"
#import "MSChooseDeviceTypeViewController.h"
#import <MSBusiness/MSLocationManager.h>
#import "MSAddDeviceProgressViewController.h"


static NSString * const MSDeviceConnectNetGuildeTableViewCellIdentifier = @"MSDeviceConnectNetGuildeTableViewCellIdentifier";

@interface MSDeviceConnectNetGuildeHeadView : HGView


@end

@interface MSTipsItem : NSObject

@property (nonatomic, copy) NSString *icon;
@property (nonatomic, copy) NSString *title;


@end

@interface MSDeviceConnectNetGuildeTableViewCell : HGTableViewCell

@property (nonatomic, strong) MSTipsItem *item;

@end


@interface MSDeviceConnectNetGuildeViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) MSDeviceConnectNetGuildeHeadView *headView;
@property (nonatomic, strong) HGTableView *tableView;
@property (nonatomic, strong) NSArray<MSTipsItem *> *items;
@property (nonatomic, strong) HGButton *gotButton;


@end

@implementation MSDeviceConnectNetGuildeViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.headView = [MSDeviceConnectNetGuildeHeadView new];
        self.tableView = [HGTableView new];
        self.gotButton = [HGButton new];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    [self createLeftButtonWithImage:MSResourceImage(@"nav_close_black")];
    
    self.headView.bounds = CGRectMake(0, 0, SCREEN_WIDTH, 180);
    self.tableView.tableHeaderView = self.headView;
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
//    self.tableView.rowHeight = 66;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 66;
    [self.tableView registerClass:[MSDeviceConnectNetGuildeTableViewCell class] forCellReuseIdentifier:MSDeviceConnectNetGuildeTableViewCellIdentifier];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:self.tableView];
    
    self.gotButton.backgroundColor = RGB_HEX(0xEC1C24);
    self.gotButton.layer.cornerRadius = 22;
    [self.gotButton setTitle:MSResourceString(@"home_get_it") forState:UIControlStateNormal];
    [self.gotButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
    self.gotButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    [self.gotButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.gotButton];
    self.gotButton.layer.shadowColor = RGBA_HEX(0xEC1C24, 0.25f).CGColor;
    self.gotButton.layer.shadowOffset = CGSizeMake(0,2);
    self.gotButton.layer.shadowOpacity = 1;
    self.gotButton.layer.shadowRadius = 10;
    self.gotButton.layer.shadowPath = [UIBezierPath bezierPathWithRect:CGRectMake(0, 0, SCREEN_WIDTH-30*2, 44)].CGPath;
    
    [self makeConstraints];
    [self loadData];

}

-(void)makeConstraints{
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.equalTo(self.view);
        make.top.mas_equalTo(STATUSBAR_HEIGHT+44);
        make.bottom.equalTo(self.gotButton.mas_top).offset(-15);
    }];
    [self.gotButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.view).offset(30);
        make.trailing.equalTo(self.view).offset(-30);
        make.height.mas_equalTo(44);
        make.bottom.equalTo(self.view).offset(-kSafeAreaBottom-30);
    }];
}

-(void)loadData{
    MSTipsItem* item1 = [MSTipsItem new];
    item1.icon = @"guide_ic_near";
    item1.title = MSResourceString(@"guide_standing_device");
    
    MSTipsItem* item2 = [MSTipsItem new];
    item2.icon = @"guide_ic_WiFi";
    item2.title = MSResourceString(@"guide_wifi_stay_connected");
    
    MSTipsItem* item3 = [MSTipsItem new];
    item3.icon = @"guide_ic_password";
    item3.title = MSResourceString(@"guide_have_wif_passwoed");
    
    self.items = @[item1, item2, item3];
    [self.tableView reloadData];
}

- (void)clickButton:(UIButton*)sender{
    //删除定位权限检查
//    if (@available(iOS 13.0, *)) {
//        if ([[MSLocationManager shareManager] locationOpen]) {
//            MSChooseDeviceTypeViewController* chooseDeviceTypeViewController = [[MSChooseDeviceTypeViewController alloc]init];
//            [self.navigationController pushViewController:chooseDeviceTypeViewController animated:YES];
//        } else {
//            [[MSLocationManager shareManager] showLocationAuthorAlert];
//        }
//    } else {
        MSChooseDeviceTypeViewController* chooseDeviceTypeViewController = [[MSChooseDeviceTypeViewController alloc]init];
        [self.navigationController pushViewController:chooseDeviceTypeViewController animated:YES];
//    }
    
}

#pragma mark - UITableViewDelegate, UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.items.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MSDeviceConnectNetGuildeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MSDeviceConnectNetGuildeTableViewCellIdentifier forIndexPath:indexPath];
    if (indexPath.row < self.items.count) {
        cell.item = [self.items objectAtIndex:indexPath.row];
    }
    return cell;
}



@end

@interface MSDeviceConnectNetGuildeHeadView ()

@property (nonatomic, strong) HGLabel *titleLabel;
@property (nonatomic, strong) HGLabel *subtitleLabel;


@end

@implementation MSDeviceConnectNetGuildeHeadView
-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.titleLabel = [HGLabel labelWithFont:[UIFont boldSystemFontOfSize:21] text:MSResourceString(@"guide_tips_title") textColor:RGB_HEX(0x000000)];
        self.titleLabel.numberOfLines = 0;
        [self addSubview:self.titleLabel];
        
        self.subtitleLabel = [HGLabel labelWithFont:[UIFont systemFontOfSize:14] text:MSResourceString(@"guide_confirm_that") textColor:RGB_HEX(0x000000)];
        self.subtitleLabel.numberOfLines = 0;
        [self addSubview:self.subtitleLabel];
        
        [self makeContstraints];
    }
    return self;
}

-(void)makeContstraints{
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self).offset(60);
        make.trailing.equalTo(self).offset(-60);
        make.top.mas_equalTo(40);
    }];
    [self.subtitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleLabel.mas_bottom).offset(8);
        make.leading.equalTo(self.titleLabel);
        make.trailing.equalTo(self.titleLabel);
    }];
}


@end

@implementation MSTipsItem



@end

@interface MSDeviceConnectNetGuildeTableViewCell ()

@property (nonatomic, strong) HGImageView *iconImageView;
@property (nonatomic, strong) HGLabel *titleLabel;


@end

@implementation MSDeviceConnectNetGuildeTableViewCell
-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        self.iconImageView = [HGImageView new];
        [self.contentView addSubview:self.iconImageView];
        
        self.titleLabel = [HGLabel new];
        self.titleLabel.textColor = RGB_HEX(0x000000);
        self.titleLabel.font = [UIFont systemFontOfSize:14];
        self.titleLabel.numberOfLines = 0;
        [self.contentView addSubview:self.titleLabel];
        
        [self makeContstraints];
    }
    return self;
}

-(void)makeContstraints{
    [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(32, 32));
        make.leading.equalTo(self.contentView).offset(60);
        make.centerY.equalTo(self.titleLabel.mas_centerY);
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.iconImageView.mas_trailing).offset(20);
        make.trailing.equalTo(self.contentView).offset(-60);
        make.top.equalTo(self.contentView);
        make.bottom.equalTo(self.contentView).offset(-30);
        make.height.mas_greaterThanOrEqualTo(32);
    }];
}

-(void)setItem:(MSTipsItem *)item{
    self.iconImageView.image = MSResourceImage(item.icon);
    self.titleLabel.text = item.title;
}

@end


