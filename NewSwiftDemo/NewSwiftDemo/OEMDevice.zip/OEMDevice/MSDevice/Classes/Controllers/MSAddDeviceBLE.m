//  
//  MSAddDeviceBLE.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/31
//  Copyright © 2020 Midea. All rights reserved.
//   


#import "MSAddDeviceBLE.h"
#import <OEMFoundation/OEMMacros.h>
//#import <MSmartOverseaSDK/MSmartSDK.h>
#import "MSAddDeviceCloudRepository.h"
#import "MSDeviceBundle.h"
#import <OEMBluetooth/MSOEMDeviceManager.h>
#import <MSBusiness/MSUserInfoManager.h>
#import <MSBusiness/MSAppInfo.h>
#import <OEMBluetooth/MSOEMBleError.h>
#import <OEMFoundation/HGInternationalization.h>
#import <MSDevice/MSDevice-Swift.h>
#import <OEMFoundation/OEMCustomize.h>




//static const NSInteger MSBLEPasswordWrongCode = 114094;

//UI步骤
typedef NS_ENUM(NSInteger, MSBLEStepType) {
    MSBLEStepTypeNetPrepare = 0,
    MSBLEStepTypeDeviceNetworking,
    MSBLEStepTypeBindAccount
};

//实际进度步骤
typedef NS_ENUM(NSInteger, MSAddBLEDeviceStage) {
    MSAddBLEDeviceStageConnectBLE ,//APP连接设备热点 10S
    MSAddBLEDeviceStageSetWiFiInfo ,//APP与模组建立连接+传输信息至设备 12S
    MSAddBLEDeviceStageBindUser,//绑定到用户2S
};

@interface MSAddDeviceBLE ()

/// 进度条定时器
@property (nonatomic, strong) dispatch_source_t timer;

@property (nonatomic, assign) MSBLEStepType currentStep;

@property (nonatomic, assign) MSAddBLEDeviceStage addDeviceStage;

@property (nonatomic, assign) NSInteger progressCounter;

@property (nonatomic, assign) BOOL haveSuspend;


///随机数
@property (nonatomic, copy) NSString *randomCode;
///udp版本
@property (nonatomic, copy) NSString *udpVersion;

/// 是否重试 第一次绑定失败后 增加一次绑定操作
@property (nonatomic, assign) BOOL isRetry;


///重试查询绑定的结果次数
@property (nonatomic, assign) NSUInteger repeatCount; //重复3次（15秒）



@end

@implementation MSAddDeviceBLE
@synthesize msDelegete = _msDelegete;
@synthesize msConnectType = _msConnectType;
@synthesize deviceCategory = _deviceCategory;
@synthesize wifiSsid = _wifiSsid;
@synthesize wifiBssid = _wifiBssid;
@synthesize deviceSsid = _deviceSsid;
@synthesize wifiPassword = _wifiPassword;
@synthesize deviceSn = _deviceSn;
@synthesize deviceSubType = _deviceSubType;
@synthesize deviceId = _deviceId;
@synthesize deviceName = _deviceName;
@synthesize productCode = _productCode;
@synthesize productId = _productId;
@synthesize deviceMac = _deviceMac;
@synthesize peripheral = _peripheral;
@synthesize countryChannel = _countryChannel;


@synthesize firmwareVersion = _firmwareVersion;
@synthesize thingCode = _thingCode;
@synthesize deviceSn8 = _deviceSn8;
@synthesize deviceType = _deviceType;

- (void)msAddDeviceCancel {
    [self destroyTimer];
    [[MSOEMDeviceManager sharedManager] disconnect:self.peripheral];
    if ([self.msDelegete respondsToSelector:@selector(msAddDeviceCancel:)]) {
        [self.msDelegete msAddDeviceCancel:self];
    }
}

- (void)msAddDeviceStart {
    self.progressCounter = 0;
    self.currentStep = MSBLEStepTypeNetPrepare;
    self.addDeviceStage = MSAddBLEDeviceStageConnectBLE;
    
    CGFloat perSec = 0.22;
    
    if ([self.msDelegete respondsToSelector:@selector(msAddDeviceStart:)]) {
        [self.msDelegete msAddDeviceStart:self];
    }
    
    self.isRetry = YES;
    self.repeatCount = 0;
    [self msConnectDevice];
    
    
    self.haveSuspend = NO;
    @weakify(self)
    self.timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0));
    dispatch_source_set_timer(self.timer, DISPATCH_TIME_NOW, perSec * NSEC_PER_SEC, 0 * NSEC_PER_SEC);
    dispatch_source_set_event_handler(self.timer, ^{
        dispatch_async(dispatch_get_main_queue(), ^{
            @strongify(self)
            if(!self) return;
            self.progressCounter += 1;
            if (self.progressCounter == 25 && self.addDeviceStage == MSAddBLEDeviceStageConnectBLE) {
                [self suspendTimer];
            }
            
            if (self.progressCounter == 75 && self.addDeviceStage == MSAddBLEDeviceStageSetWiFiInfo) {
                //等于90的时候，需要暂停定时功能
                [self suspendTimer];
            }
            
            if (self.progressCounter > 95 && self.addDeviceStage == MSAddBLEDeviceStageBindUser) {
                [self suspendTimer];
            }
            
            // 更新UI进度
            [self refreshStep];
            
        });
    });
    
    dispatch_resume(self.timer);
}

- (NSArray<NSString *> *)msAddDeviceStepTitles {
    return @[
        MSResourceString(@"add_device_process_page_step_device_preparing"),
        MSResourceString(@"add_device_process_page_step_device_access_network"),
        MSResourceString(@"add_device_process_page_step_account_binding")
    ];
}

#pragma mark - Other

- (void)refreshStep {
    if ([self.msDelegete respondsToSelector:@selector(msAddDeviceRefresh:progress:step:)]) {
        [self.msDelegete msAddDeviceRefresh:self progress:self.progressCounter step:self.currentStep];
    }
}

- (void)suspendTimer {
    if (self.timer && !self.haveSuspend) {
        self.haveSuspend = YES;
        dispatch_suspend(self.timer);
    }
}

- (void)resumeTimer {
    CGFloat perSec =   0.22;
    
    if (!self.timer) return;
    if (self.haveSuspend) {
        //如果已经暂停了定时功能，这个时候需要重新启动定时器
        dispatch_resume(self.timer);
        self.haveSuspend = NO;
    }
    dispatch_source_set_timer(self.timer, DISPATCH_TIME_NOW, perSec * NSEC_PER_SEC, 0 * NSEC_PER_SEC);
}



- (void)msConnectDevice {
    
    //存量设备开关(默认打开）
    BOOL needToBAndMSmartSdk = YES;
    if ([OEMCustomize getEncryptedStringValueWithKey:@"msClientId"] == nil
        || [OEMCustomize getEncryptedStringValueWithKey:@"msClientSecret"] == nil) {
        needToBAndMSmartSdk = NO;
    }
    BOOL isSdkInited = NO;
    
    if (needToBAndMSmartSdk) {
        isSdkInited = [MSOEMDeviceManager sharedManager].isMSSmartSDKInited;
    }
    

    if (!self.peripheral.isFromMSBLECenter || isSdkInited){
        [self addDevice];
    }else{
        WEAKSELF
        [[ToBAuthAdapter adapter]  updateToBAuth:^(BOOL success,NSDictionary<NSString *,id> * _Nullable dict, NSError *_Nullable error) {
            if (success) {
                [[MSOEMDeviceManager sharedManager] reInitedWithParams:dict completion:^(BOOL success) {
                    if (success) {
                        [weakSelf addDevice];
                    }else{
                        DDLogDeviceInfo(@"再次初始化失败--------------------------------------------------------------------------------");
                        NSError *error = [NSError errorWithDomain:@"SDK没有没有初始化" code:-88 userInfo:nil];
                        if ([weakSelf.msDelegete respondsToSelector:@selector(msAddDeviceFaild:error:)]) {
                            [weakSelf.msDelegete msAddDeviceFaild:self error:error];
                        }
                    }
                }];
            }else{
                DDLogDeviceInfo(@"再次初始化获取token失败--------------------------------------------------------------------------------");
                NSError *error = [NSError errorWithDomain:@"再次获取ToB token失败" code:-77 userInfo:nil];
                if ([self.msDelegete respondsToSelector:@selector(msAddDeviceFaild:error:)]) {
                    [self.msDelegete msAddDeviceFaild:self error:error];
                }
            }
        }];
    }
}



- (void)addDevice {
    DDLogDeviceInfo(@"step 1: start ble connect:wifiSsid=%@, wifiPassword=%@, wifiBssid=%@", self.wifiSsid, self.wifiPassword, self.wifiBssid);
    MSUserInfoManager *manger = [MSUserInfoManager shareManager];
    NSString  *accessToken = manger.loginInfoModel.accessToken;
    NSString *url = [MSAppInfo mucBaseUrl];
    NSString *countryCode = [HGInternationalization sharedInstance].currentCountry.code;
    NSString *mqttBroker = [MSAppInfo awsEndPoint];
    
    @weakify(self)
    [[MSOEMDeviceManager sharedManager] startConfigWithType:OEMNetAccessType_BLE
                                                 peripheral:self.peripheral
                                                routerBSSID:self.wifiBssid
                                                 routerSSID:self.wifiSsid
                                             routerPassword:self.wifiPassword
                                                accessToken:accessToken
                                                        url:url
                                                countryCode:countryCode
                                                 mqttBroker:mqttBroker
                                                   extraDic:self.countryChannel
                                              connectUpdate:^(MSOEMBleConnectStateType status) {
        DDLogDeviceInfo(@"MSOEMBleConnectStateType status:%ld", status);
        @strongify(self)
        if (status == MSOEMBleConnectStepTypeDiscoverCharacteristicsSuccess) {
            DDLogDeviceInfo(@"step 1.1:  ble connect success");
            if (self.progressCounter > 25) {  //防止配网过程中，SDK返回之前的步骤，导致进度条回退
                return;
            }
            self.addDeviceStage = MSAddBLEDeviceStageSetWiFiInfo;
            self.currentStep = MSBLEStepTypeDeviceNetworking;
            self.progressCounter = 25;
            [self refreshStep];
            [self resumeTimer];
        }else if (status >= MSOEMBleConnectStepTypeFindDeviceInCloudSuccess) {
            if(self.peripheral.isFromMSBLECenter){
//                if (self.progressCounter > 75) {  //防止配网过程中，SDK返回之前的步骤，导致进度条回退
//                    return;
//                }
                self.addDeviceStage = MSAddBLEDeviceStageBindUser;
                self.currentStep = MSBLEStepTypeBindAccount;
                self.progressCounter = 75;
                [self refreshStep];
                [self resumeTimer];
            }
        }
        
    } completion:^(NSError * _Nonnull error, NSDictionary * _Nullable dict) {
        @strongify(self)
        if (error.code == 0) {
            self.deviceSn8 = dict[@"deviceSn8"];
            self.firmwareVersion = dict[@"firmwareVersion"];
            DDLogDeviceInfo(@"step 3.1: active device success");
            
            if(self.peripheral.isFromMSBLECenter){//MS协议
               // [self updateStepTwoWithProgressCounter:100 dict:dict];
                self.progressCounter = 100;
                self.deviceType = dict[@"deviceType"];
                self.thingCode = dict[@"wifiMac"];
                if ([self.msDelegete respondsToSelector:@selector(msAddDeviceSuccess:)]) {
                    [self.msDelegete msAddDeviceSuccess:self];
                }
            }else{ //新流程
                
                self.progressCounter = 100;
                if (self.timer && self.haveSuspend) {
                    dispatch_resume(self.timer);
                    self.haveSuspend = NO;
                }
                if ([self.msDelegete respondsToSelector:@selector(msAddDeviceSuccess:)]) {
                    [self.msDelegete msAddDeviceSuccess:self];
                }
            }
        } else if (error.code == MSOEMBleErrorTypeSendWifiInfoPasswordError + 110000) {
            [MSAddDeviceCloudRepository reportAddDeviceFailure:dict];
            DDLogDeviceInfo(@"step 2.2: ble connect fail, wifi password");
            //wifi密码错误
            [self suspendTimer];
            if ([self.msDelegete respondsToSelector:@selector(msAddDeviceFaild:error:)]) {
                [self.msDelegete msAddDeviceFaild:self error:error];
            }
        }else if (error.code == 888 ){//连接上路由(网络）成功--->绑定设备
            DDLogDeviceInfo(@"step 2.1: net config success");
            [self updateStepTwoWithProgressCounter:75 dict:dict];
        }else if (error.code == 999 ){//mqtt消息无法收到，主动查询绑定结果
            [self queryBindResult];
        }else {
            
            if ([dict objectForKey:MSOEMBLE_Property_Body]) {
                //如果有MSOEMBLE_Property_Body，才能认为是失败
                [MSAddDeviceCloudRepository reportAddDeviceFailure:dict];
            }else if (error.userInfo && [error.userInfo isKindOfClass:[NSDictionary class]]){ //error.code == 9508:mqtt设备绑定失败，用户token解析错误！
                //mqtt绑定失败或者其他非模组问题
                NSError * jsonErr = nil;
                NSData * data = [NSJSONSerialization dataWithJSONObject:error.userInfo options:0 error:&jsonErr];
                if (data && !jsonErr) {
                    NSString * str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                    if (str) {
                        NSString * fversion = [dict objectForKey:MSOEMBLE_Property_FirmwareVersion];
                        NSString * mac = [dict objectForKey:MSOEMBLE_Property_WIFIMac];
                        NSString * sn8 = [dict objectForKey:MSOEMBLE_Property_SN8];
                        NSString * component = ComposeBLEConfigFailure(fversion,
                                                                       mac,
                                                                       sn8,
                                                                       error.code);
                        NSString *parma = [NSString stringWithFormat:@"wifi==%@,wifiBBSID==%@,password==%@", self.wifiSsid, self.wifiBssid,self.wifiPassword];
                        component = [component stringByAppendingFormat:@"(code:%ld,msg:%@)//%@//", (long)error.code, str, parma];
                        NSDictionary * failure = @{
                            MSOEMBLE_Property_Body: component
                        };
                        [MSAddDeviceCloudRepository reportAddDeviceFailure:failure];
                    }
                }
            }
            DDLogDeviceInfo(@"step 3.3: active (New) device fail: %@ dict:%@", error, dict);
            DDLogDeviceInfo(@"step 2.2: ble config fail: %@", error);
            if ([self.msDelegete respondsToSelector:@selector(msAddDeviceFaild:error:)]) {
                [self.msDelegete msAddDeviceFaild:self error:error];
            }
        }
        
    }];
}

//更新第二步UI
-(void)updateStepTwoWithProgressCounter:(NSInteger)progressCounter
                                   dict:(NSDictionary *)dict{
    self.addDeviceStage = MSAddBLEDeviceStageBindUser;
    self.currentStep = MSBLEStepTypeBindAccount;
    self.progressCounter = progressCounter;
    self.deviceType = dict[@"deviceType"];
    self.deviceSn8 = dict[@"deviceSn8"];
    self.firmwareVersion = dict[@"firmwareVersion"];
    self.thingCode = dict[@"wifiMac"];
    [self refreshStep];
    [self resumeTimer];
}


- (void)msRetryAddDeviceWithNewPassword {
    if (self.progressCounter < 90) {
        [self resumeTimer];
    }
    NSDictionary *dic = @{@"routerPassword":self.wifiPassword? :@""};
    [[MSOEMDeviceManager sharedManager] resumeBLEConfigWithDic:dic peripheral:self.peripheral];
    DDLogDeviceInfo(@"step 2.2: retry ble wifi password");
}

- (void)activeDevice {
    DDLogDeviceInfo(@"step 3: active device");
    @weakify(self)
    [MSAddDeviceCloudRepository activeDeviceWithWiFiMac:self.thingCode
                                             deviceName:self.deviceName
                                             deviceType:self.deviceType
                                              deviceSn8:self.deviceSn8
                                        firmwareVersion:self.firmwareVersion
                                                success:^(NSDictionary *result) {
        @strongify(self)
        DDLogDeviceInfo(@"step 3.1: active device success");
        self.progressCounter = 100;
        if (self.timer && self.haveSuspend) {
            dispatch_resume(self.timer);
            self.haveSuspend = NO;
        }
        if ([self.msDelegete respondsToSelector:@selector(msAddDeviceSuccess:)]) {
            [self.msDelegete msAddDeviceSuccess:self];
        }
        
        
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        if (self.isRetry && error.code == 319000) {
            self.isRetry = NO;
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                @strongify(self)
                DDLogDeviceInfo(@"step 3.2: active device fail, retry");
                [self activeDevice];
            });
            return;
        }
        DDLogDeviceInfo(@"step 3.3: active device fail: %@", error);
        if ([self.msDelegete respondsToSelector:@selector(msAddDeviceFaild:error:)]) {
            [self.msDelegete msAddDeviceFaild:self error:[error NSError]];
        }
    }];
}



//主动查询绑定结果
-(void)queryBindResult{
    DDLogDeviceInfo(@"step 3: uery device bind");
    @weakify(self)
    [MSAddDeviceCloudRepository queryDeviceBindResultWithThingCode:self.thingCode
                                                           success:^(NSArray *list) {
        @strongify(self)
        DDLogDeviceInfo(@"step 3.1: query device bind result: %@", list);
        BOOL hasObject = NO;
        NSDictionary *map = list.firstObject;
        long creatTime = [map[@"createTime"] longValue] / 1000;
        long currenrTime = (long)[[NSDate date] timeIntervalSince1970];   //
        DDLogDeviceInfo(@"step 3.1: query device createTime = %ld:  currentTime = %ld , 差值：%ld", creatTime, currenrTime, currenrTime - creatTime);
        if (map != nil && [map.allKeys containsObject:@"createTime"]) {
            if (currenrTime - creatTime <= 12 ) { //时间差小于12秒才算是本次绑定成功
                hasObject = YES;
            }
        }
        if (list.count > 0 && hasObject) { //有设备(绑定成功）
            DDLogDeviceInfo(@"step 3.1: active device success");
            self.progressCounter = 100;
            if (self.timer && self.haveSuspend) {
                dispatch_resume(self.timer);
                self.haveSuspend = NO;
            }
            if ([self.msDelegete respondsToSelector:@selector(msAddDeviceSuccess:)]) {
                [self.msDelegete msAddDeviceSuccess:self];
            }
        }else{
            if (self.repeatCount < 3) {
                self.repeatCount ++;
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    @strongify(self)
                    DDLogDeviceInfo(@"step 3.2: query device bind result no yet, retry");
                    [self queryBindResult];
                });
                return;
            }
            
            //上报蓝牙连接超时
            NSString * timeoutMsg =  ComposeBLEConfigFailure(self.firmwareVersion,
                                                             self.deviceMac,
                                                             self.thingCode,
                                                             AddBLEDeviceReportFailureCode_Unknow);
            timeoutMsg = [timeoutMsg stringByAppendingString:@"(msg:bindTimeout)"];
            NSDictionary * failure = @{
                MSOEMBLE_Property_Body: timeoutMsg
            };
            [MSAddDeviceCloudRepository reportAddDeviceFailure:failure];
            
            NSError *error = [[NSError alloc] initWithDomain:NSCocoaErrorDomain code:999 userInfo:nil];//绑定失败
            DDLogDeviceInfo(@"step 3.3: query device bind result fai: %@", error);
            if ([self.msDelegete respondsToSelector:@selector(msAddDeviceFaild:error:)]) {
                [self.msDelegete msAddDeviceFaild:self error:error];
            }
        }
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        if (self.repeatCount < 3) {
            self.repeatCount ++;
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                @strongify(self)
                DDLogDeviceInfo(@"step 3.2: query device bind result fail, retry");
                [self queryBindResult];
            });
            return;
        }
        DDLogDeviceInfo(@"step 3.3: query device bind result fai: %@", error);
        if ([self.msDelegete respondsToSelector:@selector(msAddDeviceFaild:error:)]) {
            [self.msDelegete msAddDeviceFaild:self error:[error NSError]];
        }
    }];
}


- (void)destroyTimer {
    DDLogDeviceInfo(@"BLE destroyTimer");
    if (_timer) {
        if (_haveSuspend) {
            dispatch_resume(_timer);
            _haveSuspend = NO;
        }
        dispatch_source_cancel(_timer);
        _timer = nil;
    }
}

- (void)dealloc {
    [self destroyTimer];
    DDLogDeviceInfo(@"BLE dealloc");
}




@end
