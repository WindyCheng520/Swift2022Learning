//
//  MSAuthorizeViewController.h
//  MSDevice
//
//  Created by pactera on 2020/11/25.
//

#import <MSBusiness/MVPViewController.h>
#import "MSAuthorizePresenter.h"
#import <MSBusiness/MSDeviceConnectResult.h>
#import <MSBusiness/MSDeviceCardResult.h>

typedef void (^AuthorizeDismissBlock)(void);
@interface MSAuthorizeViewController : MVPViewController<MSAuthorizePresenter *><MSAuthorizeViewProtocol>

@property (nonatomic, assign) NSInteger enterType;     //1代表配网成功页面进入   2代表首页进入
@property (nonatomic, copy) NSString *applianceId;    //设备id
@property (nonatomic, copy) NSString *code;   //sn8
@property (nonatomic, copy) NSString *category;    //品类
@property (nonatomic, copy) NSString *pluginAddress;    //插件的地址, 首页进入需要
@property (nonatomic, strong) MSDeviceCardResult *cardResult;   //跳转插件页需要

@property (nonatomic, copy)AuthorizeDismissBlock block;      //关闭

@end

