//
//  MSConnectFailedViewController.h
//  MSDevice
//
//  Created by 及时行乐 on 2020/6/24.
//

#import <MSBusiness/MVPViewController.h>
#import "MSConnectWiFiPresenter.h"
#import "MSDeviceConnectResult.h"


@interface MSConnectFailedViewController : MVPViewController<MSConnectWiFiPresenter *>

@property (nonatomic, strong) NSError *error;

@property (nonatomic, strong) MSDeviceConnectResult *connectInfo;

@end

