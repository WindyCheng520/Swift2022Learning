//
//  MSNetworkTipsViewController.m
//  MSDevice
//
//  Created by 及时行乐 on 2020/6/24.
//  tips提示页面

#import "MSNetworkTipsViewController.h"
#import "MSDeviceBundle.h"


@interface MSNetworkTipsViewController ()

@property (nonatomic, strong) HGScrollView *contentView;

@property (nonatomic, copy) NSArray *questionList;
@property (nonatomic, copy) NSArray *answerList;
@property (nonatomic, strong) NSMutableArray *questionViews;
@property (nonatomic, strong) NSMutableArray *answerViews;

@property (nonatomic, assign) MSNetworkTipsType type;

@end

@implementation MSNetworkTipsViewController

- (instancetype)initWithType:(MSNetworkTipsType)type {
    if (self = [super init]) {
        self.type = type;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = MSResourceString(@"config_faildetail_page_title");
    
    self.contentView = [HGScrollView new];
    self.contentView.bounces = NO;
    self.contentView.showsVerticalScrollIndicator = NO;
    self.contentView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:self.contentView];
    
    if (@available(iOS 11.0, *)) {
        self.contentView.contentInsetAdjustmentBehavior = YES;
    } else {
        self.automaticallyAdjustsScrollViewInsets = YES;
    }
    
    if (self.type == MSNetworkTipsTypeWiFi5G) {
        NSString *question1 = MSResourceString(@"config_faildetail_page_2_4_and_5ghz_diff_question");
        NSString *answer1 = MSResourceString(@"config_faildetail_page_2_4_and_5ghz_diff_answer");
        
        NSString *question2 = MSResourceString(@"config_faildetail_page_what_if_5g_not_support");
        NSString *answer2 = MSResourceString(@"config_faildetail_page_what_if_5g_not_support_ans");
        
        NSString *question3 = MSResourceString(@"config_faildetail_page_check_frequency_band");
        NSString *answer3 = MSResourceString(@"config_faildetail_page_check_frequency_band_ways");
        
        self.questionList = @[question1,question2,question3];
        self.answerList = @[answer1,answer2,answer3];
    }else {
        NSString *question1 = MSResourceString(@"config_faildetail_page_second_verify_network_question");
        NSString *answer1 = MSResourceString(@"config_faildetail_page_second_verify_network_answer");
        
        self.questionList = @[question1];
        self.answerList = @[answer1];
    }
    
    if (self.questionList.count != self.answerList.count) {
        return;
    }
    self.questionViews = [NSMutableArray array];
    self.answerViews = [NSMutableArray array];
    
    for (int i = 0; i < self.questionList.count; i++)
    {
        HGLabel *questionLabel = [HGLabel new];
        questionLabel.font = [UIFont fontWithName:@"PingFangSC-Medium" size:14];
        questionLabel.textColor = RGBA_HEX(0x000000, 1);
        questionLabel.text = self.questionList[i];
        questionLabel.numberOfLines = 0;
        [self.contentView addSubview:questionLabel];
        [self.questionViews addObject:questionLabel];
        
        HGLabel *answerLabel = [HGLabel new];
        answerLabel.font = [UIFont fontWithName:@"PingFangSC-Regular" size:14];
        answerLabel.textColor = RGBA_HEX(0x333333, 1);
        answerLabel.text = self.answerList[i];
        answerLabel.numberOfLines = 0;
        [self.contentView addSubview:answerLabel];
        [self.answerViews addObject:answerLabel];
    }
    
    [self makeContstraints];
    
    [self configureOEMTheme];
}

- (void)configureOEMTheme{
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    [self.view configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.contentView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.questionViews enumerateObjectsUsingBlock:^(UILabel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if (![obj isKindOfClass:[UILabel class]]) {
            return;
        }
        [obj configureThemeTag:OEMThemesTag_UILabel_TextColor];
    }];
    
    [self.answerViews enumerateObjectsUsingBlock:^(UILabel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if (![obj isKindOfClass:[UILabel class]]) {
            return;
        }
        [obj configureThemeTag:OEMThemesTag_UILabel_TextColor];
    }];
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        [weakSelf setNav];
    } callImmidiately:YES];
}

- (void)setNav{
    if (OEMThemeIsDarkMode) {
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_dm")];
    }else{
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_lg")];
    }
}

- (void)makeContstraints
{
    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(0);
        make.bottom.leading.trailing.width.equalTo(self.view);
    }];
    
    UIView *lastView = self.contentView;
    for (int i = 0; i < self.questionViews.count; i++)
    {
        HGLabel *questionLabel = self.questionViews[i];
        HGLabel *answerLabel = self.answerViews[i];
        
        [questionLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            if (i == 0) {
                make.top.equalTo(lastView).offset(16);
            }else {
                make.top.equalTo(lastView.mas_bottom).offset(32);
            }
            make.leading.equalTo(self.contentView).offset(16);
            make.trailing.equalTo(self.contentView).offset(-16);
            make.width.equalTo(self.contentView).offset(-32);
        }];
        
        [answerLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(questionLabel.mas_bottom).offset(8);
            make.leading.trailing.width.equalTo(questionLabel);
            if (i == self.questionList.count - 1) {
                make.bottom.lessThanOrEqualTo(self.contentView).offset(-kSafeAreaBottom);
            }
        }];
        
        lastView = answerLabel;
    }
}








@end
