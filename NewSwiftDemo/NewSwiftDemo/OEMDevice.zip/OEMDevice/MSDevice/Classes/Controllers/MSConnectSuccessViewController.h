//
//  MSConnectSuccessViewController.h
//  MSDevice
//
//  Created by 及时行乐 on 2020/6/23.
//

#import <MSBusiness/MVPViewController.h>
#import "MSAddDeviceSuccessPresenter.h"
#import <MSBusiness/MSDeviceConnectResult.h>


@interface MSConnectSuccessViewController : MVPViewController<MSAddDeviceSuccessPresenter *> <MSAddDeviceSuccessViewProtocol>

@property (nonatomic, copy) NSString *applianceId;

@property (nonatomic, copy) NSString *thingCode;

@property (nonatomic, copy) NSString *applianceName;

@property (nonatomic, assign) BOOL isBluetooth;  //是蓝牙配网还是AP

@property (nonatomic, strong) MSDeviceConnectResult *connectInfo;

@property (nonatomic, copy) NSString *sn8;


@end

