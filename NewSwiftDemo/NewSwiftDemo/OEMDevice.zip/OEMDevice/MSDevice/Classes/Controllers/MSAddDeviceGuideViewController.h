//  
//  MSAddDeviceGuideViewController.h
//  Pods
//   
//  Created by 李 燕强 on 2020/8/5
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <MSBusiness/MVPViewController.h>
#import <MSBusiness/MSDeviceConnectResult.h>

@interface MSAddDeviceGuideViewController : MVPViewController

@property (nonatomic, strong) MSDeviceConnectResult *connectInfo;

- (void)changeToAuxi;
- (void)changeToOtherWay;

@end
