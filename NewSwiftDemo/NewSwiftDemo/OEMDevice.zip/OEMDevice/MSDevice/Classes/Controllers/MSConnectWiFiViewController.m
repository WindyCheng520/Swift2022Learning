//
//  MSConnectWiFiViewController.m
//  MSDevice
//
//  Created by 及时行乐 on 2020/6/23.
//  WIFI填写页面

#import "MSConnectWiFiViewController.h"
#import "MSAddDeviceProgressViewController.h"
#import "MSDeviceBundle.h"
//#import "MSConnectSuccessViewController.h"
#import "MSBLEGuideViewController.h"
#import "MSConnectFailedViewController.h"
#import <OEMFoundation/OEMMacros.h>
#import <OEMFoundation/OEMDeviceTool.h>
#import <MSBusiness/MideaTool.h>
#import "MSAddDeviceGuideViewController.h"
#import <MSBusiness/MSLocationManager.h>
#import <MSBusiness/MSSystemPermissionManager.h>
#import <MSBusiness/MSNotificationConst.h>
#import <CoreLocation/CoreLocation.h>
#import <OEMTheme/MSInputView_Private.h>
#import "MSNetworkTipsViewController.h"
#import <MSBusiness/MSUserDefaultTools.h>
#import <MSBusiness/MSBLEManager.h>
#import <MSBusiness/BusinessRequestManager.h>
#import <MSBusiness/MSBusiness-Swift.h>
#import <MSBusiness/BusinessRequestManager.h>
#import <MSBusiness/OEMGlobalUIManager.h>
#import <MSBusiness/OEMBLEAlertViewController.h>
#import "OEMAddDeviceButton.h"
#import "MSConnnectAPViewController.h"
#import "MSBLEGuideViewController.h"

static const NSInteger kTextFieldTag = 5432;

@interface MSConnectWiFiViewController ()<MSInputViewDelegate>


@property (nonatomic, strong) HGLabel *titleLabel;  //请选择设备需要连接的网络
@property (nonatomic, strong) HGLabel *networkTipLabel;  //请先将手机切换至WiFi网络

@property (nonatomic, strong) HGButton *helpButton;      //常见问题

@property (nonatomic, strong) HGImageView *iconImageView;   //路由器图标

@property (nonatomic, strong) HGLabel *warrningDescription;   //仅支持2.4GHz

@property (nonatomic, strong) HGButton *connectButton;
@property (nonatomic, strong) MSInputView *wifiInputView;

@property(strong, nonatomic)HGButton *jumpButton; //跳转设置按钮

@property (nonatomic, strong) MSInputView *passwordInputView;
@property (nonatomic, strong) HGButton *nextButton;          //开始绑定

@property(nonatomic ,strong) UITextField *firstResponderTextField;//记录将要编辑的输入框


@property (nonatomic, strong) HGButton *tipsButton; // @"手动输入Wi-Fi名称，或开启定位权限，以便自动获取附近Wi-Fi设备";

@property (nonatomic, strong) OEMBLEAlertViewController *alertViewController;

@property (nonatomic, strong) OEMAddDeviceButton *addDeviceButton;

@end

@implementation MSConnectWiFiViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        self.titleLabel = [HGLabel new];
        self.networkTipLabel = [HGLabel new];
        self.helpButton = [HGButton new];
        self.iconImageView = [HGImageView new];
        self.warrningDescription = [HGLabel new];
        
        self.connectButton = [HGButton new];
        
        self.wifiInputView = [MSInputView new];
        self.passwordInputView = [MSInputView new];
        self.nextButton = [HGButton new];
        
        self.tipsButton = [HGButton new];
        
        self.presenter = [[MSConnectWiFiPresenter alloc] initWithView:self];
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
#if OEMTHEMEDEBUGMODE
    NSNumber * num = [[NSUserDefaults standardUserDefaults] objectForKey:@"OEMTHEMEDEBUGMODE_wifistatus"];
    if (num.intValue == AFNetworkReachabilityStatusReachableViaWiFi) {
        [self wiFiUIMode];
        [self.presenter setWifiName:@"wtf"];
    }else{
        [self deWiFiUIMode];
    }
    return;
#endif
    if ([BusinessNetWorkTools isNetworkConnectConnectViaWIFI]) {
        [self wiFiUIMode];
    } else {
        [self deWiFiUIMode];
    }
    
    
    if (self.connectInfo.deviceConnectType == MSDeviceConnectTypeHomeAutoFind || self.connectInfo.deviceConnectType == MSDeviceConnectTypeSelectAutoFind) {
        self.addDeviceButton.hidden = YES;
    }
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidBecomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(locationAuthorizationStatusChanged:) name:kMideaLocationAuthorizationStatusDidChangeNotification object:nil];
     [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(bluetoothAuthorizationStatusDidChange:) name:kMideaBluetoothAuthorizationStatusDidChangeNotification object:nil];
    @weakify(self)
    [BusinessNetWorkTools registerListenerWithRefrence:self block:^{
#if OEMTHEMEDEBUGMODE
        //status = AFNetworkReachabilityStatusReachableViaWiFi;
        NSNumber * num = [[NSUserDefaults standardUserDefaults] objectForKey:@"OEMTHEMEDEBUGMODE_wifistatus"];
        if ([num isKindOfClass:[NSNumber class]]) {
            status = num.intValue;
        }
#endif
        @strongify(self)
        if ([BusinessNetWorkTools isNetworkConnectConnectViaWIFI]) {
            [self wiFiUIMode];
        }else{
            [self deWiFiUIMode];
        }
    }];
    
    self.hiddenKeyboardWhenTap = YES;
    [self createLeftButtonWithImage:MSResourceImage(@"nav_close_black")];

    self.titleLabel.textColor = RGB_HEX(0x000000);
    self.titleLabel.font = kSemiboldFont(22);
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.numberOfLines = 0;
    self.titleLabel.text = MSResourceString(@"connect_wifi_page_title");
    [self.view addSubview:self.titleLabel];
    
    self.networkTipLabel.textColor = RGB_HEX(0xFF8225);
    self.networkTipLabel.font = kRegularFont(15);
    self.networkTipLabel.textAlignment = NSTextAlignmentCenter;
    self.networkTipLabel.numberOfLines = 0;
    [self.view addSubview:self.networkTipLabel];
    self.networkTipLabel.text = MSResourceString(@"connect_wifi_page_phone_switch_to_wifi");

    [self.view addSubview:self.helpButton];
    self.helpButton.titleLabel.font = kRegularFont(14);
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:MSResourceString(@"connect_wifi_page_common_problem")];
    NSRange strRange = {0,[str length]};
    [str addAttribute:NSUnderlineStyleAttributeName value:[NSNumber numberWithInteger:NSUnderlineStyleSingle] range:strRange];
    [self.helpButton setAttributedTitle:str forState:UIControlStateNormal];
    [self.helpButton addTarget:self action:@selector(onHelpButton:) forControlEvents:UIControlEventTouchUpInside];
    
    self.iconImageView.image = MSResourceImage(@"add_pic_wifi");
    [self.view addSubview:self.iconImageView];

    self.warrningDescription.text = MSResourceString(@"connect_wifi_page_only_2.4G_supported");
    self.warrningDescription.font = kRegularFont(14);
    [self.view addSubview:self.warrningDescription];
    
    [self.wifiInputView setRightImage:MSResourceImage(@"ic_input_go")];
    [self.wifiInputView setFont:kSemiboldFont(16)];
    [self.wifiInputView setTextColor:RGB_HEX(0x000000)];
    
    //if ([[MSLocationManager shareManager] locationOpen]) {  //开启定位才能点击修改wifi连接
        self.wifiInputView.clickRightButtonBlock = ^{
            @strongify(self)
            [self locationCheck];
        };
     //   [self.wifiInputView addClickEventToTextField];
   // }
    

    self.wifiInputView.delegate = self;
    self.wifiInputView.placeholder = MSResourceString(@"connect_wifi_page_wifi_text_placeholder"); //MSResourceString(@"connect_wifi_page_wifi_name");   //
    [self.view addSubview:self.wifiInputView];
    [self.wifiInputView setTextFieldTag:kTextFieldTag];
    
    self.jumpButton= [HGButton new];
    [self.jumpButton setTitle:@"" forState:UIControlStateNormal];
    self.jumpButton.layer.cornerRadius = 22;
    self.jumpButton.backgroundColor = [UIColor clearColor];
    [self.jumpButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.wifiInputView addSubview:self.jumpButton];
   
    
    
    
    [self.passwordInputView setRightImage:MSResourceImage(@"ic_input_view")];
    [self.passwordInputView setFont:kSemiboldFont(16)];
    [self.passwordInputView setTextColor:RGB_HEX(0x000000)];
    self.passwordInputView.secureTextEntry = YES;
    self.passwordInputView.clickRightButtonBlock = ^{
        @strongify(self)
        if (self.passwordInputView.isSecureTextEntry) {
            self.passwordInputView.secureTextEntry = NO;
            [self.passwordInputView setRightImage:MSResourceImage(@"ic_input_view_s")];
        } else {
            self.passwordInputView.secureTextEntry = YES;
            [self.passwordInputView setRightImage:MSResourceImage(@"ic_input_view")];
        }
    };
    self.passwordInputView.delegate = self;
    self.passwordInputView.placeholder = MSResourceString(@"connect_wifi_page_wifi_password_tip");
    [self.view addSubview:self.passwordInputView];
    [self.passwordInputView setTextFieldTag:kTextFieldTag+1];
    
    [self.nextButton setTitle:MSResourceString(@"connect_wifi_page_start_bind") forState:UIControlStateNormal];
    [self.nextButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
    self.nextButton.titleLabel.font = kRegularFont(18);
    self.nextButton.layer.cornerRadius = 22;
    self.nextButton.backgroundColor = RGBA_HEX(0xEC1C24 ,0.3);
    self.nextButton.enabled = NO;
    [self.view addSubview:self.nextButton];
    [self.nextButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
        
    
    [self.connectButton setTitle:MSResourceString(@"connect_wifi_page_connect_button") forState:UIControlStateNormal];
    [self.connectButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
    self.connectButton.titleLabel.font = kRegularFont(18);
    self.connectButton.layer.cornerRadius = 22;
    self.connectButton.backgroundColor = RGBA_HEX(0xEC1C24 ,0.3);
    [self.view addSubview:self.connectButton];
    [self.connectButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    
    
    
    
    
    self.tipsButton.titleLabel.lineBreakMode = NSLineBreakByWordWrapping;
    [self.tipsButton setTitle:MSResourceString(@"connect_wifi_page_addition_tips") forState:UIControlStateNormal];
    self.tipsButton.backgroundColor = RGB_HEX(0xFFFBE6);
    [self.tipsButton setTitleColor:kBusiness.orangeColor forState:UIControlStateNormal];
    self.tipsButton.titleEdgeInsets = UIEdgeInsetsMake(0, 9.5, 0, 9.5);
    self.tipsButton.titleLabel.font = kRegularFont(14);
    self.tipsButton.layer.cornerRadius = 6.0;
    self.tipsButton.layer.masksToBounds = YES;
    self.tipsButton.userInteractionEnabled = NO;
    self.tipsButton.hidden = YES;
    [self.view addSubview:self.tipsButton];
    
    if (self.connectInfo.mode.integerValue == 0) {
        self.addDeviceButton = [[OEMAddDeviceButton alloc] initWithFrame:CGRectZero type:ConnectTypeBLE];
        [self.nextButton setTitle:MSResourceString(@"connect_wifi_page_ap_connect_button") forState:UIControlStateNormal];
        
    }else{
        self.addDeviceButton = [[OEMAddDeviceButton alloc] initWithFrame:CGRectZero type:ConnectTypeAP];
        [self.nextButton setTitle:MSResourceString(@"connect_wifi_page_ble_connect_button") forState:UIControlStateNormal];
    }
    
    [self.addDeviceButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.addDeviceButton];
   
    [self makeContstraints];
    
    

    
    //先检查一次定位权限
    [[MSLocationManager shareManager] checkLocationForCurrentWiFi];
    
//    WEAKSELF
//    [MSLocationManager shareManager].inputsBlock = ^{
//
//    };
    
    [self configureOEMTheme];
}

- (void)configureOEMTheme{
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        [weakSelf setNavButton];
    } callImmidiately:YES];
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    [self.view configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.connectButton configureThemeTag:OEMThemesTag_UIButton_Background];
    [self.connectButton configureThemeTag:OEMThemesTag_UIButton_AttributedTraitColor];
    
    [self.nextButton configureThemeTag:OEMThemesTag_UIButton_Background];
    [self.nextButton configureThemeTag:OEMThemesTag_UIButton_AttributedTraitColor];
    
    [self.titleLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
    
    [self.networkTipLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
    [self.networkTipLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : RGBA_HEX(0xFFFFFF, 0.4)
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : RGBA_HEX(0x000000, 0.4)
    }];
    
    [self.warrningDescription configureThemeTag:OEMThemesTag_UILabel_TextColor];
    [self.warrningDescription specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : RGBA_HEX(0xFFB51B, 1.0)
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : RGBA_HEX(0xFFB51B, 1.0)
    }];
    [self.wifiInputView.textField configureThemeTag:OEMThemesTag_UITextField_Textcolor];
    [self.passwordInputView.textField configureThemeTag:OEMThemesTag_UITextField_Textcolor];
    [self.helpButton configureThemeTag:OEMThemesTag_UIButton_AttributedThemeColor];
    
    
    
    
    
    
    [self.titleLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.mainTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.mainTextColor
    }];
    
    
    [self.networkTipLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.secondColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.secondColor
    }];
    
    [self.warrningDescription specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kBusiness.orangeColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kBusiness.orangeColor
    }];
    
    
    
    [self.wifiInputView.textField specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UITextField_Textcolor) : kDarkText.mainTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UITextField_Textcolor) : kLightText.mainTextColor
    }];
    
    
    [self.passwordInputView.textField specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UITextField_Textcolor) : kDarkText.mainTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UITextField_Textcolor) : kLightText.mainTextColor
    }];
    
    [self.connectButton specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : RGB_HEX(0xFFFFFF)
    } lightModeProperties:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : RGB_HEX(0xFFFFFF)
    }];
    
    
//    [self.nextButton specialPropertiesForDarkMode:@{
//        @(OEMThemesTag_UIButton_TitleThemeColor) : RGB_HEX(0xFFFFFF)
//    } lightModeProperties:@{
//        @(OEMThemesTag_UIButton_TitleThemeColor) : RGB_HEX(0xFFFFFF)
//    }];
    
    [self.tipsButton specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : kBusiness.orangeColor
    } lightModeProperties:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : kBusiness.orangeColor
    }];
}

-(OEMBLEAlertViewController *)alertViewController{
    if (!_alertViewController) {
        _alertViewController = [[OEMBLEAlertViewController alloc] init];
        _alertViewController.modalPresentationStyle =  UIModalPresentationOverFullScreen;
    }
    return  _alertViewController;
}


- (void)setNavButton{
    if (OEMThemeIsDarkMode) {
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_dm")];
    }else{
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_lg")];
    }
    
    if (OEMThemeIsDarkMode) {
        self.wifiInputView.placeholderColor = kDarkText.tipsColor;
        self.passwordInputView.placeholderColor = kDarkText.tipsColor;
    }else{
        self.wifiInputView.placeholderColor = kLightText.tipsColor;
        self.passwordInputView.placeholderColor = kLightText.tipsColor;
    }
}

- (void)wiFiUIMode {
    //有网络，可输入Wi-Fi密码
    self.titleLabel.hidden = NO;
    self.networkTipLabel.hidden = NO;
    self.helpButton.hidden = NO;
    
    self.wifiInputView.hidden = NO;
    self.passwordInputView.hidden = NO;
    self.nextButton.hidden = NO;

    self.connectButton.hidden = YES;
    self.addDeviceButton.hidden = NO;
    
    NSString *wifiSsid = [OEMDeviceTool currentWifiSSID];
    if (wifiSsid && ![wifiSsid isEqualToString:@""]) {
        self.wifiInputView.text = wifiSsid;
        self.presenter.wifiName = wifiSsid;
        NSString *password = [self.presenter fetchPasswordWithSsid:wifiSsid];
        if(password.length > 0){
        self.passwordInputView.text = password;
        self.presenter.wifiPassword = password;
        }
    }
    if (self.connectInfo.deviceConnectType == MSDeviceConnectTypeHomeAutoFind || self.connectInfo.deviceConnectType == MSDeviceConnectTypeSelectAutoFind) {
        self.addDeviceButton.hidden = YES;
    }
}

- (void)deWiFiUIMode {
    //无网络，提示连接
    self.titleLabel.hidden = NO;
    self.networkTipLabel.hidden = NO;
    self.helpButton.hidden = YES;
    
    self.wifiInputView.hidden = YES;
    self.passwordInputView.hidden = YES;
    self.nextButton.hidden = YES;
    
    self.connectButton.hidden = NO;
    self.addDeviceButton.hidden = YES;
    
    if (self.connectInfo.deviceConnectType == MSDeviceConnectTypeHomeAutoFind || self.connectInfo.deviceConnectType == MSDeviceConnectTypeSelectAutoFind) {
        self.addDeviceButton.hidden = YES;
    }
}

- (void)makeContstraints {
    
    [self.titleLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleLabel.superview).offset(10);
        make.leading.mas_equalTo(61);
        make.trailing.mas_equalTo(-61);
    }];
    
    [self.networkTipLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleLabel.mas_bottom).offset(5);
        make.leading.mas_equalTo(47.5);
        make.trailing.mas_equalTo(-47.5);
    }];
    
    [self.helpButton mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.networkTipLabel.mas_bottom).offset(10);
        make.centerX.equalTo(self.view);
        make.height.mas_equalTo(14);
    }];
    
    [self.iconImageView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.top.equalTo(self.helpButton.mas_bottom).offset(25);
        make.size.mas_equalTo(CGSizeMake(240, 80));
    }];
    
    [self.warrningDescription mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.iconImageView.mas_bottom).offset(10);
        make.centerX.equalTo(self.view);
    }];

    [self.wifiInputView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.warrningDescription.mas_bottom).offset(30);
        make.leading.mas_equalTo(16);
        make.trailing.mas_equalTo(-16);
        make.height.mas_equalTo(44);
    }];
    
    [self.jumpButton mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.wifiInputView.mas_top).offset(0);
        make.trailing.mas_equalTo(self.wifiInputView.mas_trailing).offset(0);
        make.height.mas_equalTo(44);
        make.width.mas_equalTo(60);
    }];
    
    
    [self.passwordInputView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.wifiInputView.mas_bottom).offset(10);
        make.leading.mas_equalTo(16);
        make.trailing.mas_equalTo(-16);
        make.height.mas_equalTo(44);
    }];
    [self.nextButton mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.passwordInputView.mas_bottom).offset(30);
        make.leading.mas_equalTo(16);
        make.trailing.mas_equalTo(-16);
        make.height.mas_equalTo(44);
    }];
    
    
    CGFloat w = self.view.frame.size.width;
    CGRect labelTitleSize = [MSResourceString(@"connect_wifi_page_addition_tips") boundingRectWithSize:CGSizeMake(w -32, 1000)
                                                                                               options:NSStringDrawingUsesLineFragmentOrigin
                                                                                            attributes:@{NSFontAttributeName:kRegularFont(14)} context:nil];
    
    
    [self.tipsButton mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.nextButton.mas_bottom).offset(15);
        make.leading.mas_equalTo(16);
        make.trailing.mas_equalTo(-16);
        make.height.mas_equalTo(labelTitleSize.size.height + 10);
    }];
    

    
    
    [self.connectButton mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.warrningDescription.mas_bottom).offset(90);
        make.leading.mas_equalTo(16);
        make.trailing.mas_equalTo(-16);
        make.height.mas_equalTo(44);
    }];
    
    
    
    [self.addDeviceButton mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.view.mas_bottom).offset(-49);
        make.leading.mas_equalTo(16);
        make.trailing.mas_equalTo(-16);
        //make.height.mas_equalTo(44);
    }];
    
}

- (void)leftBarButtonClick:(UIButton *)button {
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (void)clickButton:(UIButton *)sender {
    if(![[MSLocationManager shareManager] checkLocationForCurrentWiFi]) return;
    
    if (sender == self.jumpButton) {
        [[MSSystemPermissionManager shareManager] jumpToSystemAppSettingPage];
        return;
    }
    
    if (sender == self.addDeviceButton) {
        
        if (/*self.passwordInputView.text.length > 0 && */self.wifiInputView.text.length == 0) { //产品定义可以手动输入wifi
            [self toastText:MSResourceString(@"connect_wifi_page_wifi_text_placeholder")];
            return;
        }
        
        if (/*self.passwordInputView.text.length > 0 && */self.passwordInputView.text.length < 8) { //产品定义不允许不需要密码的路由器wifi
            [self toastText:MSResourceString(@"config_fail_wifi_password_length")];
            return;
        }
        
        if (self.connectInfo.mode.integerValue == 3) {//当前AP配网（反向切换后为蓝牙）
            [self pushToAPConnect];
        }else{//当前蓝牙配网（反向切换后为AP)
            
            if ([[MSBLEManager shareManager] checkBluetoothAuthState] != MSBLEManagerTypeAuthorizedAndTurnOn){
             //   [[MSBLEManager shareManager] showBluetoothAuthorAlert];
                
                self.alertViewController = [[OEMBLEAlertViewController alloc] init];
                self.alertViewController.modalPresentationStyle =  UIModalPresentationOverFullScreen;
                self.alertViewController.isAuthorized = ([[MSBLEManager shareManager] checkBluetoothAuthState] <= MSBLEManagerTypeAuthorized);
                self.alertViewController.isOpen = NO;
                self.alertViewController.hasNoTryButton = YES;
                self.alertViewController.setBlock = ^{
                    //跳转到app的系统设置页面
                    [[MSSystemPermissionManager shareManager] jumpToSystemAppSettingPage];
                };
                
                self.alertViewController.openBlock = ^{
                    //跳转到app的系统设置页面
                    [[MSSystemPermissionManager shareManager] jumpToSystemAppSettingPage];
                };
                
                WEAKSELF
                self.alertViewController.switchBlock = ^{
                    [weakSelf pushToAPConnect];
                };
                [self presentViewController:self.alertViewController animated:NO completion:nil];
                return;
            }else{
                
                MSBLEGuideViewController *dest = [[MSBLEGuideViewController alloc] init];
                MSDeviceConnectResult *connectInfo = [[MSDeviceConnectResult alloc] init];
                connectInfo.category = self.connectInfo.category;
                connectInfo.deviceConnectType =  self.connectInfo.deviceConnectType;
                connectInfo.deviceName =  self.connectInfo.deviceName;
                connectInfo.deviceImageUrl = self.connectInfo.deviceImageUrl;
                
                connectInfo.wifiSsid = self.wifiInputView.text;
                connectInfo.wifiPassword = self.passwordInputView.text?:@"";
                connectInfo.wifiBssid = [MideaTool currentWifiBSSID];
                connectInfo.deviceSsid = self.connectInfo.deviceSsid;
                connectInfo.mode = @"3";
                dest.connectInfo = connectInfo;
                [self.navigationController pushViewController:dest animated:YES];
            }
            
            
        }
        return;
    }
    
    if (sender == self.connectButton) {
        [[MSSystemPermissionManager shareManager] jumpToSystemSettingPage];
    } else if (sender == self.nextButton) {
        
//        //================
//        self.connectInfo.wifiSsid = @"OEM_solutions_libo";
//        self.connectInfo.wifiPassword = @"test123456";
//        self.connectInfo.wifiBssid = @"00:00:00:00:00:00";
//        MSAddDeviceProgressViewController *test = [[MSAddDeviceProgressViewController alloc] init];
//        test.connectInfo = self.connectInfo;
//        [self.navigationController pushViewController:test animated:YES];
//
//        return;
        
        //======================
        
        if (/*self.passwordInputView.text.length > 0 && */self.wifiInputView.text.length == 0) { //产品定义可以手动输入wifi
            [self toastText:MSResourceString(@"connect_wifi_page_wifi_text_placeholder")];
            return;
        }
        
        if (/*self.passwordInputView.text.length > 0 && */self.passwordInputView.text.length < 8) { //产品定义不允许不需要密码的路由器wifi
            [self toastText:MSResourceString(@"config_fail_wifi_password_length")];
            return;
        }
        
        self.connectInfo.wifiSsid = self.wifiInputView.text;
        self.connectInfo.wifiPassword = self.passwordInputView.text?:@"";
        self.connectInfo.wifiBssid = [MideaTool currentWifiBSSID];
        
        //--------------------//由蓝牙切换回AP配网
        if((self.connectInfo.mode.integerValue == 0) /*&& (self.connectInfo.deviceConnectType == MSDeviceConnectTypeAP)*/){
            [self pushToAPConnect];
            return;
        }
        //--------------------//由蓝牙切换回AP配网
        
        
        if ([[MSBLEManager shareManager] checkBluetoothAuthState] != MSBLEManagerTypeAuthorizedAndTurnOn){
         //   [[MSBLEManager shareManager] showBluetoothAuthorAlert];
            
            self.alertViewController = [[OEMBLEAlertViewController alloc] init];
            self.alertViewController.modalPresentationStyle =  UIModalPresentationOverFullScreen;
            self.alertViewController.isAuthorized = ([[MSBLEManager shareManager] checkBluetoothAuthState] <= MSBLEManagerTypeAuthorized);
            self.alertViewController.isOpen = NO;
            self.alertViewController.setBlock = ^{
                //跳转到app的系统设置页面
                [[MSSystemPermissionManager shareManager] jumpToSystemAppSettingPage];
            };
            
            self.alertViewController.openBlock = ^{
                //跳转到app的系统设置页面
                [[MSSystemPermissionManager shareManager] jumpToSystemAppSettingPage];
            };
            
            WEAKSELF
            self.alertViewController.switchBlock = ^{
                [weakSelf pushToAPConnect];
            };
            [self presentViewController:self.alertViewController animated:NO completion:nil];
            return;
        }
        
        
        //自发现不需要经过配网指引页
        if (self.connectInfo.deviceConnectType == MSDeviceConnectTypeHomeAutoFind || self.connectInfo.deviceConnectType == MSDeviceConnectTypeSelectAutoFind) {
            MSAddDeviceProgressViewController *dest = [[MSAddDeviceProgressViewController alloc] init];
            dest.connectInfo = self.connectInfo;
            [self.navigationController pushViewController:dest animated:YES];
        }else{
            MSBLEGuideViewController *dest = [[MSBLEGuideViewController alloc] init];
            dest.connectInfo = self.connectInfo;
            [self.navigationController pushViewController:dest animated:YES];
        }
        
     
        MSUrlEnvironmentType type = [MSUserDefaultTools getUrlEnvironmentType];
        if (type == MSUrlEnvironmentTypeDev) {
            [self.presenter saveSsid:self.wifiInputView.text password:self.passwordInputView.text?:@""];  //暂不保存wifi 密码
        }
        return;//---- OEM注释掉配网指引。
        MSAddDeviceGuideViewController *guide = [[MSAddDeviceGuideViewController alloc] init];
        self.connectInfo.wifiSsid = self.wifiInputView.text;
        self.connectInfo.wifiPassword = self.passwordInputView.text?:@"";
        self.connectInfo.wifiBssid = [MideaTool currentWifiBSSID];
        guide.connectInfo = self.connectInfo;
        [self.navigationController pushViewController:guide animated:YES];
     //   [self.presenter saveSsid:self.wifiInputView.text password:self.passwordInputView.text?:@""]; //暂不保存wifi 密码
        
    }
}

//跳转AP配网
-(void)pushToAPConnect{
    
    if(![[MSLocationManager shareManager] checkLocationForCurrentWiFi]) return;
    MSBLEGuideViewController *dest = [[MSBLEGuideViewController alloc] init];
    
    //指针传递修复
    MSDeviceConnectResult *connectInfo = [[MSDeviceConnectResult alloc] init];
    connectInfo.category = self.connectInfo.category;
    connectInfo.deviceConnectType =  self.connectInfo.deviceConnectType;
    connectInfo.deviceName =  self.connectInfo.deviceName;
    connectInfo.deviceImageUrl = self.connectInfo.deviceImageUrl;
    connectInfo.wifiSsid = self.wifiInputView.text;
    connectInfo.wifiPassword = self.passwordInputView.text?:@"";
    connectInfo.wifiBssid = [MideaTool currentWifiBSSID];
    connectInfo.deviceSsid = self.connectInfo.deviceSsid;
    connectInfo.mode = @"0";
    dest.connectInfo = connectInfo;
    [self.navigationController pushViewController:dest animated:YES];
}

- (void)locationCheck {
    if ([[MSLocationManager shareManager] checkLocationForCurrentWiFi]) {
        [[MSSystemPermissionManager shareManager] jumpToSystemSettingPage];
    }
}


- (void)bluetoothAuthorizationStatusDidChange:(NSNotification *)notification {
    if ([[MSBLEManager shareManager] checkBluetoothAuthState] != MSBLEManagerTypeAuthorizedAndTurnOn){ //未打开
        self.alertViewController.isOpen = NO;
    }else{
        self.alertViewController.isOpen = YES;
    }
    
    if ([[MSBLEManager shareManager] checkBluetoothAuthState] >= MSBLEManagerTypeUnauthorized){ //未授权
        self.alertViewController.isAuthorized = NO;
    }else{
        self.alertViewController.isAuthorized = YES;
    }
    [self.alertViewController refreshUI];
}



#pragma mark - NSNotification
- (void)applicationDidBecomeActive:(NSNotification *)notification {
#if OEMTHEMEDEBUGMODE
    NSNumber * num = [[NSUserDefaults standardUserDefaults] objectForKey:@"OEMTHEMEDEBUGMODE_wifistatus"];
    if (num.intValue == AFNetworkReachabilityStatusReachableViaWiFi) {
        [self wiFiUIMode];
    }else{
        [self deWiFiUIMode];
    }
    return;
#endif
    
//    @weakify(self)
//    if ([[MSLocationManager shareManager] locationOpen]) {  //开启定位才能点击修改链接
//        [self.view endEditing:YES];
//        self.wifiInputView.clickRightButtonBlock = ^{
//            @strongify(self)
//            [self locationCheck];
//        };
//        [self.wifiInputView addClickEventToTextField];
//    }else{
//        NSMutableArray *newges = [NSMutableArray arrayWithArray:self.wifiInputView.textField.gestureRecognizers];
//           for (int i = 0; i < [newges count]; i++) {
//               [self.wifiInputView.textField removeGestureRecognizer:[newges objectAtIndex:i]];
//           }
//        [self.wifiInputView.textField becomeFirstResponder];
//        [self.view endEditing:YES];
//    }
    
    
    if ([BusinessNetWorkTools isNetworkConnectConnectViaWIFI]) {
        [self wiFiUIMode];
    } else {
        [self deWiFiUIMode];
    }
}

- (void)locationAuthorizationStatusChanged:(NSNotification *)notification {
    NSDictionary *userInfo = notification.userInfo;
    int status = [userInfo[@"status"] intValue];
    
    if (status == kCLAuthorizationStatusAuthorizedWhenInUse) {
        NSString *wifiSsid = [OEMDeviceTool currentWifiSSID];
        if (wifiSsid && ![wifiSsid isEqualToString:@""]) {
            self.wifiInputView.text = wifiSsid;
            self.presenter.wifiName = wifiSsid;
            NSString *password = [self.presenter fetchPasswordWithSsid:wifiSsid];
            self.passwordInputView.text = password;
            self.presenter.wifiPassword = password;
        }
    }
}

- (void)keyboardWillShow:(NSNotification *)notification {
    CGFloat moveHeight = self.firstResponderTextField.tag == kTextFieldTag ? 12+44+24+44+10 : 24+44+10;
    
    CGRect rect = [self.firstResponderTextField.superview convertRect:self.firstResponderTextField.frame toView:self.view];//获取相对于self.view的位置
    NSDictionary *userInfo = [notification userInfo];
    NSValue* aValue = [userInfo objectForKey:UIKeyboardFrameEndUserInfoKey];//获取弹出键盘的fame的value值
    CGRect keyboardRect = [aValue CGRectValue];
    keyboardRect = [self.view convertRect:keyboardRect fromView:self.view.window];//获取键盘相对于self.view的frame ，传window和传nil是一样的
    CGFloat keyboardTop = keyboardRect.origin.y;
    NSNumber * animationDurationValue = [userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];//获取键盘弹出动画时间值
    NSTimeInterval animationDuration = [animationDurationValue doubleValue];
    if (keyboardTop < CGRectGetMaxY(rect)) {//如果键盘盖住了输入框
        CGFloat gap = keyboardTop - CGRectGetMaxY(rect) - moveHeight;//计算需要网上移动的偏移量（输入框底部离键盘顶部为10的间距）
        __weak typeof(self)weakSelf = self;
        [UIView animateWithDuration:animationDuration animations:^{
            weakSelf.view.frame = CGRectMake(weakSelf.view.frame.origin.x, gap, weakSelf.view.frame.size.width, weakSelf.view.frame.size.height);
        }];
    }
}

- (void)keyboardWillHide:(NSNotification *)notification {
    NSDictionary *userInfo = [notification userInfo];
    NSNumber * animationDurationValue = [userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];//获取键盘隐藏动画时间值
    NSTimeInterval animationDuration = [animationDurationValue doubleValue];
    if (self.view.frame.origin.y < 0) {//如果有偏移，当影藏键盘的时候就复原
        __weak typeof(self)weakSelf = self;
        [UIView animateWithDuration:animationDuration animations:^{
            weakSelf.view.frame = CGRectMake(weakSelf.view.frame.origin.x, 0, weakSelf.view.frame.size.width, weakSelf.view.frame.size.height);
        }];
    }
}

#pragma mark - MSInputViewDelegate
- (void)inputView:(MSInputView *)inputView didChangeText:(NSString *)text {
    
    if (inputView == self.wifiInputView) {
        self.presenter.wifiName = inputView.text;
    } else if (inputView == self.passwordInputView) {
        self.presenter.wifiPassword = inputView.text;
    }
    
}

//- (void)didClickInputView:(MSInputView *)inputView {
//  //  if ([[MSLocationManager shareManager] locationOpen]){
//        if (inputView == self.wifiInputView) {
//            [self locationCheck];
//        }
//  //  }
//}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    if (textField.tag == kTextFieldTag) {
        self.firstResponderTextField = textField;
        return YES;
     //   return NO;
//        if ([[MSLocationManager shareManager] locationOpen]) { //已开启定位
//            return NO;
//        }else{
//            self.firstResponderTextField = textField;
//            return YES;
//        }
        
        
    } else {
        self.firstResponderTextField = textField;
        return YES;
    }
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
}



//- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
//    NSString *newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
//    newString = [newString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
//   if(textField.tag == kTextFieldTag + 1 && textField.isSecureTextEntry ){//屏蔽密码密文输入状态状态重新编辑清除原有内容
//        textField.text = newString;
//        self.presenter.wifiPassword = newString;
//        return NO;
//    }
//    return YES;
//}


#pragma mark - MSConnectWiFiViewProtocol
- (void)presenter:(MSConnectWiFiPresenter *)presenter didEnableClick:(BOOL)enable {
    if (enable) {
        self.nextButton.backgroundColor = RGBA_HEX(0xEC1C24 ,1);
        self.nextButton.enabled = YES;
    } else {
        self.nextButton.backgroundColor = RGBA_HEX(0xEC1C24 ,0.3);
        self.nextButton.enabled = NO;
    }
    
}

- (void)onHelpButton:(id)sender{
    MSNetworkTipsViewController * helpTipVC = [[MSNetworkTipsViewController alloc] init];
    [self.navigationController pushViewController:helpTipVC animated:YES];
}


@end
