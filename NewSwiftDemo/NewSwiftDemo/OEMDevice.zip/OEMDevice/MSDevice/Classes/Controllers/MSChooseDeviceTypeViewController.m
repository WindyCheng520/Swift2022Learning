//
//  MSChooseDeviceTypeViewController.m
//  MSDevice
//
//  Created by 及时行乐 on 2020/6/23.
//  选择家电类型页面

#import "MSChooseDeviceTypeViewController.h"
#import "MSAddDeviceProgressViewController.h"
#import "MSChooseDeviceModelViewController.h"
#import "MSConnectWiFiViewController.h"
#import "MSAuthorizeViewController.h"
#import "MSBLEGuideViewController.h"

#import <MSBusiness/MSRouterUrl.h>

#import "MSDeviceRouterService.h"
#import "MSDeviceBundle.h"
#import "MSAddDeviceTypes.h"

#import <SDWebImage/UIImageView+WebCache.h>

#import <MSBusiness/MSBLEManager.h>
#import <MSBusiness/MSNotificationConst.h>
#import "MSChooseDeviceTypeCountView.h"
#import "MSChooseDeviceTypeCell.h"
#import "MSChooseDeviceTypeHeadView.h"
#import <MSBusiness/MSSystemPermissionManager.h>
#import <MSBusiness/MSBLEOpenAlertView.h>
#import <MSBusiness/MideaTool.h>
#import <MSBusiness/MSRouterUrl.h>
#import <MSBusiness/MSDeviceProtocol.h>

#import <OEMBluetooth/MSOEMDeviceManager.h>

#import <OEMFoundation/OEMDeviceTool.h>
#import <OEMTheme/OEMHGCollectionViewCell.h>
#import <OEMTheme/UICollectionViewCell+GridStyle.h>
#import <MSBusiness/MSDeviceInfoDisposeTool.h>

#import <MSBusiness/OEMGlobalUIManager.h>

#import "MSConnnectAPViewController.h"
#import <MSBusiness/OEMBLEAlertViewController.h>
#import <MSBusiness/OEMCommomAlertViewController.h>




@interface MSChooseDeviceTypeViewController ()<UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, MSChooseDeviceTypeHeadViewDelegate>

@property (nonatomic, strong) HGCollectionView *collectionView;
@property (nonatomic, strong) MSChooseDeviceTypeCountView *countView;
@property (nonatomic, strong) MSChooseDeviceTypeHeadView *headView;
@property (nonatomic, assign) BOOL isSecondEnter;  //记录是否再次进入此页面

@property (nonatomic, strong) HGButton *scanButton;  //扫码入口
@end

@implementation MSChooseDeviceTypeViewController

#pragma mark - lifecycle
- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.presenter = [[MSChooseDevicePresenter alloc] initWithView:self];
        self.countView = [MSChooseDeviceTypeCountView new];
        self.scanButton = [HGButton new];
        self.collectionView = [[HGCollectionView alloc]initWithFrame:CGRectZero collectionViewLayout:[self collectionViewLayout]];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = MSResourceString(@"add_device_process_page_adding_title");
    self.view.backgroundColor = RGB(250, 250, 250);


    self.scanButton.frame = CGRectMake(0, 0, 24, 24);
    [self.scanButton setBackgroundImage:MSResourceImage(@"ico_sys_qs_44") forState:UIControlStateNormal];
    [self.scanButton addTarget:self action:@selector(clickButton) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *scanItem = [[UIBarButtonItem alloc] initWithCustomView:self.scanButton];
    
    [self.countView addTarget:self action:@selector(clickCountView) forControlEvents:UIControlEventTouchUpInside];
    self.countView.hidden = YES;
    
    UIBarButtonItem *countItem = [[UIBarButtonItem alloc] initWithCustomView:self.countView];
    self.navigationItem.rightBarButtonItems = @[scanItem, countItem];
   // self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.countView];
    
    [self.collectionView registerClass:[MSChooseDeviceTypeCell class] forCellWithReuseIdentifier:NSStringFromClass([MSChooseDeviceTypeCell class])];
    [self.collectionView registerClass:[OEMHGCollectionViewCell class] forCellWithReuseIdentifier:NSStringFromClass([OEMHGCollectionViewCell class])];
    [self.collectionView registerClass:[MSChooseDeviceTypeHeadView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:NSStringFromClass([MSChooseDeviceTypeHeadView class])];
    [self.collectionView registerClass:[MSChooseDeviceTypeCellHeadView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:NSStringFromClass([MSChooseDeviceTypeCellHeadView class])];
    self.collectionView.backgroundColor = [UIColor clearColor];
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;
    self.collectionView.showsVerticalScrollIndicator = NO;
    [self.view addSubview:self.collectionView];
        
    [self makeConstraints];
    
    [self.presenter fetchTypeList];
    [self.presenter getDcpApplianceTypeData];
    [self.presenter getCloudApplianceNameData];

    [[MSBLEManager shareManager] showBluetoothAuthorAlert];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(bluetoothAuthorizationStatusDidChange:) name:kMideaBluetoothAuthorizationStatusDidChangeNotification object:nil];
    
    [self configureOEMTheme];
}

- (void)configureOEMTheme{
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    [self.view configureThemeTag:OEMThemesTag_UIView_Background];
    [self.collectionView configureThemeTag:OEMThemesTag_UIView_Background];
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        [weakSelf setNavButton];
    } callImmidiately:YES];
}

- (void)setNavButton{
    if (OEMThemeIsDarkMode) {
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_dm")];
        [self.scanButton setBackgroundImage:MSResourceImage(@"ic_24_scan_dm") forState:UIControlStateNormal];
    }else{
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_lg")];
        [self.scanButton setBackgroundImage:MSResourceImage(@"ic_24_scan") forState:UIControlStateNormal];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    if (self.isSecondEnter) {
        [self refreshHeadViewWithBluetoothState];
    } else {
        self.isSecondEnter = YES;
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self.presenter viewWillDisappear];
    [self.headView viewWillDisappear];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - UI
- (void)makeConstraints {
    [self.collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.bottom.top.equalTo(self.view);
    }];
}

- (UICollectionViewFlowLayout *)collectionViewLayout {
    UICollectionViewFlowLayout *viewLayout = [[UICollectionViewFlowLayout alloc] init];
    viewLayout.itemSize = [MSChooseDeviceTypeCell cellSize];
    viewLayout.minimumInteritemSpacing = 0;
    viewLayout.minimumLineSpacing = 0;
    viewLayout.scrollDirection = UICollectionViewScrollDirectionVertical;
    return viewLayout;
}

#pragma mark - event

-(void)clickButton{
    
    [OEMRouter handleURL:MSRouterScanCode];
}


- (void)clickCountView {
    
//    MSAuthorizeViewController *dest = [[MSAuthorizeViewController alloc] init];
//    dest.modalPresentationStyle =  UIModalPresentationOverFullScreen;
//    [self presentViewController:dest animated:NO completion:nil];
//    return;
    

    [self.collectionView setContentOffset:CGPointMake(0, -(BHStatusBarHeight + 44)) animated:YES];
    self.countView.hidden = YES;
}

- (void)bluetoothAuthorizationStatusDidChange:(NSNotification *)notification {
    if (![[OEMRouterHandler getCurrentViewController] isKindOfClass:[self class]]) {
        [[MSOEMDeviceManager sharedManager] stopBLEScan];
        return;
    }
    [self refreshHeadViewWithBluetoothState];
}

- (void)refreshHeadViewWithBluetoothState {
    DDLogDeviceInfo(@"更新头部视图---------------------");
    MSBLEManagerType type = [[MSBLEManager shareManager] checkBluetoothAuthState];
    
    switch (type) {
        case MSBLEManagerTypeAuthorizedAndTurnOn:{
            DDLogDeviceInfo(@"蓝牙开关已打开");
            [self.headView refreshHeadViewWithType:MSChooseDeviceTypeHeadViewTypeScanning dataArray:@[]];
            [self.countView updateCountWithNumber:0];
            [self.presenter startAutoFind];
            [[MSBLEManager shareManager] hiddenTurnOnBluetoothAlertControllerNew];
        }
            break;
            
        case MSBLEManagerTypeAuthorized:{
            DDLogDeviceInfo(@"蓝牙已授权但开关未打开");
            [self.headView refreshHeadViewWithType:MSChooseDeviceTypeHeadViewTypeTurnOff dataArray:@[]];
            [self.countView updateCountWithNumber:0];
            [self.presenter viewWillDisappear];
            [[MSBLEManager shareManager] showTurnOnBluetoothAlertControllerNew];
        }
            break;
 
            
        case MSBLEManagerTypeUnauthorized:
        case MSBLEManagerTypeUnauthorized130:
        case MSBLEManagerTypeUnauthorized131:{
            DDLogDeviceInfo(@"蓝牙未授权");
            [self.headView refreshHeadViewWithType:MSChooseDeviceTypeHeadViewTypeUnauthorized dataArray:@[]];
            [self.countView updateCountWithNumber:0];
        }
            break;
            
        default:
            break;
    }
}

#pragma mark - UICollectionViewDataSource, UICollectionViewDelegate
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 2;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if (section == 0) {
        return 0;
    } else {
        //一行cell不能刚好排满，则用空白cell代替
        if (self.presenter.dataArray.count % 3 == 0) {
            return self.presenter.dataArray.count;
        } else {
            return self.presenter.dataArray.count + (3 - self.presenter.dataArray.count % 3);
        }
    }
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    if (section == 0) {
        return UIEdgeInsetsMake(0, 0, 8, 0);
    } else {
        return UIEdgeInsetsMake(0, 0, 0, 0);
    }
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        if (self.headView) {
            return CGSizeMake(SCREEN_WIDTH, [self.headView viewHeight]);
        } else {
            return CGSizeMake(SCREEN_WIDTH, 162);
        }
    } else {
        return CGSizeMake(SCREEN_WIDTH, 44);
    }
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
    if (kind == UICollectionElementKindSectionHeader) {
        if (indexPath.section == 0) {
            if (!self.headView) {
                self.headView = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:NSStringFromClass([MSChooseDeviceTypeHeadView class]) forIndexPath:indexPath];
                self.headView.delegate = self;
                [self refreshHeadViewWithBluetoothState];
            }
            return self.headView;
        } else {
            MSChooseDeviceTypeCellHeadView * headView = [collectionView dequeueReusableSupplementaryViewOfKind:kind withReuseIdentifier:NSStringFromClass([MSChooseDeviceTypeCellHeadView class]) forIndexPath:indexPath];
            headView.titleLabel.text = MSResourceString(@"add_device_page_manually_select_device");
            return headView;
        }
    } else {
        return [UICollectionReusableView new];
    }
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (self.presenter.dataArray.count > indexPath.item) {
        MSChooseDeviceTypeCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([MSChooseDeviceTypeCell class]) forIndexPath:indexPath];
        MSDeviceProductResult *result = self.presenter.dataArray[indexPath.item];
        [cell.imageView sd_setImageWithURL:[NSURL URLWithString:result.imgUrl] placeholderImage:[UIImage imageNamed:@"pic_category_default"]];
        cell.nameLabel.text = result.typeName;
        [cell configureCellWithTotalCount:[self.presenter.dataArray count]  perRow:3 currentIndex:indexPath.row];
        return cell;
    } else {
        OEMHGCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([OEMHGCollectionViewCell class]) forIndexPath:indexPath];
        cell.backgroundColor = [UIColor whiteColor];
        [cell configureCellWithTotalCount:[self.presenter.dataArray count]  perRow:3 currentIndex:indexPath.row];
        return cell;
    }
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {

#if OEMTHEMEDEBUGMODE

    
    if (indexPath.row >= 0 && indexPath.row <= 2) {
        [[NSUserDefaults standardUserDefaults] setObject:@(indexPath.row + AFNetworkReachabilityStatusNotReachable) forKey:@"OEMTHEMEDEBUGMODE_wifistatus"];
        MSDeviceConnectResult * connectInfo = [[MSDeviceConnectResult alloc] init];
        //MSDeviceProductResult *connectInfo = [[MSDeviceProductResult alloc] init];
        MSConnectWiFiViewController *connectWifiVC = [[MSConnectWiFiViewController alloc] init];
        connectWifiVC.connectInfo = connectInfo;
        connectWifiVC.connectInfo.deviceImageUrl = @"";
        connectWifiVC.connectInfo.deviceConnectType = MSDeviceConnectTypeManualSelect;
        [self.navigationController pushViewController:connectWifiVC animated:YES];
        dispatch_async(dispatch_get_main_queue(), ^{
                NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
                NSDictionary *userInfo = @{@"AFNetworkingReachabilityNotificationStatusItem": @(1) };
                [notificationCenter postNotificationName:AFNetworkingReachabilityDidChangeNotification object:nil userInfo:userInfo];
        });
        
        return;
    }
    
    if (indexPath.row == 3) {
        MSDeviceProductResult *result = [[MSDeviceProductResult alloc] init];
        MSChooseDeviceModelViewController *chooseDeviceModelViewController = [[MSChooseDeviceModelViewController alloc] init];
        chooseDeviceModelViewController.typeId = result.pId;
        chooseDeviceModelViewController.deviceImageUrl = result.imgUrl;
        [self.navigationController pushViewController:chooseDeviceModelViewController animated:YES];
        
        return;
    }
    
    
    return;
#endif
    
    if (self.presenter.dataArray.count > indexPath.item) {
        MSDeviceProductResult *result = self.presenter.dataArray[indexPath.item];
        if(YES){
            MSDeviceConnectResult *connectInfo = [[MSDeviceConnectResult alloc] init];
            connectInfo.category = result.category;
            connectInfo.deviceConnectType = MSDeviceConnectTypeManualSelect;
            connectInfo.deviceName = result.typeName;
            connectInfo.deviceImageUrl = result.imgUrl; //失败页面用到
            connectInfo.mode = @"3";
            
            MSConnectWiFiViewController *connectWifiVC = [[MSConnectWiFiViewController alloc] init];
            connectWifiVC.connectInfo = connectInfo;
            [self.navigationController pushViewController:connectWifiVC animated:YES];
          //  [OEMRouter handleURL: MSRouterBLEDeviceGuide withParams:@{@"connectInfo":connectInfo}];
        }else{
            //[self toastText:MSResourceString(@"add_device_page_comming_soom")];
        }
        
        return;
        
        MSChooseDeviceModelViewController *chooseDeviceModelViewController = [[MSChooseDeviceModelViewController alloc] init];
        chooseDeviceModelViewController.typeId = result.pId;
        chooseDeviceModelViewController.deviceImageUrl = result.imgUrl;
        [self.navigationController pushViewController:chooseDeviceModelViewController animated:YES];
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView.contentOffset.y > 165 + 8 - BHStatusBarHeight - 44) {
        self.countView.hidden = NO;
    } else {
        self.countView.hidden = YES;
    }
}

#pragma mark - MSChooseDeviceTypeHeadViewDelegate
- (void)headView:(MSChooseDeviceTypeHeadView *)headView didSelectItemWithModel:(MSAutoFindResult *)result {
    [[MSOEMDeviceManager sharedManager] stopBLEScan];
    DDLogDeviceInfo(@"点击开启配网-------------------------------------------------");
    DDLogDeviceInfo(@"当前配网设备广播---%@", result.bleAdvDict);
    [self.presenter fetchConnectInfoWithAutoFindResult:result];
    
    return;
    
    [self.presenter requestConnectInfoWithSN8:result.deviceSN8 dcpImageUrl:result.dcpImageUrl];
}

- (void)headViewDidClickHelpButton:(MSChooseDeviceTypeHeadView *)headView {
    [OEMRouter handleURL:MSRouterReactNativeIndex withParams:@{
        MSReactNativeModuleNameDefine : MSReactNativeInnerModule_guide
    }];
}

- (void)headViewDidLongPressHelpButton:(MSChooseDeviceTypeHeadView *)headView {
#if (AppStore_ENV==0 || UAT_ENV==1)
    [[NSUserDefaults standardUserDefaults] setObject:@(1) forKey:@"OEM_Display_Auto_Found_Device_Mac_Suffix"];
    [self toastText:@"已显示设备编号后4位"];
#endif
}

- (void)headViewDidClickToOpenBluetooth:(MSChooseDeviceTypeHeadView *)headView {
    [[MSBLEManager shareManager] showTurnOnBluetoothAlertControllerNew];
}

- (void)headViewDidClickToAuthorizeBluetooth:(MSChooseDeviceTypeHeadView *)headView {
    [[MSSystemPermissionManager shareManager] jumpToSystemAppSettingPage];
}

- (void)headViewNeedUpdateHeight:(MSChooseDeviceTypeHeadView *)headView {
    [self.collectionView reloadSections:[NSIndexSet indexSetWithIndex:0]];
}

#pragma mark - MSChooseDeviceViewProtocol
- (void)presenterDidLoadData:(MSChooseDevicePresenter *)presenter {
    [self.collectionView reloadData];
}

- (void)presenter:(MSChooseDevicePresenter *)presenter discoverDevices:(NSArray<MSAutoFindResult *> *)result {
    [self.countView updateCountWithNumber:self.presenter.scanResult.count];
    [self.headView refreshHeadViewWithType:MSChooseDeviceTypeHeadViewTypeFindDevice dataArray:[self.presenter.scanResult copy]];
}

- (void)presenterDidScan15Seconds:(MSChooseDevicePresenter *)presenter {
    [self.countView updateCountWithNumber:0];
    [self.headView refreshHeadViewWithType:MSChooseDeviceTypeHeadViewType15Timeout dataArray:@[]];
}


//配网入口
- (void)presenter:(MSChooseDevicePresenter *)presenter getConnectInfo:(MSDeviceConnectResult *)result {
    //过滤掉设备sn8请求到的设备信息为空的情况，防止崩溃
    if (!result) {
        DDLogDeviceInfo(@"设备信息获取为空");
        return;
    }
    
  //  MSDeviceRouterService *service = [[MSDeviceRouterService alloc] init];
    NSString *wifiSsid = [OEMDeviceTool currentWifiSSID];
    if (!wifiSsid) {
        [self pushToConnectViewControllerWithConnectInfo:result];
    } else {
//        NSString *pwd = [service fetchPasswordWithSsid:wifiSsid];
//        if (pwd) {
//            result.wifiSsid = wifiSsid;
//            result.wifiBssid = [MideaTool currentWifiBSSID];
//            result.wifiPassword = pwd;
//            MSAddDeviceProgressViewController *dest = [[MSAddDeviceProgressViewController alloc] init];
//            dest.connectInfo = result;
//            [self.navigationController pushViewController:dest animated:YES];
//
//        } else {
            [self pushToConnectViewControllerWithConnectInfo:result];
  //      }
    }
}

//必须进入wifi登记页
-(void)pushToConnectViewControllerWithConnectInfo:(MSDeviceConnectResult *)result{
    MSConnectWiFiViewController *connectWifiVC = [[MSConnectWiFiViewController alloc] init];
    connectWifiVC.connectInfo = result;
    [self.navigationController pushViewController:connectWifiVC animated:YES];
}


@end




