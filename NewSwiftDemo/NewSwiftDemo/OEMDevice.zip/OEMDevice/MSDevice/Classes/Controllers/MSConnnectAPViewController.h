//  
//  MSConnnectAPViewController.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/14
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <MSBusiness/MVPViewController.h>
#import <MSBusiness/MSDeviceConnectResult.h>

@interface MSConnnectAPViewController : MVPViewController

@property (nonatomic, strong) MSDeviceConnectResult *connectInfo;

@end
