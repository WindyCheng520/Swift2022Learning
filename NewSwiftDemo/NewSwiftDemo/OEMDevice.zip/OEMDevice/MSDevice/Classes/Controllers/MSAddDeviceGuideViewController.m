//  
//  MSAddDeviceGuideViewController.m
//  Pods
//   
//  Created by 李 燕强 on 2020/8/5
//  Copyright © 2020 Midea. All rights reserved.
//  ap配网和蓝牙配网操作指引的父控制器

#import "MSAddDeviceGuideViewController.h"
#import "MSAPGuideViewController.h"
#import "MSBLEGuideViewController.h"
#import "MSDeviceBundle.h"

@interface MSAddDeviceGuideViewController ()

@end

@implementation MSAddDeviceGuideViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = MSResourceString(@"connect_set_device");
    [self addChildViews];
}

- (void)addChildViews {
    if (self.childViewControllers.count) {
        UIViewController *vc = [self.childViewControllers lastObject];
        [vc.view removeFromSuperview];
        [vc removeFromParentViewController];
    }
    
    switch (self.connectInfo.deviceConnectType) {
        case MSDeviceConnectTypeHomeAutoFind:{
            [self bluetoothAutoFindTypeChildView];
        }
            break;
            
        case MSDeviceConnectTypeSelectAutoFind:{
            [self bluetoothAutoFindTypeChildView];
        }
            break;
            
        case MSDeviceConnectTypeManualSelect:{
            [self manualSelectTypeChildView];
        }
            break;
            
        default:
            break;
    }
}

//首页蓝牙自发现和选择家电页蓝牙自发现配网，先找有没有蓝牙配网，有则走蓝牙指引，无则走主配网
- (void)bluetoothAutoFindTypeChildView {
    if (self.connectInfo.mode.intValue == MSDeviceModeTypeBluetooth) {
        self.connectInfo.auxiing = NO;
        [self jumpToBluetoothGuideVCWithAuxi:NO];
    } else {
        if (self.connectInfo.auxiMode.intValue == MSDeviceModeTypeBluetooth) {
            self.connectInfo.auxiing = YES;
            [self jumpToBluetoothGuideVCWithAuxi:YES];
        } else {
            [self manualSelectTypeChildView];
        }
    }
}

//手动选择配网，直接先走主配网模式,主配网模式是蓝牙就走蓝牙指引，主配网是AP就走AP
- (void)manualSelectTypeChildView {
    self.connectInfo.auxiing = NO;
    if (self.connectInfo.mode.intValue == MSDeviceModeTypeAP) {
        [self jumpToAPGuideVCWithAuxi:NO];
    } else if (self.connectInfo.mode.intValue == MSDeviceModeTypeBluetooth) {
        [self jumpToBluetoothGuideVCWithAuxi:NO];
    }
}

- (void)changeToAuxi {
    if (self.childViewControllers.count) {
        UIViewController *vc = [self.childViewControllers lastObject];
        [vc.view removeFromSuperview];
        [vc removeFromParentViewController];
    }
    self.connectInfo.auxiing = YES;
    if (self.connectInfo.auxiMode.intValue == MSDeviceModeTypeAP) {
        [self jumpToAPGuideVCWithAuxi:YES];
    } else if (self.connectInfo.auxiMode.intValue == MSDeviceModeTypeBluetooth) {
        [self jumpToBluetoothGuideVCWithAuxi:YES];
    }
}

- (void)changeToOtherWay {
    if (self.childViewControllers.count) {
        UIViewController *vc = [self.childViewControllers lastObject];
        [vc.view removeFromSuperview];
        [vc removeFromParentViewController];
    }
    self.connectInfo.isTryOther = YES;
    if (self.connectInfo.auxiing) {
        self.connectInfo.auxiing = NO;
        if (self.connectInfo.mode.intValue == MSDeviceModeTypeAP) {
            [self jumpToAPGuideVCWithAuxi:NO];
        } else if (self.connectInfo.mode.intValue == MSDeviceModeTypeBluetooth) {
            [self jumpToBluetoothGuideVCWithAuxi:NO];
        }
    } else {
        self.connectInfo.auxiing = YES;
        if (self.connectInfo.auxiMode.intValue == MSDeviceModeTypeAP) {
            [self jumpToAPGuideVCWithAuxi:YES];
        } else if (self.connectInfo.auxiMode.intValue == MSDeviceModeTypeBluetooth) {
            [self jumpToBluetoothGuideVCWithAuxi:YES];
        }
    }
    
}

- (void)jumpToAPGuideVCWithAuxi:(BOOL)isAuxi {
    MSAPGuideViewController *apGuideVC = [[MSAPGuideViewController alloc] init];
    apGuideVC.connectInfo = self.connectInfo;
    apGuideVC.auxi = isAuxi;
    [apGuideVC didMoveToParentViewController:self];
    [self.view addSubview:apGuideVC.view];
    [self addChildViewController:apGuideVC];
}

- (void)jumpToBluetoothGuideVCWithAuxi:(BOOL)isAuxi {
    MSBLEGuideViewController *bleGuideVC = [[MSBLEGuideViewController alloc] init];
    bleGuideVC.connectInfo = self.connectInfo;
    bleGuideVC.auxi = isAuxi;
    [bleGuideVC didMoveToParentViewController:self];
    [self.view addSubview:bleGuideVC.view];
    [self addChildViewController:bleGuideVC];
}

- (void)leftBarButtonClick:(UIButton *)button {
    if (self.childViewControllers.count) {
        UIViewController *vc = [self.childViewControllers lastObject];
        if ([vc isKindOfClass:[MSAPGuideViewController class]]) {
            MSAPGuideViewController *apVC = (MSAPGuideViewController *)vc;
            [apVC leftBarButtonClick:nil];
        } else if ([vc isKindOfClass:[MSBLEGuideViewController class]]) {
            MSBLEGuideViewController *bleVC = (MSBLEGuideViewController *)vc;
            [bleVC leftBarButtonClick:nil];
        }
    }
}


@end
