//
//  MSConnectWiFiViewController.h
//  MSDevice
//
//  Created by 及时行乐 on 2020/6/23.
//

#import <MSBusiness/MVPViewController.h>
#import <MSBusiness/MSDeviceConnectResult.h>
#import "MSConnectWiFiPresenter.h"


@interface MSConnectWiFiViewController : MVPViewController<MSConnectWiFiPresenter *> <MSConnectWiFiViewProtocol>

@property (nonatomic, strong) MSDeviceConnectResult *connectInfo;




//@property (nonatomic, copy) void (^viewControllerCompleteBlock)(void); //完成跳转


@end

