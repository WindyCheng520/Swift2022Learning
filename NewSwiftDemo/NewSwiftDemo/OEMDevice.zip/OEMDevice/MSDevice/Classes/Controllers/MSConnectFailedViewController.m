//
//  MSConnectFailedViewController.m
//  MSDevice
//
//  Created by 及时行乐 on 2020/6/24.
//  配网失败页面

#import "MSConnectFailedViewController.h"
#import "MSDeviceBundle.h"
#import "MSNetworkTipsViewController.h"
#import "MSAddDeviceGuideViewController.h"
#import "MSAddDeviceProgressViewController.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import <MSBusiness/MideaTool.h>
#import <OEMFoundation/OEMMacros.h>
#import <OEMFoundation/OEMDeviceTool.h>
#import <MSBusiness/MSSystemPermissionManager.h>
#import <MSBusiness/MSLocationManager.h>
#import <MSBusiness/MSNotificationConst.h>
#import <CoreLocation/CoreLocation.h>
#import "SequenceItemCellView.h"
#import <OEMTheme/MSInputView_Private.h>
#import "MSConnectSuccessViewController.h"
#import "MSBLEGuideViewController.h"
#import <MSBusiness/MSRouterUrl.h>
#import <MSBusiness/MSBusiness-Swift.h>
#import <MSBusiness/OEMGlobalUIManager.h>
#import "MSConnnectAPViewController.h"
#import "OEMAddDeviceButton.h"
#import <MSBusiness/OEMCommomAlertViewController.h>
#import <MSBusiness/OEMBLEAlertViewController.h>
#import <MSBusiness/MSBLEManager.h>

static const NSInteger kTextFieldTag = 5432;

@interface MSConnectFailedViewController ()<MSInputViewDelegate>

@property (nonatomic, strong) HGImageView *leftIconImageView;
@property (nonatomic, strong) HGImageView *centerFailIconView;
@property (nonatomic, strong) HGImageView *rightIconImageView;

@property (nonatomic, strong) HGLabel *titleLabel;

@property (nonatomic, strong) SequenceItemCellView *wifiSSIDOrPasswordFailItem;

@property (nonatomic, strong) MSInputView *wifiInputView;
@property (nonatomic, strong) MSInputView *passwordInputView;

@property (nonatomic, strong) SequenceItemCellView * channel24GhzItem;
@property (nonatomic, strong) SequenceItemCellView * secondAuthItem;
@property (nonatomic, strong) SequenceItemCellView * networkAuthItem;

@property (nonatomic, strong) HGView *networkTipView;
@property (nonatomic, strong) HGButton *networkTipButton;
@property (nonatomic, strong) HGButton *tryButton;
@property (nonatomic, strong) HGButton *otherWaysButton; //其它方式


@property (nonatomic, strong) UIButton *leftButton;
@property (nonatomic, strong) UIButton *rightButton; //其它方式

@property (nonatomic, strong) OEMAddDeviceButton *addDeviceButton;

@property (nonatomic, strong) OEMBLEAlertViewController *alertViewController;



@end

@implementation MSConnectFailedViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        self.leftIconImageView = [HGImageView new];
        self.centerFailIconView = [HGImageView new];
        self.rightIconImageView = [HGImageView new];
        self.titleLabel = [HGLabel new];
        
        self.wifiInputView = [MSInputView new];
        self.passwordInputView = [MSInputView new];
        
        self.channel24GhzItem = [SequenceItemCellView new];
        self.secondAuthItem = [SequenceItemCellView new];
        
        self.wifiSSIDOrPasswordFailItem = [SequenceItemCellView new];
        self.networkAuthItem = [SequenceItemCellView new];
        
        self.networkTipView = [HGView new];
//        self.networkTipLabel = [HGLabel new];
//        self.networkTipButton = [HGButton new];
        self.tryButton = [HGButton new];
//        self.otherWaysButton = [HGButton new];
        
        self.otherWaysButton = [HGButton new];
        self.presenter = [[MSConnectWiFiPresenter alloc] initWithView:self];
    }
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    if(self.connectInfo.mode.integerValue == 3){
        self.addDeviceButton.type = ConnectTypeAP;
    }else{
        self.addDeviceButton.type = ConnectTypeBLE;
    }
    
    if (![self judgeIsContainAPConnectViewVC]){
        [self insertAPConncetVC];
    }
    
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.navigationController.interactivePopGestureRecognizer.enabled = YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.canRightSlideBack = NO;
    
   // test
  //  self.connectInfo.mode = @"0";
    // test
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidBecomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(locationAuthorizationStatusChanged:) name:kMideaLocationAuthorizationStatusDidChangeNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(bluetoothAuthorizationStatusDidChange:) name:kMideaBluetoothAuthorizationStatusDidChangeNotification object:nil];

    self.hiddenKeyboardWhenTap = YES;
    [self createLeftButtonWithText:MSResourceString(@"add_device_process_page_cancel_button")];
    
    [self createRightButtonWithText:MSResourceString(@"config_fail_page_button_feedback")];

    
    if (self.connectInfo.deviceImageUrl && ![self.connectInfo.deviceImageUrl isEqualToString:@""]) {
        [self.leftIconImageView sd_setImageWithURL:[NSURL URLWithString:self.connectInfo.deviceImageUrl] placeholderImage:[UIImage imageNamed:@"pic_category_default"]];
    } else {
        self.leftIconImageView.image = [UIImage imageNamed:@"pic_category_default"];
    }

    [self.view addSubview:self.leftIconImageView];
    
    self.centerFailIconView.image = MSResourceImage(@"device_icon_warn");
    [self.view addSubview:self.centerFailIconView];
    
    self.rightIconImageView.image = MSResourceImage(@"pic_connect_server");
    [self.view addSubview:self.rightIconImageView];
    
    self.titleLabel.textColor = RGB_HEX(0x000000);
    self.titleLabel.font = kSemiboldFont(22);
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:self.titleLabel];
    self.titleLabel.text = MSResourceString(@"config_fail_page_config_fail");
    
    
    [self.wifiInputView setRightImage:MSResourceImage(@"ic_input_go")];
    [self.wifiInputView setFont:kSemiboldFont(16)];
    [self.wifiInputView setTextColor:RGB_HEX(0x000000)];
    
    [self.view addSubview:self.wifiSSIDOrPasswordFailItem];
    [self.view addSubview:self.channel24GhzItem];
    [self.view addSubview:self.secondAuthItem];
    [self.view addSubview:self.networkAuthItem];
    
    [self.wifiSSIDOrPasswordFailItem setText:MSResourceString(@"config_fail_page_check_wifi_password") index:1 type:SequenceItemType_Number enableQuestionMark:NO];
    [self.channel24GhzItem setText:MSResourceString(@"config_fail_page_2_4ghz_only") index:1 type:SequenceItemType_Dot enableQuestionMark:YES];
    
    WEAKSELF
    self.channel24GhzItem.onQuestionMarkTap = ^{
        MSNetworkTipsViewController* networkTipsViewController = [[MSNetworkTipsViewController alloc] initWithType:MSNetworkTipsTypeWiFi5G];
        [weakSelf.navigationController pushViewController:networkTipsViewController animated:YES];
    };
    
    [self.secondAuthItem setText:MSResourceString(@"config_fail_page_second_auth_require") index:1 type:SequenceItemType_Dot enableQuestionMark:YES];
    
    self.secondAuthItem.onQuestionMarkTap = ^{
        MSNetworkTipsViewController* networkTipsViewController = [[MSNetworkTipsViewController alloc] initWithType:MSNetworkTipsTypeSecondary];
        [weakSelf.navigationController pushViewController:networkTipsViewController animated:YES];
    };
    
    [self.networkAuthItem setText:MSResourceString(@"config_fail_page_local_network_access_turn_on") index:2 type:SequenceItemType_Number enableQuestionMark:NO];
    
    @weakify(self)
    self.wifiInputView.clickRightButtonBlock = ^{
        @strongify(self)
        [self locationCheck];
    };
    self.wifiInputView.delegate = self;
    self.wifiInputView.placeholder = MSResourceString(@"connect_wifi_page_wifi_name");
    [self.view addSubview:self.wifiInputView];
    [self.wifiInputView setTextFieldTag:kTextFieldTag];
    [self.wifiInputView addClickEventToTextField];
    
    [self.passwordInputView setRightImage:MSResourceImage(@"ic_input_view")];
    [self.passwordInputView setFont:kSemiboldFont(16)];
    [self.passwordInputView setTextColor:RGB_HEX(0x000000)];
    self.passwordInputView.secureTextEntry = YES;
    self.passwordInputView.clickRightButtonBlock = ^{
        @strongify(self)
        if (self.passwordInputView.isSecureTextEntry) {
            self.passwordInputView.secureTextEntry = NO;
            [self.passwordInputView setRightImage:MSResourceImage(@"ic_input_view_s")];
        } else {
            self.passwordInputView.secureTextEntry = YES;
            [self.passwordInputView setRightImage:MSResourceImage(@"ic_input_view")];
        }
    };
    self.passwordInputView.delegate = self;
    self.passwordInputView.placeholder = MSResourceString(@"connect_wifi_page_wifi_password_tip");
    [self.view addSubview:self.passwordInputView];
    [self.passwordInputView setTextFieldTag:kTextFieldTag+1];
    
    
    self.networkTipView.backgroundColor = RGB_HEX(0xCCCCCC);
    self.networkTipView.layer.cornerRadius = 2;
    [self.view addSubview:self.networkTipView];

    
    [self.tryButton setTitle:MSResourceString(@"ble_guide_page_reconnect") forState:UIControlStateNormal];
    [self.tryButton setTitleColor:kLightText.mainLightColor forState:UIControlStateNormal];
    self.tryButton.titleLabel.font = kSFProFont(18);
    self.tryButton.layer.cornerRadius = 22;
    [self.view addSubview:self.tryButton];
    [self.tryButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    
    
//    if (self.connectInfo.deviceConnectType == MSDeviceConnectTypeManualSelect) {
//        if (self.connectInfo.auxiing || (!self.connectInfo.auxiMode) || [self.connectInfo.auxiMode isEqualToString:@"-1"]) {
//            self.otherWaysButton.hidden = YES;
//        }
//    } else {
//        if (self.connectInfo.isTryOther) {
//            self.otherWaysButton.hidden = YES;
//        } else {
//            if (self.connectInfo.auxiing) {
//                if (!self.connectInfo.mode || [self.connectInfo.mode isEqualToString:@"-1"]) {
//                    self.otherWaysButton.hidden = YES;
//                }
//            } else {
//                if (!self.connectInfo.auxiMode || [self.connectInfo.auxiMode isEqualToString:@"-1"]) {
//                    self.otherWaysButton.hidden = YES;
//                }
//            }
//        }
//    }
    
    NSString *wifiSsid = self.connectInfo.wifiSsid;
    self.wifiInputView.text = wifiSsid;
    NSString *password = self.connectInfo.wifiPassword;
    self.passwordInputView.text = password;
    
    
//    [self.otherWaysButton setTitle:MSResourceString(@"尝试设备AP配网连接") forState:UIControlStateNormal];
//    [self.otherWaysButton setTitleColor:kLightText.mainColor forState:UIControlStateNormal];
//    self.otherWaysButton.titleLabel.font =  kRegularFont(14);
//    [self.view addSubview:self.otherWaysButton];
//    [self.otherWaysButton sizeToFit];
//    [self.otherWaysButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    
    
    self.addDeviceButton = [[OEMAddDeviceButton alloc] initWithFrame:CGRectZero type:ConnectTypeAP];
    [self.addDeviceButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.addDeviceButton];
    
    
    
    
    [self makeContstraints];
    
    //先检查一次定位权限
    [[MSLocationManager shareManager] checkLocationForCurrentWiFi];
    
    [self configureOEMTheme];
    
    if (![self judgeIscontainBLEGuideViewVC]){
        [self insertVC];
    }
}



- (BOOL)judgeIsContainAPConnectViewVC {
     NSMutableArray *mvcvs = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
     __block BOOL isContain = NO;
     [mvcvs enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
         UIViewController *viewController = (UIViewController *)obj;
         if ([viewController isKindOfClass:NSClassFromString(@"MSConnnectAPViewController")]) {
             isContain = YES;
             *stop = YES;
         }
     }];
    return isContain;
}


//插入AP连接控制器
- (void)insertAPConncetVC {
    NSMutableArray *mvcvs = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
    MSConnnectAPViewController *guide = [[MSConnnectAPViewController alloc] init];
    guide.connectInfo = self.connectInfo;
    guide.hidesBottomBarWhenPushed = YES;
    __block NSInteger index = 0;
    [mvcvs enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        UIViewController *viewController =   (UIViewController *)obj;
        if ([viewController isKindOfClass:NSClassFromString(@"MSAddDeviceProgressViewController")]) {
            index = idx;
            *stop = YES;
        }
    }];
    if (index != 0){ //包含MSAddDeviceProgressViewController（不是根视图）才插入
        [mvcvs insertObject:guide atIndex:index];
        self.navigationController.viewControllers = mvcvs;
    }
}


- (BOOL)judgeIscontainBLEGuideViewVC {
     NSMutableArray *mvcvs = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
     __block BOOL isContain = NO;
     [mvcvs enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
         UIViewController *viewController = (UIViewController *)obj;
         if ([viewController isKindOfClass:NSClassFromString(@"MSBLEGuideViewController")]) {
             isContain = YES;
             *stop = YES;
         }
     }];
    return isContain;
}

- (void)insertVC {
    NSMutableArray *mvcvs = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
    MSBLEGuideViewController *guide = [[MSBLEGuideViewController alloc] init];
    guide.connectInfo = self.connectInfo;
    guide.hidesBottomBarWhenPushed = YES;
    __block NSInteger index = 0;
    [mvcvs enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        UIViewController *viewController =   (UIViewController *)obj;
        if ([viewController isKindOfClass:NSClassFromString(@"MSConnectWiFiViewController")]) {
            index = idx;
            *stop = YES;
        }
    }];
    if (index != 0){ //包含MSConnectWiFiViewController（不是根视图）才插入
        [mvcvs insertObject:guide atIndex:index];
        self.navigationController.viewControllers = mvcvs;
    }
}




- (void)configureOEMTheme{
    [self.titleLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    [self.view configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.wifiInputView.textField configureThemeTag:OEMThemesTag_UITextField_Textcolor];
    [self.passwordInputView.textField configureThemeTag:OEMThemesTag_UITextField_Textcolor];
    [self.tryButton configureThemeTag:OEMThemesTag_UIButton_Background];
    [self.centerFailIconView specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIImageView_BackgroundColor) : CommonThemeWarningColor
    } lightModeProperties:@{
        @(OEMThemesTag_UIImageView_BackgroundColor) : CommonThemeWarningColor
    }];
    
    
    
    [self.leftButton specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIButton_TitleTraitColor) : kDarkText.mainTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UIButton_TitleTraitColor) : kLightText.mainTextColor
    }];
    
    [self.rightButton specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : kDarkText.mainColor
    } lightModeProperties:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : kLightText.mainColor
    }];
    
    
    [self.titleLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.mainTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.mainTextColor
    }];
    
    
    [self.wifiSSIDOrPasswordFailItem.contentLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.secondColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.secondColor
    }];
    
    
    
    [self.wifiInputView.textField specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UITextField_Textcolor) : kDarkText.mainTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UITextField_Textcolor) : kLightText.mainTextColor
    }];
    
    
    
    [self.passwordInputView.textField specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UITextField_Textcolor) : kDarkText.mainTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UITextField_Textcolor) : kLightText.mainTextColor
    }];
    
    
    [self.channel24GhzItem.contentLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.thirdColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.thirdColor
    }];
    
    
    [self.secondAuthItem.contentLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.thirdColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.thirdColor
    }];
    
    
    [self.networkAuthItem.contentLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.secondColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.secondColor
    }];
    
    
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        [weakSelf setPlaceholderColor];
    } callImmidiately:YES];
}

-(void)setPlaceholderColor{
    if (OEMThemeIsDarkMode) {
        self.wifiInputView.placeholderColor = kDarkText.tipsColor;
        self.passwordInputView.placeholderColor = kDarkText.tipsColor;
      
    }else{
        self.wifiInputView.placeholderColor = kLightText.tipsColor;
        self.passwordInputView.placeholderColor = kLightText.tipsColor;
    }
}

-(void)makeContstraints{
    
    [self.centerFailIconView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(STATUSBAR_HEIGHT + 20);
        make.size.mas_equalTo(CGSizeMake(16, 16));
        make.centerX.equalTo(self.view);
    }];
    
    self.centerFailIconView.layer.masksToBounds = YES;
    self.centerFailIconView.layer.cornerRadius = 8;
    
    [self.leftIconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.centerFailIconView.mas_centerY);
        make.trailing.equalTo(self.centerFailIconView.mas_leading).offset(-14);
        make.size.mas_equalTo(CGSizeMake(88, 88));
    }];
    
    [self.rightIconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.centerFailIconView.mas_centerY);
        make.leading.equalTo(self.centerFailIconView.mas_trailing).offset(14);
        make.size.mas_equalTo(CGSizeMake(88, 88));
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.leftIconImageView.mas_bottom).offset(24);
        make.leading.mas_equalTo(16);
        make.trailing.mas_equalTo(-16);
    }];
    
    [self.wifiSSIDOrPasswordFailItem mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.equalTo(self.wifiSSIDOrPasswordFailItem.superview);
        make.height.mas_equalTo([self.wifiSSIDOrPasswordFailItem getExpectedHeigt]);
        make.top.equalTo(self.titleLabel.mas_bottom).offset(20);
    }];
    
    [self.wifiInputView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.wifiSSIDOrPasswordFailItem.mas_bottom).offset(15);
        make.leading.mas_equalTo(16);
        make.trailing.mas_equalTo(-16);
        make.height.mas_equalTo(44);
    }];
    
    [self.passwordInputView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.wifiInputView.mas_bottom).offset(10);
        make.leading.mas_equalTo(16);
        make.trailing.mas_equalTo(-16);
        make.height.mas_equalTo(44);
    }];

    [self.channel24GhzItem mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.equalTo(self.channel24GhzItem.superview);
        make.height.mas_equalTo([self.channel24GhzItem getExpectedHeigt]);
        make.top.equalTo(self.passwordInputView.mas_bottom).offset(15);
    }];
    
    [self.secondAuthItem mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.equalTo(self.secondAuthItem.superview);
        make.height.mas_equalTo([self.secondAuthItem getExpectedHeigt]);
        make.top.equalTo(self.channel24GhzItem.mas_bottom).offset(10);
    }];
    
    [self.networkAuthItem mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.equalTo(self.networkAuthItem.superview);
        make.height.mas_equalTo([self.networkAuthItem getExpectedHeigt]);
        make.top.equalTo(self.secondAuthItem.mas_bottom).offset(15);
    }];
    
    
    CGFloat space = 60;
    CGFloat bottomSpace = -49;
    if (SCREEN_HEIGHT <= 667) {
        space = 20;
        bottomSpace = -25;
    }
    
    [self.tryButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.networkAuthItem.mas_bottom).offset(space);
        make.leading.mas_equalTo(16);
        make.trailing.mas_equalTo(-16);
        make.height.mas_equalTo(44);
    }];

//    [self.otherWaysButton mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.bottom.equalTo(self.view.mas_bottom).offset(-49);
//        make.centerX.equalTo(self.view);
//       // make.height.mas_equalTo(20);
//    }];
    
    
    [self.addDeviceButton mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.view.mas_bottom).offset(bottomSpace);
        make.leading.mas_equalTo(16);
        make.trailing.mas_equalTo(-16);
        //make.height.mas_equalTo(44);
    }];
    
}

-(void)createLeftButtonWithText:(NSString *)text{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:text forState:UIControlStateNormal];
    [button setTitleColor:kLightText.mainTextColor forState:UIControlStateNormal];
    button.titleLabel.font = kRegularFont(15);
    [button addTarget:self action:@selector(leftBarButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *Item = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = Item;
    self.leftButton = button;
}


-(void)createRightButtonWithText:(NSString *)text{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:text forState:UIControlStateNormal];
    [button setTitleColor:kLightText.mainColor forState:UIControlStateNormal];
    button.titleLabel.font = kRegularFont(15);
    [button addTarget:self action:@selector(rightBarButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *Item = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.rightBarButtonItem = Item;
    self.rightButton = button;
}



-(void)leftBarButtonClick:(UIButton*)sender{
    [self.navigationController popToRootViewControllerAnimated:YES];
}

-(void)rightBarButtonClick:(UIButton*)sender{
    [OEMRouter handleURL:MSRouterReactNativeIndex withParams:@{
        MSReactNativeModuleNameDefine : MSReactNativeInnerModule_usehelp,
        MSReactNativeViewProps: @{
                @"initialRouteName" : @"feedBackIndex"
        }
    }];
}



-(void)clickButton:(UIButton *)sender{
    if (self.addDeviceButton == sender) { //切换AP/蓝牙
        if ([BusinessNetWorkTools isNetworkUnreachable]) {
            [self toastText:MSResourceString(@"me_network_not_connected")];
            return;
        }
        if (/*self.passwordInputView.text.length > 0 && */self.passwordInputView.text.length < 8) {
            [self toastText:MSResourceString(@"connect_wifi_password_length")];
            return;
        }
        
        if ([self isOverRetryLimit]) {
            [self showOvertimeAlert];
            return;
        }
        
        if (self.addDeviceButton.type == ConnectTypeAP){ //尝试按钮为ap
            [self popToAPConnectViewController];
            return;
        }else{
            self.connectInfo.deviceConnectType =  MSDeviceConnectTypeManualSelect;
            self.connectInfo.mode = @"3";
            [self showBLEAlert];
            return;
        }
        return;
    }
    

#if OEMTHEMEDEBUGMODE
    if (sender == self.tryButton) {
        MSConnectSuccessViewController *successVC = [MSConnectSuccessViewController new];
        successVC.applianceId = @"123123";
        successVC.applianceName = @"deviceName";
        successVC.isBluetooth = NO;
        successVC.connectInfo = self.connectInfo;
        successVC.sn8 = @"123123";
        [self.navigationController pushViewController:successVC animated:YES];
        return;
    }
#endif
    
//    if (sender == self.wifiTipButton || sender == self.networkTipButton) {
    if (sender == self.networkTipButton) {
        MSNetworkTipsType type = MSNetworkTipsTypeSecondary;
        MSNetworkTipsViewController* networkTipsViewController = [[MSNetworkTipsViewController alloc] initWithType:type];
        [self.navigationController pushViewController:networkTipsViewController animated:YES];
        
    } else if (sender == self.otherWaysButton) {
        
        if ([BusinessNetWorkTools isNetworkUnreachable]) {
            [self toastText:MSResourceString(@"me_network_not_connected")];
            return;
        }
        if (self.passwordInputView.text.length > 0 && self.passwordInputView.text.length < 8) {
            [self toastText:MSResourceString(@"connect_wifi_password_length")];
            return;
        }
        
        __block MSAddDeviceGuideViewController *guideVC = nil;
        NSArray<UIViewController *> *vcs = [self.navigationController viewControllers];
        [vcs enumerateObjectsUsingBlock:^(UIViewController *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([obj isKindOfClass:MSAddDeviceGuideViewController.class]) {
                guideVC = (MSAddDeviceGuideViewController *)obj;
                *stop = YES;
            }
        }];
        if (guideVC) {

            NSString *ssid = self.wifiInputView.text;
            NSString *password = self.passwordInputView.text;
            NSString *currentSsid = [OEMDeviceTool currentWifiSSID];
            NSString *bssid = nil;
            if ([ssid isEqualToString:currentSsid]) {
                bssid = [MideaTool currentWifiBSSID];
            } else if ([ssid isEqualToString:self.connectInfo.wifiSsid]) {
                bssid = self.connectInfo.wifiBssid;
            } else {
                bssid = @"00:00:00:00:00:00";
            }
            
            self.connectInfo.wifiSsid = ssid;
            self.connectInfo.wifiPassword = password;
            self.connectInfo.wifiBssid = bssid;
          //  [self.presenter saveSsid:ssid password:password];
            if (self.connectInfo.deviceConnectType == MSDeviceConnectTypeManualSelect) {
                [guideVC changeToAuxi];
            } else {
                [guideVC changeToOtherWay];
            }
            [self.navigationController popToViewController:guideVC animated:YES];
        }
    } else if (sender == self.tryButton) {
        
        if ([BusinessNetWorkTools isNetworkUnreachable]) {
            [self toastText:MSResourceString(@"config_fail_page_network_not_connected")];
            return;
        }
        if (/*self.passwordInputView.text.length > 0 && */self.passwordInputView.text.length < 8) {
            [self toastText:MSResourceString(@"config_fail_wifi_password_length")];
            return;
        }
        
        if (self.connectInfo.mode.integerValue == 0) { //ap配网
            
            if ([self isOverRetryLimit]) {
                [self showOvertimeAlert];
                return;
            }
            
            [self popToAPConnectViewController];
            
            return;
        }
        
        if (self.connectInfo.deviceConnectType >= MSDeviceConnectTypeHomeAutoFind && self.connectInfo.mode.integerValue == 3) { //蓝牙配网
            
            if ([self isOverRetryLimit]) {
                [self showOvertimeAlert];
                return;
            }
            
            
            __block MSAddDeviceProgressViewController *progressVC = nil;
            NSArray<UIViewController *> *vcs = [self.navigationController viewControllers];
            [vcs enumerateObjectsUsingBlock:^(UIViewController *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if ([obj isKindOfClass:MSAddDeviceProgressViewController.class]) {
                    progressVC = (MSAddDeviceProgressViewController *)obj;
                    *stop = YES;
                }
            }];
            
            
            if (progressVC) {
                
                NSString *ssid = self.wifiInputView.text;
                NSString *password = self.passwordInputView.text;
                NSString *currentSsid = [OEMDeviceTool currentWifiSSID];
                NSString *bssid = nil;
                if ([ssid isEqualToString:currentSsid]) {
                    bssid = [MideaTool currentWifiBSSID];
                } else if ([ssid isEqualToString:self.connectInfo.wifiSsid]) {
                    bssid = self.connectInfo.wifiBssid;
                } else {
                    bssid = @"00:00:00:00:00:00";
                }
                
                self.connectInfo.wifiSsid = ssid;
                self.connectInfo.retryCount += 1;
                self.connectInfo.wifiPassword = password;
                self.connectInfo.wifiBssid = bssid;
                progressVC.connectInfo = self.connectInfo;
                progressVC.connectInfo.deviceConnectType = MSDeviceConnectTypeRetry;
                progressVC.isScanSuccess = NO;
                [self.navigationController popToViewController:progressVC animated:YES];
              //  [progressVC retry];
            }
            return;
            
            
            
            
            
            
            __block MSBLEGuideViewController *guide = [[MSBLEGuideViewController alloc] init];
            self.connectInfo.deviceConnectType = MSDeviceConnectTypeRetry;
            NSArray<UIViewController *> *vcas = [self.navigationController viewControllers];
            [vcas enumerateObjectsUsingBlock:^(UIViewController *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if ([obj isKindOfClass:MSBLEGuideViewController.class]) {
                    guide = (MSBLEGuideViewController *)obj;
                    *stop = YES;
                }
            }];
            
            
            if (guide) {
                
                NSString *ssid = self.wifiInputView.text;
                NSString *password = self.passwordInputView.text;
                NSString *currentSsid = [OEMDeviceTool currentWifiSSID];
                NSString *bssid = nil;
                if ([ssid isEqualToString:currentSsid]) {
                    bssid = [MideaTool currentWifiBSSID];
                } else if ([ssid isEqualToString:self.connectInfo.wifiSsid]) {
                    bssid = self.connectInfo.wifiBssid;
                } else {
                    bssid = @"00:00:00:00:00:00";
                }
                
                self.connectInfo.wifiSsid = ssid;
                self.connectInfo.wifiPassword = password;
                self.connectInfo.wifiBssid = bssid;
                guide.connectInfo = self.connectInfo;
                [self.navigationController popToViewController:guide animated:YES];
            }
            return;
            
            
            
//            __block MSAddDeviceProgressViewController *progressVC = nil;
//            NSArray<UIViewController *> *vcs = [self.navigationController viewControllers];
//            [vcs enumerateObjectsUsingBlock:^(UIViewController *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//                if ([obj isKindOfClass:MSAddDeviceProgressViewController.class]) {
//                    progressVC = (MSAddDeviceProgressViewController *)obj;
//                    *stop = YES;
//                }
//            }];
//
//
//            if (progressVC) {
//                [self.navigationController popToViewController:progressVC animated:YES];
//                [progressVC retry];
//            }
//            return;
        }
        
        
        __block MSAddDeviceGuideViewController *guideVC = nil;
        NSArray<UIViewController *> *vcs = [self.navigationController viewControllers];
        [vcs enumerateObjectsUsingBlock:^(UIViewController *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([obj isKindOfClass:MSAddDeviceGuideViewController.class]) {
                guideVC = (MSAddDeviceGuideViewController *)obj;
                *stop = YES;
            }
        }];
        if (guideVC) {
            
            NSString *ssid = self.wifiInputView.text;
            NSString *password = self.passwordInputView.text;
            NSString *currentSsid = [OEMDeviceTool currentWifiSSID];
            NSString *bssid = nil;
            if ([ssid isEqualToString:currentSsid]) {
                bssid = [MideaTool currentWifiBSSID];
            } else if ([ssid isEqualToString:self.connectInfo.wifiSsid]) {
                bssid = self.connectInfo.wifiBssid;
            } else {
                bssid = @"00:00:00:00:00:00";
            }
            
            self.connectInfo.wifiSsid = ssid;
            self.connectInfo.wifiPassword = password;
            self.connectInfo.wifiBssid = bssid;
          //  [self.presenter saveSsid:ssid password:password];
            [self.navigationController popToViewController:guideVC animated:YES];
        }
        
    }
}

#pragma mark - notification
- (void)applicationDidBecomeActive:(NSNotification *)notification {
    NSString *wifiSsid = [OEMDeviceTool currentWifiSSID];
    if (wifiSsid && ![wifiSsid isEqualToString:@""]) {
        self.wifiInputView.text = wifiSsid;
        NSString *password = [self.presenter fetchPasswordWithSsid:wifiSsid];
        self.passwordInputView.text = password;
    }
}

- (void)locationAuthorizationStatusChanged:(NSNotification *)notification {
    NSDictionary *userInfo = notification.userInfo;
    int status = [userInfo[@"status"] intValue];
    
    if (status == kCLAuthorizationStatusAuthorizedWhenInUse) {
        NSString *wifiSsid = [OEMDeviceTool currentWifiSSID];
        if (wifiSsid && ![wifiSsid isEqualToString:@""]) {
            self.wifiInputView.text = wifiSsid;
            NSString *password = [self.presenter fetchPasswordWithSsid:wifiSsid];
            self.passwordInputView.text = password;
        }
    }
}

- (void)bluetoothAuthorizationStatusDidChange:(NSNotification *)notification {
    if ([[MSBLEManager shareManager] checkBluetoothAuthState] != MSBLEManagerTypeAuthorizedAndTurnOn){ //未打开
        self.alertViewController.isOpen = NO;
    }else{
        self.alertViewController.isOpen = YES;
    }
    
    if ([[MSBLEManager shareManager] checkBluetoothAuthState] >= MSBLEManagerTypeUnauthorized){ //未授权
        self.alertViewController.isAuthorized = NO;
    }else{
        self.alertViewController.isAuthorized = YES;
    }
    [self.alertViewController refreshUI];
}


- (void)locationCheck {
    if ([[MSLocationManager shareManager] checkLocationForCurrentWiFi]) {
        [[MSSystemPermissionManager shareManager] jumpToSystemSettingPage];
    }
}

#pragma mark - MSInputViewDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    if (textField.tag == kTextFieldTag+1) {
    }
    
}

- (void)didClickInputView:(MSInputView *)inputView {
    if (inputView == self.wifiInputView) {
        [self locationCheck];
    }
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    if (textField.tag == kTextFieldTag) {
        return NO;
    } else {
        return YES;
    }
}

-(void)showBLEAlert{
    if ([[MSBLEManager shareManager] checkBluetoothAuthState] != MSBLEManagerTypeAuthorizedAndTurnOn){
        self.alertViewController = [[OEMBLEAlertViewController alloc] init];
        self.alertViewController.modalPresentationStyle =  UIModalPresentationOverFullScreen;
        self.alertViewController.isAuthorized = ([[MSBLEManager shareManager] checkBluetoothAuthState] <= MSBLEManagerTypeAuthorized);
        self.alertViewController.isOpen = NO;
       // self.alertViewController.isSwitchBLE = YES;
        self.alertViewController.setBlock = ^{
            //跳转到app的系统设置页面
            [[MSSystemPermissionManager shareManager] jumpToSystemAppSettingPage];
        };
        
        self.alertViewController.openBlock = ^{
            //跳转到app的系统设置页面
            [[MSSystemPermissionManager shareManager] jumpToSystemAppSettingPage];
        };
        
        
        WEAKSELF
        self.alertViewController.switchBlock = ^{
            if (weakSelf.alertViewController.isAuthorized && weakSelf.alertViewController.isOpen) {
                [weakSelf popToProgressViewController];
            }
        };
        [self presentViewController:self.alertViewController animated:NO completion:nil];
        return;
    }else{
        [self popToProgressViewController];
    }
}



-(BOOL)isOverRetryLimit{
    BOOL isLimit = NO;
    if (([self.connectInfo.category.uppercaseString containsString:@"AC"] || [self.connectInfo.category.uppercaseString containsString:@"A1"]) &&  self.connectInfo.retryCount >= 2) {
        isLimit = YES;
    }else if (self.connectInfo.retryCount >= 1){
        isLimit = YES;
    }else{
        isLimit = NO;
    }
    return isLimit;
}

-(void)showOvertimeAlert{
    
    NSString *title = MSResourceString(@"config_fail_page_config_over_time");
    NSString *leftTitle = MSResourceString(@"config_fail_page_config_back_home");
    NSString *rightTitle = MSResourceString(@"ap_connect_fail_button_reset");
    

    OEMCommomAlertViewController *dest = [OEMCommomAlertViewController alertControllerWithTitle:title
                                                                                        content:@""
                                                                                        buttons:@[leftTitle,rightTitle]
                                                                                  isMiddleTheme:NO];
    WEAKSELF
    dest.leftBlock = ^{
        [weakSelf.navigationController popToRootViewControllerAnimated:YES];
    };
    
    dest.rightBlock = ^{
        [weakSelf popToGuideViewController];
    };
    [self presentViewController:dest animated:NO completion:nil];
}

-(void)popToProgressViewController{
    __block MSAddDeviceProgressViewController *progressVC = nil;
    NSArray<UIViewController *> *vcs = [self.navigationController viewControllers];
    [vcs enumerateObjectsUsingBlock:^(UIViewController *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj isKindOfClass:MSAddDeviceProgressViewController.class]) {
            progressVC = (MSAddDeviceProgressViewController *)obj;
            *stop = YES;
        }
    }];
    
    
    if (progressVC) {
        NSString *ssid = self.wifiInputView.text;
        NSString *password = self.passwordInputView.text;
        NSString *currentSsid = [OEMDeviceTool currentWifiSSID];
        NSString *bssid = nil;
        if ([ssid isEqualToString:currentSsid]) {
            bssid = [MideaTool currentWifiBSSID];
        } else if ([ssid isEqualToString:self.connectInfo.wifiSsid]) {
            bssid = self.connectInfo.wifiBssid;
        } else {
            bssid = @"00:00:00:00:00:00";
        }
        
        self.connectInfo.wifiSsid = ssid;
        self.connectInfo.mode = @"3";
        self.connectInfo.retryCount += 1;
        self.connectInfo.wifiPassword = password;
        self.connectInfo.wifiBssid = bssid;
        progressVC.connectInfo = self.connectInfo;
        progressVC.connectInfo.deviceConnectType = MSDeviceConnectTypeRetry;
        progressVC.isScanSuccess = NO;
        [self.navigationController popToViewController:progressVC animated:YES];
      //  [progressVC retry];
    }
}




-(void)popToAPConnectViewController{
    __block MSConnnectAPViewController *guide = [[MSConnnectAPViewController alloc] init];
    self.connectInfo.deviceConnectType = MSDeviceConnectTypeAP;
    self.connectInfo.retryCount += 1;
    self.connectInfo.mode = @"0";
    NSArray<UIViewController *> *vcas = [self.navigationController viewControllers];
    [vcas enumerateObjectsUsingBlock:^(UIViewController *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj isKindOfClass:MSConnnectAPViewController.class]) {
            guide = (MSConnnectAPViewController *)obj;
            *stop = YES;
        }
    }];
    
    if (guide) {
        guide.connectInfo = self.connectInfo;
        [self.navigationController popToViewController:guide animated:YES];
    }
}


-(void)popToGuideViewController{
    __block MSBLEGuideViewController *guide = [[MSBLEGuideViewController alloc] init];
    self.connectInfo.deviceConnectType = MSDeviceConnectTypeRetry;
    NSArray<UIViewController *> *vcas = [self.navigationController viewControllers];
    [vcas enumerateObjectsUsingBlock:^(UIViewController *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj isKindOfClass:MSBLEGuideViewController.class]) {
            guide = (MSBLEGuideViewController *)obj;
            *stop = YES;
        }
    }];
    
    
    if (guide) {
        NSString *ssid = self.wifiInputView.text;
        NSString *password = self.passwordInputView.text;
        NSString *currentSsid = [OEMDeviceTool currentWifiSSID];
        NSString *bssid = nil;
        if ([ssid isEqualToString:currentSsid]) {
            bssid = [MideaTool currentWifiBSSID];
        } else if ([ssid isEqualToString:self.connectInfo.wifiSsid]) {
            bssid = self.connectInfo.wifiBssid;
        } else {
            bssid = @"00:00:00:00:00:00";
        }
        
        if (self.addDeviceButton.type == ConnectTypeBLE || self.connectInfo.mode.integerValue == 3){
            self.connectInfo.mode = @"3";
        }else{
            self.connectInfo.mode = @"0";
        }
        
        self.connectInfo.wifiSsid = ssid;
        self.connectInfo.wifiPassword = password;
        self.connectInfo.wifiBssid = bssid;
        self.connectInfo.retryCount = 0;
        guide.connectInfo = self.connectInfo;
        [self.navigationController popToViewController:guide animated:YES];
    }
}

@end
