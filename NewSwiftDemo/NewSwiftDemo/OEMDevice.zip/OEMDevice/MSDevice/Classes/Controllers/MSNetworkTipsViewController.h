//
//  MSNetworkTipsViewController.h
//  MSDevice
//
//  Created by 及时行乐 on 2020/6/24.
//

#import <MSBusiness/MVPViewController.h>

typedef NS_ENUM(NSUInteger, MSNetworkTipsType) {
    MSNetworkTipsTypeWiFi5G,        // 不支持5GWiFi
    MSNetworkTipsTypeSecondary,     // 网络2次认证
};

@interface MSNetworkTipsViewController : MVPViewController

- (instancetype)initWithType:(MSNetworkTipsType)type;

@end

