//  
//  MSAddDeviceProgressViewController.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/14
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <MSBusiness/MVPViewController.h>
#import "MSAddDevicePresenter.h"
#import <MSBusiness/MSDeviceConnectResult.h>



@interface MSAddDeviceProgressViewController : MVPViewController<MSAddDevicePresenter *><MSAddDeviceViewProtocol>

@property (nonatomic, strong) MSDeviceConnectResult *connectInfo;
@property (nonatomic, assign) BOOL isFirstBle;   //设备是否为一代蓝牙
@property (nonatomic, assign) BOOL isAPFirstPage;    //是否ap配网指引的第一个页面进入

@property (nonatomic, assign) BOOL isScanSuccess;


//重试配网
-(void)retry;


@end
