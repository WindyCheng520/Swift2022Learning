//
//  MSChooseDeviceTypeViewController.h
//  MSDevice
//
//  Created by 及时行乐 on 2020/6/23.
//

#import <MSBusiness/MVPViewController.h>
#import "MSChooseDevicePresenter.h"

@interface MSChooseDeviceTypeViewController : MVPViewController<MSChooseDevicePresenter *><MSChooseDeviceViewProtocol>



@end

