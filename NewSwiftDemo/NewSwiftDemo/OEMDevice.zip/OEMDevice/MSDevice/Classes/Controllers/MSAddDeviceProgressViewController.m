//  
//  MSAddDeviceProgressViewController.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/14
//  Copyright © 2020 Midea. All rights reserved.
//  正在配网中页面
   

#import "MSAddDeviceProgressViewController.h"
#import "MSConnectSuccessViewController.h"
#import "MSConnectFailedViewController.h"
#import "MSConnnectAPViewController.h"
#import "MSAuthorizeViewController.h"
#import "MSBLEScanFailViewController.h"
#import <OEMTheme/OEMHGAlertController.h>

#import "MSAPAutoConnectWiFiView.h"
#import "MSPasswordWrongView.h"
#import "MSImagePageView.h"
#import "MSStepCell.h"
#import <OEMTheme/UILabel+OEMThemes.h>
#import <Lottie/LOTAnimationView.h>

#import <OEMFoundation/HGUIKit.h>
#import <OEMFoundation/HGFoundationMacros.h>
#import <OEMFoundation/OEMWeakProxy.h>
#import <OEMFoundation/OEMMacros.h>
#import "MSDeviceBundle.h"

#import <MSBusiness/MideaSecurity.h>
#import <MSBusiness/MSBLEManager.h>
#import <SDWebImage/UIImageView+WebCache.h>
#import <OEMFoundation/OEMDeviceTool.h>
#import <MSBusiness/OEMGlobalUIManager.h>
#import <MSBusiness/OEMCommomAlertViewController.h>
#import <OEMFoundation/OEMProgressView.h>

static NSString *const MSStepCellID = @"MSStepCellID";
static const NSInteger timeCount = 20;
@interface MSAddDeviceProgressViewController ()<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) HGImageView *leftIconImageView;
@property (nonatomic, strong) LOTAnimationView *animateView;
@property (nonatomic, strong) HGImageView *rightIconImageView;
@property (nonatomic, strong) LOTAnimationView *rightAnimateView;
@property (nonatomic, strong) HGImageView *cloudImageView;  
@property (nonatomic, strong) HGImageView *headImageView;   //头像

@property (nonatomic, strong) HGLabel *titleLabel;    //（添加设备）
@property (nonatomic, strong) HGLabel *tipLabel;      //家电与设备越靠近越容易成功
@property (nonatomic, strong) HGTableView *tableView;
@property (nonatomic, strong) OEMProgressView *progressView;
@property (nonatomic, strong) HGButton *cancelButton;

@property (nonatomic, strong) NSArray *dataArray;

@property (nonatomic, assign) NSInteger selectIndex;
@property (nonatomic, assign) BOOL isShowAlert;
@property (nonatomic, assign) BOOL isClickRetry;
@property (nonatomic, strong) HGAlertController *alertController;




@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, assign) NSInteger sec;


@end

@implementation MSAddDeviceProgressViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.titleLabel = [HGLabel new];
        self.leftIconImageView = [HGImageView new];
        if (isRTL()) {
            self.animateView = [LOTAnimationView animationNamed:@"data_rtl" inBundle:MSCurrentBundle];
            self.rightAnimateView = [LOTAnimationView animationNamed:@"data_rtl" inBundle:MSCurrentBundle];
        }else{
            self.animateView = [LOTAnimationView animationNamed:@"data" inBundle:MSCurrentBundle];
            self.rightAnimateView = [LOTAnimationView animationNamed:@"data" inBundle:MSCurrentBundle];

        }
        self.rightIconImageView = [HGImageView new];
        self.cloudImageView = [HGImageView new];
        self.headImageView = [HGImageView new];
        
        self.tableView = [HGTableView new];
        self.progressView = [OEMProgressView new];
        self.cancelButton = [HGButton new];
        self.tipLabel = [HGLabel new];
        self.presenter = [[MSAddDevicePresenter alloc] initWithView:self];
    }
    return self;
}



- (BOOL)navigationBarHidden {
    return YES;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
//    [self.navigationController setNavigationBarHidden:YES animated:YES];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    
    self.isShowAlert = NO;
    self.sec = timeCount;
    [self startScan];
}

- (void)applicationDidBecomeActive:(NSNotification *)notification {
    [self startScan];
}

- (void)startScan {
    if ((self.connectInfo.deviceConnectType <= MSDeviceConnectTypeSelectAutoFind && self.connectInfo.mode.integerValue == 3) || self.connectInfo.mode.integerValue == 0) {   //重试/手动/扫码才需要开启扫描(AP配网也不需要开开启扫描）
        return;
    }
    if ([[MSBLEManager shareManager] checkBluetoothAuthState] == MSBLEManagerTypeAuthorizedAndTurnOn) {
        if (!self.timer) {
            self.sec = timeCount;
            self.timer = [NSTimer timerWithTimeInterval:1.0 target:[OEMWeakProxy proxyWithTarget:self] selector:@selector(timerMethod) userInfo:nil repeats:YES];
            [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
        }
        [self.timer setFireDate:[NSDate date]];
        
        NSString  *sn8 = @"";
        if (self.connectInfo.deviceConnectType == MSDeviceConnectTypeManualSelect) {
            sn8 = @"";
        }else{
            sn8 = self.connectInfo.deviceSn8;
        }
        NSLog(@"进度页开始扫描配网--------------");
        [self.presenter startScanBLEWithCategory:self.connectInfo.category deviceSn8:sn8 timeout:(timeCount-1)];
    } else {
        if (!self.isShowAlert) {
            self.isShowAlert = YES;
            [[MSBLEManager shareManager] showBluetoothAuthorAlert];
        }
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidBecomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
    }
}


- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.navigationController.interactivePopGestureRecognizer.enabled = YES;
    [self.timer setFireDate:[NSDate distantFuture]];
    if (!self.isScanSuccess) {
        [self.presenter stopScan];
    } else {
        self.isScanSuccess = NO;
    }
}

- (void)timerMethod {
    self.sec --;
    if (self.sec < 0) {
        self.sec = 0;
        [self.timer setFireDate:[NSDate distantFuture]];
        [self pushToScanFail];
    }
}

- (void)pushToScanFail {
    MSBLEScanFailViewController *dest = [MSBLEScanFailViewController new];
    dest.connectInfo = self.connectInfo;
    [self.navigationController pushViewController:dest animated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.canRightSlideBack = NO;
    self.sec = timeCount;
    
    if (self.connectInfo.auxiing) {
        if (self.connectInfo.auxiMode.intValue == 0) {
            self.presenter.isBluetooth = NO;
        } else if (self.connectInfo.auxiMode.intValue == 3) {
            self.presenter.isBluetooth = YES;
        }
    } else {
        if (self.connectInfo.mode.intValue == 0) {
            self.presenter.isBluetooth = NO;
        } else if (self.connectInfo.mode.intValue == 3) {
            self.presenter.isBluetooth = YES;
        }
    }
    
        
    [self.view addSubview:self.cancelButton];
    self.cancelButton.titleLabel.font = kRegularFont(15);
    [self.cancelButton setTitleColor:RGBA_HEX(0x666666, 1) forState:UIControlStateNormal];
    [self.cancelButton setTitle:MSResourceString(@"add_device_process_page_cancel_button") forState:UIControlStateNormal];
    [self.cancelButton addTarget:self action:@selector(cancelAction:) forControlEvents:UIControlEventTouchUpInside];
    
    self.leftIconImageView.image = MSResourceImage(@"pic_connect_mobile");
    [self.view addSubview:self.leftIconImageView];
    
    self.animateView.loopAnimation = YES;
    self.animateView.animationSpeed = 1;
    [self.animateView play];
    [self.view addSubview:self.animateView];
    
    if (self.connectInfo.deviceImageUrl && ![self.connectInfo.deviceImageUrl isEqualToString:@""]) {
        [self.rightIconImageView sd_setImageWithURL:[NSURL URLWithString:self.connectInfo.deviceImageUrl] placeholderImage:[UIImage imageNamed:@"pic_category_default"]];
    } else {
        self.rightIconImageView.image = [UIImage imageNamed:@"pic_category_default"];
    }
   // self.rightIconImageView.image = MSResourceImage(@"pic_connect_server");
    [self.view addSubview:self.rightIconImageView];
    self.rightIconImageView.contentMode = UIViewContentModeScaleAspectFill;
    self.rightIconImageView.layer.masksToBounds = YES;
    
    self.rightAnimateView.loopAnimation = YES;
    self.rightAnimateView.animationSpeed = 1;
    [self.rightAnimateView play];
    [self.view addSubview:self.rightAnimateView];
    self.rightAnimateView.alpha = 0;
    
    self.cloudImageView.image = MSResourceImage(@"icon_cloud");
    [self.view addSubview:self.cloudImageView];
    self.cloudImageView.alpha = 0;

    self.headImageView.image = MSResourceImage(@"icon_user");
    [self.view addSubview:self.headImageView];
    self.headImageView.alpha = 0;
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.showsVerticalScrollIndicator = NO;
    [self.tableView registerClass:[MSStepCell class] forCellReuseIdentifier:MSStepCellID];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.allowsSelection = NO;
    self.tableView.estimatedRowHeight = 50;
    self.tableView.bounces = NO;
    
    [self.view addSubview:self.tableView];
    
    self.progressView.proViewBgColor = RGB_HEX(0xE5E5E8);
    self.progressView.proViewTintColor = RGB_HEX(0x25CF42);
    self.progressView.proCornerRadius = 3.0;
//    [self.progressView setProgressTintColor:RGB_HEX(0x25CF42)];
//    [self.progressView setTrackTintColor:RGB_HEX(0xE5E5E8)];
//    self.progressView.layer.cornerRadius = 3;
//    self.progressView.clipsToBounds = YES;
//    self.progressView.progress = 0;
    [self.view addSubview:self.progressView];
    
    self.titleLabel.font = kSemiboldFont(22);
    self.titleLabel.text = MSResourceString(@"add_device_process_page_adding_title");
    self.titleLabel.numberOfLines = 0;
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:self.titleLabel];
    
    self.tipLabel.font = kRegularFont(15);
    self.tipLabel.textColor = RGBA_HEX(0x000000, 1);
    self.tipLabel.text = MSResourceString(@"add_device_process_page_likelihood_to_configure_success_tip");
    self.tipLabel.numberOfLines = 0;
    self.tipLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:self.tipLabel];
    
    self.dataArray = [self.presenter msAddDeviceStepTitles];
    
    [self makeContstraints];
    
    self.selectIndex = 0;
    [self.tableView reloadData];
    
//    if (self.isAPFirstPage) {
//        NSString *ssidPrefix = [NSString stringWithFormat:@"toshiba_%@_", [self.connectInfo.category lowercaseString]];
//        [self.presenter autoConnectDeviceWiFiWithSSIDPrefix:ssidPrefix];
//    } else {
//        [self startAddDevice];
//    }
 
    if(self.connectInfo.deviceConnectType <= MSDeviceConnectTypeSelectAutoFind || self.connectInfo.mode.integerValue == 0){
        [self startAddDevice];
    }
    [self configureOEMTheme];
}

- (void)configureOEMTheme{
    [self.view configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.tableView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.titleLabel configure90TranslucentTrait];
    [self.tipLabel configure40TranslucentTrait];
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
#if OEMTHEMEDEBUGMODE
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self jumpToConnectFailVC:nil];
    });
#endif
    
    
    [self.cancelButton specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIButton_TitleTraitColor) : kDarkText.mainTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UIButton_TitleTraitColor) : kLightText.mainTextColor
    }];
    
    
    [self.titleLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.mainTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.mainTextColor
    }];
    
    
    [self.tipLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.secondColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.secondColor
    }];
    
}


-(void)retry{
//    self.selectIndex = 0;
//    self.progressView.progress = 0.0;
//    [self.tableView reloadData];
 //   [self startAddDevice];
}

//开始配网的方法
- (void)startAddDevice {
    [self.presenter setupAddDeviceModuleWithConnectInfo:self.connectInfo];
    [self.presenter startAddDevice];
}

- (void)makeContstraints {
    [self.cancelButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(16);
        make.top.mas_equalTo(STATUSBAR_HEIGHT+5);
    }];
    
    [self.animateView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(STATUSBAR_HEIGHT + 80);
        make.centerX.mas_equalTo(self.view.mas_centerX);
        make.size.mas_equalTo(CGSizeMake(60, 60));
    }];
    
    [self.leftIconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.animateView.mas_centerY);
        make.trailing.mas_equalTo(self.animateView.mas_leading);
        make.size.mas_equalTo(CGSizeMake(88, 88));
    }];
    
    [self.rightIconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.animateView.mas_centerY);
        make.leading.mas_equalTo(self.animateView.mas_trailing);
        make.size.mas_equalTo(CGSizeMake(88, 88));
    }];
    
    [self.rightAnimateView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.animateView.mas_centerY);
        make.leading.mas_equalTo(self.rightIconImageView.mas_trailing);
        make.size.mas_equalTo(CGSizeMake(60, 60));
    }];
    
    [self.cloudImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.animateView.mas_centerY);
        make.leading.mas_equalTo(self.rightAnimateView.mas_trailing);
        make.size.mas_equalTo(CGSizeMake(88, 88));
    }];
    
    [self.headImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.animateView.mas_centerY);
        make.leading.mas_equalTo(self.rightAnimateView.mas_trailing);
        make.size.mas_equalTo(CGSizeMake(88, 88));
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.view.mas_centerX);
        make.top.mas_equalTo(self.rightIconImageView.mas_bottom).offset(30);
        make.leading.mas_equalTo(80);
        make.trailing.mas_equalTo(-80);
    }];
    
    [self.tipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.view.mas_centerX);
        make.top.mas_equalTo(self.titleLabel.mas_bottom).offset(9);
        make.leading.mas_equalTo(80);
        make.trailing.mas_equalTo(-80);
    }];
    
    [self.progressView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.view.mas_centerX);
        make.top.mas_equalTo(self.tipLabel.mas_bottom).offset(40);
        make.width.mas_equalTo(120);
        make.height.mas_equalTo(4);
    }];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.progressView.mas_bottom).offset(80);
        make.leading.mas_equalTo(0);
        make.trailing.mas_equalTo(0);
        make.bottom.mas_equalTo(0);
    }];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    MSStepCell *cell = [tableView dequeueReusableCellWithIdentifier:MSStepCellID forIndexPath:indexPath];
    NSString *title = self.dataArray[indexPath.row];
    cell.stepLabel.text = title;
    [cell.loadView setAnimationNamed:@"loading" inBundle:MSCurrentBundle];
    cell.loadView.hidden = YES;
    [cell.loadView stop];

    if (indexPath.row < self.selectIndex-1) {
        cell.loadView.hidden = NO;
        [cell.loadView setAnimationNamed:@"check" inBundle:MSCurrentBundle];
        cell.loadView.animationSpeed = 1;
        cell.loadView.loopAnimation = NO;
        [cell.loadView playFromProgress:1 toProgress:1 withCompletion:nil];
    } else if (indexPath.row == self.selectIndex-1) {
        cell.loadView.hidden = NO;
        [cell.loadView setAnimationNamed:@"check" inBundle:MSCurrentBundle];
        cell.loadView.animationSpeed = 1;
        cell.loadView.loopAnimation = NO;
        [cell.loadView play];
    } else if (indexPath.row == self.selectIndex) {
        cell.loadView.hidden = NO;
        @try {
            [cell.loadView setAnimationNamed:@"loading" inBundle:MSCurrentBundle];
        } @catch (NSException *exception) {
            NSLog(@"%s,%@", __func__, exception);
        } @finally {
                
        }
        cell.loadView.animationSpeed = 1;
        cell.loadView.loopAnimation = YES;
        [cell.loadView play];
    } else {
        cell.loadView.hidden = YES;
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 38;
}

#pragma mark - action
- (void)cancelAction:(UIButton *)sender {
//    WEAK_SELF;
//    HGAlertAction* giveUpAction = [HGAlertAction actionWithTitle:MSResourceString(@"add_device_process_page_giveup_button") style:HGAlertActionStyleCancel action:^{
//        STRONG_SELF;
//        [self.presenter cancelAddDevice];
////        [self.navigationController popToRootViewControllerAnimated:YES];
//    }];
//
    NSString *typeName = self.connectInfo.deviceName; //[self.presenter deviceNameWithCategory:self.connectInfo.category];
    NSString *title = [NSString stringWithFormat:MSResourceString(@"add_device_process_page_alert_give_up"), typeName];
    NSString *message = [NSString stringWithFormat:MSResourceString(@"add_device_process_page_giveup_message"), typeName];
//    HGAlertAction* tryingAction = [HGAlertAction actionWithTitle:MSResourceString(@"add_device_process_page_giveup_cancel") action:^{
//        STRONG_SELF;
//        [self.alertController.view removeFromSuperview];
//    }];
//    HGAlertController* alertController = [OEMHGAlertController alertControllerWithTitle:title message:message actions:@[giveUpAction, tryingAction]];
//    self.alertController = alertController;
//    [self.view addSubview:self.alertController.view];
    
    
    NSArray *buttons = @[MSResourceString(@"add_device_process_page_giveup_button"), MSResourceString(@"add_device_process_page_giveup_cancel")];
    
    OEMCommomAlertViewController *dest = [OEMCommomAlertViewController alertControllerWithTitle:title
                                                                                        content:message
                                                                                        buttons:buttons
                                                                                isMiddleTheme:NO];
    WEAKSELF
    dest.leftBlock = ^{
        [weakSelf.presenter cancelAddDevice];
    };
    
    dest.rightBlock = ^{
        
    };
    
    [self presentViewController:dest animated:NO completion:nil];
    
}

#pragma mark - MSAddDeviceViewProtocol
- (void)msAddDeviceSuccess:(MSAddDevicePresenter *)presenter
                  deviceId:(NSString *)deviceId
                deviceName:(NSString *)deviceName
                 deviceSN8:(NSString *)deviceSN8
                 thingCode:(NSString *)thingCode
           firmwareVersion:(NSString *)firmwareVersion{
    self.connectInfo.deviceId = deviceId;
    self.connectInfo.deviceName = deviceName;
    self.connectInfo.deviceSn8 = deviceSN8;
    self.connectInfo.thingCode = thingCode;
    self.connectInfo.firmwareVersion = firmwareVersion;
    self.progressView.progress = 1.0;
    self.selectIndex = self.dataArray.count;
    [self.tableView reloadData];
    
    MSAuthorizeViewController *dest = [[MSAuthorizeViewController alloc] init];
    dest.modalPresentationStyle =  UIModalPresentationOverFullScreen;
    WEAKSELF
    dest.block = ^{
        [weakSelf jumpToConnectSuccessVCWithDeviceId:deviceId deviceName:deviceName sn8:deviceSN8];
    };
    [self presentViewController:dest animated:NO completion:nil];
    
}


//有wifi 模块的模组
- (void)msAddDeviceSuccess:(MSAddDevicePresenter *)presenter
                 thingCode:(NSString *)thingcode
                deviceName:(NSString *)deviceName{
    self.progressView.progress = 1.0;
    self.selectIndex = self.dataArray.count;
    [self.tableView reloadData];
    [self jumpToConnectSuccessVCWithThingCode:thingcode deviceName:deviceName];
}


//只含有thingCode
- (void)jumpToConnectSuccessVCWithThingCode:(NSString *)thingCode deviceName:(NSString *)deviceName{
    if ([[OEMRouterHandler getCurrentViewController] isKindOfClass:[self class]]) {
        MSConnectSuccessViewController *successVC = [MSConnectSuccessViewController new];
        successVC.thingCode = thingCode;
        successVC.applianceName = deviceName;
        successVC.isBluetooth = self.presenter.isBluetooth;
        successVC.connectInfo = self.connectInfo;
        [self.navigationController pushViewController:successVC animated:YES];
        [self.presenter saveSsid:self.connectInfo.wifiSsid?:@"" password:self.connectInfo.wifiPassword?:@""];  //验证密码正确了(配网成功了）才保存wifi 密码
        [self.presenter destroyTimer];
    }
}




- (void)msAddDeviceSuccess:(MSAddDevicePresenter *)presenter deviceId:(NSString *)deviceId deviceName:(NSString *)deviceName deviceSN:(NSString *)deviceSN {
    self.progressView.progress = 1.0;
    self.selectIndex = self.dataArray.count;
    [self.tableView reloadData];
    
    //解析sn8
    NSString *sn8 = @"";
    if (deviceSN.length > 0) {
        sn8 = deviceSN.length >= 17 ? [deviceSN substringWithRange:NSMakeRange(9, 8)] : @"";
    }
//    if (self.alertController) {
//        @weakify(self)
//        [self.alertController dismissViewControllerAnimated:NO completion:^{
//           @strongify(self)
//            [self jumpToConnectSuccessVCWithDeviceId:deviceId deviceName:deviceName sn8:sn8];
//        }];
//    } else {
        [self jumpToConnectSuccessVCWithDeviceId:deviceId deviceName:deviceName sn8:sn8];
//    }
    
    //埋点
    NSString *category = self.connectInfo.category ?: @"";
    if (self.connectInfo.category.length > 0 && ![self.connectInfo.category hasPrefix:@"0x"]) {
        category = [NSString stringWithFormat:@"0x%@", self.connectInfo.category];
    }
}

- (void)jumpToConnectSuccessVCWithDeviceId:(NSString *)deviceId deviceName:(NSString *)deviceName sn8:(NSString *)sn8{
    if ([[OEMRouterHandler getCurrentViewController] isKindOfClass:[self class]]) {
        MSConnectSuccessViewController *successVC = [MSConnectSuccessViewController new];
        successVC.applianceId = deviceId;
        successVC.applianceName = deviceName;
        successVC.isBluetooth = self.presenter.isBluetooth;
        successVC.connectInfo = self.connectInfo;
        successVC.sn8 = sn8;
        [self.navigationController pushViewController:successVC animated:YES];
        [self.presenter destroyTimer];
    }
}

- (void)msAddDeviceFaild:(MSAddDevicePresenter *)presenter error:(NSError *)error {
    if (error.code == 110000 + 4002) {
        // !!!: 已确认交互不做处理
    } else if (error.code == 110000 + 4090 || error.code == 110000 + 4094) {
        //AP配网密码错误code114090，蓝牙配网密码错误114094
        if (self.isShowAlert) {
            if (self.isClickRetry) {
                //如果已经返回过密码错误，再返回则直接跳转配网失败页面
                [self jumpToConnectFailVC:error];
            }
            return;
        }
        self.isShowAlert = YES;
        // 密码错误时弹框
        MSPasswordWrongView *passwordView = [[MSPasswordWrongView alloc] initWithWifiName:self.connectInfo.wifiSsid?:@"" password:self.connectInfo.wifiPassword?:@""];
        [passwordView showWithSuperview:self.view];
        @weakify(self)
        passwordView.clickRetryBlock = ^(NSString *password) {
            @strongify(self)
            self.isClickRetry = YES;
            [self.presenter retryAddDeviceWithNewPassword:password?:@""];
           // [self.presenter saveSsid:self.connectInfo.wifiSsid?:@"" password:password?:@""];  //暂不保存wifi密码
        };
    } else {
        [self jumpToConnectFailVC:error];
    }
    
   // [self jumpToConnectFailVC:error];
    
}

- (void)jumpToConnectFailVC:(NSError *)error {
    self.progressView.progress = 0.0;
    self.selectIndex = 0;
    [self.tableView reloadData];
    if (![[OEMRouterHandler getCurrentViewController] isKindOfClass:[self class]]) {
        return;
    }
    if (error.code == 110003 ) {
        MSBLEScanFailViewController *dest = [MSBLEScanFailViewController new];
        dest.connectInfo = self.connectInfo;
        dest.errorCode = error.code;
        [self.navigationController pushViewController:dest animated:YES];
    }else{
        MSConnectFailedViewController *failVC = [MSConnectFailedViewController new];
        failVC.error = error;
        failVC.connectInfo = self.connectInfo;
        [self.navigationController pushViewController:failVC animated:YES];
    }

    [self.presenter destroyTimer];
    NSString *category = self.connectInfo.category ?: @"";
    if (self.connectInfo.category.length > 0 && ![self.connectInfo.category hasPrefix:@"0x"]) {
        category = [NSString stringWithFormat:@"0x%@", self.connectInfo.category];
    }
    
}

- (void)msAddDeviceRefresh:(MSAddDevicePresenter *)presenter progress:(NSInteger)progress step:(NSInteger)stepType {
    if ((self.connectInfo.deviceConnectType >= MSDeviceConnectTypeManualSelect) && (!self.isScanSuccess)) {
        return;
    }
    
    if (self.selectIndex < stepType) {
        self.selectIndex = stepType;
        [self.tableView reloadData];
        
        if (stepType == 1) {
            [self firstStepToSecondStepAnimation];
        } else if (stepType == 2) {
            [self secondStepToThirdStepAnimation];
        }
    }
    self.progressView.progress = ((CGFloat)progress) / 100.0;
}

- (void)msAddDeviceCancel:(MSAddDevicePresenter *)presenter {
    if  (self.connectInfo.deviceConnectType ==  MSDeviceConnectTypeHomeAutoFind){
        [self.navigationController popToRootViewControllerAnimated:YES];
    }else{
        [self popToChooseDeviceTypeViewController];
    }
}

//返回选择品类页
- (void)popToChooseDeviceTypeViewController{
    NSMutableArray *mvcvs = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
    __block UIViewController *tempViewController = nil;
    [mvcvs enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        UIViewController *viewController =   (UIViewController *)obj;
        if ([viewController isKindOfClass:NSClassFromString(@"MSChooseDeviceTypeViewController")]) {
            tempViewController = viewController;
            *stop = YES;
            return;
        }
    }];
    if (tempViewController){
        [self.navigationController popToViewController:tempViewController animated:YES];
    }
}


- (void)msAutoConnectDeviceWiFiFinished:(MSAddDevicePresenter *)presenter error:(NSError *)error {
    
    if (error) {
        if (error.code == 7) {  //取消, 则弹框
            [self showRetryAutoConnectWiFiView];
        } else {
            [self jumpToConnectAPVC];
        }
        
    } else {
        //判断当前连接的wifi是否正确
        NSString *wifiSsid = [OEMDeviceTool currentWifiSSID];
        NSString *prefix = [NSString stringWithFormat:@"toshiba_%@_", [self.connectInfo.category lowercaseString]];
        
        if ([wifiSsid hasPrefix:prefix]) {
            self.connectInfo.deviceSsid = wifiSsid;
            [self startAddDevice];
        } else {
            [self jumpToConnectAPVC];
        }
    }
    
}


//当前页面扫描到设备并开启配网
- (void)scanDeviceSuccess:(MSAddDevicePresenter *)presenter peripheral:(MSOEMCBPeripheral *)peripheral {
    if (self.isScanSuccess) {
        return;
    }
    self.isScanSuccess = YES;
    [self.timer setFireDate:[NSDate distantFuture]];
    self.connectInfo.peripheral = peripheral;
    self.connectInfo.deviceSsid = self.presenter.deviceSSID;
    [self.presenter stopScan];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 需要延迟执行的代码
        [self startAddDevice];
    });
    
    
}

- (void)showRetryAutoConnectWiFiView {
    NSString *wifiName = [NSString stringWithFormat:@"toshiba_%@_xxxx", [self.connectInfo.category lowercaseString]];
    MSAPAutoConnectWiFiView *retryView = [[MSAPAutoConnectWiFiView alloc]initWithWiFiName:wifiName];
    [retryView showWithSuperview:self.view.window];
    
    @weakify(self)
    retryView.didClickDelete = ^{
        @strongify(self)
        [self.navigationController popViewControllerAnimated:YES];
    };
    
    retryView.didClickRetry = ^{
        @strongify(self)
        NSString *ssidPrefix = [NSString stringWithFormat:@"toshiba_%@_", [self.connectInfo.category lowercaseString]];
        [self.presenter autoConnectDeviceWiFiWithSSIDPrefix:ssidPrefix];
    };
    
}

- (void)jumpToConnectAPVC {
    DDLogDeviceInfo(@"jumpToConnectAPVC");
    
    MSConnnectAPViewController *vc = [MSConnnectAPViewController new];
    vc.connectInfo = self.connectInfo;
    [self.navigationController pushViewController:vc animated:YES];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        __block MSAddDeviceProgressViewController *progressVC = nil;
        NSArray<UIViewController *> *vcs = [self.navigationController viewControllers];
        [vcs enumerateObjectsUsingBlock:^(UIViewController *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([obj isKindOfClass:MSAddDeviceProgressViewController.class]) {
                progressVC = (MSAddDeviceProgressViewController *)obj;
                *stop = YES;
            }
        }];
        DDLogDeviceInfo(@"MSAddDeviceProgressViewController : %@", progressVC);
        if (progressVC) {
            NSMutableArray *vcArray = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
            [vcArray removeObject:progressVC];
            self.navigationController.viewControllers = [vcArray copy];
        }
    });
}

#pragma mark - animation
- (void)firstStepToSecondStepAnimation {
    
    //更换图片
    if (self.connectInfo.deviceImageUrl && ![self.connectInfo.deviceImageUrl isEqualToString:@""]) {
        [self.rightIconImageView sd_setImageWithURL:[NSURL URLWithString:self.connectInfo.deviceImageUrl] placeholderImage:[UIImage imageNamed:@"pic_category_default"]];
    }
    if (isRTL()) {
        [UIView animateWithDuration:1 animations:^{
            [self.animateView mas_updateConstraints:^(MASConstraintMaker *make) {
                make.centerX.mas_equalTo(self.view.mas_centerX).offset(60+88);
            }];
            self.rightAnimateView.alpha = 1;
            [self.view layoutIfNeeded];
        } completion:nil];
    }else{
        [UIView animateWithDuration:1 animations:^{
            [self.animateView mas_updateConstraints:^(MASConstraintMaker *make) {
                make.centerX.mas_equalTo(self.view.mas_centerX).offset(-60-88);
            }];
            self.rightAnimateView.alpha = 1;
            [self.view layoutIfNeeded];
        } completion:nil];
    }
    [UIView animateWithDuration:0.5 animations:^{
        self.leftIconImageView.alpha = 0;
        self.animateView.alpha = 0;
        self.rightIconImageView.transform = CGAffineTransformMakeScale(1.1, 1.1);
        
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.5 animations:^{
            self.cloudImageView.alpha = 1;
            self.rightIconImageView.transform = CGAffineTransformMakeScale(1, 1);
        } completion:nil];
    }];
    
    
}

- (void)secondStepToThirdStepAnimation {
    
    self.headImageView.transform = CGAffineTransformMakeScale(0.2, 0.2);
    [UIView animateWithDuration:1 animations:^{
        self.cloudImageView.transform = CGAffineTransformMakeScale(0.2, 0.2);
        self.cloudImageView.alpha = 0;
        self.headImageView.transform = CGAffineTransformMakeScale(1, 1);
        self.headImageView.alpha = 1;
    } completion:nil];
    
}



@end
