//
//  MSAuthorizeViewController.m
//  MSDevice
//
//  Created by pactera on 2020/11/25.
//  后确权

#import "MSAuthorizeViewController.h"
#import "MSImagePageView.h"
#import <MSBusiness/MSRequestFailView.h>
#import <OEMFoundation/MSVerticalButtonAlertView.h>
#import "MSAuthorizeTimeoutView.h"
#import "MSDeviceBundle.h"
#import <MBProgressHUD/MBProgressHUD.h>
#import <MSBusiness/MSNotificationConst.h>
#import <MSBusiness/MSRouterUrl.h>
#import <OEMTheme/OEMHGAlertController.h>
#import <OEMTheme/UILabel+OEMThemes.h>
#import <OEMFoundation/OEMFoundation-Swift.h>
#import <MSBusiness/BusinessRequestManager.h>
#import <MSBusiness/MSBusiness-Swift.h>

@interface MSAuthorizeViewController ()

@property (nonatomic, strong) HGView *backView;


@property (nonatomic, strong) HGScrollView *scrollView;
@property (nonatomic, strong) HGView *contentView;      //内容容器
@property (nonatomic, strong) MSImagePageView *imagePageView;
@property (nonatomic, strong) HGLabel *titleLabel;      //提示标题
@property (nonatomic, strong) HGLabel *desLabel;        //描述内容

@property (nonatomic, strong) HGLabel *minuteLabel;     //

@property (nonatomic, strong) HGTextView *messageView;
@property (nonatomic, strong) MSRequestFailView *requestFailView;

@property (nonatomic, strong) HGButton *tryAgainButton;
@property (nonatomic, strong) HGButton *abandanButton;
@property (nonatomic, strong) HGButton *cancelButton;


@property (nonatomic, strong) MSVerticalButtonAlertView *cancelAlertView;
@property (nonatomic, strong) MSAuthorizeTimeoutView *timeoutView;
@property (nonatomic, assign) BOOL isAddSubviews;    //是否加载过子视图

@property (nonatomic, assign) BOOL isTimeOut;         //是否超时

@end

@implementation MSAuthorizeViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        self.presenter = [[MSAuthorizePresenter alloc] initWithView:self];
        self.backView = [HGView new];
        self.scrollView = [[HGScrollView alloc] init];
        self.contentView = [[HGView alloc] initWithFrame:CGRectZero];
        
        self.titleLabel = [HGLabel new];
        self.desLabel = [HGLabel new];
        
        self.minuteLabel = [HGLabel new];
        
        self.tryAgainButton = [HGButton new];
        self.abandanButton = [HGButton new];
        self.cancelButton = [HGButton new];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];      //RGBA_HEX(0x000000, 0.5f);
//    self.containView.backgroundColor = [UIColor whiteColor];
//    [self.view addSubview:self.containView];
    
    self.cancelButton.frame = CGRectMake(16, STATUSBAR_HEIGHT, 200, 44);
    self.cancelButton.titleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightRegular];
    [self.cancelButton setTitleColor:RGB_HEX(0x666666) forState:UIControlStateNormal];
    [self.cancelButton setTitle:MSResourceString(@"connect_notnow_set") forState:UIControlStateNormal];
    self.cancelButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [self.cancelButton addTarget:self action:@selector(cancelAction:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithCustomView:self.cancelButton];
   // self.navigationItem.leftBarButtonItem = leftItem;
    
   // [self.presenter getAuthInfoWithCategory:self.category code:self.code];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillEnterForeground:) name:UIApplicationWillEnterForegroundNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deviceAuthConfirm:) name:kMideaDeviceAuthConfirmNotification object:nil];
    
    [self configSubviews];
    [self configureOEMTheme];
    [self.presenter startTimerCountDown];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.navigationController.interactivePopGestureRecognizer.enabled = YES;
    [self.timeoutView dismiss];
    [self.cancelAlertView dismiss];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)configSubviews {
    self.backView.frame = CGRectMake(0, 0, SCREEN_WIDTH, 454);
    self.backView.backgroundColor = [UIColor whiteColor];
//    self.backView.layer.cornerRadius = 16.;
//    self.backView.clipsToBounds = YES;
    [self.view addSubview:self.backView];
    
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:self.backView.bounds byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadii:CGSizeMake(16,16)];
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = self.backView.bounds;
    maskLayer.path = maskPath.CGPath;
    self.backView.layer.mask = maskLayer;

    
    
    self.scrollView.showsVerticalScrollIndicator = YES;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.backgroundColor = [UIColor clearColor];
    [self.backView addSubview:self.scrollView];
    
    self.contentView.backgroundColor = [UIColor clearColor];
    [self.scrollView addSubview:self.contentView];
    
    self.imagePageView.layer.cornerRadius = 8.0;
    self.imagePageView.clipsToBounds = YES;
   // NSString *url = @"https://s3.us-east-2.amazonaws.com/c.dcpfc.s3.us-east-2.amazonaws.com/idcp/2021/1/20/54b707df935c4e8daf306f72b9f30eb2.png";
    UIImage *image =  MSResourceImage(@"img_connect_confirm");
    self.imagePageView = [[MSImagePageView alloc] initWithFrame:CGRectZero imageList:@[image] defaultImageColor:RGB_HEX(0xE5E5E8)];
    [self.contentView addSubview:self.imagePageView];
    
    
    self.titleLabel.textColor = RGB_HEX(0x000000);
    self.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.numberOfLines = 0;
    [self.titleLabel sizeToFit];
    [self.contentView addSubview:self.titleLabel];
    self.titleLabel.text = MSResourceString(@"To continue connecting, please follow the guide to complete the setup in 60S");
    
    
    self.desLabel.textColor = RGB_HEX(0x8A8A8F);
    self.desLabel.font =  [UIFont systemFontOfSize:14 weight:UIFontWeightRegular];
    self.desLabel.text = MSResourceString(@"Press the \"∧\" and \"∨\" key at the same time on the front side of the water heater, which will be turned on after the warning tone of \"beep\".");
    [self.desLabel sizeToFit];
    self.desLabel.textAlignment = NSTextAlignmentCenter;
    self.desLabel.numberOfLines = 0;
    [self.contentView addSubview:self.desLabel];
    
    
    self.minuteLabel.textAlignment = NSTextAlignmentCenter;
    self.minuteLabel.textColor = RGB_HEX(0x267AFF);
    self.minuteLabel.font =  [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
    self.minuteLabel.text = @"60S";
    self.minuteLabel.hidden = NO;
    [self.backView addSubview:self.minuteLabel];
    
    
    
    self.tryAgainButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    [self.tryAgainButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
    self.tryAgainButton.backgroundColor = RGB_HEX(0x267AFF);
    self.tryAgainButton.layer.cornerRadius = 22.0;
    self.tryAgainButton.clipsToBounds = YES;
    [self.tryAgainButton setTitle:MSResourceString(@"Try Again") forState:UIControlStateNormal];
    self.tryAgainButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    [self.tryAgainButton addTarget:self action:@selector(clickAction:) forControlEvents:UIControlEventTouchUpInside];
    self.tryAgainButton.hidden = YES;
    [self.backView addSubview:self.tryAgainButton];
    
    
  
    self.abandanButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    [self.abandanButton setTitleColor:RGBA_HEX(0x000000, 0.4f) forState:UIControlStateNormal];
    [self.abandanButton setTitle:MSResourceString(@"abandan") forState:UIControlStateNormal];
    self.abandanButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    [self.abandanButton addTarget:self action:@selector(clickAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.backView addSubview:self.abandanButton];
    


    [self makeContstraints];
}

- (void)makeContstraints {

    [self.backView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.view).offset(0);
        make.trailing.equalTo(self.view).offset(0);
        make.bottom.equalTo(self.view).offset(0);
        make.height.mas_equalTo(454);
    }];
    
    
    [self.scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.backView).offset(16);
        make.leading.equalTo(self.backView).offset(16);
        make.trailing.equalTo(self.backView).offset(-16);
        make.bottom.equalTo(self.backView).offset(-140);
    }];
    
    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.bottom.right.equalTo(self.scrollView).with.insets(UIEdgeInsetsZero);
        make.width.equalTo(self.scrollView);
    }];
    
    [self.imagePageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.contentView);
        make.trailing.equalTo(self.contentView);
        make.top.equalTo(self.contentView);
        make.height.mas_equalTo(184);
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.imagePageView.mas_bottom).offset(16);
        make.leading.equalTo(self.contentView).offset(13);
        make.trailing.equalTo(self.contentView).offset(-13);
    }];
    
    [self.desLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleLabel.mas_bottom).offset(16);
        make.leading.equalTo(self.contentView).offset(13);
        make.trailing.equalTo(self.contentView).offset(-13);
    }];
    
    
    
    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.desLabel.mas_bottom).offset(5);
    }];
    
    [self.minuteLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.backView).offset(-80);
        make.width.mas_equalTo(100);
        make.centerX.equalTo(self.backView);
    }];
    
    
    [self.tryAgainButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.backView).offset(-67);
        make.leading.equalTo(self.backView).offset(16);
        make.trailing.equalTo(self.backView).offset(-16);
        make.height.mas_equalTo(44);
    }];

    
    [self.abandanButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.backView).offset(-40);
        make.width.mas_equalTo(100);
        make.centerX.equalTo(self.backView);
        make.height.mas_equalTo(15);
    }];
}


- (void)configureOEMTheme{
    [self.backView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.titleLabel configure90TranslucentTrait];
    [self.desLabel configure60TranslucentTrait];
    [self.abandanButton configureThemeTag:OEMThemesTag_UIButton_TitleTraitColor];
}


- (MSRequestFailView *)requestFailView {
    if (!_requestFailView) {
        _requestFailView = [[MSRequestFailView alloc]initWithFrame:CGRectMake(0, STATUSBAR_HEIGHT+44+80, SCREEN_WIDTH, 0)];
        WEAK_SELF;
        _requestFailView.clickButtonBlock = ^{
            STRONG_SELF;
            self.requestFailView.hidden = YES;
            if (self.isAddSubviews) {
                self.backView.hidden = NO;
                [self.presenter checkApplianceAuthStatusWithApplianceCode:self.applianceId showLoading:YES];
            } else {
                [self.presenter getAuthInfoWithCategory:self.category code:self.code];
            }
        };
        [self.view addSubview:self.requestFailView];
    }
    return _requestFailView;
}

#pragma mark - click event/notification
- (void)clickAction:(HGButton *)sender{
    
    if (sender == self.tryAgainButton) {
        self.minuteLabel.hidden = NO;
        self.tryAgainButton.hidden = YES;
        self.titleLabel.text =  MSResourceString(@"To continue connecting, please follow the guide to complete the setup in 60S");
        self.isTimeOut = NO;
        [self.presenter startTimerCountDown];
        
    }else{
        
 
        WEAKSELF
        [self dismissViewControllerAnimated:NO completion:^{
           // [DOFRouter handleURL:MSRouterHomeIndex];
            if (weakSelf.block) {
                weakSelf.block();
            }
        }];
    }
}





- (void)cancelAction:(HGButton *)sender {
    [self.cancelAlertView showWithSuperview:self.view.window];

    WEAK_SELF;
    self.cancelAlertView.clickCancelBlock = ^{
        STRONG_SELF;
        [self popMethod];
    };
    self.cancelAlertView.clickConfirmBlock = ^{
    };
    
}

- (void)applicationWillEnterForeground:(NSNotification *)notification {
    [self.presenter applicationWillEnterForeground:notification];
}

- (void)deviceAuthConfirm:(NSNotification *)notification {
    if (notification.userInfo[@"applianceCode"]) {
        NSString *applianceCode = notification.userInfo[@"applianceCode"];
        if ([applianceCode isEqualToString:self.applianceId]) {
            [self showSuccessToast];
        }
    }
}

- (void)showSuccessToast {
    [self hideLoading];
    
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view.window animated:YES];
    hud.mode = MBProgressHUDModeCustomView;
    UIView *firstView = [hud.bezelView.subviews firstObject];
    if ([firstView isKindOfClass:[UIVisualEffectView class]]) {
        UIVisualEffectView *effectView = (UIVisualEffectView *)firstView;
        effectView.effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    }
    UIImageView *imageView = [[UIImageView alloc] initWithImage:MSResourceImage(@"ic_setupcomplete")];
    hud.customView = imageView;
    hud.label.text = MSResourceString(@"connect_set_success");
    hud.label.numberOfLines = 0;
    [hud.label mas_updateConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(110);
    }];
    hud.bezelView.layer.cornerRadius = 13;
    hud.label.textColor = UIColor.whiteColor;
    hud.label.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5f * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [hud hideAnimated:NO];
        [self authSuccessToJump];
    });
    
    NSString *category = self.category ?: @"";
    if (self.category.length > 0 && ![self.category hasPrefix:@"0x"]) {
        category = [NSString stringWithFormat:@"0x%@", self.category];
    }
}

//确权成功的跳转操作
- (void)authSuccessToJump {
    if (self.enterType == 2) {
        //已确权 进入插件页
        if (self.pluginAddress && self.pluginAddress.length != 0) {
            if ([BusinessNetWorkTools isNetworkUnreachable]) {
                [self popMethod];
                [self toastText:MSResourceString(@"me_network_not_connected")];
            } else {
                //直接进入插件页，退出时直接回到首页
                NSString *urlString = [NSString stringWithFormat:@"%@/%@", NSHomeDirectory(),self.pluginAddress];
                NSURL *url = [NSURL fileURLWithPath:[urlString stringByAppendingPathComponent:@"weex.js"]];
                [OEMRouter handleURL:MSRouterWeexIndex withParams:@{@"url":url, @"appliance":self.cardResult} sourceController:self andCompletion:nil];
                NSMutableArray* controllerArray = [self.navigationController.viewControllers mutableCopy];
                for (UIViewController *vc in controllerArray) {
                    if ([vc isKindOfClass:[MSAuthorizeViewController class]]) {
                        [controllerArray removeObject:vc];
                        break;
                    }
                }
                self.navigationController.viewControllers = [controllerArray copy];
            }
        } else {
            [self popMethod];
            [self toastText:MSResourceString(@"home_plugin_nonexistent")];
        }
        
    } else {
        [self popMethod];
    }
}

//我的设备页面，添加+配网成功也需要跳转到首页
- (void)popMethod {
    UIViewController *rootViewController = [UIApplication sharedApplication].keyWindow.rootViewController;
    if ([rootViewController isKindOfClass:[UITabBarController class]]) {
        UITabBarController *tabbarController = (UITabBarController *)rootViewController;
        if (tabbarController.selectedIndex != 0) {
            tabbarController.selectedIndex = 0;
            for (UIView *view in tabbarController.tabBar.subviews) {
                if (view.tag == 1001) {
                    view.hidden = NO;
                } else if (view.tag == 1002) {
                    view.hidden = YES;
                } else if (view.tag == 1003) {
                    view.hidden = YES;
                }
            }
        }
    }
    [self.navigationController popToRootViewControllerAnimated:YES];
}

#pragma mark - MSAuthorizeViewProtocol
- (void)presenter:(MSAuthorizePresenter *)presenter getAuthInfoCompletion:(MSBusinessError *)error {
    if (error) {
        self.requestFailView.hidden = NO;
    } else {
        [self.presenter checkApplianceAuthStatusWithApplianceCode:self.applianceId showLoading:NO];
    }
}

- (void)presenter:(MSAuthorizePresenter *)presenter checkApplianceAuthCompletion:(MSBusinessError *)error {
    if (error) {
        self.requestFailView.hidden = NO;
        if (self.isAddSubviews) {
            self.backView.hidden = YES;
        }
    } else {
        if (self.presenter.status == 1 || self.presenter.status == 2) {  //1待确权  2未确权
            [self.presenter confirmApplianceAuthWithApplianceCode:self.applianceId];
        } else {
            //直接走确权成功流程
            [self showSuccessToast];
        }
    }
    
}

- (void)presenter:(MSAuthorizePresenter *)presenter confirmApplianceAuthCompletion:(MSBusinessError *)error {
    if (error) {
        self.requestFailView.hidden = NO;
        if (self.isAddSubviews) {
            self.backView.hidden = YES;
        }
    } else {
        if (!self.isAddSubviews) {
            self.isAddSubviews = YES;
            [self configSubviews];
        } else {
            self.backView.hidden = NO;
        }
        [self.presenter startTimerCountDown];
    }
}

- (void)presenter:(MSAuthorizePresenter *)presenter updateTimerCountDown:(NSUInteger)count {
//    NSMutableAttributedString *minuteString = [[NSMutableAttributedString alloc]initWithString:MSResourceString(@"authorize_time_message") attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14 weight:UIFontWeightRegular], NSForegroundColorAttributeName:RGB_HEX(0x000000)}];
//    [minuteString appendAttributedString:[[NSAttributedString alloc]initWithString:[NSString stringWithFormat:@"(%lds)", count] attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14 weight:UIFontWeightMedium], NSForegroundColorAttributeName:RGB_HEX(0xEC1C24)}]];
//    self.minuteLabel.attributedText = minuteString;
    
    self.minuteLabel.text = [NSString stringWithFormat:@"%ldS", count];
    
    if (count == 0) {
       self.minuteLabel.hidden = YES;
       self.tryAgainButton.hidden = NO;
       self.titleLabel.text = MSResourceString(@"Set up failed, please try again");
        self.minuteLabel.text = @"60S";
       self.isTimeOut = YES;
        
        return;
        [self.cancelAlertView dismiss];
        [self.timeoutView showWithSuperview:self.view.window];
        
        @weakify(self)
        self.timeoutView.clickContinueBlock = ^{
            @strongify(self)
            [self.presenter checkApplianceAuthStatusWithApplianceCode:self.applianceId showLoading:YES];
            
        };
        self.timeoutView.clickQuiteBlock = ^{
            @strongify(self)
            [self popMethod];
            
        };
        
    }
}

#pragma mark - getter
- (MSVerticalButtonAlertView *)cancelAlertView {
    if (!_cancelAlertView) {
        _cancelAlertView = [[MSVerticalButtonAlertView alloc]initWithTitle:MSResourceString(@"connect_confirm_quite") message:MSResourceString(@"connect_confirm_quite_message") confirmButtonName:MSResourceString(@"connect_continue_set") cancelButtonName:MSResourceString(@"connect_notnow_set")];
    }
    return _cancelAlertView;
}

- (MSAuthorizeTimeoutView *)timeoutView {
    if (!_timeoutView) {
        _timeoutView = [[MSAuthorizeTimeoutView alloc]init];
    }
    return _timeoutView;
}


@end
