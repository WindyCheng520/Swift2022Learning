//  
//  MSBLEGuideViewController.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/14
//  Copyright © 2020 Midea. All rights reserved.
//  蓝牙配网操作指引页面
   

#import "MSBLEGuideViewController.h"
#import "MSDeviceBundle.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "MSAddDeviceProgressViewController.h"
#import "MSBLEScanFailViewController.h"
#import <OEMFoundation/OEMWeakProxy.h>
#import "MSImagePageView.h"
#import <MSBusiness/MSBLEManager.h>
#import <OEMTheme/UILabel+OEMThemes.h>
#import "UINavigationController+OEMFullscreenPopGesture.h"

#import <MSBusiness/MideaTool.h>
#import <MSBusiness/MSRouterUrl.h>
#import <MSBusiness/MSDeviceProtocol.h>
#import <OEMFoundation/OEMDeviceTool.h>
#import <MSBusiness/MSRouterUrl.h>

#import <MSBusiness/MSDeviceAuthResult.h>


#import "MSGuideView.h"
#import <MJExtension/MJExtension.h>
#import <MSBusiness/MSRequestFailView.h>
#import <MSBusiness/OEMGlobalUIManager.h>
#import <MSBusiness/OEMBLEAlertViewController.h>
#import "MSConnnectAPViewController.h"


@interface MSBLEGuideViewController ()<UITextViewDelegate>

@property (nonatomic, copy) NSString *connectTypeDesc;

@property (nonatomic, strong) MSGuideView *guideView;
@property (nonatomic, strong) MSRequestFailView *requestFailView;


@property(strong, nonatomic)HGView *bottomView;
@property(strong, nonatomic)HGView *containerView;
@property(strong, nonatomic)HGButton *checkButton;
@property(strong, nonatomic)HGLabel *tipsLabel;
@property(strong, nonatomic)HGButton *confirmButton;


@end

@implementation MSBLEGuideViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        
        self.presenter = [[MSAuthorizePresenter alloc] initWithView:self];
    }
    return self;
}

-(void)dealloc{
    NSLog(@"MSBLEGuideViewController ------------");
}


- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    self.checkButton.selected = NO;
    self.confirmButton.backgroundColor = RGBA_HEX(0xEC1C24 ,0.3);
    self.confirmButton.enabled = NO;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = MSResourceString(@"add_device_process_page_adding_title");
  //  self.canRightSlideBack = NO;
   
   self.guideView = [[MSGuideView alloc] initWithFrame:CGRectZero];
   [self.view addSubview:self.guideView];
    self.guideView.hidden = YES;
    
    _requestFailView = [[MSRequestFailView alloc]initWithFrame:CGRectMake(0, STATUSBAR_HEIGHT+44+78, SCREEN_WIDTH, 0)];
    WEAKSELF
    _requestFailView.clickButtonBlock = ^{
        weakSelf.requestFailView.hidden = YES;
        [weakSelf loadData];
        
    };
    self.requestFailView.hidden = YES;
    [self.view addSubview:self.requestFailView];

    self.bottomView = [[HGView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 120)];
    self.bottomView.backgroundColor = [UIColor whiteColor];
   // self.bottomView.layer.cornerRadius = 12.0;
    
    [self.view addSubview:self.bottomView];
    
    self.containerView = [HGView new];
    self.containerView.backgroundColor = [UIColor clearColor];
    [self.bottomView addSubview:self.containerView];
    
    self.checkButton = [HGButton new];
    self.checkButton.layer.cornerRadius = 10.0;
    self.checkButton.clipsToBounds = YES;
    [self.checkButton setImage:MSResourceImage(@"ic_checkbox") forState:UIControlStateNormal];
    [self.checkButton setImage:MSResourceImage(@"ic_checkbox_s") forState:UIControlStateSelected];
    [self.checkButton addTarget:self action:@selector(checkClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.containerView addSubview:self.checkButton];
    
    
    self.tipsLabel = [HGLabel new];
    self.tipsLabel.font =  kRegularFont(14);
    self.tipsLabel.textAlignment = NSTextAlignmentLeft;
    self.tipsLabel.backgroundColor = [UIColor clearColor];
    self.tipsLabel.text =  MSResourceString(@"ble_guide_page_complete");
    self.tipsLabel.textColor = RGBA_HEX(0x000000, 0.9);
    self.tipsLabel.numberOfLines = 1;
    [self.tipsLabel sizeToFit];
    [self.containerView addSubview:self.tipsLabel];
    self.tipsLabel.hidden = YES;
    self.checkButton.hidden = YES;
    
    self.confirmButton = [HGButton new];
    self.confirmButton.backgroundColor = RGB_HEX(0x267AFF);
    [self.confirmButton setTitle:MSResourceString(@"ble_guide_page_next") forState:UIControlStateNormal];
    self.confirmButton.titleLabel.font = kRegularFont(18);
    self.confirmButton.enabled = NO;
    self.confirmButton.layer.cornerRadius = 22.0;
    self.confirmButton.clipsToBounds = YES;
    self.confirmButton.hidden = YES;
    [self.confirmButton addTarget:self action:@selector(confirmClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.bottomView addSubview:self.confirmButton];
    
    [self makeContstraints];
    [self configureOEMTheme];
    
  //  [[MSBLEManager shareManager] showBluetoothAuthorAlert];
   // [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(bluetoothAuthorizationStatusDidChange:) name:kMideaBluetoothAuthorizationStatusDidChangeNotification object:nil];
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    if (self.connectInfo.authResult) {
        self.tipsLabel.hidden = NO;
        self.checkButton.hidden = NO;
        self.requestFailView.hidden = YES;
        self.guideView.hidden = NO;
        self.confirmButton.hidden = NO;
        MSDeviceAuthResult *result = self.connectInfo.authResult;
        NSArray *array = result.guideContent;
        NSArray *resultArray = [MSGuideEntity mj_objectArrayWithKeyValuesArray:array];
        self.guideView.dataArray = resultArray;
        
    }else{
        [self loadData];
    }
}



-(void)loadData{
    NSString *category = self.connectInfo.category;
    NSString *deviceType = @"";
    if (![category hasPrefix:@"0x"]) {
        deviceType = [NSString stringWithFormat:@"0x%@", category];
    }else{
        deviceType = category;
    }
    [self.presenter fetchAddDeviceGuideContentWithDeviceType:deviceType model:@"" guideType:@"0" subCategory:@""];
}


- (void)configureOEMTheme{
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    self.view.backgroundColor = [UIColor clearColor];
   // [self.view configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.guideView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.bottomView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.tipsLabel configure40TranslucentTrait];
    [self.confirmButton configureThemeTag:OEMThemesTag_UIView_Main_Color];
    [self.confirmButton configureThemeTag:OEMThemesTag_UIButton_Background];
    [self.confirmButton configureThemeTag:OEMThemesTag_UIButton_AttributedTraitColor];
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        [weakSelf setNavButton];
    } callImmidiately:YES];
    
    
    
    [self.tipsLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.thirdColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.thirdColor
    }];
}

- (void)setNavButton{
    if (OEMThemeIsDarkMode) {
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_dm")];
    }else{
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_lg")];
    }
}

- (void)makeContstraints {
    [self.guideView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(0);
        make.leading.equalTo(self.view).offset(0);
        make.trailing.equalTo(self.view).offset(0);
        make.bottom.equalTo(self.view).offset(-150);
    }];
    
    
    
    
    [self.bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.bottom.equalTo(self.view);
        make.height.mas_equalTo(150);
    }];
    
    
    [self.confirmButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.bottomView.mas_bottom).offset(-44);
        make.leading.mas_equalTo(self.bottomView.mas_leading).offset(16);
        make.trailing.mas_equalTo(self.bottomView.mas_trailing).offset(-16);
        make.height.mas_equalTo(44);
    }];
    
    CGFloat tipsLabelWidth  = [self.tipsLabel.text sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14 weight:UIFontWeightRegular]}].width;
    [self.containerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(self.confirmButton.mas_top).offset(-17);
        make.centerX.equalTo(self.bottomView);
        make.height.mas_equalTo(18);
        make.width.mas_equalTo(tipsLabelWidth + 28);
    }];
    
    
    [self.checkButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.containerView.mas_top).offset(0);
        make.leading.mas_equalTo(self.containerView.mas_leading).offset(0);
        make.height.mas_equalTo(18);
        make.width.mas_equalTo(18);
    }];
    
    [self.tipsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(self.checkButton.mas_trailing).offset(7.5);
        make.height.mas_equalTo(17);
        make.centerY.equalTo(self.checkButton);
    }];
}




- (void)leftBarButtonClick:(UIButton *)button {
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)checkClick:(UIButton *)sender{
    sender.selected = !sender.selected;
    if (sender.selected) {
        self.confirmButton.backgroundColor = RGBA_HEX(0xEC1C24 ,1);
        self.confirmButton.enabled = YES;
     } else {
        self.confirmButton.backgroundColor = RGBA_HEX(0xEC1C24 ,0.3);
        self.confirmButton.enabled = NO;
    }
}

-(void)confirmClick:(UIButton *)sender{
    if (!self.checkButton.selected) {
        return;
    }
    
    //从失败页修改密码回来
    if(self.connectInfo.wifiSsid.length > 0 &&  self.connectInfo.wifiBssid.length > 0 &&  self.connectInfo.wifiPassword.length > 0 && self.connectInfo.deviceConnectType == MSDeviceConnectTypeRetry && self.connectInfo.mode.integerValue == 3){
        if ([[MSBLEManager shareManager] checkBluetoothAuthState] != MSBLEManagerTypeAuthorizedAndTurnOn){
            [[MSBLEManager shareManager] showBluetoothAuthorAlert];
            return;
        }
        MSAddDeviceProgressViewController *dest = [[MSAddDeviceProgressViewController alloc] init];
        dest.connectInfo = self.connectInfo;
        dest.isScanSuccess = NO;
        [self.navigationController pushViewController:dest animated:YES];
        return;
    }
    
    
    if (([[MSBLEManager shareManager] checkBluetoothAuthState] != MSBLEManagerTypeAuthorizedAndTurnOn) && self.connectInfo.deviceConnectType >=  MSDeviceConnectTypeManualSelect && self.connectInfo.mode.integerValue == 3){
        [[MSBLEManager shareManager] showBluetoothAuthorAlert];
        return;
    }
    
    if (self.connectInfo.mode.integerValue == 3) {
        MSAddDeviceProgressViewController *dest = [[MSAddDeviceProgressViewController alloc] init];
        dest.connectInfo = self.connectInfo;
        dest.isScanSuccess = NO;
        [self.navigationController pushViewController:dest animated:YES];
    }else{
        MSConnnectAPViewController *dest = [[MSConnnectAPViewController alloc] init];
        dest.connectInfo = self.connectInfo;
       // dest.connectInfo.mode = @"0";
        dest.connectInfo.deviceConnectType = MSDeviceConnectTypeAP;
        [self.navigationController pushViewController:dest animated:YES];
    }
    
}



#pragma mark - MSAuthorizeViewProtocol
- (void)presenter:(MSAuthorizePresenter *)presenter fetchAddDeviceGuideContentCompletion:(MSBusinessError *)error{
    if (error || !presenter.authResult) {
      //  [self toastText:error.localizedDescription];
         self.tipsLabel.hidden = YES;
         self.checkButton.hidden = YES;
         self.requestFailView.hidden = NO;
         self.confirmButton.hidden = YES;
    } else {
            self.tipsLabel.hidden = NO;
            self.checkButton.hidden = NO;
            self.requestFailView.hidden = YES;
            self.guideView.hidden = NO;
            self.confirmButton.hidden = NO;
            self.connectInfo.authResult = presenter.authResult;
            MSDeviceAuthResult *result = presenter.authResult;
            NSArray *array = result.guideContent;
            NSArray *resultArray = [MSGuideEntity mj_objectArrayWithKeyValuesArray:array];
            self.guideView.dataArray = resultArray;
    }
}





@end
