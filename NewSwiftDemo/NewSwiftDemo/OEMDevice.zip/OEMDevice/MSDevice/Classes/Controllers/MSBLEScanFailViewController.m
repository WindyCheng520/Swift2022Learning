//  
//  MSBLEScanFailViewController.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/14
//  Copyright © 2020 Midea. All rights reserved.
//  蓝牙配网指定时间内扫描设备失败页面
   

#import "MSBLEScanFailViewController.h"
#import "MSDeviceBundle.h"
#import "MSSetAndConnectDeviceTipsCell.h"
#import "MSBLEGuideViewController.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import <OEMTheme/UILabel+OEMThemes.h>
#import <MSBusiness/MSRouterUrl.h>

#import <MSBusiness/OEMGlobalUIManager.h>
#import <MSBusiness/OEMCommomAlertViewController.h>
#import "OEMAddDeviceButton.h"
#import "MSConnnectAPViewController.h"

static const NSInteger kErrorCode = 110003;

@interface MSBLEScanFailViewController ()


@property (nonatomic, strong) HGImageView *leftIconImageView;
@property (nonatomic, strong) HGImageView *centerFailIconView;
@property (nonatomic, strong) HGImageView *rightIconImageView;
@property (nonatomic, strong) HGLabel *titleLabel;  //联网失败
@property (nonatomic, strong) HGLabel *tipsLabel;  //无法扫描到设备，

@property (nonatomic, strong) HGButton *tryButton;

@property (nonatomic, strong) HGButton *feadbackButton;



@property (nonatomic, strong) UIButton *leftButton;  //取消
@property (nonatomic, strong) UIButton *rightButton; //反馈问题

@property (nonatomic, strong) OEMAddDeviceButton *addDeviceButton;




@end

@implementation MSBLEScanFailViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        
        self.leftIconImageView = [HGImageView new];
        self.centerFailIconView = [HGImageView new];
        self.rightIconImageView = [HGImageView new];
        self.titleLabel = [HGLabel new];
        self.tipsLabel = [HGLabel new];
        self.tryButton = [HGButton new];
      //  self.feadbackButton = [HGButton new];

    }
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.canRightSlideBack = NO;
    [self createLeftButtonWithText:MSResourceString(@"add_device_process_page_cancel_button")];
    [self createRightButtonWithText:MSResourceString(@"config_fail_page_button_feedback")];
    if (self.errorCode == kErrorCode){
       // [self createLeftButtonWithText:@""];
        if (self.connectInfo.deviceImageUrl && ![self.connectInfo.deviceImageUrl isEqualToString:@""]) {
          [self.leftIconImageView sd_setImageWithURL:[NSURL URLWithString:self.connectInfo.deviceImageUrl] placeholderImage:[UIImage imageNamed:@"pic_category_default"]];
        } else {
            self.leftIconImageView.image = [UIImage imageNamed:@"pic_category_default"];
        }
        self.rightIconImageView.image = MSResourceImage(@"icon_cloud");
        
    }else{
       
        
        if (self.connectInfo.deviceImageUrl && ![self.connectInfo.deviceImageUrl isEqualToString:@""]) {
          [self.rightIconImageView sd_setImageWithURL:[NSURL URLWithString:self.connectInfo.deviceImageUrl] placeholderImage:[UIImage imageNamed:@"pic_category_default"]];
        } else {
            self.rightIconImageView.image = [UIImage imageNamed:@"pic_category_default"];
        }
        self.leftIconImageView.image = MSResourceImage(@"pic_connect_mobile");
    }
  

    [self.view addSubview:self.leftIconImageView];
    [self.view addSubview:self.centerFailIconView];
    [self.view addSubview:self.rightIconImageView];
    
    self.centerFailIconView.image = MSResourceImage(@"device_icon_warn");
    self.titleLabel.textColor = RGB_HEX(0x000000);
    self.titleLabel.font =  kSemiboldFont(22);
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.text = MSResourceString(@"config_fail_page_config_fail");
    [self.view addSubview:self.titleLabel];
   
    self.tipsLabel.textColor = RGB_HEX(0x000000);
    self.tipsLabel.font = kRegularFont(15);
    self.tipsLabel.textAlignment = NSTextAlignmentCenter;
    self.tipsLabel.numberOfLines = 0;
    [self.tipsLabel sizeToFit];
    if(self.errorCode == kErrorCode){
        self.tipsLabel.text = MSResourceString(@"config_fail_page_config_thing_code_fail");
    }else{
        self.tipsLabel.text = MSResourceString(@"ble_guide_page_scan_fail");
    }
   
    [self.view addSubview:self.tipsLabel];
   
    
   // NSString *buttonTitle = (self.errorCode == kErrorCode?MSResourceString(@"config_fail_page_config_back_home"):MSResourceString(@"ble_guide_page_reconnect"));
    NSString *buttonTitle = (self.errorCode == kErrorCode?MSResourceString(@"ble_guide_page_scan_fail_got_it"):MSResourceString(@"ble_guide_page_reconnect"));
    
    [self.tryButton setTitle:buttonTitle forState:UIControlStateNormal];
    [self.tryButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
    self.tryButton.titleLabel.font =   kRegularFont(18);
    self.tryButton.backgroundColor = kBusiness.brandColor;
    self.tryButton.layer.cornerRadius = 22;
    [self.view addSubview:self.tryButton];
    [self.tryButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    
    
    [self.feadbackButton setTitle:MSResourceString(@"config_fail_page_button_feedback") forState:UIControlStateNormal];
    [self.feadbackButton setTitleColor:RGB_HEX(0x267AFF) forState:UIControlStateNormal];
    self.feadbackButton.titleLabel.font =  [UIFont fontWithName:@"Helvetica" size:16];// [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    [self.view addSubview:self.feadbackButton];
    [self.feadbackButton sizeToFit];
    [self.feadbackButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    
    self.addDeviceButton = [[OEMAddDeviceButton alloc] initWithFrame:CGRectZero type:ConnectTypeAP];
    [self.addDeviceButton addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.addDeviceButton];
    
    self.addDeviceButton.hidden = (self.errorCode == kErrorCode);
    
    if (![self judgeIsContainAPConnectViewVC]) {
         [self insertVC];
    }
    
    [self makeContstraints];
    [self configureOEMTheme];
}


- (BOOL)judgeIsContainAPConnectViewVC {
     NSMutableArray *mvcvs = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
     __block BOOL isContain = NO;
     [mvcvs enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
         UIViewController *viewController = (UIViewController *)obj;
         if ([viewController isKindOfClass:NSClassFromString(@"MSConnnectAPViewController")]) {
             isContain = YES;
             *stop = YES;
         }
     }];
    return isContain;
}

//插入AP连接控制器
- (void)insertVC {
    NSMutableArray *mvcvs = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
    MSConnnectAPViewController *guide = [[MSConnnectAPViewController alloc] init];
    guide.connectInfo = self.connectInfo;
    guide.hidesBottomBarWhenPushed = YES;
    __block NSInteger index = 0;
    [mvcvs enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        UIViewController *viewController =   (UIViewController *)obj;
        if ([viewController isKindOfClass:NSClassFromString(@"MSAddDeviceProgressViewController")]) {
            index = idx;
            *stop = YES;
        }
    }];
    if (index != 0){ //包含MSAddDeviceProgressViewController（不是根视图）才插入
        [mvcvs insertObject:guide atIndex:index];
        self.navigationController.viewControllers = mvcvs;
    }
}

- (void)makeContstraints {
    
    [self.centerFailIconView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(STATUSBAR_HEIGHT + 20);
        make.size.mas_equalTo(CGSizeMake(16, 16));
        make.centerX.equalTo(self.view);
    }];
    
    self.centerFailIconView.layer.masksToBounds = YES;
    self.centerFailIconView.layer.cornerRadius = 8;
    
    [self.leftIconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.centerFailIconView.mas_centerY);
        make.trailing.equalTo(self.centerFailIconView.mas_leading).offset(-14);
        make.size.mas_equalTo(CGSizeMake(88, 88));
    }];
    
    [self.rightIconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.centerFailIconView.mas_centerY);
        make.leading.equalTo(self.centerFailIconView.mas_trailing).offset(14);
        make.size.mas_equalTo(CGSizeMake(88, 88));
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.leftIconImageView.mas_bottom).offset(30);
        make.leading.mas_equalTo(30);
        make.trailing.mas_equalTo(-30);
        make.height.mas_equalTo(26);
    }];
    
    
    [self.tipsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleLabel.mas_bottom).offset(9);
        make.leading.mas_equalTo(30);
        make.trailing.mas_equalTo(-30);
    }];
    
    [self.tryButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.tipsLabel.mas_bottom).offset(60);
        make.leading.mas_equalTo(16);
        make.trailing.mas_equalTo(-16);
        make.height.mas_equalTo(44);
    }];
    
//    [self.feadbackButton mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.bottom.equalTo(self.view.mas_bottom).offset(-68);
//        make.centerX.equalTo(self.view);
//       // make.height.mas_equalTo(20);
//    }];
    
    [self.addDeviceButton mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.view.mas_bottom).offset(-49);
        make.leading.mas_equalTo(16);
        make.trailing.mas_equalTo(-16);
        //make.height.mas_equalTo(44);
    }];
    
    
}

- (void)configureOEMTheme{
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    [self.view configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.titleLabel configure90TranslucentTrait];
    [self.tipsLabel configure40TranslucentTrait];
    
   // [self.tryButton configureThemeTag:OEMThemesTag_UIButton_Background];
    [self.centerFailIconView specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIImageView_BackgroundColor) : CommonThemeWarningColor
    } lightModeProperties:@{
        @(OEMThemesTag_UIImageView_BackgroundColor) : CommonThemeWarningColor
    }];
    
    
    
    [self.titleLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.mainTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.mainTextColor
    }];
    
    
    [self.tipsLabel specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UILabel_TextColor) : kDarkText.secondColor
    } lightModeProperties:@{
        @(OEMThemesTag_UILabel_TextColor) : kLightText.secondColor
    }];
    
    
    
    [self.leftButton specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIButton_TitleTraitColor) : kDarkText.mainTextColor
    } lightModeProperties:@{
        @(OEMThemesTag_UIButton_TitleTraitColor) : kLightText.mainTextColor
    }];
    
    [self.rightButton specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : kDarkText.mainColor
    } lightModeProperties:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : kLightText.mainColor
    }];
    
    
    [self.tryButton specialPropertiesForDarkMode:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : RGB_HEX(0xFFFFFF)
    } lightModeProperties:@{
        @(OEMThemesTag_UIButton_TitleThemeColor) : RGB_HEX(0xFFFFFF)
    }];
}

-(void)createLeftButtonWithText:(NSString*)text{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:text forState:UIControlStateNormal];
    [button setTitleColor:RGB_HEX(0x666666) forState:UIControlStateNormal];
    button.titleLabel.font = kRegularFont(15);
    [button addTarget:self action:@selector(leftBarButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *Item = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.leftBarButtonItem = Item;
    self.leftButton = button;
}


-(void)createRightButtonWithText:(NSString *)text{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:text forState:UIControlStateNormal];
    [button setTitleColor:kLightText.mainColor forState:UIControlStateNormal];
    button.titleLabel.font = kRegularFont(15);
    [button addTarget:self action:@selector(rightBarButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *Item = [[UIBarButtonItem alloc] initWithCustomView:button];
    self.navigationItem.rightBarButtonItem = Item;
    self.rightButton = button;
}


- (void)leftBarButtonClick:(UIButton *)button {
    [self clickButton:self.tryButton];
}

- (void)rightBarButtonClick:(UIButton *)button {
    [OEMRouter handleURL:MSRouterReactNativeIndex withParams:@{
        MSReactNativeModuleNameDefine : MSReactNativeInnerModule_usehelp,
        MSReactNativeViewProps: @{
                @"initialRouteName" : @"feedBackIndex"
        }
    }];
}


- (void)clickButton:(UIButton *)sender {

    if(sender == self.addDeviceButton){ //切换AP
  
        __block MSConnnectAPViewController *guide = [[MSConnnectAPViewController alloc] init];
//        self.connectInfo.deviceConnectType = MSDeviceConnectTypeAP;
//        self.connectInfo.mode = @"0";
        NSArray<UIViewController *> *vcas = [self.navigationController viewControllers];
        [vcas enumerateObjectsUsingBlock:^(UIViewController *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([obj isKindOfClass:MSConnnectAPViewController.class]) {
                guide = (MSConnnectAPViewController *)obj;
                *stop = YES;
            }
        }];
        
        if (guide) {
            guide.connectInfo = self.connectInfo;
            [self.navigationController popToViewController:guide animated:YES];
        }
        return;
    }
    

    if (self.tryButton == sender) {
        if (self.errorCode == kErrorCode){
            [self.navigationController popToRootViewControllerAnimated:YES];
            return;
        }
        [self popToBLEGuideViewController];
    }else{
        [OEMRouter handleURL:MSRouterReactNativeIndex withParams:@{
            MSReactNativeModuleNameDefine : MSReactNativeInnerModule_usehelp,
            MSReactNativeViewProps: @{
                    @"initialRouteName" : @"feedBackIndex"
            }
        }];
    }
}

- (void)popToBLEGuideViewController{
    NSMutableArray *mvcvs = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
    __block UIViewController *tempViewController = nil;
    [mvcvs enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        UIViewController *viewController =   (UIViewController *)obj;
        if ([viewController isKindOfClass:NSClassFromString(@"MSBLEGuideViewController")]) {
            tempViewController = viewController;
            *stop = YES;
        }
    }];
    if (tempViewController){
        [self.navigationController popToViewController:tempViewController animated:YES];
    }
}
@end
