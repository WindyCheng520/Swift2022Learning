//  
//  MSDeviceTypeModel.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/8
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <MSBusiness/MVPModel.h>
#import "MSAddDeviceDCPRepository.h"

@interface MSDeviceTypeModel : MVPModel

- (void)fetchTypeListSuccess:(MSAddDeviceRepositoryTypeSuccessBlock)success failure:(MSAddDeviceRepositoryFailureBlock)failure;

- (void)fetchIotProductWithTypeId:(NSString *)typeId success:(MSAddDeviceRepositoryModelSuccessBlock)success failure:(MSAddDeviceRepositoryFailureBlock)failure;

- (void)fetchIotConnectInfoWithIotProductId:(NSString *)iotProductId productId:(NSString *)productId success:(MSAddDeviceRepositoryConnectInfoSuccessBlock)success failure:(MSAddDeviceRepositoryFailureBlock)failure;

- (void)fetchIotConfirmInfoWithCategory:(NSString *)category code:(NSString *)code success:(MSAddDeviceRepositoryConfirmInfoSuccessBlock)success failure:(MSAddDeviceRepositoryFailureBlock)failure;


@end
