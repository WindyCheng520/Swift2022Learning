//  
//  MSDeviceTypeModel.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/8
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSDeviceTypeModel.h"

@implementation MSDeviceTypeModel


- (void)fetchTypeListSuccess:(MSAddDeviceRepositoryTypeSuccessBlock)success failure:(MSAddDeviceRepositoryFailureBlock)failure {
    
    [MSAddDeviceDCPRepository fetchTypeListSuccess:success failure:failure];
}


- (void)fetchIotProductWithTypeId:(NSString *)typeId success:(MSAddDeviceRepositoryModelSuccessBlock)success failure:(MSAddDeviceRepositoryFailureBlock)failure {
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setValue:typeId forKey:@"typeId"];
    [MSAddDeviceDCPRepository fetchIotProductWithParas:dic success:success failure:failure];
}

- (void)fetchIotConnectInfoWithIotProductId:(NSString *)iotProductId productId:(NSString *)productId success:(MSAddDeviceRepositoryConnectInfoSuccessBlock)success failure:(MSAddDeviceRepositoryFailureBlock)failure {
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setValue:iotProductId forKey:@"iotProductId"];
    [dic setValue:productId forKey:@"productId"];
    [MSAddDeviceDCPRepository fetchIotConnectInfoWithParas:dic success:success failure:failure];
}

- (void)fetchIotConfirmInfoWithCategory:(NSString *)category code:(NSString *)code success:(MSAddDeviceRepositoryConfirmInfoSuccessBlock)success failure:(MSAddDeviceRepositoryFailureBlock)failure {
    if ([category hasPrefix:@"0x"] && category.length >= 3) {
        category = [category substringFromIndex:2];
    }
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setValue:category?:@"" forKey:@"category"];
    [dic setValue:code?:@"" forKey:@"code"];
    [MSAddDeviceDCPRepository fetchIotConfirmInfoWithParas:dic success:success failure:failure];
}

@end
