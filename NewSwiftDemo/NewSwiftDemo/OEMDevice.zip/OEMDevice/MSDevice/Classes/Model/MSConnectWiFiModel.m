//  
//  MSConnectWiFiModel.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/20
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSConnectWiFiModel.h"
#import "MSSsidPasswordRepository.h"

@implementation MSConnectWiFiModel


- (NSString *)fetchPasswordWithSsid:(NSString *)ssid {
    return [MSSsidPasswordRepository fetchPasswordWithSsid:ssid];
}

- (void)saveSsid:(NSString *)ssid password:(NSString *)password {
    [MSSsidPasswordRepository saveSsid:ssid password:password];
}

@end
