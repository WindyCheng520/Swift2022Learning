//  
//  MSChooseDeviceModelPresenter.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/10
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSChooseDeviceModelPresenter.h"
#import "MSDeviceTypeModel.h"
#import <OEMFoundation/OEMMacros.h>
#import "MSAddDeviceCloudRepository.h"
#import "MSDeviceBundle.h"

@interface MSChooseDeviceModelPresenter ()

@property (nonatomic, strong) MSDeviceTypeModel *deviceModel;

@end

@implementation MSChooseDeviceModelPresenter

- (MSDeviceTypeModel *)deviceModel {
    if (!_deviceModel) {
        _deviceModel = [MSDeviceTypeModel new];
    }
    return _deviceModel;
}

- (void)fetchIotProductWithTypeId:(NSString *)typeId {
    if ([self.view respondsToSelector:@selector(showLoading)]) {
        [self.view showLoading];
    }
    @weakify(self)
    [self.deviceModel fetchIotProductWithTypeId:typeId success:^(NSArray<MSDeviceModelResult *> *result) {
        @strongify(self)
        if ([self.view respondsToSelector:@selector(hideLoading)]) {
            [self.view hideLoading];
        }
        self.dataArray = result;
        if ([self.view respondsToSelector:@selector(presenterDidLoadData:)]) {
            [self.view presenterDidLoadData:self];
        }
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        if ([self.view respondsToSelector:@selector(hideLoading)]) {
            [self.view hideLoading];
        }
        if ([self.view respondsToSelector:@selector(toastText:)]) {
            [self.view toastText:error.localizedDescription];
        }
    }];
}

- (void)requestDataAfterSelectedWithIotProductId:(NSString *)iotProductId productId:(NSString *)productId {
    @weakify(self)
    [self fetchApplianceCityCodeWithSuccess:^{
        @strongify(self)
        [self fetchIotConnectInfoWithIotProductId:iotProductId productId:productId];
    }];
    
}

- (void)fetchApplianceCityCodeWithSuccess:(void(^)(void))success {
    if ([self.view respondsToSelector:@selector(showLoading)]) {
        [self.view showLoading];
    }
    
    @weakify(self)
    [MSAddDeviceCloudRepository fetchApplianceCityCodeWithSuccess:^(MSApplianceCityCodeResult *result) {
        safeCallBlock(success);
        
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        if ([self.view respondsToSelector:@selector(hideLoading)]) {
            [self.view hideLoading];
        }
        if ([self.view respondsToSelector:@selector(toastText:)]) {
            [self.view toastText:MSResourceString(@"device_cityId_fail")];
        }
    }];
    
}

- (void)fetchIotConnectInfoWithIotProductId:(NSString *)iotProductId productId:(NSString *)productId {
//    if ([self.view respondsToSelector:@selector(showLoading)]) {
//        [self.view showLoading];
//    }
    @weakify(self)
    [self.deviceModel fetchIotConnectInfoWithIotProductId:iotProductId productId:productId success:^(MSDeviceConnectResult *result) {
        @strongify(self)
        if ([self.view respondsToSelector:@selector(hideLoading)]) {
            [self.view hideLoading];
        }
        if ([self.view respondsToSelector:@selector(presenter:didLoadConnectInfo:)]) {
            [self.view presenter:self didLoadConnectInfo:result];
        }
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        if ([self.view respondsToSelector:@selector(hideLoading)]) {
            [self.view hideLoading];
        }
        if ([self.view respondsToSelector:@selector(toastText:)]) {
            [self.view toastText:error.localizedDescription];
        }
    }];
}


@end
