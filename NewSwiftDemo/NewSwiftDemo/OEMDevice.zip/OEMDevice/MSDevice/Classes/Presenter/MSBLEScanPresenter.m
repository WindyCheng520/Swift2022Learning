//  
//  MSBLEScanPresenter.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/31
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSBLEScanPresenter.h"
#import <OEMFoundation/OEMMacros.h>
#import <MSBusiness/MideaSecurity.h>

@implementation MSBLEScanPresenter

- (void)startScanBLEWithCategory:(NSString *)category timeout:(NSTimeInterval)timeout {
    DDLogDeviceInfo(@"方法调用startScanBLEWithCategory :%@", category);

    if (![category hasPrefix:@"0x"]) {
        category = [NSString stringWithFormat:@"0x%@", category.uppercaseString];
    }
//
//    @weakify(self)
//    [[MSmartDeviceManager sharedManager] stopBLEScan];
//    DDLogDeviceInfo(@"BLE step:1 stopBLEScan");
//
//    [[MSmartDeviceManager sharedManager] startScanBLEPeripheralWithInterval:timeout extradic:nil competion:^(NSError *error, MSOEMCBPeripheral *peripheral) {
//        @strongify(self)
//        NSDictionary *bleAdvDict = [[MSmartDeviceManager sharedManager] advDataForPeripheral:peripheral];//广播数据中获取的字典
//        DDLogDeviceInfo(@"startScanBLEWithCategory:%@  设备详情:%@ 蓝牙阈值:%@", category, bleAdvDict, peripheral.RSSI);
//        DDLogDeviceInfo(@"startScanBLEWithCategory peripheral.advertisementData:%@", peripheral.advertisementData);
//        DDLogDeviceInfo(@"startScanBLEWithCategory error:%@, %@", error.localizedDescription, error.userInfo);
//        DDLogDeviceInfo(@"startScanBLEWithCategory kCBAdvDataManufacturerData:%@", [MideaSecurity hexStringForData:peripheral.advertisementData[@"kCBAdvDataManufacturerData"]]);
//
//        //首选判断category一致
//        if ([category isEqualToString:bleAdvDict[@"deviceType"]]) {
//            if ([bleAdvDict[@"bleProtcolVersion"] isEqualToString:@"0"]) {
//                //一代蓝牙
//                if ([self isAvailableFirstBle:peripheral]) {
//                    [self stopScan];
//                    if ([self.view respondsToSelector:@selector(scanDeviceSuccess:peripheral:)]) {
//                        [self.view scanDeviceSuccess:self peripheral:peripheral];
//                    }
//                }
//
//            } else if ([bleAdvDict[@"bleProtcolVersion"] isEqualToString:@"1"]) {
//                //二代蓝牙
//                if ([self isAvailableSecondBle:peripheral]) {
//                    [self stopScan];
//                    if ([self.view respondsToSelector:@selector(scanDeviceSuccess:peripheral:)]) {
//                        [self.view scanDeviceSuccess:self peripheral:peripheral];
//                    }
//                }
//
//            }
//        }
//    }];
}

//一代蓝牙判断逻辑
- (BOOL)isAvailableFirstBle:(MSOEMCBPeripheral *)peripheral {

    BOOL result = NO;

    NSDictionary *bleAdvDict =@{}; //[[MSmartDeviceManager sharedManager] advDataForPeripheral:peripheral];//广播数据中获取的字典
    
    //一代蓝牙逻辑

    if(bleAdvDict &&
       
    [bleAdvDict[@"wifiConfigEnable"] boolValue] && //wifi配置功能可用

    ![bleAdvDict[@"isWifiConfiged"] boolValue] && //未配置

    [bleAdvDict[@"moduleType"] intValue] == 1 && //wifi+ble
       
    [bleAdvDict[@"deviceName"] hasPrefix:@"toshiba"]  //东芝设备

    ) {
        result = YES;
    }

    return result;
}

//二代蓝牙判断逻辑
- (BOOL)isAvailableSecondBle:(MSOEMCBPeripheral *)peripheral {

    BOOL result = NO;
    
    NSDictionary *bleAdvDict = @{};//[[MSmartDeviceManager sharedManager] advDataForPeripheral:peripheral];//广播数据中获取的字典

    //二代蓝牙逻辑

    if(bleAdvDict &&
       
    ![bleAdvDict[@"isWifiConfiged"] boolValue] && //未配置

    [bleAdvDict[@"moduleType"] intValue] == 1 && //wifi+ble
       
    [bleAdvDict[@"deviceName"] hasPrefix:@"toshiba"]  //东芝设备

    ) {
        result = YES;
    }

    return result;
}

- (void)stopScan {
  //  [[MSmartDeviceManager sharedManager] stopBLEScan];
    DDLogDeviceInfo(@"BLE step:2 stopBLEScan");
}

@end
