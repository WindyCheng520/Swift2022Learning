//  
//  MSConnectWiFiPresenter.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/17
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSConnectWiFiPresenter.h"
#import "MSConnectWiFiModel.h"

@interface MSConnectWiFiPresenter ()

@property (nonatomic, strong) MSConnectWiFiModel *wifiModel;
@property (nonatomic, assign) BOOL enableClick;

@end

@implementation MSConnectWiFiPresenter

- (MSConnectWiFiModel *)wifiModel {
    if (!_wifiModel) {
        _wifiModel = [MSConnectWiFiModel new];
    }
    return _wifiModel;
}

- (NSString *)fetchPasswordWithSsid:(NSString *)ssid {
    return [self.wifiModel fetchPasswordWithSsid:ssid];
}

- (void)saveSsid:(NSString *)ssid password:(NSString *)password {
    [self.wifiModel saveSsid:ssid password:password];
}

- (void)setWifiName:(NSString *)wifiName {
    _wifiName = wifiName;
  //  self.enableClick = self.wifiName.length > 0 && self.wifiPassword.length > 0;
 //   self.enableClick = self.wifiName.length > 0;
}

- (void)setWifiPassword:(NSString *)wifiPassword {
    _wifiPassword = wifiPassword;
    self.enableClick = self.wifiName.length > 0 && self.wifiPassword.length > 0;
}

- (void)setEnableClick:(BOOL)enableClick {
    _enableClick = enableClick;
    
    if ([self.view respondsToSelector:@selector(presenter:didEnableClick:)]) {
        [self.view presenter:self didEnableClick:enableClick];
    }
}


@end
