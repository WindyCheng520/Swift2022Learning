//  
//  MSChooseDevicePresenter.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/8
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <MSBusiness/MVPPresenter.h>
#import <MSBusiness/MSBusinessError.h>
#import <MSBusiness/MSAutoFindResult.h>
#import "MSDeviceRouterService.h"
@class MSChooseDevicePresenter;

@protocol MSChooseDeviceViewProtocol <MVPViewProtocol>

- (void)presenterDidLoadData:(MSChooseDevicePresenter *)presenter;
- (void)presenter:(MSChooseDevicePresenter *)presenter discoverDevices:(NSArray<MSAutoFindResult *> *)result;
- (void)presenterDidScan15Seconds:(MSChooseDevicePresenter *)presenter;
- (void)presenter:(MSChooseDevicePresenter *)presenter getConnectInfo:(MSDeviceConnectResult *)result;

@end

@interface MSChooseDevicePresenter : MVPPresenter<id<MSChooseDeviceViewProtocol>>

@property (nonatomic, strong) NSArray *dataArray;  //品类列表
@property (nonatomic, strong) NSMutableArray<MSAutoFindResult *> *scanResult;

- (void)fetchTypeList;
- (void)getDcpApplianceTypeData;
- (void)getCloudApplianceNameData;
- (void)viewWillDisappear;
- (void)requestConnectInfoWithSN8:(NSString *)sn8 dcpImageUrl:(NSString *)dcpImageUrl;
- (void)startAutoFind;


-(void)fetchConnectInfoWithAutoFindResult:(MSAutoFindResult *)device;


@end
