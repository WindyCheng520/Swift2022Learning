//  
//  MSAddDevicePresenter.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/16
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSAddDevicePresenter.h"
#import "MSAddDeviceAP.h"
#import "MSAddDeviceBLE.h"
#import "MSAddDeviceCloudRepository.h"
#import <MSBusiness/MSDeviceCardResult.h>
#import <MSBusiness/MSHomeProtocol.h>
#import "MSConnectWiFiModel.h"
#import <NetworkExtension/NEHotspotConfigurationManager.h>
#import <MSBusiness/MSAppInfo.h>
#import <OEMBluetooth/MSOEMDeviceManager.h>
#import <MSBusiness/MideaSecurity.h>
#import <MSDevice/MSDevice-Swift.h>
@interface MSAddDevicePresenter ()<MSAddDeviceDelegate>

@property (nonatomic, strong) id<MSAddDeviceProtocol> addDeviceModule;
@property (nonatomic, strong) MSConnectWiFiModel *wifiModel;

@end

@implementation MSAddDevicePresenter

- (MSConnectWiFiModel *)wifiModel {
    if (!_wifiModel) {
        _wifiModel = [MSConnectWiFiModel new];
    }
    return _wifiModel;
}

- (id<MSAddDeviceProtocol>)addDeviceModule {
    if (!_addDeviceModule) {
        _addDeviceModule = [MSAddDeviceAP new];
        _addDeviceModule.wifiBssid = @"";
        _addDeviceModule.msDelegete = self;
    }
    return _addDeviceModule;
}


//有Sn8 就匹配到Sn8, 否则只匹配到品类
- (void)startScanBLEWithCategory:(NSString *)category deviceSn8:(NSString *)deviceSn8 timeout:(NSTimeInterval)timeout {
    if (![category hasPrefix:@"0x"]) {
        category = [category stringByReplacingOccurrencesOfString:@"0x"
                                                       withString:@""];
    }
    DDLogDeviceInfo(@"方法调用startScanBLEWithCategory :%@----%@", category, deviceSn8);
    
    @weakify(self)
    [[MSOEMDeviceManager sharedManager] stopBLEScan];
    DDLogDeviceInfo(@"BLE step:1 stopBLEScan");
    
    [[MSOEMDeviceManager sharedManager] startScanBLEPeripheralWithInterval:timeout extradic:@{} competion:^(NSError *error, MSOEMCBPeripheral *peripheral) {
        @strongify(self)
        NSDictionary *bleAdvDict = [[MSOEMDeviceManager sharedManager] advDataForPeripheral:peripheral];//广播数据中获取的字典
        DDLogDeviceDebug(@"startScanBLEWithCategory:%@  设备详情:%@ 蓝牙阈值:%@", category, bleAdvDict, peripheral.RSSI);
        DDLogDeviceDebug(@"startScanBLEWithCategory peripheral.advertisementData:%@", peripheral.advertisementData);
        DDLogDeviceDebug(@"startScanBLEWithCategory error:%@, %@", error.localizedDescription, error.userInfo);
        DDLogDeviceDebug(@"startScanBLEWithCategory kCBAdvDataManufacturerData:%@", [MideaSecurity hexStringForData:peripheral.advertisementData[@"kCBAdvDataManufacturerData"]]);
        NSString  *sn8 = bleAdvDict[@"deviceSN8"];
        //首先判断category一致，再次判断sn8一致
        //   NSString  *sn8 = @"51015EW1";
        NSString * deviceType =  bleAdvDict[@"deviceType"];
        deviceType = [deviceType stringByReplacingOccurrencesOfString:@"0x" withString:@""];
        if(deviceSn8.length > 0){
            DDLogDeviceInfo(@"匹配到品类deviceSn8---------------------------");
            if ([category isEqualToString:deviceType]) {
                //相同品类-------------------------
                if ([sn8 isEqualToString:deviceSn8]) { //相同型号/SN8
                    if ([MSAddDeviceTools isAvailableWithPer:peripheral]) {
                        DDLogDeviceInfo(@"符合配网条件00---------------------------");
                        // [self stopScan];
                        self.deviceSSID = bleAdvDict[@"deviceSSID"];
                        if ([self.view respondsToSelector:@selector(scanDeviceSuccess:peripheral:)]) {
                            [self.view scanDeviceSuccess:self peripheral:peripheral];
                        }
                    }
                }
            }//-----------------------------------xxxxxx
        }else{ //只有品类可以匹配
            if ([category isEqualToString:deviceType]) {
                DDLogDeviceInfo(@"匹配到品类---------------------------");
                if ([MSAddDeviceTools isAvailableWithPer:peripheral]) {
                    DDLogDeviceInfo(@"符合配网条件01---------------------------");
                    self.deviceSSID = bleAdvDict[@"deviceSSID"];
                    if ([self.view respondsToSelector:@selector(scanDeviceSuccess:peripheral:)]) {
                        [self.view scanDeviceSuccess:self peripheral:peripheral];
                    }
                }
            }
        }
    }];
}


- (void)stopScan {
    [[MSOEMDeviceManager sharedManager] stopBLEScan];
    DDLogDeviceInfo(@"BLE step:2 stopBLEScan");
}


- (void)setupAddDeviceModuleWithConnectInfo:(MSDeviceConnectResult *)connectInfo {
    if (connectInfo.auxiing) {
        if (connectInfo.auxiMode.intValue == 0) {
            self.addDeviceModule = [MSAddDeviceAP new];
        } else if (connectInfo.auxiMode.intValue == 3) {
            self.addDeviceModule = [MSAddDeviceBLE new];
        }
    } else {
        if (connectInfo.mode.intValue == 0) {
            self.addDeviceModule = [MSAddDeviceAP new];
        } else if (connectInfo.mode.intValue == 3) {
            self.addDeviceModule = [MSAddDeviceBLE new];
        }
    }
    
    self.addDeviceModule.wifiSsid = connectInfo.wifiSsid;
    self.addDeviceModule.wifiPassword = connectInfo.wifiPassword;
    self.addDeviceModule.wifiBssid = connectInfo.wifiBssid;
    self.addDeviceModule.deviceSsid = connectInfo.deviceSsid;
    self.addDeviceModule.deviceCategory = connectInfo.category;
    self.addDeviceModule.peripheral = connectInfo.peripheral;
    NSString *deviceName = [self deviceNameWithCategory:connectInfo.category];
    self.addDeviceModule.deviceName = deviceName.length == 0? connectInfo.deviceName : deviceName;
    self.addDeviceModule.msDelegete = self;
    self.addDeviceModule.countryChannel = [self getCountryChannelDic];
    
}

- (NSDictionary *)getCountryChannelDic {
    NSArray<MSCountryChannelResult *> *list = [MSAddDeviceCloudRepository fetchCountryChannelRetrieve];
    NSMutableDictionary *extraDic = [NSMutableDictionary new];
//    NSMutableArray *channelList = [NSMutableArray new];
//    NSString *countryCode = @"";
//    NSString *timeZone = [self getTimeZone];
//    for (MSCountryChannelResult *model in list) {
//        NSMutableDictionary *dict = [NSMutableDictionary new];
//        [dict setValue:(model.channelNum ? : @"") forKey:kMSSDKConfigFirstChannelNumber];
//        [dict setValue:(model.channelCounts ? : @"") forKey:kMSSDKConfigChannelCount];
//        [dict setValue:(model.maxTransferPower ? : @"") forKey:kMSSDKConfigChannelMaxPower];
//        [dict setValue:(model.dfs ? : @"") forKey:kMSSDKConfigChannelDFSEnable];
//        [channelList addObject:dict];
//        countryCode = model.countryCode;
//    }
//    [extraDic setValue:(countryCode ? : @"") forKey:kMSSDKConfigCountryCode];
//    [extraDic setValue:(timeZone ? : @"") forKey:kMSSDKConfigTimeZone];
//    [extraDic setValue:channelList forKey:kMSSDKConfigChannelList];
//    
//    //1.5版本新增固件二合一参数
//    [extraDic setValue:[MSAppInfo getModuleServerDomain] forKey:kMSSDKConfigModuleServerDomain];
//    [extraDic setValue:[MSAppInfo getModuleServerPort] forKey:kMSSDKConfigModuleServerPort];
//    [extraDic setValue:@"2" forKey:kMSSDKConfigFunctionType];
//    DDLogDeviceInfo(@"固件二合一参数 Domain:%@, Port:%@", [MSAppInfo getModuleServerDomain], [MSAppInfo getModuleServerPort]);
//    
//    //1.5版本新增冬夏令时参数
//    MSApplianceCityCodeResult *cityResult = [MSAddDeviceCloudRepository getApplianceCityCodeFromLocal];
//    [extraDic setValue:cityResult.cityId ?: @"" forKey:kMSSDKConfigRegionID];
//    DDLogDeviceInfo(@"冬夏令时的cityId：%@", cityResult.cityId);
    
    return extraDic;
}

/// 获取时区
- (NSString *)getTimeZone {
    //0表示0区，1~12表示东1~12区，13~24表示西1~12区
    [NSTimeZone resetSystemTimeZone]; // 重置手机系统的时区
    NSInteger offset = [NSTimeZone localTimeZone].secondsFromGMT;
    offset = offset/3600;//+8:东八区，-8:西八区
    if (offset < 0) {
        offset = 12-offset;
    }
    NSString *tzStr = [NSString stringWithFormat:@"%ld", (long)offset];
    return tzStr;
}

- (void)startAddDevice {
    if ([self.addDeviceModule respondsToSelector:@selector(msAddDeviceStart)]) {
        [self.addDeviceModule msAddDeviceStart];
    }
}

- (NSArray <NSString *> *)msAddDeviceStepTitles {
    return [self.addDeviceModule msAddDeviceStepTitles];
}

- (void)cancelAddDevice {
    [self.addDeviceModule msAddDeviceCancel];
}

- (void)retryAddDeviceWithNewPassword:(NSString *)password {
    self.addDeviceModule.wifiPassword = password;
    [self.addDeviceModule msRetryAddDeviceWithNewPassword];
}

- (void)saveSsid:(NSString *)ssid password:(NSString *)password {
    [self.wifiModel saveSsid:ssid password:password];
}

- (void)destroyTimer {
    [self.addDeviceModule destroyTimer];
}

- (void)autoConnectDeviceWiFiWithSSIDPrefix:(NSString *)ssidPrefix {
    if (@available(iOS 13.0, *)) {
        NEHotspotConfiguration *configuration = [[NEHotspotConfiguration alloc]initWithSSIDPrefix:ssidPrefix ?: @"" passphrase:@"12345678" isWEP:NO];
        @weakify(self)
        [[NEHotspotConfigurationManager sharedManager] applyConfiguration:configuration completionHandler:^(NSError * _Nullable error) {
            @strongify(self)
            DDLogDeviceInfo(@"NEHotspotConfigurationManager applyConfiguration error.localizedDescription:%@ error.code:%ld", error.localizedDescription, error.code);

            if (self.view && [self.view respondsToSelector:@selector(msAutoConnectDeviceWiFiFinished:error:)]) {
                [self.view msAutoConnectDeviceWiFiFinished:self error:error];
            }
        }];
    }
    
}

#pragma mark -  MSAddDeviceDelegate

- (void)msAddDeviceRefresh:(id <MSAddDeviceProtocol>)addDeviceModule progress:(NSInteger)progress step:(NSInteger)step {
    if ([self.view respondsToSelector:@selector(msAddDeviceRefresh:progress:step:)]) {
        [self.view msAddDeviceRefresh:self progress:progress step:step];
    }
}

- (void)msAddDeviceSuccess:(id <MSAddDeviceProtocol>)addDeviceModule {
//    if ([self.view respondsToSelector:@selector(msAddDeviceSuccess:deviceId:deviceName: deviceSN:)]) {
//        [self.view msAddDeviceSuccess:self deviceId:addDeviceModule.deviceId deviceName:addDeviceModule.deviceName deviceSN:addDeviceModule.deviceSn];
//    }
//
//    if ([self.view respondsToSelector:@selector(msAddDeviceSuccess:deviceId:deviceName:deviceSN8:thingCode:firmwareVersion:)]){
//        [self.view msAddDeviceSuccess:self deviceId:addDeviceModule.deviceId deviceName:addDeviceModule.deviceName deviceSN8:addDeviceModule.deviceSn8 thingCode:addDeviceModule.thingCode firmwareVersion:addDeviceModule.firmwareVersion];
//    }
    
    if ([self.view respondsToSelector:@selector(msAddDeviceSuccess:thingCode:deviceName:)]) {
        [self.view msAddDeviceSuccess:self thingCode:addDeviceModule.thingCode deviceName:addDeviceModule.deviceName];
    }
}

- (void)msAddDeviceFaild:(id <MSAddDeviceProtocol>)addDeviceModule error:(NSError *)error {
    if ([self.view respondsToSelector:@selector(msAddDeviceFaild:error:)]) {
        [self.view msAddDeviceFaild:self error:error];
    }
}

- (void)msAddDeviceCancel:(id <MSAddDeviceProtocol>)addDeviceModule {
    if ([self.view respondsToSelector:@selector(msAddDeviceCancel:)]) {
        [self.view msAddDeviceCancel:self];
    }
}

- (void)msAddDeviceStart:(id <MSAddDeviceProtocol>)addDeviceModule {
  
}

- (NSString *)deviceNameWithCategory:(NSString *)category {
    NSString *name = [MSAddDeviceCloudRepository fetchApplianceTypeNameWithCategory:category];
    if ([name isEqualToString:@""]) {
        return name;
    }
    
    //更新设备的默认名称、有重复的话，依次在后面加数字123
    id<MSHomeProtocol> homeService = [OEMRouter getServiceInstance:@protocol(MSHomeProtocol)];
    if (homeService) {
        NSArray * deviceArray = [homeService getLocalDeviceInfo];
        NSInteger number = 0;
        for (MSDeviceCardResult *result in deviceArray) {
            if ([result.name hasPrefix:name]) {
                NSInteger deviceNumber = 0;
                if ([result.name isEqualToString:name]) {
                    deviceNumber = 1;
                } else {
                    NSString *numberString = [result.name substringFromIndex:name.length];
                    if ([self judgeTextIsNumber:numberString]) {
                        deviceNumber = numberString.integerValue;
                    }
                }
                
                number = number < deviceNumber ? deviceNumber : number;
            }
        }

        if (number > 0) {
            name = [NSString stringWithFormat:@"%@%ld", name, number+1];
        }
    }
    
    return name;
}

//判断字符串是否全为数字
- (BOOL)judgeTextIsNumber:(NSString *)str {
   if (str.length == 0) {
        return NO;
    }
    NSString *regex = @"[0-9]*";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    if ([pred evaluateWithObject:str]) {
        return YES;
    }
    return NO;
}


//蓝牙判断逻辑
//- (BOOL)isAvailable:(MSOEMCBPeripheral *)peripheral {
//    NSDictionary *bleAdvDict = [[MSOEMDeviceManager sharedManager] advDataForPeripheral:peripheral];//广播数据中获取的字典
//    if (!bleAdvDict) return NO;
//    BOOL result = NO;
//    if(!peripheral.isFromMSBLECenter &&
//       ![bleAdvDict[@"isWifiConfiged"] boolValue] &&            //未配置
//       [bleAdvDict[@"moduleType"] intValue] == 1 &&            //wifi+ble
//       ![bleAdvDict[@"deviceType"] isEqualToString:@"00"]&&    //尚未读取到品类信息则不加入
//       [bleAdvDict[@"deviceName"] hasPrefix:@"oemiot"]
//    )  {
//        result = YES;
//    }else if(peripheral.isFromMSBLECenter &&
//             [bleAdvDict[@"isWifiConfiged"] intValue] == 0 &&
//             [bleAdvDict[@"wifiConfigEnable"] intValue] == 1 &&
//             [bleAdvDict[@"bindState"] intValue] == 0){
//        result = YES;
//    }
//    return result;
//}


@end
