//
//  MSAddDeviceSS.swift
//  MSDevice
//
//  Created by zhongch18 on 2022/2/18.
//

import Foundation
//import#import <OEMBluetooth/MSOEMDeviceManager.h>
import OEMBluetooth
import MSBusiness
import DolphinRouter
@objc public class MSAddDeviceTools :NSObject {
    @objc public class func isAvailable(per:MSOEMCBPeripheral) -> Bool{
    
        var isAvailable = false
        let bleAdvDict:[AnyHashable : Any] = MSOEMDeviceManager.shared().advData(for: per)
        let isWifiConfiged = bleAdvDict["isWifiConfiged"] as? Bool
        let moduleType = bleAdvDict["moduleType"] as? Int
        let deviceType = bleAdvDict["deviceType"] as? String
        let deviceName = bleAdvDict["deviceName"] as? String
        let wifiConfigEnable = bleAdvDict["wifiConfigEnable"] as? Bool
        let bindState = bleAdvDict["bindState"] as? Bool
        if per.isFromMSBLECenter == false  &&
            isWifiConfiged == false &&
            moduleType == 1 &&
            deviceType != "00" &&
            (deviceName?.hasPrefix("oemiot") == true)
        {
            isAvailable = true
        }else if per.isFromMSBLECenter == true &&
                    isWifiConfiged == false &&
                    wifiConfigEnable == true &&
                    bindState == false
        {
            isAvailable = true
        }
        
//        (lldb) po productRes.category
//        ▿ Optional<String>
//          - some : "AC"
//
//        (lldb) po deviceType
//        ▿ Optional<String>
//          - some : "0xAC"
        
        let deviceService:MSDeviceProtocol? = OEMRouter.getServiceInstance(MSDeviceProtocol.self) as? MSDeviceProtocol
        let deviceProductList:Array<MSDeviceProductResult>? =  deviceService?.fetchApplianceTypeFromDCP()
        //没有拿到设备列表，直接显示false
        guard let deviceProductList = deviceProductList else {
            return false;
        }
        var isContain = false
        guard let deviceType = deviceType else{
            return false
        }
        for productRes in deviceProductList {
            if deviceType.contains(productRes.category) {
                isContain = true
                break
            }
        }
        if isContain && isAvailable {
            return true
        }else{
            return false
        }
    }
}


//
//  MSAddDeviceTool.m
//  MSDevice
//
//  Created by zhongch18 on 2022/2/17.
//

//#import "MSAddDeviceTool.h"
//#import <OEMBluetooth/MSOEMCBPeripheral.h>
//#import <OEMBluetooth/MSOEMDeviceManager.h>
//@implementation MSAddDeviceTool
////蓝牙判断逻辑
//+ (BOOL)isAvailable:(MSOEMCBPeripheral *)peripheral {
//    NSDictionary *bleAdvDict = [[MSOEMDeviceManager sharedManager] advDataForPeripheral:peripheral];//广播数据中获取的字典
//    BOOL isAvailable = NO;
//    if(!peripheral.isFromMSBLECenter &&
//       ![bleAdvDict[@"isWifiConfiged"] boolValue] &&            //未配置
//       [bleAdvDict[@"moduleType"] intValue] == 1 &&            //wifi+ble
//       ![bleAdvDict[@"deviceType"] isEqualToString:@"00"]&&    //尚未读取到品类信息则不加入
//       [bleAdvDict[@"deviceName"] hasPrefix:@"oemiot"]
//    )  {
//        isAvailable = YES;
//    }else if(peripheral.isFromMSBLECenter &&
//             [bleAdvDict[@"isWifiConfiged"] intValue] == 0 &&
//             [bleAdvDict[@"wifiConfigEnable"] intValue] == 1 &&
//             [bleAdvDict[@"bindState"] intValue] == 0){
//        isAvailable = YES;
//    }
//    return isAvailable;
//}
//@end
