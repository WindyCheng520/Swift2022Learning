//
//  OEMScanCodePresenter.m
//  MSDevice
//
//  Created by WindyCheng on 2021/11/3.
//

#import "OEMScanCodePresenter.h"
#import <MSBusiness/MSDeviceProtocol.h>




static NSString *const kBLEScanCodeId = @"mode=003";

static NSString *const kAPScanCodeId = @"mode=000";

static NSString *const kDeviceShareCodeId = @"MADEVICESHARE:";


@implementation OEMScanCodePresenter


//解析二维码数据
-(void)decodeQRCode:(NSString *)code{
    [self.view showLoading];
    
     //http://qrcode.midea.com/midea_10/index.html?cd=1OCn9cfJhAydVnXnzIARCHslse5UbniO4VJyKXdZ&SSID=midea_fd_0008&mode=003
     //https://us.dollin.net/index.html?mode=003&sn8=51015EW1&SSID=dollin_E2_0001
     //https://us.dollin.net/index.html?mode=000&sn8=51015EW1&SSID=dollin_AC_0001
    if ([code containsString:kBLEScanCodeId]||[code containsString:kAPScanCodeId]) { //蓝牙/AP配网二维码
        NSURLComponents *components = [[NSURLComponents alloc] initWithURL:[NSURL URLWithString:code] resolvingAgainstBaseURL:YES];
        NSMutableDictionary *dict = @{}.mutableCopy;
        NSString *category = @"";
        for (NSURLQueryItem *item in components.queryItems) {
            DDLogDeviceInfo(@"--------key:%@ =====  value:%@", item.name, item.value);
            if ([item.name isEqualToString:@"sn8"]) {//sn8
                dict[@"deviceSN8"] = item.value;
            }
            if ([item.name isEqualToString:@"SSID"]) {
                NSArray *array = [item.value componentsSeparatedByString:@"_"];
                if (array.count > 2) {
                    category = [array[1] uppercaseString];
                }
                dict[@"ssid"] = item.value;
            }
            
            if ([item.name isEqualToString:@"mode"]) {//sn8
                dict[@"mode"] = [NSString stringWithFormat:@"%ld",item.value.integerValue];
            }
        }
        
        dict[@"category"] = category;
        id<MSDeviceProtocol> deviceService = [OEMRouter getServiceInstance:@protocol(MSDeviceProtocol)];
        if (deviceService) {
            NSArray *dataArray = [deviceService fetchApplianceTypeFromDCP];
            [dataArray enumerateObjectsUsingBlock:^(MSDeviceProductResult *obj, NSUInteger idx, BOOL * _Nonnull stop) {
                if ([category hasSuffix:obj.category]) {
                    dict[@"imgUrl"] = obj.imgUrl;
                    dict[@"typeName"] = obj.typeName;
                }
            }];
        }
        self.type = OEMCodeTypeBLE;
        if ([self.view respondsToSelector:@selector(presenter:decodeQRCodeComplete:)]) {
            [self.view hideLoading];
            [self.view presenter:self decodeQRCodeComplete:dict];
        }
        
    }else if([code containsString:kDeviceShareCodeId]){ //设备分享二维码: MADEVICESHARE:eyJ1c2VySWQiOiI1MDY1MDE
        self.type = OEMCodeTypeDeviceShare;
        NSArray *array = [code componentsSeparatedByString:@"SHARE:"];
        NSString *shareInfo = array.lastObject;
      //  {"requestCode":"CHJBHVVYTT7SGHJKL","deviceType":"0xAC","deviceName":"我的空调"}
        NSDictionary *dict = [self parseJSONStringToNSDictionary:shareInfo];
        if ([self.view respondsToSelector:@selector(presenter:decodeQRCodeComplete:)]) {
            [self.view hideLoading];
            [self.view presenter:self decodeQRCodeComplete:dict];
        }
    }
    else if([self stringShouldMacAddress:code]){ //设备mac地址: 1122334455EE
        self.type = OEMCodeTypeMacAddress;
        if ([self.view respondsToSelector:@selector(presenter:decodeQRCodeComplete:)]) {
            [self.view hideLoading];
            [self.view presenter:self decodeQRCodeComplete:@{}];
        }
    }else{
        self.type = OEMCodeTypeUnknown;
        if ([self.view respondsToSelector:@selector(presenter:decodeQRCodeComplete:)]) {
            [self.view hideLoading];
            [self.view presenter:self decodeQRCodeComplete:@{}];
        }
    }
}

//判断是否是mac 地址（例如：1122334455EE)
- (BOOL)stringShouldMacAddress:(NSString *)string {
    if (string.length != 12) return NO;
    NSString *regex = @"[a-zA-Z0-9]*";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    return [pred evaluateWithObject:string];
}


- (NSDictionary*)parseJSONStringToNSDictionary:(NSString*)JSONString {
   NSData *JSONData = [JSONString dataUsingEncoding:NSUTF8StringEncoding];
   NSDictionary *responseJSON = [NSJSONSerialization JSONObjectWithData:JSONData options:NSJSONReadingMutableLeaves error:nil];
   return responseJSON;
}



@end
