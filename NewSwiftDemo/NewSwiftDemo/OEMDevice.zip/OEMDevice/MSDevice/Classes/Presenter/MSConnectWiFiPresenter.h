//  
//  MSConnectWiFiPresenter.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/17
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <MSBusiness/MVPPresenter.h>

@class MSConnectWiFiPresenter;
@protocol MSConnectWiFiViewProtocol <MVPViewProtocol>

- (void)presenter:(MSConnectWiFiPresenter *)presenter didEnableClick:(BOOL)enable;

@end

@interface MSConnectWiFiPresenter : MVPPresenter

@property (nonatomic, copy) NSString *wifiName;
@property (nonatomic, copy) NSString *wifiPassword;


- (NSString *)fetchPasswordWithSsid:(NSString *)ssid;

- (void)saveSsid:(NSString *)ssid password:(NSString *)password;

@end
