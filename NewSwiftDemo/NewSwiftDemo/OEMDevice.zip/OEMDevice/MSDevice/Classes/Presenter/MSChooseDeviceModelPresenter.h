//  
//  MSChooseDeviceModelPresenter.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/10
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <MSBusiness/MVPPresenter.h>
#import <MSBusiness/MSBusinessError.h>

@class MSChooseDeviceModelPresenter;
@class MSDeviceConnectResult;

@protocol MSChooseDeviceModelViewProtocol <MVPViewProtocol>

- (void)presenterDidLoadData:(MSChooseDeviceModelPresenter *)presenter;

- (void)presenter:(MSChooseDeviceModelPresenter *)presenter didLoadConnectInfo:(MSDeviceConnectResult *)connectInfo;

@end

@interface MSChooseDeviceModelPresenter : MVPPresenter<id<MSChooseDeviceModelViewProtocol>>

@property (nonatomic, strong) NSArray *dataArray;

- (void)fetchIotProductWithTypeId:(NSString *)typeId;

- (void)fetchIotConnectInfoWithIotProductId:(NSString *)iotProductId productId:(NSString *)productId;

- (void)requestDataAfterSelectedWithIotProductId:(NSString *)iotProductId productId:(NSString *)productId;

@end


