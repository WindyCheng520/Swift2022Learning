//  
//  MSAddDeviceSuccessPresenter.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/16
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSAddDeviceSuccessPresenter.h"
#import <OEMFoundation/OEMMacros.h>
#import "MSDeviceBundle.h"
#import <MSBusiness/MSBusiness-Swift.h>

@implementation MSAddDeviceSuccessPresenter

- (void)changeDeviceNameWithThingCode:(NSString *)thingCode name:(NSString *)name{
    if ([self.view respondsToSelector:@selector(showLoading)]) {
        [self.view showLoading];
    }
    
    @weakify(self)
    [MSAddDeviceCloudRepository modifyApplianceInfoWiththingCode:thingCode applianceName:name success:^ {
        @strongify(self)
        if ([self.view respondsToSelector:@selector(presenter:didChangeDeviceName:)]) {
            [self.view presenter:self didChangeDeviceName:nil];
        }
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        if ([self.view respondsToSelector:@selector(hideLoading)]) {
            [self.view hideLoading];
        }
        if ([self.view respondsToSelector:@selector(presenter:didChangeDeviceName:)]) {
            [self.view presenter:self didChangeDeviceName:error];
        }
    }];
}




- (void)fetchApplianceAuthStatusWithApplianceCode:(NSString *)applianceCode showLoading:(BOOL)showLoading {
    if ([BusinessNetWorkTools isNetworkUnreachable]) {
        [self.view toastText:MSResourceString(@"me_network_not_connected")];
        return;
    }
    
    if (showLoading) {
        [self.view showLoading];
    }
    
    @weakify(self)
    [MSAddDeviceCloudRepository fetchApplianceAuthStatusWithApplianceCode:applianceCode success:^(MSDeviceAuthStatusResult *result) {
        @strongify(self)
        [self.view hideLoading];
        self.authType = result.status;
        
        if ([self.view respondsToSelector:@selector(presenter:didFetchApplianceAuthStatus:)]) {
            [self.view presenter:self didFetchApplianceAuthStatus:nil];
        }
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        [self.view hideLoading];
        if ([self.view respondsToSelector:@selector(presenter:didFetchApplianceAuthStatus:)]) {
            [self.view presenter:self didFetchApplianceAuthStatus:error];
        }
//        [self.view toastText:MSResourceString(@"connect_jump_fail")];
    }];
    
}




@end
