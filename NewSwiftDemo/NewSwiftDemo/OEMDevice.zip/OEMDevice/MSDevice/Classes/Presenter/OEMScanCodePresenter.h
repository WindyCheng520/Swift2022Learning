//
//  OEMScanCodePresenter.h
//  MSDevice
//
//  Created by WindyCheng on 2021/11/3.
//

#import <MSBusiness/MVPPresenter.h>

NS_ASSUME_NONNULL_BEGIN

//二维码类型
typedef NS_ENUM(NSInteger, OEMCodeType)  {
    OEMCodeTypeUnknown,         //未知
    OEMCodeTypeBLE,             //蓝牙配网二维码(解析出品类，sn8，配网模式)
    OEMCodeTypeAP,              //AP配网二维码(解析出品类，sn8，配网模式)
    OEMCodeTypeDeviceShare,     //设备分享二维码
    OEMCodeTypeMacAddress       //12位mac地址
};


@class OEMScanCodePresenter;

@protocol OEMScanCodeModelViewProtocol <MVPViewProtocol>

- (void)presenter:(OEMScanCodePresenter *)presenter decodeQRCodeComplete:(NSDictionary *)dict;

@end


@interface OEMScanCodePresenter : MVPPresenter<id<OEMScanCodeModelViewProtocol>>

@property(nonatomic, assign)OEMCodeType type;

-(void)decodeQRCode:(NSString *)code;

@end

NS_ASSUME_NONNULL_END
