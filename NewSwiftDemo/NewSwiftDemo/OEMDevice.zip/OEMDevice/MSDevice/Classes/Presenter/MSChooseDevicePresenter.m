//  
//  MSChooseDevicePresenter.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/8
//  Copyright © 2020 Midea. All rights reserved.
//   


#import "MSChooseDevicePresenter.h"
#import "MSDeviceTypeModel.h"
#import <OEMFoundation/OEMMacros.h>
#import <MJExtension/MJExtension.h>
#import "MSDeviceBundle.h"
#import <OEMBluetooth/MSOEMDeviceManager.h>
#import <MSmartSDK/MSmartSDK.h>
#import <MSDevice/MSDevice-Swift.h>
@interface MSChooseDevicePresenter ()

@property (nonatomic, strong) MSDeviceTypeModel *deviceModel;
@property (nonatomic, strong) MSDeviceRouterService *routerService;
@property (nonatomic, strong) NSArray<MSDeviceProductResult *> *deviceProductList;  //根据category查询自发现设备的图片
@property (nonatomic, strong) NSArray<MSDeviceTypeResult *> *deviceTypeList;  //根据category查询自发现设备的名称

@end

@implementation MSChooseDevicePresenter

- (MSDeviceTypeModel *)deviceModel {
    if (!_deviceModel) {
        _deviceModel = [MSDeviceTypeModel new];
    }
    return _deviceModel;
}

- (MSDeviceRouterService *)routerService {
    if (!_routerService) {
        _routerService = [MSDeviceRouterService new];
    }
    return _routerService;
}

- (NSMutableArray<MSAutoFindResult *> *)scanResult {
    if (!_scanResult) {
        _scanResult = [NSMutableArray array];
    }
    return _scanResult;
}

- (void)fetchTypeList {
    @weakify(self)
    
    if ([self.view respondsToSelector:@selector(showLoading)]) {
        [self.view showLoading];
    }
    
    [self.deviceModel fetchTypeListSuccess:^(NSArray<MSDeviceProductResult *> *result) {
        @strongify(self)
        if ([self.view respondsToSelector:@selector(hideLoading)]) {
            [self.view hideLoading];
        }
        self.dataArray = result;
        if ([self.view respondsToSelector:@selector(presenterDidLoadData:)]) {
            [self.view presenterDidLoadData:self];
        }
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        if ([self.view respondsToSelector:@selector(hideLoading)]) {
            [self.view hideLoading];
        }
        if ([self.view respondsToSelector:@selector(toastText:)]) {
            [self.view toastText:error.localizedDescription];
        }
    }];
}

#pragma mark - auto find
- (void)startAutoFind {
    DDLogDeviceInfo(@"开始扫描");
    
    [self.scanResult removeAllObjects];
    @weakify(self)
    [self performSelector:@selector(scanTime15Seconds) withObject:nil afterDelay:15];
    
    [[MSOEMDeviceManager sharedManager] startScanBLEPeripheralWithInterval:MAXFLOAT extradic:@{} competion:^(NSError *error, MSOEMCBPeripheral *peripheral) {
        @strongify(self)
        NSDictionary *bleAdvDict = [[MSOEMDeviceManager sharedManager] advDataForPeripheral:peripheral];//广播数据中获取的字典
        DDLogDeviceDebug(@"find device bleAdvDict: %@ 蓝牙阈值：%@", bleAdvDict, peripheral.RSSI);
        if ([self checkBluetoothRSSI:peripheral.RSSI]) {
            [self isAvailableBle:bleAdvDict peripheral:peripheral];
        }
    }];
}

- (void)scanTime15Seconds {
    DDLogDeviceInfo(@"扫描到15s");
    if (self.scanResult.count == 0) {
        if (self.view && [self.view respondsToSelector:@selector(presenterDidScan15Seconds:)]) {
            [self.view presenterDidScan15Seconds:self];
        }
    }
}

- (void)viewWillDisappear {
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(scanTime15Seconds) object:nil];
    [[MSOEMDeviceManager sharedManager] stopBLEScan];
    DDLogDeviceInfo(@"Device cancelPreviousPerformRequestsWithTarget");
}

- (void)getDcpApplianceTypeData {
    NSArray *array = [self.routerService fetchApplianceTypeFromDCP];
    if (array) {
        self.deviceProductList = array;
    } else {
        self.deviceProductList = @[];
    }
}

//从数据库缓存中遍历获取对应品类码的品类图标
- (NSString *)getDeviceDcpImageUrlWithCategory:(NSString *)category {
    if ([category hasPrefix:@"0x"]) {
        category = [category stringByReplacingOccurrencesOfString:@"0x" withString:@""];
    }
    NSString *dcpImageUrl = @"";
    for (MSDeviceProductResult *result in self.deviceProductList) {
        if ([result.category isEqualToString:category]) {
            dcpImageUrl = result.imgUrl;
            break;
        }
    }
    return dcpImageUrl;
}


//从数据库缓存中遍历获取对应品类码的品类名
- (NSString *)getDeviceDcpTypeNameWithCategory:(NSString *)category {
    if ([category hasPrefix:@"0x"]) {
        category = [category stringByReplacingOccurrencesOfString:@"0x" withString:@""];
    }

    NSString *typeName = @"";
    for (MSDeviceProductResult *result in self.deviceProductList) {
        if ([result.category isEqualToString:category]) {
            typeName = result.typeName;
            break;
        }
    }
    return typeName;
}



- (void)getCloudApplianceNameData {
    NSArray<MSDeviceTypeResult *> *resultArray = [MSDeviceTypeResult bg_findAll:nil];
    if (resultArray) {
        self.deviceTypeList = resultArray;
    } else {
        self.deviceTypeList = @[];
    }
}

- (NSString *)getDeviceNameFromCloudWithCategory:(NSString *)category {
    if (![category hasPrefix:@"0x"]) {
        category = [NSString stringWithFormat:@"0x%@", category];
    }
    NSString *name = @"";
    for (MSDeviceTypeResult *result in self.deviceTypeList) {
        if ([result.type isEqualToString:category]) {
            name = result.name;
            break;
        }
    }
    return name;
}

//蓝牙阈值判断
- (BOOL)checkBluetoothRSSI:(NSNumber *)rssi {
    return rssi.integerValue >= -158;
}


//蓝牙判断逻辑
- (BOOL)isAvailableBle:(NSDictionary *)bleAdvDict peripheral:(MSOEMCBPeripheral *)peripheral {
    
    if (!bleAdvDict) return NO;
    BOOL result = NO;
//    BOOL isAvailable = [MSAddDeviceTool isAvailable:peripheral];
    BOOL isAvailable = [MSAddDeviceTools isAvailableWithPer:peripheral];
    if (isAvailable) {
        __block BOOL exist = NO;
        [self.scanResult enumerateObjectsUsingBlock:^(MSAutoFindResult * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            
            if ([obj.deviceMac isEqualToString:bleAdvDict[@"deviceMac"]]) {
                exist = YES;
                *stop = YES;
            }
        }];
        
        if (!exist) {
            [self refreshScanResultsWithDeviceDic:bleAdvDict peripheral:peripheral];
            result = YES;
        }
    }
//    if(!peripheral.isFromMSBLECenter &&
//       ![bleAdvDict[@"isWifiConfiged"] boolValue] &&            //未配置
//       [bleAdvDict[@"moduleType"] intValue] == 1 &&            //wifi+ble
//       ![bleAdvDict[@"deviceType"] isEqualToString:@"00"]&&    //尚未读取到品类信息则不加入
//       [bleAdvDict[@"deviceName"] hasPrefix:@"oemiot"]
//       ) {
//        __block BOOL exist = NO;
//        [self.scanResult enumerateObjectsUsingBlock:^(MSAutoFindResult * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//
//            if ([obj.deviceMac isEqualToString:bleAdvDict[@"deviceMac"]]) {
//                exist = YES;
//                *stop = YES;
//            }
//        }];
//
//        if (!exist) {
//            [self refreshScanResultsWithDeviceDic:bleAdvDict peripheral:peripheral];
//            result = YES;
//        }
//    }else if(peripheral.isFromMSBLECenter &&
//             [bleAdvDict[@"isWifiConfiged"] intValue] == 0 &&
//             [bleAdvDict[@"wifiConfigEnable"] intValue] == 1 &&
//             [bleAdvDict[@"bindState"] intValue] == 0){
//        __block BOOL exist = NO;
//        [self.scanResult enumerateObjectsUsingBlock:^(MSAutoFindResult * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//
//            if ([obj.deviceMac isEqualToString:bleAdvDict[@"deviceMac"]]) {
//                exist = YES;
//                *stop = YES;
//            }
//        }];
//
//        if (!exist) {
//            [self refreshScanResultsWithDeviceDic:bleAdvDict peripheral:peripheral];
//            result = YES;
//        }
//
//    }
    
    return result;
}

- (void)refreshScanResultsWithDeviceDic:(NSDictionary *)bleAdvDict peripheral:(MSOEMCBPeripheral *)peripheral {
    // DDLogDeviceInfo(@"扫描到设备---------------:%@--------------%@", bleAdvDict, peripheral);
    MSAutoFindResult *result = [MSAutoFindResult mj_objectWithKeyValues:bleAdvDict];
    result.peripheral = peripheral;
    
    result.bleAdvDict = bleAdvDict;
    if ([result.peripheral isKindOfClass:[MSOEMCBPeripheral class]]) {
        MSOEMCBPeripheral * p = (MSOEMCBPeripheral *)result.peripheral;
        [p.central addPeripheral:peripheral];
    }
    
    result.dcpImageUrl = [self getDeviceDcpImageUrlWithCategory:[result.deviceType copy]];
    result.cloudName = [self getDeviceDcpTypeNameWithCategory:[result.deviceType copy]];

#if (AppStore_ENV==0 || UAT_ENV==1)
    //区别oem设备和存量设备
    NSNumber * number = [[NSUserDefaults standardUserDefaults] objectForKey:@"OEM_Display_Auto_Found_Device_Mac_Suffix"];
    if (number) {
        if (!peripheral.isFromMSBLECenter) {
            NSString * name = result.deviceMac;
            if (name.length > 4) {
                name = [name substringWithRange:NSMakeRange(name.length - 4, 4)];
            }
            result.cloudName = [NSString stringWithFormat:@"%@_%@",result.cloudName,name];
        }else{
            NSString * name = result.deviceMac;
            if (name.length > 4) {
                name = [name substringWithRange:NSMakeRange(name.length - 4, 4)];
            }
            result.cloudName = [NSString stringWithFormat:@"net_%@_%@",result.cloudName,name];
        }
    }
#endif
    //result.cloudName = [self getDeviceNameFromCloudWithCategory:[result.deviceType copy]];
    [self.scanResult addObject:result];
    
    if (self.view && [self.view respondsToSelector:@selector(presenter:discoverDevices:)]) {
        [self.view presenter:self discoverDevices:self.scanResult];
    }
    
}

- (void)requestConnectInfoWithSN8:(NSString *)sn8 dcpImageUrl:(NSString *)dcpImageUrl {
    [self.view showLoading];
    @weakify(self)
    id <MSDeviceProtocol>service = [OEMRouter getServiceInstance:@protocol(MSDeviceProtocol)];
    if ([service respondsToSelector:@selector(fetchApplianceCityCodeWithSuccess:failure:)]) {
        
        [service fetchApplianceCityCodeWithSuccess:^{
            @strongify(self)
            [self requestConnectInfoAfterCityCodeWithSN8:sn8 dcpImageUrl:dcpImageUrl];
        } failure:^(MSBusinessError *error) {
            @strongify(self)
            [self.view hideLoading];
            [self.view toastText:MSResourceString(@"device_cityId_fail")];
        }];
    } else {
        [self.view hideLoading];
    }
    
    //    [self requestConnectInfoAfterCityCodeWithSN8:sn8 dcpImageUrl:dcpImageUrl];
}

- (void)requestConnectInfoAfterCityCodeWithSN8:(NSString *)sn8 dcpImageUrl:(NSString *)dcpImageUrl {
    @weakify(self)
    [self.routerService fetchIotConnectInfoWithSN8:sn8 success:^(MSDeviceConnectResult * _Nonnull result) {
        @strongify(self)
        [self.view hideLoading];
        result.deviceImageUrl = dcpImageUrl;
        result.deviceConnectType = MSDeviceConnectTypeSelectAutoFind;
        if ([self.view respondsToSelector:@selector(presenter:getConnectInfo:)]) {
            [self.view presenter:self getConnectInfo:result];
        }
    } failure:^(MSBusinessError * _Nonnull error) {
        @strongify(self)
        [self.view hideLoading];
        [self.view toastText:error.localizedDescription];
    }];
    
}



-(void)fetchConnectInfoWithAutoFindResult:(MSAutoFindResult *)device{
    MSDeviceConnectResult *result = [[MSDeviceConnectResult alloc] init];
    result.category = device.deviceType;  //存量：0xAC
    result.deviceMac = device.deviceMac;
    result.deviceConnectType =  MSDeviceConnectTypeSelectAutoFind;
    result.peripheral = device.peripheral;
    result.deviceName = device.cloudName;
    result.deviceImageUrl = device.dcpImageUrl; //失败页面用到
    result.deviceSn8 =  device.deviceSN8;
    result.deviceSsid =  device.deviceSSID;
    result.mode = @"3";   //蓝牙配网
    
    if ([self.view respondsToSelector:@selector(presenter:getConnectInfo:)]) {
        [self.view presenter:self getConnectInfo:result];
    }
}


@end
