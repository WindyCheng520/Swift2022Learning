//  
//  MSAddDevicePresenter.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/16
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <MSBusiness/MVPPresenter.h>
#import "MSAddDeviceProtocol.h"
#import <MSBusiness/MSDeviceConnectResult.h>
#import <OEMBluetooth/MSOEMCBPeripheral.h>


@class MSAddDevicePresenter;

@protocol MSAddDeviceViewProtocol <MVPViewProtocol>

- (void)msAddDeviceSuccess:(MSAddDevicePresenter *)presenter deviceId:(NSString *)deviceId deviceName:(NSString *)deviceName deviceSN:(NSString *)deviceSN;


- (void)msAddDeviceFaild:(MSAddDevicePresenter *)presenter error:(NSError *)error;

- (void)msAddDeviceRefresh:(MSAddDevicePresenter *)presenter progress:(NSInteger)progress step:(NSInteger)stepType;

- (void)msAddDeviceCancel:(MSAddDevicePresenter *)presenter;

- (void)msAutoConnectDeviceWiFiFinished:(MSAddDevicePresenter *)presenter error:(NSError *)error;

- (void)msAddDeviceSuccess:(MSAddDevicePresenter *)presenter
                  deviceId:(NSString *)deviceId
                deviceName:(NSString *)deviceName
                 deviceSN8:(NSString *)deviceSN8
                 thingCode:(NSString *)thingCode
           firmwareVersion:(NSString *)firmwareVersion;


- (void)msAddDeviceSuccess:(MSAddDevicePresenter *)presenter
                 thingCode:(NSString *)thingcode
                deviceName:(NSString *)deviceName;


- (void)scanDeviceSuccess:(MSAddDevicePresenter *)presenter
               peripheral:(MSOEMCBPeripheral *)peripheral;



@end

@interface MSAddDevicePresenter : MVPPresenter<id<MSAddDeviceViewProtocol>>

@property (nonatomic, assign) BOOL isBluetooth;
@property (nonatomic, copy) NSString *deviceSSID;

- (void)setupAddDeviceModuleWithConnectInfo:(MSDeviceConnectResult *)connectInfo;

- (void)startAddDevice;

- (void)cancelAddDevice;

//密码错误时，重新输入密码恢复配网
- (void)retryAddDeviceWithNewPassword:(NSString *)password;

- (NSArray <NSString *> *)msAddDeviceStepTitles;

- (NSString *)deviceNameWithCategory:(NSString *)category;

//本地保存配网使用的wifi和密码
- (void)saveSsid:(NSString *)ssid password:(NSString *)password;

- (void)destroyTimer;

//ap配网自动连接设备热点
- (void)autoConnectDeviceWiFiWithSSIDPrefix:(NSString *)ssidPrefix;



- (void)startScanBLEWithCategory:(NSString *)category deviceSn8:(NSString *)deviceSn8 timeout:(NSTimeInterval)timeout;

- (void)stopScan;



@end
