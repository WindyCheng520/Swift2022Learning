//
//  MSAuthorizePresenter.h
//  MSDevice
//
//  Created by pactera on 2020/11/25.
//

#import <MSBusiness/MVPPresenter.h>
#import <MSBusiness/MSBusinessError.h>
#import "MSAddDeviceCloudRepository.h"

@class MSAuthorizePresenter;
@protocol MSAuthorizeViewProtocol <MVPViewProtocol>


- (void)presenter:(MSAuthorizePresenter *)presenter fetchAddDeviceGuideContentCompletion:(MSBusinessError *)error;

- (void)presenter:(MSAuthorizePresenter *)presenter getAuthInfoCompletion:(MSBusinessError *)error;
- (void)presenter:(MSAuthorizePresenter *)presenter checkApplianceAuthCompletion:(MSBusinessError *)error;
- (void)presenter:(MSAuthorizePresenter *)presenter confirmApplianceAuthCompletion:(MSBusinessError *)error;
- (void)presenter:(MSAuthorizePresenter *)presenter updateTimerCountDown:(NSUInteger)count;

@end


@interface MSAuthorizePresenter : MVPPresenter<id<MSAuthorizeViewProtocol>>

@property (nonatomic, strong) MSDeviceAuthResult *authResult;
@property (nonatomic, assign) NSInteger status;   //查询设备的状态



-(void)fetchAddDeviceGuideContentWithDeviceType:(NSString *)deviceType
                                          model:(NSString *)model
                                      guideType:(NSString *)guideType
                                    subCategory:(NSString *)subCategory;


- (void)getAuthInfoWithCategory:(NSString *)category code:(NSString *)code;
- (void)checkApplianceAuthStatusWithApplianceCode:(NSString *)applianceCode showLoading:(BOOL)showLoading;
- (void)confirmApplianceAuthWithApplianceCode:(NSString *)applianceCode;
- (void)startTimerCountDown;
- (void)applicationWillEnterForeground:(NSNotification *)notification;


@end

