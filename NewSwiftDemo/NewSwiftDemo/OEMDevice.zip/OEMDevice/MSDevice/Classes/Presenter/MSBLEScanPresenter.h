//  
//  MSBLEScanPresenter.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/31
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <MSBusiness/MVPPresenter.h>
#import <OEMBluetooth/MSOEMCBPeripheral.h>

@class MSBLEScanPresenter;

@protocol MSBLEScanViewProtocol <MVPViewProtocol>

- (void)scanDeviceSuccess:(MSBLEScanPresenter *)presenter peripheral:(MSOEMCBPeripheral *)peripheral;

@end


@interface MSBLEScanPresenter : MVPPresenter<id<MSBLEScanViewProtocol>>

- (void)startScanBLEWithCategory:(NSString *)category timeout:(NSTimeInterval)timeout;

- (void)stopScan;

@end
