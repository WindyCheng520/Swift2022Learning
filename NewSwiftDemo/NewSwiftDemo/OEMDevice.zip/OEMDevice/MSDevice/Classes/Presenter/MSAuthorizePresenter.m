//
//  MSAuthorizePresenter.m
//  MSDevice
//
//  Created by pactera on 2020/11/25.
//

#import "MSAuthorizePresenter.h"
#import <OEMFoundation/OEMMacros.h>
#import "MSDeviceTypeModel.h"
#import <OEMFoundation/OEMGCDTimer.h>
#import "MSDeviceBundle.h"
#import <MSBusiness/MSBusiness-Swift.h>

static const NSInteger totalTimer = 60;
static const NSInteger networkErrorCode = 9999;  //无网络的错误码

@interface MSAuthorizePresenter ()

@property (nonatomic, strong) MSDeviceTypeModel *deviceModel;
@property (nonatomic, strong) OEMGCDTimer *countDownTimer;
@property (nonatomic, assign) NSInteger currentCount;
@property (nonatomic, copy) NSString *startTime;

@end

@implementation MSAuthorizePresenter

- (MSDeviceTypeModel *)deviceModel {
    if (!_deviceModel) {
        _deviceModel = [MSDeviceTypeModel new];
    }
    return _deviceModel;
}

-(void)fetchAddDeviceGuideContentWithDeviceType:(NSString *)deviceType
                                          model:(NSString *)model
                                      guideType:(NSString *)guideType
                                    subCategory:(NSString *)subCategory{
    [self.view showLoading];
    @weakify(self)
    [MSAddDeviceCloudRepository fetchAddDeviceGuideContentWithDeviceType:deviceType
                                                                   model:model
                                                               guideType:guideType
                                                             subCategory:subCategory
                                                                 success:^(NSArray *list) {
        @strongify(self)
        [self.view hideLoading];
        self.authResult = list.firstObject;
        if ([self.view respondsToSelector:@selector(presenter:fetchAddDeviceGuideContentCompletion:)]) {
            [self.view presenter:self fetchAddDeviceGuideContentCompletion:nil];
        }
        
    }
                                                                 failure:^(MSBusinessError *error) {
        @strongify(self)
        [self.view hideLoading];
        if ([self.view respondsToSelector:@selector(presenter:fetchAddDeviceGuideContentCompletion:)]) {
            [self.view presenter:self fetchAddDeviceGuideContentCompletion:error];
        }
        
    }];
    
    
}






- (void)getAuthInfoWithCategory:(NSString *)category code:(NSString *)code {
    [self.view showLoading];
    
    @weakify(self)
    [self.deviceModel fetchIotConfirmInfoWithCategory:category code:code success:^(MSDeviceAuthResult *result) {
        @strongify(self)
        self.authResult = result;
        if ([self.view respondsToSelector:@selector(presenter:getAuthInfoCompletion:)]) {
            [self.view presenter:self getAuthInfoCompletion:nil];
        }
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        [self.view hideLoading];
        if ([self.view respondsToSelector:@selector(presenter:getAuthInfoCompletion:)]) {
            [self.view presenter:self getAuthInfoCompletion:error];
        }
    }];
    
}

- (void)checkApplianceAuthStatusWithApplianceCode:(NSString *)applianceCode showLoading:(BOOL)showLoading {
    if ([BusinessNetWorkTools isNetworkUnreachable]) {
        if ([self.view respondsToSelector:@selector(presenter:checkApplianceAuthCompletion:)]) {
            [self.view presenter:self checkApplianceAuthCompletion:[MSBusinessError errorWithDomain:MSAddDeviceErrorDomain code:networkErrorCode]];
        }
        return;
    }
    if (showLoading) {
        [self.view showLoading];
    }
    
    @weakify(self)
    [MSAddDeviceCloudRepository fetchApplianceAuthStatusWithApplianceCode:applianceCode success:^(MSDeviceAuthStatusResult *result) {
        @strongify(self)
        self.status = result.status;
        if ([self.view respondsToSelector:@selector(presenter:checkApplianceAuthCompletion:)]) {
            [self.view presenter:self checkApplianceAuthCompletion:nil];
        }
        
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        [self.view hideLoading];
        if ([self.view respondsToSelector:@selector(presenter:checkApplianceAuthCompletion:)]) {
            [self.view presenter:self checkApplianceAuthCompletion:error];
        }
    }];
    
}

- (void)confirmApplianceAuthWithApplianceCode:(NSString *)applianceCode {
    
    @weakify(self)
    [MSAddDeviceCloudRepository confirmApplianceAuthStatusWithApplianceCode:applianceCode success:^{
        @strongify(self)
        [self.view hideLoading];
        if ([self.view respondsToSelector:@selector(presenter:confirmApplianceAuthCompletion:)]) {
            [self.view presenter:self confirmApplianceAuthCompletion:nil];
        }
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        [self.view hideLoading];
        if ([self.view respondsToSelector:@selector(presenter:confirmApplianceAuthCompletion:)]) {
            [self.view presenter:self confirmApplianceAuthCompletion:error];
        }
    }];
    
}

- (void)startTimerCountDown {
    self.currentCount = totalTimer;
    self.startTime = [self getCurrentSystemTime];
    WEAK_SELF;
    void(^updateTimerCodeCountDown)(void) = ^() {
        STRONG_SELF;
        if ([self.view respondsToSelector:@selector(presenter:updateTimerCountDown:)]) {
            [self.view presenter:self updateTimerCountDown:self.currentCount];
        }
    };
    
    updateTimerCodeCountDown();
    self.countDownTimer = [OEMGCDTimer scheduleTimer:1 actionBlock:^{
        STRONG_SELF;
        self.currentCount -= 1;
        updateTimerCodeCountDown();
        if (self.currentCount == 0) {
            [self.countDownTimer stop];
            self.countDownTimer = nil;
        }
    } willRepeat:YES];
}

- (void)applicationWillEnterForeground:(NSNotification *)notification {
    if (self.countDownTimer.isValid && self.startTime) {
        NSString *currentTimeStr = [self getCurrentSystemTime];
        self.currentCount = totalTimer - (currentTimeStr.integerValue - self.startTime.integerValue);
        if (self.currentCount <= 0) {
           self.currentCount = 0;
           [self.countDownTimer stop];
           self.countDownTimer = nil;
        }
        if ([self.view respondsToSelector:@selector(presenter:updateTimerCountDown:)]) {
           [self.view presenter:self updateTimerCountDown:self.currentCount];
        }
    }
}

//当前时间戳
- (NSString*)getCurrentSystemTime {
    NSDate* date = [NSDate dateWithTimeIntervalSinceNow:0];
    NSTimeInterval a = [date timeIntervalSince1970];
    NSString *timeString = [NSString stringWithFormat:@"%.0f", a];
    return timeString;
}


@end
