//  
//  MSAddDeviceSuccessPresenter.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/16
//  Copyright © 2020 Midea. All rights reserved.
//   
   


#import <MSBusiness/MVPPresenter.h>
#import "MSAddDeviceCloudRepository.h"

@class MSAddDeviceSuccessPresenter;

@protocol MSAddDeviceSuccessViewProtocol <MVPViewProtocol>

- (void)presenter:(MSAddDeviceSuccessPresenter *)presenter didChangeDeviceName:(MSBusinessError *)error;
- (void)presenter:(MSAddDeviceSuccessPresenter *)presenter didFetchApplianceAuthStatus:(MSBusinessError *)error;
//- (void)changeDeviceNameSuccess:(MSAddDeviceSuccessPresenter *)presenter;
//- (void)fetchApplianceAuthStatusSuccess:(MSAddDeviceSuccessPresenter *)presenter;

@end

@interface MSAddDeviceSuccessPresenter : MVPPresenter<id<MSAddDeviceSuccessViewProtocol>>

@property (nonatomic, assign) NSInteger authType;

- (void)changeDeviceNameWithThingCode:(NSString *)thingCode name:(NSString *)name;
- (void)fetchApplianceAuthStatusWithApplianceCode:(NSString *)applianceCode showLoading:(BOOL)showLoading;


@end
