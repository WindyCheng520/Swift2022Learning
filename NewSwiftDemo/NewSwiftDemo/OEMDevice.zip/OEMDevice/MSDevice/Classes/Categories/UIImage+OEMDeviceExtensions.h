//
//  UIImage+Extension.h
//  UI_common
//
//  Created by Vincent on 2017/9/20.
//  Copyright © 2017年 Vincent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (OEMDeviceExtensions)

/**
 颜色创建图片

 @param color 颜色值
 @return 图片
 */
+ (nullable UIImage *)imageWithColor:(nonnull UIColor *)color;

/**
 视图创建图片

 @param view 视图
 @return 图片
 */
+ (nullable UIImage *)imageWithView:(nonnull UIView *)view;

/**
 截取某段图片

 @param rect 相对于原图的rect大小
 @return 截取到的新图片
 */
- (nullable UIImage *)subimageWithRect:(CGRect)rect;

+ (nullable UIImage *)animatedGIFWithData:(nonnull NSData *)data;

@end
