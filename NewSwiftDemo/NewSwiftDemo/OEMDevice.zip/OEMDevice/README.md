# MSDevice

[![CI Status](https://img.shields.io/travis/yanghy2013@163.com/MSDevice.svg?style=flat)](https://travis-ci.org/yanghy2013@163.com/MSDevice)
[![Version](https://img.shields.io/cocoapods/v/MSDevice.svg?style=flat)](https://cocoapods.org/pods/MSDevice)
[![License](https://img.shields.io/cocoapods/l/MSDevice.svg?style=flat)](https://cocoapods.org/pods/MSDevice)
[![Platform](https://img.shields.io/cocoapods/p/MSDevice.svg?style=flat)](https://cocoapods.org/pods/MSDevice)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

MSDevice is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'MSDevice'
```

## Author

yanghy2013@163.com, yanghy22@midea.com

## License

MSDevice is available under the MIT license. See the LICENSE file for more info.
