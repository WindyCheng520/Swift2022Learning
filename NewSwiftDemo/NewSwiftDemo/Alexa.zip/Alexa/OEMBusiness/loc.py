#!/usr/bin/python
#-*- coding: UTF-8 -*- 
import sys
import os

def oem_replaceLoc(src,dst):
  try:
      f1Path = "./Loc/%s.strings" %(src)
      f1 = open(f1Path,'r+')
  except IOError:
      print("File is not accessible ./Loc/%s.strings."%(src))
      return  
  f2Path = "./MSBusiness/Assets/strings/%s.lproj/Localizable.strings"  %(dst)
  os.remove(f2Path) 
  f2 = open(f2Path,'w+')
  for str in f1.readlines():
      res= str.replace("**","%@")
      f2.write(res)
  f1.close()
  f2.close()
  return

  
oem_replaceLoc("ar_SA","ar")
oem_replaceLoc("en_US","en")
oem_replaceLoc("ru_RU","ru")
oem_replaceLoc("zh_CN","zh-Hans-CN")
oem_replaceLoc("zh_HK","zh-Hant-HK")

