//
//  DeviceMemoryTempStatus.h
//  MSHome
//
//  Created by Neil 韦学宁 on 2021/12/14.
//

#import <Foundation/Foundation.h>
#import "MSDeviceStatusDefine.h"

NS_ASSUME_NONNULL_BEGIN

#define DDLogDeviceControlCenter(frmt, ...)       DDLogBusinessDebug(@"Device control:", frmt, ##__VA_ARGS__)

@interface DeviceControlCenter : NSObject

+ (instancetype)sharedInstance;

#pragma mark - ====== 状态管理 ======

//power
- (void)setTemporaryState:(NSString *)thingCode power:(MSDevicePowerStatus)power;
- (MSDevicePowerStatus)getTemporaryPowerStatusWithThingCode:(NSString *)thingCode;

#pragma mark - ====== 指令管理 ======

+ (NSDictionary *)switchControlParamWithIsOn:(BOOL)isOn;

@end

NS_ASSUME_NONNULL_END
