//
//  MSDevicePluginResult.h
//  MSHome
//
//  Created by pactera on 2020/7/24.
//

#import <Foundation/Foundation.h>
#import "BGFMDB.h"

@interface MSDevicePluginResult : NSObject<BGProtocol, NSCoding, NSCopying>

@property (nonatomic, copy) NSString *appType;      //升级包适用的硬件类型码
@property (nonatomic, copy) NSString *appModel;      //升级包型号码,目前使用sn8码。0代表使用所有型号码的通用包
@property (nonatomic, copy) NSString *imposed;   //强制升级标识，0（默认）：普通；1：强制

@property (nonatomic, copy) NSString *packageSize;      //包大小（单位KB）
@property (nonatomic, copy) NSString *title;      //
@property (nonatomic, copy) NSString *versionName;      //版本名称
@property (nonatomic, copy) NSString *versionCode;      //版本号
@property (nonatomic, copy) NSString *appEnterprise;      //升级包适用的企业码，对应家电企业码标识，默认为0000
@property (nonatomic, copy) NSString *configPurge;      //清除配置标识，0（默认）：不清除；1：清除
@property (nonatomic, copy) NSString *updateTime;      //更新时间
@property (nonatomic, copy) NSString *createTime;      //包上传时间


/******** (后台)json数据模型 begin *******/

@property (nonatomic, assign) BOOL needUpdate;
@property (nonatomic, copy) NSString *thingModel;
@property (nonatomic, copy) NSString *thingType;
@property (nonatomic, copy) NSString *appId;
@property (nonatomic, copy) NSString *md5;
@property (nonatomic, copy) NSString *size;
@property (nonatomic, copy) NSString *version;
@property (nonatomic, copy) NSString *des;      //版本描述
@property (nonatomic, copy) NSString *url;      //包下载地址

/******** (后台)json数据模型 end *******/


/********以下不是接口返回数据*******/
@property (nonatomic, copy) NSString *localAddress;   //插件包的本地地址
@property (nonatomic, copy) NSString *ignoreTimeString;   //忽略的时间字符串  yyMMdd
@property (nonatomic, assign) BOOL isSecurity; //1.3.0版本开始数据有加密操作，为了兼容旧版本添加此字段标识数据是否有加密


+ (MSDevicePluginResult *)encryptDevicePluginResultForLocal:(MSDevicePluginResult *)result;
+ (MSDevicePluginResult *)decryptDevicePluginResultForLocal:(MSDevicePluginResult *)result;
+ (void)saveDevicePluginResultToLocal:(MSDevicePluginResult *)result;
+ (MSDevicePluginResult *)getDeviceCardLocalPluginWithAppType:(NSString *)appType appModel:(NSString *)appModel;
+ (NSArray<MSDevicePluginResult *> *)getAllDevicePluginDataFromLocal;
+ (void)saveAllDevicePluginResultToLocal:(NSArray<MSDevicePluginResult *> *)resultArray;



@end

