//
//  MSDeviceCardResult.h
//  MSHome
//
//  Created by 及时行乐 on 2020/7/17.
//

#import <Foundation/Foundation.h>
#import "MSDevicePluginResult.h"
#import "MSDeviceStatusDefine.h"

@interface Home :NSObject

@property (nonatomic , copy) NSString *homeId;
@property (nonatomic , copy) NSString *roomId;

@end

@interface MSDeviceCardExtras: NSObject
@property(nonatomic ,copy) NSString * icon;
@property(nonatomic ,assign) NSInteger order;
@property(nonatomic ,copy) NSString * text;
@end

@interface Binder :NSObject
@property (nonatomic , copy) NSString *uid;
@property (nonatomic , assign) MSDeviceRelationType relType;      //是否本人设备 绑定关系，0：绑定的设备 ,1:分享的设备
@property (nonatomic , copy) NSString *createTime;

@end

@interface MSDeviceCardResult : NSObject<NSCoding, NSCopying>
@property (nonatomic, copy) NSString *thingCode;             //wifi模组mac地址  00:E0:4C:09:E0:DD
@property (nonatomic, copy) NSString *thingName;             //设备名称         空调
@property (nonatomic, copy) NSString *sn8;                   //家电型号(OEM 产品已无SN, SN8)         22073645
@property (nonatomic, copy) NSString *deviceType;            //设备品类         0xAC
@property (nonatomic, copy) NSString *firmwareVersion;       //固件版本         1.0.6
@property (nonatomic, copy) NSString *activeStatus;           //激活状态。0：未激活，1：已激活

@property (nonatomic, copy) NSString *uid;                    //家电关系中家电拥有者唯一标识
@property (nonatomic, assign) NSUInteger relType;                //是否本人设备

@property (nonatomic, strong) id online_server;
@property (nonatomic, strong) id power_server;

@property (nonatomic, assign) MSDeviceConnectedStatus onlineStatus;
@property (nonatomic, assign) MSDevicePowerStatus powerStatus;

@property (nonatomic, strong)Home *home;
@property (nonatomic, strong)Binder *binder;
@property (nonatomic, strong)NSArray<MSDeviceCardExtras *> *extras;

//功能标志
@property (nonatomic, assign) BOOL funcFlag; //是否支持蓝牙控制
//蓝牙连接校验随机字符串
@property (nonatomic, copy) NSString *randomStr;


//增动态控制指令，用于设备控制等
@property (nonatomic, copy) NSString *dynamicAttr;

@property (nonatomic, copy) NSString *deviceIcon;
@property (nonatomic, copy) NSString *online;
@property (nonatomic, copy) NSString *onlineIcon;
@property (nonatomic, copy) NSString *offlineIcon;
@property (nonatomic, copy) NSString *workingMode;
@property (nonatomic, copy) NSString *workingModeIcon;
@property (nonatomic, copy) NSString *currTemp;
@property (nonatomic, copy) NSString *taretTemp;
@property (nonatomic, copy) NSString *taretTempIcon;

@property (nonatomic, copy) NSString *deviceId;   //家电设备唯一标识

//@property (nonatomic, copy) NSString *type;    //家电类型

@property (nonatomic, copy) NSString *des;    //描述

@property (nonatomic, copy) NSString *name;    //家电名称
@property (nonatomic, copy) NSString *modelNumber;    //家电型号
@property (nonatomic, copy) NSString *sn;    //家电SN（加密状态）

@property (nonatomic, assign) int thingProtocol; //设备协议 1：存量设备  2：oem设备

//@property (nonatomic, copy) NSString *registerTime;
//@property (nonatomic, copy) NSString *userType;    //用户类型 1-单用户 2- 家庭用户 如果不是家庭用户 以下字段值为空
//@property (nonatomic, copy) NSString *homegroupId;//家庭唯一标识
//@property (nonatomic, copy) NSString *homegroupNumber;    //家庭number
//@property (nonatomic, copy) NSString *homegroupCreateUserId;    //家庭创建者唯一标识

/********以下不是接口返回数据*******/
//@property (nonatomic, copy) NSString *sn8;
@property (nonatomic, copy) NSString *imageUrlString;  //设备图片名称
@property (nonatomic, copy) NSString *imageDcpUrlString;   //设备品类对应的dcp图片url
@property (nonatomic, copy) MSDevicePluginResult *latestPlugin;    //该设备最新的插件包信息
@property (nonatomic, copy) MSDevicePluginResult *localPlugin;     //该设备本地的插件包信息
@property (nonatomic, assign) MSDeviceCardUpdateType updateType;
@property (nonatomic, assign) MSDeviceCardDownloadState downloadState;
@property (nonatomic, copy) NSString *progress;    //插件下载时的进度
@property (nonatomic, assign) MSDeviceAuthStatus deviceAuthStatus;




@property (nonatomic, assign) BOOL isSecurity;  //1.3.0版本开始数据有加密操作，为了兼容旧版本添加此字段标识数据是否有加密

+ (NSArray<MSDeviceCardResult *> *)getDeviceCardResultFromLocalWithTableName:(NSString *)tablename;
+ (void)clearDeviceCardResultFromLocalWithTableName:(NSString *)tablename;
+ (void)saveDeviceCardResultToLocal:(NSArray<MSDeviceCardResult *> *)resultArray tableName:(NSString *)tablename;


@end

