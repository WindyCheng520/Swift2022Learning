//
//  MSDeviceAuthStatusResult.m
//  MSBusiness
//
//  Created by pactera on 2020/11/26.
//

#import "MSDeviceAuthStatusResult.h"

@implementation MSDeviceAuthStatusResult

@end
