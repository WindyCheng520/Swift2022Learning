//  
//  MSDeviceConnectResult.h
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/11
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import <Foundation/Foundation.h>

@class MSDeviceAuthResult;
//配网方式枚举
typedef NS_ENUM(NSInteger, MSDeviceConnectType) {
    MSDeviceConnectTypeAP = 0,                    //AP
    MSDeviceConnectTypeHomeAutoFind,         //首页蓝牙自发现
    MSDeviceConnectTypeSelectAutoFind,           //选择家电类型页面，蓝牙自发现
    MSDeviceConnectTypeManualSelect,             //手动选择家电类型-型号配网
    MSDeviceConnectTypeScanCode,                 //扫码配网---品类(sn8)配网
    MSDeviceConnectTypeRetry                     //重试配网
};

//配网指引类型
typedef NS_ENUM(NSInteger, MSDeviceModeType) {
    MSDeviceModeTypeAP = 0,                      //AP指引
    MSDeviceModeTypeBluetooth = 3                //蓝牙指引
};


@interface MSDeviceConnectResult : NSObject

//接口属性
@property(nonatomic, copy) NSString *auxiConnectTypeDesc;
@property(nonatomic, copy) NSString *auxiConnectTypeUrl;
@property(nonatomic, copy) NSString *auxiMode;
@property(nonatomic, copy) NSString *category;
@property(nonatomic, copy) NSString *code;
@property(nonatomic, copy) NSString *isAutoConnect;
@property(nonatomic, copy) NSString *mainConnectTypeDesc;
@property(nonatomic, copy) NSString *mainConnectTypeUrl;
@property(nonatomic, copy) NSString *mainConnectTypeUrlB;
@property(nonatomic, copy) NSString *mainConnectTypeUrlC;
@property(nonatomic, copy) NSString *mode;  //0:AP配网  3:蓝牙配网
@property(nonatomic, copy) NSString *priLevel;
@property(nonatomic, copy) NSString *productId;
@property(nonatomic, copy) NSString *wifiFrequencyBand;

@property(nonatomic, copy) NSString *subCategory;  //子类


@property(nonatomic, copy) NSString *deviceId;       //绑定后后台分配的id

@property (nonatomic, copy) NSString *deviceName;    //品类(设备)名字

@property (nonatomic, copy) NSString *deviceMac;     //蓝牙mac地址

@property (nonatomic, copy) NSString *thingCode;      //wifi模块mac地址

@property (nonatomic, copy) NSString *deviceSn8;        //sn8

@property (nonatomic, copy) NSString *firmwareVersion;   //固件版本


@property (nonatomic, strong) MSDeviceAuthResult *authResult;   //指引


//其他传递属性
//登记的WiFi信息
@property (nonatomic, copy) NSString *wifiSsid;
@property (nonatomic, copy) NSString *wifiBssid;
@property (nonatomic, copy) NSString *wifiPassword;
//设备发出的wifi名称，AP配网使用
@property (nonatomic, copy) NSString *deviceSsid;
//设备的蓝牙对象，蓝牙配网使用
@property (nonatomic, strong) id peripheral;
//是否辅助配网, 手动选择配网方式根据这个标识来判断有没有尝试其他方式按钮配网
@property (nonatomic, assign) BOOL auxiing;
//设备配网过程中显示的图片，取选择家电类型时的图片url
@property (nonatomic, copy) NSString *deviceImageUrl;
//配网类型区分
@property (nonatomic, assign) MSDeviceConnectType deviceConnectType;
//是否已经是尝试其他方式, 自发现配网方式根据这个标识来判断有没有尝试其他方式按钮配网
@property (nonatomic, assign) BOOL isTryOther;

@property (nonatomic, assign)NSInteger retryCount;  //重试次数：两次  8分钟的广播只有AC和A1两种品类（限制两次），其它品类只能重试1次


@end
