//
//  MSDeviceAuthResult.m
//  MSDevice
//
//  Created by pactera on 2020/11/26.
//

#import "MSDeviceAuthResult.h"

@implementation MSDeviceAuthResult

+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{
             @"typeId" : @"id"
             };
}

@end
