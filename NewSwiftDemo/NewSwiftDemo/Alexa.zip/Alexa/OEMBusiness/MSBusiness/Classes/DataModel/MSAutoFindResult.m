//  
//  MSAutoFindResult.m
//  MSHome
//   
//  Created by 李 燕强 on 2020/7/24
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSAutoFindResult.h"
#import <MJExtension/MJExtension.h>
#import "MideaSecurity.h"

@implementation MSAutoFindResult

MJExtensionCodingImplementation

- (id)copyWithZone:(NSZone *)zone {
    id obj = [[[self class] allocWithZone:zone] init];
    [self.class mj_enumerateProperties:^(MJProperty *property, BOOL *stop) {
        id value = [self valueForKey:property.name];
        [obj setValue:value forKey:property.name];
    }];
    return obj;
}

+ (NSArray* _Nonnull)bg_uniqueKeys {
    return @[@"deviceSSID"];
}

+ (void)saveAllAutoFindResult:(NSArray<MSAutoFindResult *> *)resultArray {
    [MSAutoFindResult bg_clear:nil];
    
    if (resultArray.count > 0) {
        NSMutableArray *saveArray = [NSMutableArray array];
        for (MSAutoFindResult *resultItem in resultArray) {
            MSAutoFindResult *result = [resultItem copy];
            result.isSecurity = YES;
            result.deviceSN8 = [MideaSecurity saveSensitiveDataToLocal:result.deviceSN8];
            result.deviceSSID = [MideaSecurity saveSensitiveDataToLocal:result.deviceSSID];
            [saveArray addObject:result];
        }
        [MSAutoFindResult bg_saveOrUpdateArray:saveArray];
    }
}

+ (NSArray<MSAutoFindResult *> *)getTodayAllAutoFindResultWithTimeString:(NSString *)timeString {
    NSString* where = [NSString stringWithFormat:@"where %@>%@",bg_sqlKey(@"bg_updateTime"),bg_sqlValue(timeString)];
    NSArray <MSAutoFindResult *> *resultArray = [MSAutoFindResult bg_find:nil where:where];
    
    if (resultArray.count > 0) {
        for (MSAutoFindResult *result in resultArray) {
            if (result.isSecurity) {
                result.deviceSN8 = [MideaSecurity getSensitiveDataFromLocal:result.deviceSN8];
                result.deviceSSID = [MideaSecurity getSensitiveDataFromLocal:result.deviceSSID];
            }
        }
    }
    
    return resultArray;
}

+ (NSArray<MSAutoFindResult *> *)getAllAutoFindResultDataFromLocal {
    NSArray *resultArray = [MSAutoFindResult bg_findAll:nil];
    return resultArray;
}


@end
