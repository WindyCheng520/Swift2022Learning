//  
//  MSDeviceConnectResult.m
//  MSDevice
//   
//  Created by 李 燕强 on 2020/7/11
//  Copyright © 2020 Midea. All rights reserved.
//   
   

#import "MSDeviceConnectResult.h"

@implementation MSDeviceConnectResult

@end
