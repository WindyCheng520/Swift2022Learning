//
//  NSString+Toshiba.h
//  MSBusiness
//
//  Created by pactera on 2020/10/10.
//

#import <Foundation/Foundation.h>


@interface NSString (Toshiba)

- (BOOL)isContainEmoji;

//去除字符串中所带的表情
- (NSString *)disable_emoji;


@end

