//
//  MSLoginInfo.h
//  MSBusiness
//
//  Created by pactera on 2020/12/30.
//  存储登录相关信息

#import <Foundation/Foundation.h>


@interface MSLoginInfo : NSObject

//apple sign标志: 等于79代表该apple id 没绑定过邮箱
@property(nonatomic, copy) NSString *userFlag;


//强制升级配置：app 最低版本要求
@property (nonatomic, copy) NSString *versionCode;

//邮箱
@property (nonatomic, copy) NSString *email;

//用户唯一id
@property(nonatomic, copy) NSString *uid;

//用户令牌
@property(nonatomic, copy) NSString *accessToken;

//用户昵称
@property(nonatomic, copy) NSString *nickname;

//头像
@property(nonatomic, copy) NSString *headPhoto;

//电话号码
@property (nonatomic, copy) NSString *mobile;


+ (MSLoginInfo *)modelWithDic:(NSDictionary *)dic;
+ (MSLoginInfo *)getLoginInfoFromLocal;
+ (void)clearLoginInfoLocalData;
+ (void)saveLoginInfoToLocal:(MSLoginInfo *)loginInfo;

@end

