//
//  MSLoginInfo.m
//  MSBusiness
//
//  Created by pactera on 2020/12/30.
//

#import "MSLoginInfo.h"
#import "BGFMDB.h"
#import "MideaSecurity.h"
#import <MJExtension/MJExtension.h>

@implementation MSLoginInfo

MJExtensionCodingImplementation

- (id)copyWithZone:(NSZone *)zone {
    id obj = [[[self class] allocWithZone:zone] init];
    [self.class mj_enumerateProperties:^(MJProperty *property, BOOL *stop) {
        id value = [self valueForKey:property.name];
        [obj setValue:value forKey:property.name];
    }];
    return obj;
}

+ (MSLoginInfo *)modelWithDic:(NSDictionary *)dic {
    MSLoginInfo *loginInfo = [MSLoginInfo new];
    
    loginInfo.email = [dic objectForKey:@"email"];
    
    loginInfo.uid = [dic objectForKey:@"uid"];
    loginInfo.nickname = [dic objectForKey:@"nickName"];
    
    loginInfo.accessToken = [dic objectForKey:@"accessToken"];
    
    
    loginInfo.versionCode = [dic objectForKey:@"versionCode"];
    loginInfo.headPhoto = [dic objectForKey:@"headPhoto"];
    
    loginInfo.mobile = [dic objectForKey:@"mobile"];
    loginInfo.userFlag = [dic objectForKey:@"userFlag"];
    
    
    return loginInfo;
}

+ (MSLoginInfo *)getLoginInfoFromLocal {
    MSLoginInfo *loginInfo = [MSLoginInfo bg_firstObjet:nil];
    if (loginInfo) {
        
        
        loginInfo.headPhoto = [MideaSecurity getSensitiveDataFromLocal:loginInfo.headPhoto];
        loginInfo.versionCode = [MideaSecurity getSensitiveDataFromLocal:loginInfo.versionCode];
        loginInfo.email = [MideaSecurity getSensitiveDataFromLocal:loginInfo.email];
        loginInfo.accessToken = [MideaSecurity getSensitiveDataFromLocal:loginInfo.accessToken];
        loginInfo.uid = [MideaSecurity getSensitiveDataFromLocal:loginInfo.uid];
        loginInfo.nickname = [MideaSecurity getSensitiveDataFromLocal:loginInfo.nickname];
        loginInfo.mobile = [MideaSecurity getSensitiveDataFromLocal:loginInfo.mobile];
        loginInfo.userFlag = [MideaSecurity getSensitiveDataFromLocal:loginInfo.userFlag];
    }
    return loginInfo;
}

+ (void)clearLoginInfoLocalData {
    [MSLoginInfo bg_clear:nil];
}

+ (void)saveLoginInfoToLocal:(MSLoginInfo *)loginInfo {
    if (loginInfo) {
        
        loginInfo.email = [MideaSecurity saveSensitiveDataToLocal:loginInfo.email];
        loginInfo.accessToken = [MideaSecurity saveSensitiveDataToLocal:loginInfo.accessToken];
        loginInfo.uid = [MideaSecurity saveSensitiveDataToLocal:loginInfo.uid];
        loginInfo.nickname = [MideaSecurity saveSensitiveDataToLocal:loginInfo.nickname];
        loginInfo.headPhoto = [MideaSecurity saveSensitiveDataToLocal:loginInfo.headPhoto];
        loginInfo.versionCode = [MideaSecurity saveSensitiveDataToLocal:loginInfo.versionCode];
        loginInfo.mobile = [MideaSecurity saveSensitiveDataToLocal:loginInfo.mobile];
        loginInfo.userFlag = [MideaSecurity saveSensitiveDataToLocal:loginInfo.userFlag];
        
        [loginInfo bg_cover];
    }
}


@end
