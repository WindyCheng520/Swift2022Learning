//
//  MSUserInfoManager.h
//  MSBusiness
//
//  Created by pactera on 2020/12/29.
//  用户信息管理类

#import <Foundation/Foundation.h>
#import "MSUserInfoRepository.h"
#import "MSLoginInfo.h"

#define ISLOGIN [MSUserInfoManager shareManager].isLogin
@interface MSUserInfoManager : NSObject

@property (nonatomic, readonly) MSUserInfo *userInfoModel;
@property (nonatomic, readonly) MSLoginInfo *loginInfoModel;
@property (nonatomic, readonly) BOOL isLogin;
@property (nonatomic, readonly) BOOL isAppleSignIn;


+ (instancetype)shareManager;
- (void)updateUserInfoFromNetworkWithSuccess:(void(^)(void))success failure:(void(^)(MSBusinessError *error))failure;
- (void)clearUserInfoData;

- (void)saveLoginInfoDataWithModel:(MSLoginInfo *)loginInfo;
- (void)clearLoginInfoData;
- (void)updateLoginInfoMasAccessTokenWithAccessToken:(NSString *)accessToken;
//1.3.0之前的版本，登录信息是存在userdefault且没有加密，需要取出来加密存储
- (void)resultOldVersionLoginInfo;
//苹果登录相关
- (void)cleanAppleSignInInfo;
- (void)saveAppleSignInTagAndContext:(NSDictionary *)context;
- (NSDictionary *)AppleSignInContext;
- (NSString *)appleSignInEmail;

@end

