//
//  MSUserInfo.m
//  MSLogin
//
//  Created by 及时行乐 on 2020/7/13.
//

#import "MSUserInfo.h"
#import "BGFMDB.h"
#import "MideaSecurity.h"
#import <MJExtension/MJExtension.h>

@implementation MSUserInfo

+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"profile_pic_url":@"headPhoto", @"account":@"nickName"};
}

MJExtensionCodingImplementation

- (id)copyWithZone:(NSZone *)zone {
    id obj = [[[self class] allocWithZone:zone] init];
    [self.class mj_enumerateProperties:^(MJProperty *property, BOOL *stop) {
        id value = [self valueForKey:property.name];
        [obj setValue:value forKey:property.name];
    }];
    return obj;
}

+ (MSUserInfo *)getUserInfoFromLocal {
    MSUserInfo *userInfo = [MSUserInfo bg_firstObjet:nil];
    if (userInfo && userInfo.isSecurity) {
        userInfo.email = [MideaSecurity getSensitiveDataFromLocal:userInfo.email];
        userInfo.nickName = [MideaSecurity getSensitiveDataFromLocal:userInfo.nickName];
        userInfo.account = [MideaSecurity getSensitiveDataFromLocal:userInfo.account];
        userInfo.uid = [MideaSecurity getSensitiveDataFromLocal:userInfo.uid];
        
        userInfo.account_status = [MideaSecurity getSensitiveDataFromLocal:userInfo.account_status];
        userInfo.profile_pic_url = [MideaSecurity getSensitiveDataFromLocal:userInfo.profile_pic_url];
        userInfo.mobile = [MideaSecurity getSensitiveDataFromLocal:userInfo.mobile];
    }
    return userInfo;
}

+ (void)clearUserInfoLocalData {
    [MSUserInfo bg_clear:nil];
}

+ (void)saveUserInfoToLocal:(MSUserInfo *)userInfo {
    if (userInfo) {
        userInfo.isSecurity = YES;
        userInfo.email = [MideaSecurity saveSensitiveDataToLocal:userInfo.email];
        userInfo.nickName = [MideaSecurity saveSensitiveDataToLocal:userInfo.nickName];
        userInfo.account = [MideaSecurity saveSensitiveDataToLocal:userInfo.account];
        
      //  userInfo.account = [MideaSecurity saveSensitiveDataToLocal:userInfo.nickname];
        userInfo.uid = [MideaSecurity saveSensitiveDataToLocal:userInfo.uid];
        
        userInfo.account_status = [MideaSecurity saveSensitiveDataToLocal:userInfo.account_status];
        userInfo.profile_pic_url = [MideaSecurity saveSensitiveDataToLocal:userInfo.profile_pic_url];
        userInfo.mobile = [MideaSecurity saveSensitiveDataToLocal:userInfo.mobile];
        
        [userInfo bg_cover];
    }
}


@end


