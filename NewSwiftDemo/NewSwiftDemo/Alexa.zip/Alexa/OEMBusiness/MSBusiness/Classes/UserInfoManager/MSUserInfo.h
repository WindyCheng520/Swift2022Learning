//
//  MSUserInfo.h
//  MSLogin
//
//  Created by 及时行乐 on 2020/7/13.
//

#import <Foundation/Foundation.h>


@interface MSUserInfo : NSObject

@property (nonatomic, copy) NSString *mobile;
@property (nonatomic, copy) NSString *email;
@property (nonatomic, copy) NSString *nickName;
@property (nonatomic, copy) NSString *account;
@property (nonatomic, copy) NSString *uid;
@property (nonatomic, copy) NSString *account_status;



@property (nonatomic, copy) NSString *profile_pic_url;

@property (nonatomic, assign) BOOL isSecurity;  //1.3.0版本开始数据有加密操作，为了兼容旧版本添加此字段标识数据是否有加密

+ (MSUserInfo *)getUserInfoFromLocal;
+ (void)saveUserInfoToLocal:(MSUserInfo *)userInfo;
+ (void)clearUserInfoLocalData;



@end

