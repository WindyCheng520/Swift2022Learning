//
//  MSUserInfoRepository.h
//  MSBusiness
//
//  Created by pactera on 2020/12/29.
//

#import <Foundation/Foundation.h>
#import "MSBusinessError.h"
#import "MSUserInfo.h"


typedef void(^MSUserInfoRepositoryFailureBlock)(MSBusinessError *error);
typedef void(^MSUserInfoRepositoryUserInfoSuccess)(MSUserInfo *result);

@interface MSUserInfoRepository : NSObject

//获取用户个人信息
+ (void)getUserInfoWithSuccess:(MSUserInfoRepositoryUserInfoSuccess)success failure:(MSUserInfoRepositoryFailureBlock)failure;

@end

