//
//  MSBusinessError.h
//  MSBusiness
//
//  Created by syp on 2020/6/30.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MSBusinessError : NSObject

@property (nonatomic, readonly, copy) NSString *localizedDescription;
@property (nonatomic, readonly, copy) NSErrorDomain domain;
@property (nonatomic, readonly, assign) NSInteger code;
@property (nonatomic, readonly, copy) NSDictionary<NSErrorUserInfoKey, id> *userInfo;

+ (instancetype)errorWithNetwork:(NSError *)networkingError;
+ (instancetype)errorWithDomain:(NSErrorDomain)domain code:(NSInteger)code;
+ (instancetype)errorWithDomain:(NSErrorDomain)domain code:(NSInteger)code localizedDescription:(NSString *)localizedDescription;
+ (instancetype)errorWithDomain:(NSErrorDomain)domain code:(NSInteger)code userInfo:(NSDictionary<NSErrorUserInfoKey,id> *)dict;

- (instancetype)initWithDomain:(NSErrorDomain)domain code:(NSInteger)code userInfo:(NSDictionary<NSErrorUserInfoKey,id> *)dict;

- (NSError *)NSError;

//网络未连接时的提示文案
+ (NSString *)networkDisconnectTips;

@end

NS_ASSUME_NONNULL_END
