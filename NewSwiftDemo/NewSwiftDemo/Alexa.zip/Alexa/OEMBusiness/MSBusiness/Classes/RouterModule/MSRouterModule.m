//
//  MSRouterModule.m
//  MSRouterModule
//
//  Created by yanghy on 2019/10/12.
//

#import "MSRouterModule.h"
#import <DolphinRouter/OEMRouter.h>
#import "MideaTool.h"
#import <SSZipArchive/SSZipArchive.h>
#import "SSZipArchive+Extension.h"
#import "MSBLEManager.h"
#import "MSLocationManager.h"
#import "NSObject+BGModel.h"
//#import <MSmartOverseaSDK/MSmartSDK.h>
#import "MSAppInfo.h"
#import "MSUserDefaultTools.h"
#import "MSNotificationConst.h"
#import "MSPrivacyManager.h"
#import "MSUserInfoManager.h"
#import "AuthorizationManager.h"
#import "MSUserDefaultTools.h"
#import "MSRouterUrl.h"
#import <OEMLogger/OEMLogger-Swift.h>
#import <MSBusiness/MSBusiness-Swift.h>
#import "BusinessRequestManager.h"

#define MSRouterModuleVerifyToken @"MSRouterModuleVerifyToken"

@DOFModule(MSRouterModule)
@interface MSRouterModule()<OEMModuleProtocol>

@property (nonatomic, unsafe_unretained) UIBackgroundTaskIdentifier taskId;
@property (nonatomic, strong) NSTimer *timer;

@end

@implementation MSRouterModule

- (NSInteger)modulePriority {
    return 100;
}

- (void)modInit:(OEMContext *)context {
    
#if AppStore_ENV == 1
    [OEMOCLog initLogWithConsoleEnable:NO];
#else
    [OEMOCLog initLogWithConsoleEnable:YES];
#endif
    
    //处理bundle中的weex文件
    [self copyRNBundleToDocuments];
    
    //初始化蓝牙管理类
    //[MSBLEManager shareManager];
    
    //初始化地理位置管理类
    /*
    if (@available (iOS 13.0,*)) {
        [MSLocationManager shareManager];
    }
     */
    
    //初始化数据库
    [self loadDB];
    
    //初始化埋点管理类
    
    //处理旧版本的登录存储数据
    //[[MSUserInfoManager shareManager] resultOldVersionLoginInfo];
    
    //初始化SDK
    //[self slkLoadFinish];
    
    //获取用户信息
    //[self updateUserInfo];
    
    [BusinessRequestManager sharedInstance].delegate = [BusinessNetworkImpl sharedInstance];
    
    //添加通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginSuccess:) name:kMideaLoginSuccessNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginOutSuccess:) name:kMideaQuitLoginNotification object:nil];
    
    //获取Alexa 相关信息
    [[AuthorizationManager sharedManager] fetchJumpInfo:^(BOOL success, MSBusinessError * _Nonnull error) {
        
    }];
}

- (void)modDidEnterBackground:(OEMContext *)context {
    DDLogBusinessInfo(@"---进入后台----");
    
    if (@available(iOS 13.0, *)) {
        return;
    }
    self.taskId = [context.application beginBackgroundTaskWithExpirationHandler:^(void) {
        //当申请的后台时间用完的时候调用这个block
        //此时我们需要结束后台任务，
        [self endTask];
    }];
    // 模拟一个长时间的任务 Task
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(longTimeTask:) userInfo:nil repeats:YES];
}
 
- (void)endTask {
    if (_timer != nil || _timer.isValid ) {
        [_timer invalidate];
        _timer = nil;
        //结束后台任务
        [[UIApplication sharedApplication] endBackgroundTask:_taskId];
        _taskId = UIBackgroundTaskInvalid;
        DDLogBusinessInfo(@"停止计时");
    }
}

- (void)longTimeTask:(NSTimer *)timer {
    NSTimeInterval time = [[UIApplication sharedApplication] backgroundTimeRemaining];
    DDLogBusinessInfo(@"系统留给的我们的时间 = %.02f Seconds", time);
}

- (void)modDidBecomeActive:(OEMContext *)context {
    DDLogBusinessInfo(@"---活跃状态----");
    [self endTask];
    
    if ([MSUserInfoManager shareManager].isLogin) {
        return; //暂时屏蔽
        [[MSPrivacyManager shareManager] checkPrivacyUpdate];
    }
}

- (void)modContinueUserActivity:(OEMContext *)context {
    DDLogBusinessInfo(@"从其他APP跳转到OEM");
    if ([context.userActivityItem.userActivityType isEqualToString:NSUserActivityTypeBrowsingWeb]) {
        NSURL *url = context.userActivityItem.userActivity.webpageURL;
        if ([[AuthorizationManager sharedManager] canHandleURL:url]) {
            [[AuthorizationManager sharedManager] handleURL:url];
        } else {
           // [[AuthorizationManager sharedManager] showAppUpdateAlertView];
        }
    }
        
}

//注释掉会引起fackbook 无法跳转回来。
//- (id)modOpenURL:(OEMContext *)context{
//    return @(YES);
//}

- (void)copyRNBundleToDocuments {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSString *appDir = [MideaTool getDocumentDirectoryPathComponent:@"Plugins"];
        NSArray *weexNames = @[
            MSReactNativeInnerModule_usehelp,
            MSReactNativeInnerModule_settings,
            MSReactNativeInnerModule_profile,
            MSReactNativeInnerModule_guide,
            MSReactNativeInnerModule_mydevice,
            MSReactNativeInnerModule_otaupdate,
        ];
        [weexNames enumerateObjectsUsingBlock:^(NSString *fileName, NSUInteger idx, BOOL * _Nonnull stop) {
            NSString * fullPath = [@"RNResource" stringByAppendingPathComponent:fileName];
            NSString * zipPath = [[NSBundle mainBundle] pathForResource:fullPath ofType:@"zip"];
            NSString * zipfileMD5 = [MideaTool getFileMD5WithPath:zipPath];
            NSString * persistenToken = [fileName stringByAppendingString:MSRouterModuleVerifyToken];
            NSString * lastMd5HLStr = [[NSUserDefaults standardUserDefaults] objectForKey:persistenToken];
            if (lastMd5HLStr == nil) {
                //安装后，首次打开不需要校验md5
                lastMd5HLStr = zipfileMD5;
            }
            
            [MideaTool copyFileFromResourceTOSandbox:fullPath type:@"zip"];
            NSString * documentFilePath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
            documentFilePath = [documentFilePath stringByAppendingFormat:@"/%@.zip", fileName];
            BOOL success = [SSZipArchive unzipWithZip:documentFilePath toPath:appDir];
            DDLogBusinessInfo(@"拷贝ReactNative文件%@ %@", fileName, success ? @"成功" : @"失败");
            [self saveCurrentWeexInfo:zipfileMD5 fileName:persistenToken];
            
            if ([zipfileMD5 isEqualToString:lastMd5HLStr]) {
                //fullPath加上RNResource前缀
            }
        }];
    });
    
}



- (void)saveCurrentWeexInfo:(NSString *)mdstring fileName:(NSString *)fileName {
    [[NSUserDefaults standardUserDefaults] setObject:mdstring forKey:fileName];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)loadDB {
#if AppStore_ENV==0
    bg_setDebug(YES);//打开调试模式,打印输出调试信息.
#endif
    bg_setSqliteName(@"IoLife");
}

/*
- (void)slkLoadFinish {
    MSmartSystemManager *msmartManager = [MSmartSystemManager sharedManager];
    [[MSmartDeviceManager sharedManager] enableSSIDFormatWithFormatArray:@[@"toshiba"]];
    [msmartManager initSDKWithAppID:[MSAppInfo getAppId] appKey:[MSAppInfo appKey] workMode:MSmartWorkModeFriend extraDic:nil];
    [msmartManager initHttpWithServerhost:[MSAppInfo mucBaseUrl] httpSignSecret:[MSAppInfo mucSignSecret] httpSignKey:[MSAppInfo getMasKey] enableSSLPinning:NO extraDic:nil];
        
    if ([MSAppInfo appTarget] == MSAppTargetInhouse) {
        [msmartManager printLogEnable:YES];
    } else {
        [msmartManager printLogEnable:NO];
    }
    [msmartManager isLuaScriptCryptograph:YES];
    
    //初始化一次
    [msmartManager currentUid:[MSUserInfoManager shareManager].loginInfoModel.cloudUid];
    [msmartManager initLoginWithAccessToken:[MSUserInfoManager shareManager].loginInfoModel.masAccessToken dataKey:[MSUserInfoManager shareManager].loginInfoModel.cloudAccessToken dataIv:[MSUserInfoManager shareManager].loginInfoModel.cloudRandomData extraDic:nil];
}
*/
- (void)loginSuccess:(NSNotification *)notification {
//    MSmartSystemManager *msmartManager = [MSmartSystemManager sharedManager];
//    //登录后更新
//    [msmartManager currentUid:[MSUserInfoManager shareManager].loginInfoModel.cloudUid];
//    [msmartManager initLoginWithAccessToken:[MSUserInfoManager shareManager].loginInfoModel.masAccessToken dataKey:[MSUserInfoManager shareManager].loginInfoModel.cloudAccessToken dataIv:[MSUserInfoManager shareManager].loginInfoModel.cloudRandomData extraDic:nil];

    [self updateUserInfo];
    //获取Alexa 相关信息
    [[AuthorizationManager sharedManager] fetchJumpInfo:^(BOOL success, MSBusinessError * _Nonnull error) {
        
    }];
}

- (void)loginOutSuccess:(NSNotification *)notification {

    [MSUserDefaultTools saveAlexaTokenTimeToDisk:@""];
    [MSUserDefaultTools saveAlexaTokenToDisk:@""];
    [MSUserDefaultTools saveAlexaRefleshTokenToDisk:@""];
   // dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 需要延迟执行的代码
        [[MSUserInfoManager shareManager] clearUserInfoData];
        [[MSUserInfoManager shareManager] clearLoginInfoData];
   // });
}

- (void)updateUserInfo {
    [[MSUserInfoManager shareManager] updateUserInfoFromNetworkWithSuccess:^{
        
    } failure:^(MSBusinessError *error) {
        
    }];
}

@end
