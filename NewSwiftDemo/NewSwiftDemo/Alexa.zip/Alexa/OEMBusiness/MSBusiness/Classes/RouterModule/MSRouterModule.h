//
//  MSRouterModule.h
//  MSRouterModule
//
//  Created by yanghy on 2019/10/12.
//

#import <Foundation/Foundation.h>


@interface MSRouterModule : NSObject

@end

