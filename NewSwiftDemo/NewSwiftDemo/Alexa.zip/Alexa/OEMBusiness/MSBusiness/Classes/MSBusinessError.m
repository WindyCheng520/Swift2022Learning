//
//  MSBusinessError.m
//  MSBusiness
//
//  Created by syp on 2020/6/30.
//

#import "MSBusinessError.h"
#import "MSBusinessBundle.h"


NSString * const OEMNetworkingErrorDomain = @"OEMNetworkingErrorDomain";

@interface MSBusinessError ()

@property (nonatomic, copy) NSErrorDomain domain;
@property (nonatomic, assign) NSInteger code;
@property (nonatomic, copy) NSDictionary<NSErrorUserInfoKey, id> *userInfo;

@end

@implementation MSBusinessError

+ (instancetype)errorWithNetwork:(NSError *)networkError
{
    NSString *localizedDescription;
    if (networkError.code == 999999 ||
        networkError.code == 13  ||
        networkError.code == -1009  ||
        networkError.code == -1001) {
        localizedDescription = MSResourceString(@"network_disconnect_tip");
    } else if ([networkError.localizedDescription isEqualToString:@"网络错误"] && [networkError.localizedDescription isEqualToString:@"网络未连接，请检查你的网络设置"]) {
        localizedDescription = MSResourceString(@"network_disconnect_tip");
    } else {
        localizedDescription = networkError.localizedDescription;
    }
    if (!localizedDescription) {
        localizedDescription = MSResourceString(@"Unknow Net Error");
    }
    
    return [MSBusinessError errorWithDomain:OEMNetworkingErrorDomain
                                      code:networkError.code
                                  userInfo:@{NSLocalizedDescriptionKey : localizedDescription}];
}

+ (instancetype)errorWithDomain:(NSErrorDomain)domain code:(NSInteger)code;
{
    return [MSBusinessError errorWithDomain:domain code:code userInfo:nil];
}

+ (instancetype)errorWithDomain:(NSErrorDomain)domain code:(NSInteger)code localizedDescription:(NSString *)localizedDescription
{
    if (localizedDescription.length > 0) {
        return [MSBusinessError errorWithDomain:domain code:code userInfo:@{NSLocalizedDescriptionKey : localizedDescription}];
    } else {
        return [MSBusinessError errorWithDomain:domain code:code userInfo:nil];
    }
}

+ (instancetype)errorWithDomain:(NSErrorDomain)domain code:(NSInteger)code userInfo:(NSDictionary<NSErrorUserInfoKey,id> *)dict
{
    return [[[self class] alloc] initWithDomain:domain code:code userInfo:dict];
}

- (instancetype)initWithDomain:(NSErrorDomain)domain code:(NSInteger)code userInfo:(NSDictionary<NSErrorUserInfoKey,id> *)dict
{
//    self = [super initWithDomain:domain code:code userInfo:dict];
    self = [super init];
    if (self) {
        self.domain = domain;
        self.code = code;
        self.userInfo = dict;
    }
    return self;
}

- (NSError *)NSError
{
    NSError *error = [[NSError alloc] initWithDomain:self.domain code:self.code userInfo:self.userInfo];
    return error;
}

+ (NSString *)networkDisconnectTips {
    return MSResourceString(@"network_disconnect_tip");
}


- (NSString *)localizedDescription
{
    return [self.userInfo objectForKey:NSLocalizedDescriptionKey];
}


- (NSString *)description {
    return [NSString stringWithFormat:@"domain=%@, code=%ld, userInfo=%@", self.domain, (long)self.code, self.userInfo];
}

@end
