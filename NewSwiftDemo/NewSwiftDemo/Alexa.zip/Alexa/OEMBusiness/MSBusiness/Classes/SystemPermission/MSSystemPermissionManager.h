//
//  MSSystemPermissionManager.h
//  MSBusiness
//
//  Created by pactera on 2020/9/2.
//

#import <Foundation/Foundation.h>


@interface MSSystemPermissionManager : NSObject

+ (instancetype)shareManager;


- (void)showCameraPermissionAlert;

- (void)showPhotoPermissionAlert;

//跳转系统设置页面
- (void)jumpToSystemSettingPage;

//跳转系统设置中APP的设置页面
- (void)jumpToSystemAppSettingPage;

//跳转到App Store
- (void)jumpToAppStore;

@end

