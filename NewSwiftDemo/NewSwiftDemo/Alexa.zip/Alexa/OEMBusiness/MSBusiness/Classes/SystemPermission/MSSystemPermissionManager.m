//
//  MSSystemPermissionManager.m
//  MSBusiness
//
//  Created by pactera on 2020/9/2.
//  系统权限相关

#import "MSSystemPermissionManager.h"
#import <OEMFoundation/HGAlertController.h>
#import "MSBusinessBundle.h"
#import <OEMTheme/OEMHGAlertController.h>
#import "MSAppInfo.h"

static NSString *const MSAppStoreLink = @"itms-apps://itunes.apple.com/app/id1535414457";

@interface MSSystemPermissionManager ()

@end

@implementation MSSystemPermissionManager

+ (instancetype)shareManager {
    static MSSystemPermissionManager *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[MSSystemPermissionManager alloc] init];
    });
    return manager;
}

- (void)showCameraPermissionAlert {
    HGAlertAction* cancelAction = [HGAlertAction actionWithTitle:MSResourceString(@"authorization_alert_cancel") style:HGAlertActionStyleCancel action:nil];
    HGAlertAction* settingAction = [HGAlertAction actionWithTitle:MSResourceString(@"authorization_to_setting") action:^{
        //跳转到app的系统设置页面
        NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
        if([[UIApplication sharedApplication] canOpenURL:url]) {
            [[UIApplication sharedApplication] openURL:url];
        }
    }];
    NSString * title = [NSString stringWithFormat:MSResourceString(@"authorization_camera_request_title"), [MSAppInfo appName]];
    HGAlertController* alertController = [OEMHGAlertController alertControllerWithTitle:title message:MSResourceString(@"authorization_camera_request_message") actions:@[cancelAction, settingAction]];
    [alertController show];
    
}

- (void)showPhotoPermissionAlert {
    HGAlertAction* cancelAction = [HGAlertAction actionWithTitle:MSResourceString(@"authorization_alert_cancel") style:HGAlertActionStyleCancel action:nil];
    HGAlertAction* settingAction = [HGAlertAction actionWithTitle:MSResourceString(@"authorization_to_setting") action:^{
        //跳转到app的系统设置页面
        NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
        if([[UIApplication sharedApplication] canOpenURL:url]) {
            [[UIApplication sharedApplication] openURL:url];
        }
    }];
    HGAlertController* alertController = [OEMHGAlertController alertControllerWithTitle:MSResourceString(@"authorization_album_request_title") message:MSResourceString(@"authorization_album_request_message") actions:@[cancelAction, settingAction]];
    [alertController show];
    
}

//跳转系统设置页面首页
- (void)jumpToSystemSettingPage {
    NSURL *url = [NSURL URLWithString:[self settingWifiUrlString]];
    if([[UIApplication sharedApplication] canOpenURL:url]) {
        if (@available(iOS 10.0, *)) {
            [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
        } else {
            [[UIApplication sharedApplication] openURL:url];
        }
    }
}

- (NSString *)settingWifiUrlString {
    NSString *wifiUrl = nil;
    NSData *wifiData= nil;
    if (@available(iOS 10.0, *)) {
        unsigned char wifiBytes[] = {0x41 ,0x78 ,0x78 ,0x70 ,0x63 ,0x63 ,0x70 ,0x78 ,0x63 ,0x2d ,0x50 ,0x63 ,0x78 ,0x72 ,0x63 ,0x63 ,0x78 ,0x78 ,0x65 ,0x63 ,0x66 ,0x63 ,0x73 ,0x63 ,0x3a ,0x63 ,0x72 ,0x63 ,0x6f ,0x78 ,0x78 ,0x6f ,0x78 ,0x74 ,0x78 ,0x3d ,0x63 ,0x57 ,0x78 ,0x49 ,0x78 ,0x46 ,0x63 ,0x49 ,0x78 ,0x78};
        wifiData = [NSData dataWithBytes:wifiBytes length:ARRAY_SIZE(wifiBytes)];
    } else {
        unsigned char wifiBytes[] = {0x70 ,0x78 ,0x78 ,0x63 ,0x63 ,0x72 ,0x78 ,0x78 ,0x65 ,0x63 ,0x66 ,0x73 ,0x3a ,0x72 ,0x78 ,0x78 ,0x6f ,0x6f ,0x78 ,0x78 ,0x74 ,0x3d ,0x63 ,0x63 ,0x78 ,0x57 ,0x63 ,0x49 ,0x78 ,0x78 ,0x63 ,0x46 ,0x63 ,0x49 ,0x78 ,0x78 ,0x63 ,0x63 ,0x78};
        wifiData = [NSData dataWithBytes:wifiBytes length:ARRAY_SIZE(wifiBytes)];
    }
    NSString *wifiString = [[NSString alloc] initWithData:wifiData encoding:NSASCIIStringEncoding];
    wifiString= [wifiString stringByReplacingOccurrencesOfString:@"c" withString:@""];
    wifiUrl = [wifiString stringByReplacingOccurrencesOfString:@"x" withString:@""];

    return wifiUrl;
}

//跳转系统设置中APP的设置页面
- (void)jumpToSystemAppSettingPage {
    NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
    if([[UIApplication sharedApplication] canOpenURL:url]) {
        if (@available(iOS 10.0, *)) {
            [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
        } else {
            [[UIApplication sharedApplication] openURL:url];
        }
    }
}

//跳转到App Store
- (void)jumpToAppStore {
    NSURL *url = [NSURL URLWithString:MSAppStoreLink];
    if (@available(iOS 10.0, *)) {
        [[UIApplication sharedApplication]openURL:url options:@{UIApplicationOpenURLOptionsSourceApplicationKey:@YES} completionHandler:nil];
     } else {
        [[UIApplication sharedApplication]openURL:url];
     }
}


@end
