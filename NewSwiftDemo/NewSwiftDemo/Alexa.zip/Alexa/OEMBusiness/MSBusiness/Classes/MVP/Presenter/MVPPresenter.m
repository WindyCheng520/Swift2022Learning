//
//  HGBasePresenter.m
//  OEMFoundation
//
//  Created by syp on 2020/6/21.
//

#import "MVPPresenter.h"


@implementation MVPPresenter

- (instancetype)initWithView:(id<MVPViewProtocol>)view
{
    self = [super init];
    if (self) {
        [self attachView:view];
    }
    return self;
}

- (void)attachView:(id<MVPViewProtocol>)view
{
    _view = view;
}

- (void)deattachView
{
    _view = nil;
}

- (void)load
{
    
}

- (void)unload
{
    
}

@end
