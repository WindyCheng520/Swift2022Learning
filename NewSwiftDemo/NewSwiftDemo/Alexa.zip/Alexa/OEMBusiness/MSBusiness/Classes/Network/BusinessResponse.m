//
//  MSResponse.m
//  MSBusiness
//
//  Created by syp on 2020/6/22.
//

#import "BusinessResponse.h"

@implementation BusinessResponse

- (BOOL)isOK
{
    return self.code == 0;
}

@end
