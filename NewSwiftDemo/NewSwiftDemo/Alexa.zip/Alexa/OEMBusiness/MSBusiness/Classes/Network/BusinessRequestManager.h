//
//  MSRequestManager.h
//  MSBusiness
//
//  Created by syp on 2020/6/17.
//

#import "BusinessRequest.h"
#import "BusinessRequestDefines.h"

@interface BusinessRequestManager : NSObject

+ (instancetype _Nullable )sharedInstance;

@property (nonatomic, strong) NSString * _Nullable baseURL;

@property (nonatomic, weak) id _Nullable delegate;

/**
 清除指定本地的网络缓存数据

 @param urlString 网络请求的url，删除该urlString下所有的缓存（无视parameters参数）
 */
- (void)clearRequestCache:(NSString *_Nullable)urlString;

/**
 清除指定本地的网络缓存数据
 @param urlString 网络请求的url
 @param identifier 该次请求的唯一表示id，比如楼盘id、个人信息id （可以不写，则删除该urlString下所有的缓存（无视parameters参数））
 */
- (void)clearRequestCache:(NSString *_Nullable)urlString identifier:(NSString *_Nullable)identifier;

/**
 清除所有本地的网络缓存数据
 */
- (void)clearAllCache;

- (NSURLSessionTask *_Nullable)uploadWithURLString:(NSString *_Nullable)URLString
                                        parameters:(NSDictionary *_Nullable)parameters
                                   uploadIntercept:(BusinessRequestUploadIntercept _Nullable)uploadIntercept
                                          progress:(BusinessRequestManagerProgress _Nullable)progress
                                           success:(BusinessRequestManagerSuccess _Nullable )success
                                           failure:(BusinessRequestManagerFailure _Nullable )failure;

- (NSURLSessionDataTask *_Nullable)requestMethod:(BusinessRequestMethod)method
                                       URLString:(NSString *_Nullable)URLString
                                        httpBody:(NSData * _Nullable)httpBody
                                         request:(BusinessRequest *_Nullable)request
                                      httpHeader:(NSDictionary * _Nullable)httpHeader
                                           cache:(BusinessRequestManagerCache _Nullable )cache
                                         success:(BusinessRequestManagerSuccess _Nullable )success
                                         failure:(BusinessRequestManagerFailure _Nullable )failure;

- (NSURLSessionDataTask *_Nullable)requestMethod:(BusinessRequestMethod)method
                                       URLString:(NSString *_Nullable)URLString
                                      parameters:(NSDictionary *_Nullable)parameters
                                           cache:(BusinessRequestManagerCache _Nullable )cache
                                         success:(BusinessRequestManagerSuccess _Nullable )success
                                         failure:(BusinessRequestManagerFailure _Nullable )failure;

- (NSURLSessionDataTask *_Nullable)GET:(NSString *_Nullable)URLString
                            parameters:(NSDictionary *_Nullable)parameters
                                 cache:(BusinessRequestManagerCache _Nullable )cache
                               success:(BusinessRequestManagerSuccess _Nullable )success
                               failure:(BusinessRequestManagerFailure _Nullable )failure;

- (NSURLSessionDataTask *_Nullable)POST:(NSString *_Nullable)URLString
                             parameters:(NSDictionary *_Nullable)parameters
                                  cache:(BusinessRequestManagerCache _Nullable )cache
                                success:(BusinessRequestManagerSuccess _Nullable )success
                                failure:(BusinessRequestManagerFailure _Nullable )failure;

- (void)commonRequestWithMethod:(BusinessRequestMethod)method
                      URLString:(NSString *_Nullable)URLString
                       httpBody:(NSData * _Nullable)httpBody
                        request:(BusinessRequest *_Nullable)request
                     httpHeader:(NSDictionary * _Nullable)httpHeader
                          cache:(BusinessRequestManagerCache _Nullable )cache
                        success:(BusinessRequestManagerSuccess _Nullable )success
                        failure:(BusinessRequestManagerFailure _Nullable )failure;

- (void)commonGetWithURLString:(NSString *_Nullable)URLString
                        request:(BusinessRequest *_Nullable)request
                     httpHeader:(NSDictionary * _Nullable)httpHeader
                          cache:(BusinessRequestManagerCache _Nullable )cache
                        success:(BusinessRequestManagerSuccess _Nullable )success
                        failure:(BusinessRequestManagerFailure _Nullable )failure;


// 字典转string {"key1":"value1", "key2":"value2"} => "key1=value1&key2=value2"
- (NSString *_Nullable)serializeParams:(NSDictionary *_Nullable)params;

//获取随机数方法
- (NSString *_Nullable)createRandomString;

- (void)configureToBAuthInfo:(NSString * _Nonnull)clientSecret
                    clientId:(NSString * _Nonnull)clientId
                 accessToken:(NSString * _Nullable)accessToken;

@end
