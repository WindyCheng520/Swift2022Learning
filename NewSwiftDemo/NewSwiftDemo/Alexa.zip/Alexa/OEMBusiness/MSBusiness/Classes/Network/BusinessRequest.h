//
//  BusinessRequest.h
//  MSBusiness
//
//  Created by Neil 韦学宁 on 2022/1/21.
//

#import <Foundation/Foundation.h>
#import "BusinessRequestDefines.h"

NS_ASSUME_NONNULL_BEGIN

@interface BusinessRequest : NSObject

@property (nonatomic, assign)NSTimeInterval requestTimeout;

@property (nonatomic, assign)BusinessSignType signType;

@end


@interface BusinessUploadItem : NSObject

@property (nonatomic, copy)NSString * name;
@property (nonatomic, copy)NSString * fileName;
@property (nonatomic, copy)NSString * mimeType;
@property (nonatomic, copy)NSString * fileURL;

@end

NS_ASSUME_NONNULL_END
