//
//  BusinessRequestDefines.h
//  Pods
//
//  Created by Neil 韦学宁 on 2022/2/15.
//


#ifndef BusinessRequestDefines_h
#define BusinessRequestDefines_h

/// 网络请求方法
typedef NS_ENUM(NSInteger, BusinessRequestMethod) {
    BusinessRequestMethodGet = 0, // 通常用于请求服务器发送某个资源，服务器返回的数据可能是缓存数据
    BusinessRequestMethodHead,    // 与GET方法的行为很类似，但服务器在响应中只返回首部。不会反回实体的主体部分
    BusinessRequestMethodPost,    // 起初是用来向服务器写入数据的，也可以提交表单，也可以请求获取某个资源数据
    BusinessRequestMethodPut,     // 与GET方法从服务器读取文档相反，PUT方法会向服务器写入文档
    BusinessRequestMethodPatch,   // PATCH 用于资源的部分内容的更新
    BusinessRequestMethodDelete,  // DELETE方法所做的事情就是请服务器删除请求URL所指定的资源。
};

typedef NS_ENUM(NSInteger, BusinessSignType) {
    BusinessSignType_OEM = 0,
    BusinessSignType_ToB,
};

@class BusinessUploadItem;

NS_ASSUME_NONNULL_BEGIN
typedef void(^BusinessRequestManagerCache)(id responseObject);
typedef void(^BusinessRequestManagerSuccess)(NSURLSessionTask * _Nullable httpbase, id responseObject);
typedef void(^BusinessRequestManagerFailure)(NSURLSessionTask * _Nullable httpbase, NSError * error);
typedef BusinessUploadItem *_Nullable(^BusinessRequestUploadIntercept)(void);
typedef void(^BusinessRequestManagerProgress)(NSProgress *progress);
NS_ASSUME_NONNULL_END

#endif /* BusinessRequestDefines_h */

