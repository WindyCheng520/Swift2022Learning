//
//  OEMBaseSDK.m
//  MSBusiness
//
//  Created by Neil 韦学宁 on 2022/3/16.
//

#import "OEMBaseSDK.h"
#import <OEMLogger/OEMOCLog.h>
#import <OEMFoundation/HGInternationalization.h>
#import <MSBusiness/MSBusiness-Swift.h>

@interface OEMBaseSDK()

@property (nonatomic, strong)OEMSDKConfig * defaultConfig;

@end

@implementation OEMBaseSDK

+ (instancetype)sharedInstance{
    static OEMBaseSDK * sdk = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sdk = [[OEMBaseSDK alloc] init];
    });
    return sdk;
}

+ (void)initSDKWithConfig:(OEMSDKConfig *)config{
    [OEMBaseSDK sharedInstance].defaultConfig = config;
    
    if (config.enableFileLog) {
        [OEMOCLog initLogWithConsoleEnable:config.enableConsoleLog];
    }
    
    if (config.countryCode.length > 0){
        HGCountry * c = HGCurrentCountry;
        c.code = config.countryCode;
        HGCurrentCountry = c;
    }
    
    if (config.language.length > 0){
        HGLanguage * l = HGCurrentLanguage;
        l.code = config.language;
        HGCurrentLanguage = l;
    }
}

@end
