//
//  OEMBaseSDK.h
//  MSBusiness
//
//  Created by Neil 韦学宁 on 2022/3/16.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class OEMSDKConfig;

@interface OEMBaseSDK : NSObject

+ (void)initSDKWithConfig:(OEMSDKConfig *)config;

@end

NS_ASSUME_NONNULL_END
