//
//  MSBLEOpenAlertView.h
//  MSBusiness
//
//  Created by midea on 2021/4/1.
//

#import <UIKit/UIKit.h>


@interface MSBLEOpenAlertView : UIView

- (void)showWithSuperview:(UIView *)superview;
- (void)dismiss;

@end

