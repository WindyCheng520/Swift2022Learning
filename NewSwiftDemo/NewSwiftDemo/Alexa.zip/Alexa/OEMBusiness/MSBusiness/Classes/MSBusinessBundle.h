//
//  MSBusinessBundle.h
//  MSBuniness
//
//  Created by syp on 2020/6/17.
//

#import <OEMFoundation/OEMBundle.h>
#import <OEMFoundation/HGLocalizationResource.h>

#define MSCurrentBundle [MSBusinessBundle currentBundle]

#define MSResourceString(key) [HGLocalizationResource localizedStringForKey:key table:nil inBundle:MSCurrentBundle]
#define MSResourceImage(imageName) [HGLocalizationResource localizedImageForImageName:imageName inBundle:MSCurrentBundle]

@interface MSBusinessBundle : OEMBundle

@end

