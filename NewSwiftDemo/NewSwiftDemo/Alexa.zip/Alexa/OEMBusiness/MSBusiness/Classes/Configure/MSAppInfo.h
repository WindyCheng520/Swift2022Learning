//
//  MSAppInfo.h
//  MSBusiness
//
//  Created by syp on 2020/6/28.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, MSAppEnvironmentType) {
    MSAppEnvironmentTypeDev,
    MSAppEnvironmentTypePro
};

@interface MSAppInfo : NSObject

+ (MSAppEnvironmentType)environmentType;

+ (NSString *)verifyAESKey;

+ (NSString *)mucBaseUrl;

+ (NSString *)mucProductionBaseUrl;

//aws 节点
+ (NSString *)awsEndPoint;

//当前语言code
+ (NSString *)currentLanguageCode;

//国家码
+ (NSString *)countryCode;

//是否支持apple sign（是否企业证书的bundle id)
+ (BOOL )isAppleSignEnable;

+ (NSString *)mucSignSecret;

+ (NSString *)appKey;

+ (NSString *)getAppId;

+ (NSString *)getMasKey;

//本地数据 HMACSha256加密的secret
+ (NSString *)hmacSha256SecretForLocalData;

+ (NSMutableDictionary *)getCommonData;

+ (NSString *)getEvnPrefix;

+ (NSString *)appName;

+ (NSString *)appVersion;

+ (NSString *)appShortVersion;

+ (NSString *)bundleIdentifier;

+ (nullable NSString *)msClientId;

+ (nullable NSString *)msClientSecret;

@end

