//
//  OEMBussineMineService.h
//  MSBusiness
//
//  Created by zhongch18 on 2022/2/24.
//

#import <Foundation/Foundation.h>
#import <DolphinRouter/OEMRouterBaseService.h>
NS_ASSUME_NONNULL_BEGIN

@interface OEMBussineMineService : OEMRouterBaseService


@end

NS_ASSUME_NONNULL_END
