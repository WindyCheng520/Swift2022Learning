//
//  AuthorizationResult.h
//  MSBusiness
//
//  Created by pactera on 2021/2/22.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSErrorDomain const MSBusinessAuthorizationErrorDomain;

@interface AuthorizationResult : NSObject

@property (nonatomic, copy) NSString *code;
@property (nonatomic, copy) NSString *state;
@property (nonatomic, copy) NSString *redirect_uri;

@end

