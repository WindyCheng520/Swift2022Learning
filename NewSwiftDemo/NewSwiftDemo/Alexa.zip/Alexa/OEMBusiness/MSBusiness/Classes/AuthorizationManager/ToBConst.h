//
//  ToBConst.h
//  MSBusiness
//
//  Created by zhongch18 on 2022/2/28.
//

#ifndef ToBConst_h
#define ToBConst_h
#define kOEMDidGetToBAccessTokenNotification @"kOEMDidGetToBAccessTokenNotification"
#define kOEMMSmartNetAccessClientIDKey @"OEMMSmartNetAccessClientIDKey"
#define kOEMMSmartNetAccessClientSecretKey @"OEMMSmartNetAccessClientSecretKey"
#define kOEMMSmartNetAccessHostKey @"OEMMSmartNetAccessHostKey"
#define kOEMMSmartNetAccessUidKey @"OEMMSmartNetAccessUidKey"
#define kOEMMSmartNetAccessCountryCodeKey @"OEMMSmartNetAccessCountryCodeKey"
#define kOEMMSmartNetAccessAuthDataKey @"OEMMSmartNetAccessAuthDataKey"

#endif /* ToBConst_h */
