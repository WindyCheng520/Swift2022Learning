//
//  AuthorizationCell.h
//  MSBusiness
//
//  Created by pactera on 2021/2/6.
//

#import <OEMFoundation/HGTableViewCell.h>

NS_ASSUME_NONNULL_BEGIN

@interface AuthorizationCell : HGTableViewCell

- (void)refreshTitle:(NSString *)title;
+ (CGFloat)cellHeightWithTitle:(NSString *)title maxWidth:(CGFloat)maxWidth;

@end

NS_ASSUME_NONNULL_END
