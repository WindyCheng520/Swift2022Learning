//
//  BusinessSwiftBridge.h
//  MSBusiness
//
//  Created by Neil 韦学宁 on 2022/3/9.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

//swift类调OC类，OC类中再调swift会导致编译失败，所以此类仅暴露给Swift使用，不能在此类中调用Swift代码

@interface BusinessSwiftBridge : NSObject

+ (instancetype)sharedInstance;

+ (void)handleAutoLogin:(os_block_t)block;

@end

NS_ASSUME_NONNULL_END
