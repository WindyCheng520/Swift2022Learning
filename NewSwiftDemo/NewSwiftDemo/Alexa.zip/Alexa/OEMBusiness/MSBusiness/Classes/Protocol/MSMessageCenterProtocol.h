//
//  MSMessageCenterProtocol.h
//  MSBusiness
//
//  Created by caiws on 2020/8/11.
//

#ifndef MSMessageCenterProtocol_h
#define MSMessageCenterProtocol_h

#import <DolphinRouter/OEMServiceProtocol.h>
#import "MSBusinessError.h"

@protocol MSMessageCenterProtocol <OEMServiceProtocol>

@optional
///获取消息列表
- (NSArray *)fetchMessageList;

///删除某条消息
- (BOOL)deleteMessageWithMessageID:(NSString *)messageID;

///清空消息
- (BOOL)clearMessage;

/// 更新消息内容
- (BOOL)updateMessage:(NSDictionary *)params;

/// 获取消息数
//- (NSInteger)unreadMessageCount;

- (void)unreadMessageCountSuccess:(void (^)(NSInteger count))success;


/// 清空云端pushToken
- (void)emptyFirebasePushToken;


/// 扫码接受设备分享
- (void)acceptDeviceShareWithRequestCode:(NSString *)requestCode
                                 success:(void (^)(void))success
                                 failure:(void (^)(MSBusinessError *error))failure;

//绑定token
- (void)bindPushToken:(NSString *)pushToken
              success:(void (^)(void))success
              failure:(void (^)(MSBusinessError *error))failure;


@end

#endif /* MSMessageCenterProtocol_h */
