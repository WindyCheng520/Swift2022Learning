//
//  MSMeProtocol.h
//  MSBusiness
//
//  Created by pactera on 2020/7/28.
//

#ifndef MSMeProtocol_h
#define MSMeProtocol_h

#import <DolphinRouter/OEMServiceProtocol.h>

@protocol MSMeProtocol <OEMServiceProtocol>

@optional
- (NSDictionary *)getLocalUserInfo;

- (void)getUserInfoWithSuccess:(void(^)(NSString* successCallBack))successCallBack fail:(void(^)(NSString* failCallBack))failCallBack;

- (void)uploadLog:(void (^)(BOOL isSuccess, NSDictionary * data, NSError * error))completion progressBlock:(void (^)(float p) )progressBlock;

@end

#endif /* MSMeProtocol_h */
