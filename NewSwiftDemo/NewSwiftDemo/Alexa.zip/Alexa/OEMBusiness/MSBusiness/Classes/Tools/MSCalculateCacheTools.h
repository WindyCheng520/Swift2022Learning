//
//  MSCalculateCacheTools.h
//  MSBusiness
//
//  Created by pactera on 2020/8/18.
//

#import <Foundation/Foundation.h>


@interface MSCalculateCacheTools : NSObject

//获取指定文件/文件夹路径下的所有文件大小
+ (void)getCacheFileSize:(NSString *)directoryPath completion:(void (^)(float size))completion;

//清除指定文件路径下的所有内容
+ (void)clearCacheWithDirectoryPath:(NSString *)directoryPath completion:(void (^)(void))completion;

@end

