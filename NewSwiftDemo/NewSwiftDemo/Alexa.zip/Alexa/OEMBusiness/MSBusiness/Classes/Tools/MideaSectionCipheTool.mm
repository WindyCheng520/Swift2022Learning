//
//  MideaSectionCipheTool.m
//  BHBusiness
//
//  Created by IoT熊思 on 2019/12/9.
//

#import "MideaSectionCipheTool.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <iostream>



using namespace std;

class OEMCipherSec
{
public:
    OEMCipherSec();
    virtual ~OEMCipherSec();
    unsigned char* Cipher(unsigned char* input);
    unsigned char* InvCipher(unsigned char* input);

    //aesº”√‹ Ω‚√‹
    void* Cipher(void* input, int length = 0);
    void* InvCipher(void* input, int length);

    //base64º”Ω‚√‹∫Ø ˝
    int base64Encode(const uint8_t* bindata, char* base64, int binlength);
    int base64Decode(const uint8_t* bindata, char* base64, int binlength);

    //switchº”√‹Ω‚√‹
    void swtichCalc(char* output, char* input);
    void reswtichCalc(char* output, char* input);

    void initAesKey(unsigned char* key);
    char* generateKey();

    char* getCiphertext();
    
    char* decode(char *encode_data,char *output);
    char* encode(char *src_data,char *output);
    

    //√‹≥◊ŒÔ¡œ
    //base64±‡¬Î±Ì
    char base_table[64] = {0};
    //≥ı º√‹≥◊
    unsigned char initialKey[17] = "rockykaikainihao";
    //ÃÊªª±Ì
    char switchTable[32] = { 8, 9, 10,11,
                             28,29,30,31,
                             0 ,1, 2, 3,
                             16,17,18,19,
                             12,13,14,15,
                             24,25,26,27,
                             20,21,22,23,
                             4 ,5 ,6 ,7
    };
    //base64±‰–Œ±‡¬Î±Ìµƒ√‹Œƒ
    //char keyMaterial[45] = "qbmJrwdMrJ5PqwxIqJYLr28OsbtHq2qKrbfNsw1Gqbm=";
    char keyMaterial[45] = "rw04qMdIsdu4jbuiscCKybZJg3T4yJybf3GOUUdFqfq=";


private:
    unsigned char Sbox[256];
    unsigned char InvSbox[256];
    unsigned char w[11][4][4];


    void KeyExpansion(unsigned char* key, unsigned char w[][4][4]);
    unsigned char FFmul(unsigned char a, unsigned char b);

    void SubBytes(unsigned char state[][4]);
    void ShiftRows(unsigned char state[][4]);
    void MixColumns(unsigned char state[][4]);
    void AddRoundKey(unsigned char state[][4], unsigned char k[][4]);

    void InvSubBytes(unsigned char state[][4]);
    void InvShiftRows(unsigned char state[][4]);
    void InvMixColumns(unsigned char state[][4]);

};




extern void print_array(char *name,unsigned char *array,int size);
OEMCipherSec::OEMCipherSec(){}

OEMCipherSec::~OEMCipherSec(){}

void OEMCipherSec::initAesKey(unsigned char* key) {
    //AES魔改算法版本 sBox
    unsigned char sBox[] = {
        0x28, 0xC2, 0xE8, 0x57, 0x48, 0x24, 0x97, 0xC5, 0x18, 0x8C, 0x9B, 0x72, 0xF7, 0x99, 0xDE, 0xD3,
        0x85, 0x58, 0x7A, 0x0B, 0x44, 0xD1, 0xB0, 0x47, 0xC7, 0xAE, 0xF0, 0x6D, 0x53, 0xE1, 0x60, 0xB4,
        0x4B, 0x5C, 0x10, 0x52, 0x01, 0x39, 0xB9, 0x90, 0xAB, 0x00, 0xD4, 0x73, 0x64, 0x32, 0x9F, 0xA1,
        0x6A, 0x1C, 0x6B, 0x21, 0xF1, 0xEF, 0x3F, 0x67, 0x95, 0xF2, 0x79, 0xE0, 0x0C, 0xD0, 0x66, 0x7F,
        0x2C, 0xC3, 0x12, 0x5A, 0x34, 0xEB, 0x15, 0xA6, 0xBC, 0x7D, 0xA0, 0xB8, 0x55, 0x49, 0xC1, 0xFB,
        0xE9, 0x08, 0x3C, 0xE2, 0x56, 0x2F, 0x30, 0x9E, 0x0E, 0xCB, 0x25, 0xE3, 0x46, 0x5D, 0xEC, 0x4C,
        0x09, 0xBE, 0x87, 0x04, 0x89, 0xD8, 0x19, 0x3D, 0x71, 0x40, 0x7E, 0x5F, 0x16, 0x7B, 0x3A, 0x27,
        0x43, 0x76, 0x45, 0x8A, 0x35, 0x96, 0xF9, 0x07, 0x8F, 0x0F, 0x54, 0xCF, 0xBA, 0x38, 0x83, 0xCE,
        0x2A, 0xAC, 0x68, 0xF4, 0x80, 0x31, 0xA4, 0xFE, 0x93, 0xB3, 0x7C, 0xCA, 0xB6, 0x75, 0xDA, 0xA8,
        0xD7, 0xB1, 0x37, 0xC4, 0x6C, 0x6F, 0xD5, 0x4F, 0x23, 0x14, 0x98, 0xAA, 0xDC, 0x65, 0x74, 0x42,
        0xC8, 0x41, 0x8D, 0xA5, 0x22, 0xEA, 0x4D, 0xB5, 0x17, 0x02, 0x1E, 0x88, 0x91, 0x33, 0xC6, 0x78,
        0x3B, 0x2D, 0xD9, 0xFC, 0x1B, 0x9A, 0xCD, 0xE6, 0x1F, 0xED, 0x92, 0x29, 0x4A, 0xFA, 0x1A, 0xEE,
        0x0D, 0xE7, 0x63, 0x8E, 0xFF, 0x06, 0x3E, 0x1D, 0xF8, 0xAD, 0xE5, 0x36, 0x05, 0x70, 0xA2, 0x69,
        0x84, 0xBF, 0xA9, 0x8B, 0x03, 0xD6, 0x26, 0x2E, 0x82, 0x62, 0x81, 0xE4, 0x94, 0xA7, 0xAF, 0x5E,
        0x9D, 0xD2, 0xB2, 0x86, 0x2B, 0x51, 0xCC, 0xDD, 0x13, 0xF5, 0x77, 0x50, 0xC0, 0xB7, 0x0A, 0x59,
        0x4E, 0xC9, 0xBB, 0x11, 0xA3, 0x6E, 0xDB, 0xF6, 0x61, 0x9C, 0x20, 0xDF, 0xFD, 0xBD, 0x5B, 0xF3,
    };

    ////AES魔改算法版本rsbox
    unsigned char invsBox[256] = {
        0x29, 0x24, 0xA9, 0xD4, 0x63, 0xCC, 0xC5, 0x77, 0x51, 0x60, 0xEE, 0x13, 0x3C, 0xC0, 0x58, 0x79,
        0x22, 0xF3, 0x42, 0xE8, 0x99, 0x46, 0x6C, 0xA8, 0x08, 0x66, 0xBE, 0xB4, 0x31, 0xC7, 0xAA, 0xB8,
        0xFA, 0x33, 0xA4, 0x98, 0x05, 0x5A, 0xD6, 0x6F, 0x00, 0xBB, 0x80, 0xE4, 0x40, 0xB1, 0xD7, 0x55,
        0x56, 0x85, 0x2D, 0xAD, 0x44, 0x74, 0xCB, 0x92, 0x7D, 0x25, 0x6E, 0xB0, 0x52, 0x67, 0xC6, 0x36,
        0x69, 0xA1, 0x9F, 0x70, 0x14, 0x72, 0x5C, 0x17, 0x04, 0x4D, 0xBC, 0x20, 0x5F, 0xA6, 0xF0, 0x97,
        0xEB, 0xE5, 0x23, 0x1C, 0x7A, 0x4C, 0x54, 0x03, 0x11, 0xEF, 0x43, 0xFE, 0x21, 0x5D, 0xDF, 0x6B,
        0x1E, 0xF8, 0xD9, 0xC2, 0x2C, 0x9D, 0x3E, 0x37, 0x82, 0xCF, 0x30, 0x32, 0x94, 0x1B, 0xF5, 0x95,
        0xCD, 0x68, 0x0B, 0x2B, 0x9E, 0x8D, 0x71, 0xEA, 0xAF, 0x3A, 0x12, 0x6D, 0x8A, 0x49, 0x6A, 0x3F,
        0x84, 0xDA, 0xD8, 0x7E, 0xD0, 0x10, 0xE3, 0x62, 0xAB, 0x64, 0x73, 0xD3, 0x09, 0xA2, 0xC3, 0x78,
        0x27, 0xAC, 0xBA, 0x88, 0xDC, 0x38, 0x75, 0x06, 0x9A, 0x0D, 0xB5, 0x0A, 0xF9, 0xE0, 0x57, 0x2E,
        0x4A, 0x2F, 0xCE, 0xF4, 0x86, 0xA3, 0x47, 0xDD, 0x8F, 0xD2, 0x9B, 0x28, 0x81, 0xC9, 0x19, 0xDE,
        0x16, 0x91, 0xE2, 0x89, 0x1F, 0xA7, 0x8C, 0xED, 0x4B, 0x26, 0x7C, 0xF2, 0x48, 0xFD, 0x61, 0xD1,
        0xEC, 0x4E, 0x01, 0x41, 0x93, 0x07, 0xAE, 0x18, 0xA0, 0xF1, 0x8B, 0x59, 0xE6, 0xB6, 0x7F, 0x7B,
        0x3D, 0x15, 0xE1, 0x0F, 0x2A, 0x96, 0xD5, 0x90, 0x65, 0xB2, 0x8E, 0xF6, 0x9C, 0xE7, 0x0E, 0xFB,
        0x3B, 0x1D, 0x53, 0x5B, 0xDB, 0xCA, 0xB7, 0xC1, 0x02, 0x50, 0xA5, 0x45, 0x5E, 0xB9, 0xBF, 0x35,
        0x1A, 0x34, 0x39, 0xFF, 0x83, 0xE9, 0xF7, 0x0C, 0xC8, 0x76, 0xBD, 0x4F, 0xB3, 0xFC, 0x87, 0xC4,
    };
    memcpy(Sbox, sBox, 256);
    memcpy(InvSbox, invsBox, 256);
    KeyExpansion(key, w);
}

unsigned char* OEMCipherSec::Cipher(unsigned char* input){
    unsigned char state[4][4];
    int i, r, c;

    for (r = 0; r < 4; r++){
        for (c = 0; c < 4; c++){
            state[r][c] = input[c * 4 + r];
        }
    }

    AddRoundKey(state, w[0]);

    for (i = 1; i <= 10; i++){
        SubBytes(state);
        ShiftRows(state);
        if (i != 10)MixColumns(state);
        AddRoundKey(state, w[i]);
    }

    for (r = 0; r < 4; r++){
        for (c = 0; c < 4; c++){
            input[c * 4 + r] = state[r][c];
        }
    }

    return input;
}

unsigned char* OEMCipherSec::InvCipher(unsigned char* input)
{
    unsigned char state[4][4];
    int i, r, c;

    for (r = 0; r < 4; r++){
        for (c = 0; c < 4; c++){
            state[r][c] = input[c * 4 + r];
        }
    }

    AddRoundKey(state, w[10]);
    for (i = 9; i >= 0; i--){
        InvShiftRows(state);
        InvSubBytes(state);
        AddRoundKey(state, w[i]);
        if (i)
        {
            InvMixColumns(state);
        }
    }

    for (r = 0; r < 4; r++){
        for (c = 0; c < 4; c++)
        {
            input[c * 4 + r] = state[r][c];
        }
    }

    return input;
}

/***********************************************************************************************
*函数名 : Cipher
*函数功能描述 : AES加密
*函数参数 : input-输入加密数据  length-加密数据长度
*函数返回值 : 无
*作者 : qijy
*函数创建日期 : 2019.9.19
*函数修改日期 : 尚未修改
*修改人 ：尚未修改
*修改原因 :  尚未修改
*版本 : 1.0
*历史版本 : 无
***********************************************************************************************/
void* OEMCipherSec::Cipher(void* input, int length){
    unsigned char* in = (unsigned char*)input;
    int i;
    if (!length){
        while (*(in + length++));
        in = (unsigned char*)input;
    }
    for (i = 0; i < length; i += 16){
        Cipher(in + i);
    }
    return input;
}

/***********************************************************************************************
*函数名 : InvCipher
*函数功能描述 : AES解密
*函数参数 : input-输入加密数据  length-加密数据长度
*函数返回值 : 无
*作者 : qijy
*函数创建日期 : 2019.9.19
*函数修改日期 : 尚未修改
*修改人 ：尚未修改
*修改原因 :  尚未修改
*版本 : 1.0
*历史版本 : 无
***********************************************************************************************/
void* OEMCipherSec::InvCipher(void* input, int length){
    unsigned char* in = (unsigned char*)input;
    int i;
    for (i = 0; i < length; i += 16){
        InvCipher(in + i);
    }
    return input;
}

/***********************************************************************************************
*函数名 : base64Encode
*函数功能描述 : base64加密
*函数参数 : bindata-base解密字符串  base64-加密字符串  binlength-加密字符串长度
*函数返回值 : 字符串长度
*作者 : qijy
*函数创建日期 : 2019.9.19
*函数修改日期 : 尚未修改
*修改人 ：尚未修改
*修改原因 :  尚未修改
*版本 : 1.0
*历史版本 : 无
***********************************************************************************************/
int OEMCipherSec::base64Encode(const uint8_t* bindata, char* base64, int binlength) {
    int i, j;
    uint8_t current;
    if (bindata == NULL)
        return 0;

    /*每次处理三个字符*/
    for (i = 0, j = 0; i < binlength; i += 3) {
        /*前6个bit 首先右移两位*/
        current = (bindata[i] >> 2);
        current &= (uint8_t)0x3F;//0x3F == 00111111 指定取后6位字节的数
        base64[j++] = base_table[(int)current];//switchTbale
        /*第一个字节的最后两个二进制*/
        current = ((uint8_t)(bindata[i] << 4)) & ((uint8_t)0x30);//0x30 == 00110000 指定取第3、4位字节的数
        if (i + 1 >= binlength) {//不足位的时候，自动补足
            base64[j++] = base_table[(int)current];
            base64[j++] = '='; //标准的不足补齐符号
            base64[j++] = '='; //标准的不足补齐符号
            break;
        }
        /*9~12bit, 并连接7~8bit*/
        current |= ((uint8_t)(bindata[i + 1] >> 4)) & ((uint8_t)0x0F);
        base64[j++] = base_table[(int)current];//switchTbale

        /*13~16bit*/
        current = ((uint8_t)(bindata[i + 1] << 2)) & ((uint8_t)0x3C);//0x3c == 00111100 取指定的第2、3、4、5位

        /*就此结尾*/
        if (i + 2 >= binlength) {
            base64[j++] = base_table[(int)current];
            base64[j++] = '='; //标准的不足补齐符号
            break;
        }

        /*17~18bit, 并连接13~16bit*/
        current |= ((uint8_t)(bindata[i + 2] >> 6)) & ((uint8_t)0x03);//0x3 == 00000011 取指定的第7、8位  后4位和前2位拼接
        base64[j++] = base_table[(int)current];//switchTbale

        /*19~24bit*/
        current = ((uint8_t)bindata[i + 2]) & ((uint8_t)0x3F);//0x3F == 00111111 取指定的第3、4、5、6、7、8
        base64[j++] = base_table[(int)current];//switchTbale
    }
    base64[j] = '\0';
    return j;
}

/***********************************************************************************************
*函数名 : base64Encode
*函数功能描述 : base64解密
*函数参数 : bindata-base加密字符串  base64-解密字符串  binlength-加密字符串长度
*函数返回值 : 字符串长度
*作者 : qijy
*函数创建日期 : 2019.9.19
*函数修改日期 : 尚未修改
*修改人 ：尚未修改
*修改原因 :  尚未修改
*版本 : 1.0
*历史版本 : 无
***********************************************************************************************/
int OEMCipherSec::base64Decode(const uint8_t* bindata, char* base64, int binlength)
{
    int i, j;
    uint8_t current;

    if (bindata == NULL)
        return 0;

    //4个字母为一组一起处理
    int mybindata[4];
    for (i = 0, j = 0; i < binlength; i += 4) {
        for (int h = 0; h < 64; h++){
            if (bindata[i] == base_table[h]){
                mybindata[0] = h;
                break;
            }
        }
        for (int h = 0; h < 64; h++){
            if (bindata[i + 1] == base_table[h])
            {
                mybindata[1] = h;
                break;
            }
        }
        for (int h = 0; h < 64; h++){
            if (bindata[i + 2] == base_table[h])
            {
                mybindata[2] = h;
                break;
            }
        }
        for (int h = 0; h < 64; h++){
            if (bindata[i + 3] == base_table[h]){
                mybindata[3] = h;
                break;
            }
        }


        current = (mybindata[0] << 2);
        current |= ((uint8_t)(mybindata[1] >> 4)) & ((uint8_t)0x03);
        base64[j++] = (char)current;


        current = (mybindata[1] << 4);
        current |= ((uint8_t)(mybindata[2] >> 2)) & ((uint8_t)0x0F);
        base64[j++] = (char)current;


        current = (mybindata[2] << 6);
        current |= ((uint8_t)(mybindata[3]));
        base64[j++] = (char)current;
    }


    if (bindata[binlength - 2] == '=') {
        base64[j - 1] = ' ';
        base64[j - 2] = ' ';
        base64[j - 2] = '\0';
        return j;


    }
    if (bindata[binlength - 1] == '=') {
        base64[j - 1] = ' ';
        base64[j - 1] = '\0';
        return j;
    }
    base64[j] = '\0';
    return j;
}

/***********************************************************************************************
*函数名 : generateKey
*函数功能描述 : 生成密匙
*函数参数 : input-输入密匙材料 output-输出密匙
*函数返回值 : 无
*作者 : qijy
*函数创建日期 : 2019.9.19
*函数修改日期 : 尚未修改
*修改人 ：尚未修改
*修改原因 :  尚未修改
*版本 : 1.0
*历史版本 : 无
***********************************************************************************************/
char* OEMCipherSec::generateKey() {
//base64编码表密文
char Ciphertext[1024] = {
    static_cast<char>(0x85),0x60,0x1D,static_cast<char>(0xB7),static_cast<char>(0x95),static_cast<char>(0xEE),static_cast<char>(0xED),0x3E,static_cast<char>(0xF3),0x3B,static_cast<char>(0xF8),static_cast<char>(0xE0),0x44,static_cast<char>(0xB2),0x30,static_cast<char>(0xC5),
    static_cast<char>(0xE4),0x5E,0x2E,static_cast<char>(0xF8),static_cast<char>(0xDC),static_cast<char>(0xB0),0xD, static_cast<char>(0xD9),static_cast<char>(0xAA),static_cast<char>(0xC9),static_cast<char>(0x8B),0xD, 0x67,0x5A,0x52,static_cast<char>(0xC9),
    static_cast<char>(0xAA),0x20,0x6C,0x2D,0x5,static_cast<char>(0xE6),static_cast<char>(0xA0),0x71,0x24,static_cast<char>(0xF9),static_cast<char>(0xDE),static_cast<char>(0xF0),static_cast<char>(0xE4),0x3,0x7E,static_cast<char>(0xFF),
    0x28,static_cast<char>(0xF3),static_cast<char>(0xB6),0x18,static_cast<char>(0xF3),static_cast<char>(0xA1),static_cast<char>(0x99),static_cast<char>(0xAF),static_cast<char>(0xED),static_cast<char>(0xCF),0x33,static_cast<char>(0xA8),static_cast<char>(0xEB),static_cast<char>(0x95),static_cast<char>(0x81),0x20
};
char* keyData = new char[33]{ 0 };
char* output = new char[128]{ 0 };


    //一、初始化AES key
    initAesKey(initialKey);
    //二、通过Key解密密文
    InvCipher((void*)Ciphertext, 65);
    //三、把解密后的base64码表，给与base64编码表，修改base标准编码表
    memcpy(base_table, Ciphertext, strlen(Ciphertext));

    //四、使用非标准的base64进行解密解密密钥
    char* debase64_str = (char*)calloc(1, 1024);
    base64Decode((const uint8_t*)keyMaterial, debase64_str, strlen(keyMaterial));
    debase64_str[32] = '\0';
    //五、使用替换算法将密匙打包分散重组形成新的密钥。
    swtichCalc(keyData, debase64_str);
    memcpy(output,keyData,strlen(keyData));


    //完成后释放内存
    free(debase64_str); debase64_str = nullptr;
    delete[] keyData; keyData = nullptr;
    return output;
}
char* OEMCipherSec::decode(char *encode_data,char *output){
    //base64编码表密文
    char Ciphertext[1024] = {
        static_cast<char>(0x85),0x60,0x1D,static_cast<char>(0xB7),static_cast<char>(0x95),static_cast<char>(0xEE),static_cast<char>(0xED),0x3E,static_cast<char>(0xF3),0x3B,static_cast<char>(0xF8),static_cast<char>(0xE0),0x44,static_cast<char>(0xB2),0x30,static_cast<char>(0xC5),
        static_cast<char>(0xE4),0x5E,0x2E,static_cast<char>(0xF8),static_cast<char>(0xDC),static_cast<char>(0xB0),0xD,static_cast<char>(0xD9),static_cast<char>(0xAA),static_cast<char>(0xC9),static_cast<char>(0x8B),0xD,0x67,0x5A,0x52,static_cast<char>(0xC9),
        static_cast<char>(0xAA),0x20,0x6C,0x2D,0x5,static_cast<char>(0xE6),static_cast<char>(0xA0),0x71,0x24,static_cast<char>(0xF9),static_cast<char>(0xDE),static_cast<char>(0xF0),static_cast<char>(0xE4),0x3,0x7E,static_cast<char>(0xFF),
        0x14,static_cast<char>(0xF6),static_cast<char>(0xA9),static_cast<char>(0xCC),static_cast<char>(0xD6),static_cast<char>(0xEF),static_cast<char>(0xF2),0xD,static_cast<char>(0xC2),0xD,0x37,static_cast<char>(0xDC),0x35,static_cast<char>(0xB3),0x7D,static_cast<char>(0xBB)
    };


    //一、初始化AES key
    initAesKey(initialKey);
    //二、通过Key解密密文
    InvCipher((void*)Ciphertext, 63);
    //三、把解密后的base64码表，给与base64编码表，修改base标准编码表
    memcpy(base_table, Ciphertext, strlen(Ciphertext));
    //四、使用非标准的base64进行解密解密密钥
    char* debase64_str = (char*)calloc(1, 102400);
    memset(debase64_str,0,102400);
    
    int len=base64Decode((const uint8_t*)encode_data, debase64_str, strlen(encode_data));
    //五、使用替换算法将密匙打包分散重组形成新的密钥。
    char* keyData = (char*)calloc(1, len+32);
    memset(keyData,0,len+32);
    int i=0;
    for(i=0;i<len;i+=32){
        swtichCalc(keyData+i, debase64_str+i);
    }
    memcpy(output,keyData,strlen(keyData));
    //完成后释放内存
    free(debase64_str);
    debase64_str = nullptr;
    free(keyData);
    keyData = nullptr;
    return output;
}

char* OEMCipherSec::encode(char *src_data,char *output){
    //base64编码表密文
    char Ciphertext[1024] = {
        static_cast<char>(0x85),0x60,0x1D,static_cast<char>(0xB7),static_cast<char>(0x95),static_cast<char>(0xEE),static_cast<char>(0xED),0x3E,static_cast<char>(0xF3),0x3B,static_cast<char>(0xF8),static_cast<char>(0xE0),0x44,static_cast<char>(0xB2),0x30,static_cast<char>(0xC5),
        static_cast<char>(0xE4),0x5E,0x2E,static_cast<char>(0xF8),static_cast<char>(0xDC),static_cast<char>(0xB0),0xD,static_cast<char>(0xD9),static_cast<char>(0xAA),static_cast<char>(0xC9),static_cast<char>(0x8B),0xD,0x67,0x5A,0x52,static_cast<char>(0xC9),
        static_cast<char>(0xAA),0x20,0x6C,0x2D,0x5,static_cast<char>(0xE6),static_cast<char>(0xA0),0x71,0x24,static_cast<char>(0xF9),static_cast<char>(0xDE),static_cast<char>(0xF0),static_cast<char>(0xE4),0x3,0x7E,static_cast<char>(0xFF),
        0x14,static_cast<char>(0xF6),static_cast<char>(0xA9),static_cast<char>(0xCC),static_cast<char>(0xD6),static_cast<char>(0xEF),static_cast<char>(0xF2),0xD,static_cast<char>(0xC2),0xD,0x37,static_cast<char>(0xDC),0x35,static_cast<char>(0xB3),0x7D,static_cast<char>(0xBB)
    };


    //一、初始化AES key
    initAesKey(initialKey);
    //二、通过Key解密密文
    InvCipher((void*)Ciphertext, 63);
    //三、把解密后的base64码表，给与base64编码表，修改base标准编码表
    memcpy(base_table, Ciphertext, strlen(Ciphertext));
    
    int new_len=strlen(src_data)+32;
    char* new_src = (char*)calloc(1, new_len);
    memset(new_src,0,new_len);
    strcpy(new_src,src_data);
    char* keyData = (char*)calloc(1, new_len);
    memset(keyData,0,new_len);
    int i=0;
    for(i=0;i<strlen(new_src);i+=32){
        reswtichCalc(keyData+i, new_src+i);
    }
    free(new_src);
    new_src = nullptr;
    //四、使用非标准的base64进行解密解密密钥
    char* base64_str = (char*)calloc(1, 102400);
    memset(base64_str,0,102400);
    
    for(i=new_len-1;i>0;i--){
        if(keyData[i]!=0){
            break;
        }
    }
    int len=base64Encode((const uint8_t*)keyData, base64_str, i+1);
    //五、使用替换算法将密匙打包分散重组形成新的密钥。
    
    memcpy(output,base64_str,strlen(base64_str));


    //完成后释放内存
    free(base64_str);
    base64_str = nullptr;
    free(keyData);
    keyData = nullptr;
    return output;
}



/***********************************************************************************************
*函数名 : swtichCalc
*函数功能描述 : 置换算法
*函数参数 : input-输入密匙材料 output-输出密匙
*函数返回值 : 无
*作者 : qijy
*函数创建日期 : 2019.9.19
*函数修改日期 : 尚未修改
*修改人 ：尚未修改
*修改原因 :  尚未修改
*版本 : 1.0
*历史版本 : 无
***********************************************************************************************/
void OEMCipherSec::swtichCalc(char* output, char* input) {
    int n = 32;
    int i;
    for (i = 0; i < n; i++) {
        switch (i)
        {
        case 0:
            output[switchTable[i]] = input[i]; break;
        case 1:
            output[switchTable[i]] = input[i] ^ 1; break;// ^
        case 2:
            output[switchTable[i]] = input[i]; break;
        case 3:
            output[switchTable[i]] = input[i] + 3; break; // +
        case 4:
            output[switchTable[i]] = input[i]; break;
        case 5:
            output[switchTable[i]] = input[i] ^ 5; break;// ^
        case 6:
            output[switchTable[i]] = input[i]; break;
        case 7:
            output[switchTable[i]] = input[i] - 7; break; // -
        case 8:
            output[switchTable[i]] = input[i]; break;
        case 9:
            output[switchTable[i]] = input[i] ^ 9; break;// ^
        case 10:
            output[switchTable[i]] = input[i]; break;
        case 11:
            output[switchTable[i]] = input[i] + 11; break;// +
        case 12:
            output[switchTable[i]] = input[i]; break;
        case 13:
            output[switchTable[i]] = input[i] ^ 13; break;// ^
        case 14:
            output[switchTable[i]] = input[i]; break;
        case 15:
            output[switchTable[i]] = input[i] - 15; break;// -
        case 16:
            output[switchTable[i]] = input[i]; break;
        case 17:
            output[switchTable[i]] = input[i] ^ 17; break;// ^
        case 18:
            output[switchTable[i]] = input[i]; break;
        case 19:
            output[switchTable[i]] = input[i] + 19; break;// +
        case 20:
            output[switchTable[i]] = input[i]; break;
        case 21:
            output[switchTable[i]] = input[i] ^ 21; break;// ^
        case 22:
            output[switchTable[i]] = input[i]; break;
        case 23:
            output[switchTable[i]] = input[i] - 29; break;// -
        case 24:
            output[switchTable[i]] = input[i]; break;
        case 25:
            output[switchTable[i]] = input[i] ^ 25; break;// ^
        case 26:
            output[switchTable[i]] = input[i]; break;
        case 27:
            output[switchTable[i]] = input[i] + 27; break;// +
        case 28:
            output[switchTable[i]] = input[i]; break;
        case 29:
            output[switchTable[i]] = input[i] ^ 29; break;// ^
        case 30:
            output[switchTable[i]] = input[i]; break;
        case 31:
            output[switchTable[i]] = input[i] - 31; break;// -
        default:
            break;
        }
    }
}

/***********************************************************************************************
*函数名 : reswtichCalc
*函数功能描述 : 逆置换算法
*函数参数 : input-输入密匙材料 output-输出密匙
*函数返回值 : 无
*作者 : qijy
*函数创建日期 : 2019.9.19
*函数修改日期 : 尚未修改
*修改人 ：尚未修改
*修改原因 :  尚未修改
*版本 : 1.0
*历史版本 : 无
***********************************************************************************************/
void OEMCipherSec::reswtichCalc(char* output, char* input) {
    int n = 32;
    int i;

    for (i = 0; i < n; i++) {
        switch (i)
        {
        case 0:
            output[i] = input[switchTable[i]]; break;
        case 1:
            output[i] = input[switchTable[i]] ^ 1; break;// ^
        case 2:
            output[i] = input[switchTable[i]]; break;
        case 3:
            output[i] = input[switchTable[i]] - 3; break; // +
        case 4:
            output[i] = input[switchTable[i]]; break;
        case 5:
            output[i] = input[switchTable[i]] ^ 5; break;// ^
        case 6:
            output[i] = input[switchTable[i]]; break;
        case 7:
            output[i] = input[switchTable[i]] + 7; break; // -
        case 8:
            output[i] = input[switchTable[i]]; break;
        case 9:
            output[i] = input[switchTable[i]] ^ 9; break;// ^
        case 10:
            output[i] = input[switchTable[i]]; break;
        case 11:
            output[i] = input[switchTable[i]] - 11; break;// *
        case 12:
            output[i] = input[switchTable[i]]; break;
        case 13:
            output[i] = input[switchTable[i]] ^ 13; break;// ^
        case 14:
            output[i] = input[switchTable[i]]; break;
        case 15:
            output[i] = input[switchTable[i]] + 15; break;// /
        case 16:
            output[i] = input[switchTable[i]]; break;
        case 17:
            output[i] = input[switchTable[i]] ^ 17; break;// ^
        case 18:
            output[i] = input[switchTable[i]]; break;
        case 19:
            output[i] = input[switchTable[i]] - 19; break;// +
        case 20:
            output[i] = input[switchTable[i]]; break;
        case 21:
            output[i] = input[switchTable[i]] ^ 21; break;// ^
        case 22:
            output[i] = input[switchTable[i]]; break;
        case 23:
            output[i] = input[switchTable[i]] + 29; break;// -
        case 24:
            output[i] = input[switchTable[i]]; break;
        case 25:
            output[i] = input[switchTable[i]] ^ 25; break;// ^
        case 26:
            output[i] = input[switchTable[i]]; break;
        case 27:
            output[i] = input[switchTable[i]] - 27; break;// *
        case 28:
            output[i] = input[switchTable[i]]; break;
        case 29:
            output[i] = input[switchTable[i]] ^ 29; break;// ^
        case 30:
            output[i] = input[switchTable[i]]; break;
        case 31:
            output[i] = input[switchTable[i]] + 31; break;// /
        default:
            break;
        }
    }
}

void OEMCipherSec::KeyExpansion(unsigned char* key, unsigned char w[][4][4]){
    int i, j, r, c;
    unsigned char rc[] = { 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36 };
    for (r = 0; r < 4; r++){
        for (c = 0; c < 4; c++)
        {
            w[0][r][c] = key[r + c * 4];
        }
    }
    for (i = 1; i <= 10; i++){
        for (j = 0; j < 4; j++){
            unsigned char t[4];
            for (r = 0; r < 4; r++){
                t[r] = j ? w[i][r][j - 1] : w[i - 1][r][3];
            }
            if (j == 0){
                unsigned char temp = t[0];
                for (r = 0; r < 3; r++)
                {
                    t[r] = Sbox[t[(r + 1) % 4]];
                }
                t[3] = Sbox[temp];
                t[0] ^= rc[i - 1];
            }
            for (r = 0; r < 4; r++){
                w[i][r][j] = w[i - 1][r][j] ^ t[r];
            }
        }
    }
}

unsigned char OEMCipherSec::FFmul(unsigned char a, unsigned char b){
    unsigned char bw[4];
    unsigned char res = 0;
    int i;
    bw[0] = b;
    for (i = 1; i < 4; i++){
        bw[i] = bw[i - 1] << 1;
        if (bw[i - 1] & 0x80){
            bw[i] ^= 0x1b;
        }
    }
    for (i = 0; i < 4; i++){
        if ((a >> i) & 0x01){
            res ^= bw[i];
        }
    }
    return res;
}

void OEMCipherSec::SubBytes(unsigned char state[][4]){
    int r, c;
    for (r = 0; r < 4; r++){
        for (c = 0; c < 4; c++){
            state[r][c] = Sbox[state[r][c]];
        }
    }
}

void OEMCipherSec::ShiftRows(unsigned char state[][4]){
    unsigned char t[4];
    int r, c;
    for (r = 1; r < 4; r++){
        for (c = 0; c < 4; c++){
            t[c] = state[r][(c + r) % 4];
        }
        for (c = 0; c < 4; c++){
            state[r][c] = t[c];
        }
    }
}

void OEMCipherSec::MixColumns(unsigned char state[][4]){
    unsigned char t[4];
    int r, c;
    for (c = 0; c < 4; c++){
        for (r = 0; r < 4; r++){
            t[r] = state[r][c];
        }
        for (r = 0; r < 4; r++){
            state[r][c] = FFmul(0x02, t[r])
                ^ FFmul(0x03, t[(r + 1) % 4])
                ^ FFmul(0x01, t[(r + 2) % 4])
                ^ FFmul(0x01, t[(r + 3) % 4]);
        }
    }
}

void OEMCipherSec::AddRoundKey(unsigned char state[][4], unsigned char k[][4]){
    int r, c;
    for (c = 0; c < 4; c++){
        for (r = 0; r < 4; r++){
            state[r][c] ^= k[r][c];
        }
    }
}

void OEMCipherSec::InvSubBytes(unsigned char state[][4]){
    int r, c;
    for (r = 0; r < 4; r++){
        for (c = 0; c < 4; c++)
        {
            state[r][c] = InvSbox[state[r][c]];
        }
    }
}

void OEMCipherSec::InvShiftRows(unsigned char state[][4]){
    unsigned char t[4];
    int r, c;
    for (r = 1; r < 4; r++){
        for (c = 0; c < 4; c++){
            t[c] = state[r][(c - r + 4) % 4];
        }
        for (c = 0; c < 4; c++){
            state[r][c] = t[c];
        }
    }
}

void OEMCipherSec::InvMixColumns(unsigned char state[][4]){
    unsigned char t[4];
    int r, c;
    for (c = 0; c < 4; c++){
        for (r = 0; r < 4; r++){
            t[r] = state[r][c];
        }
        for (r = 0; r < 4; r++){
            state[r][c] = FFmul(0x0e, t[r])
                ^ FFmul(0x0b, t[(r + 1) % 4])
                ^ FFmul(0x0d, t[(r + 2) % 4])
                ^ FFmul(0x09, t[(r + 3) % 4]);
        }
    }
}











@implementation MideaSectionCipheTool

+(NSString *)meijuSecEncode:(NSString *)inputStr{
    if (!inputStr) {
        return nil;
    }
    OEMCipherSec meiju;
    char * src_data = (char*) [inputStr UTF8String];
    char * output = (char *)malloc(100);
    memset(output, 0, 100);
    
    char * testKey = meiju.encode(src_data,output);
    NSString * str = [NSString stringWithUTF8String:testKey];
    free(output);
    return str;
    
}


+(NSString *)meijuSecDecode:(NSString *)inputStr
{
    if (!inputStr) {
        return nil;
    }
    OEMCipherSec meiju;
    char * src_data = (char*) [inputStr UTF8String];
    char * output = (char *)malloc(100);
    memset(output, 0, 100);
    char * testKey = meiju.decode(src_data,output);
    NSString *str = [NSString stringWithUTF8String:testKey];
    free(output);
    
    return str;
}

@end
