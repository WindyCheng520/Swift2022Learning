//
//  MideaDataSecurity.m
//  midea
//
//  Created by xuenianxiang on 14-8-14.
//  Copyright (c) 2014年 keane. All rights reserved.
//

#import "MideaSecurity.h"
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCryptor.h>
#import <CommonCrypto/CommonHMAC.h>
#import <OEMFoundation/NSArray+OEMExtension.h>
#import "MSUserDefaultTools.h"
#import "MSAppInfo.h"
#import "MSUserInfoManager.h"

@implementation MideaSecurity

#pragma mark - 登陆密码加密(本地)------SHA256(password)

+ (NSString *)localLoginPasswordEncryption:(NSString *)msg {
    return [self getSha256String:msg];
}

#pragma mark - 注册密码加密------SHA256(password)

+ (NSString *)registerPasswordEncryption:(NSString *)msg {
    return [self getSha256String:msg];
}

#pragma mark - MD5_128加密(局域网签名用)

+ (NSString *)getMD5_128WithData:(NSData *)data {
    unsigned char result[16];
    CC_MD5( [data bytes], (CC_LONG)[data length], result);
    return [NSString stringWithFormat:
            @"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
            result[0], result[1], result[2], result[3],
            result[4], result[5], result[6], result[7],
            result[8], result[9], result[10], result[11],
            result[12], result[13], result[14], result[15]
            ];
}

#pragma mark - MD5_128加密

+ (NSString *)getMD5_128:(NSString *)str {
    const char *cStr = [str UTF8String];
    unsigned char result[16];
    CC_MD5( cStr, (CC_LONG)strlen(cStr), result);
    return [NSString stringWithFormat:
            @"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
            result[0], result[1], result[2], result[3],
            result[4], result[5], result[6], result[7],
            result[8], result[9], result[10], result[11],
            result[12], result[13], result[14], result[15]
            ];
}

#pragma mark - SHA256加密

+ (NSString *)getSha256String:( NSString *)srcString {
    const char *cstr = [srcString cStringUsingEncoding : NSUTF8StringEncoding ];
    NSData *data = [ NSData dataWithBytes :cstr length :strlen(cstr)];
    uint8_t digest[ CC_SHA256_DIGEST_LENGTH ];
    CC_SHA256(data.bytes, (CC_LONG)data.length, digest);
    NSMutableString * result = [ NSMutableString stringWithCapacity : CC_SHA256_DIGEST_LENGTH * 2 ];
    for ( int i = 0 ; i < CC_SHA256_DIGEST_LENGTH ; i++) {
        [result appendFormat : @"%02x" , digest[i]];
    }
    return result;
}

#pragma mark - AES128加密(局域网加密专用)

+ (NSData *)AES128EncryptWithData:(NSData *)data key:(NSString *)key {
    if(!data) return nil;
    
    NSUInteger dataLength = [data length];
    size_t bufferSize = dataLength + kCCBlockSizeAES128;
    void *buffer = malloc(bufferSize);
    size_t numBytesEncrypted = 0;
    CCCryptorStatus cryptStatus = CCCrypt(kCCEncrypt,
                                          kCCAlgorithmAES128,
                                          kCCOptionPKCS7Padding|kCCOptionECBMode,
                                          [[self dataForHexString:key] bytes],
                                          kCCBlockSizeAES128,
                                          NULL,
                                          [data bytes],
                                          dataLength,
                                          buffer,
                                          bufferSize,
                                          &numBytesEncrypted);
    if (cryptStatus == kCCSuccess) {
        NSData *resultData = [NSData dataWithBytes:buffer length:numBytesEncrypted];
        free(buffer);
        return resultData;
    }
    free(buffer);
    return nil;
}

#pragma mark - AES128解密(局域网解密专用)

+ (NSData *)AES128DecryptWithData:(NSData *)data key:(NSString *)key {
    NSUInteger dataLength = [data length];
    size_t bufferSize = dataLength + kCCBlockSizeAES128;
    void *buffer = malloc(bufferSize);
    size_t numBytesCrypted = 0;
    CCCryptorStatus cryptStatus = CCCrypt(kCCDecrypt,
                                          kCCAlgorithmAES128,
                                          kCCOptionPKCS7Padding|kCCOptionECBMode,
                                          [[self dataForHexString:key] bytes],
                                          kCCBlockSizeAES128,
                                          NULL,
                                          [data bytes],
                                          dataLength,
                                          buffer,
                                          bufferSize,
                                          &numBytesCrypted);
    if (cryptStatus == kCCSuccess) {
        NSData *resultData = [NSData dataWithBytes:buffer length:numBytesCrypted];
        free(buffer);
        return resultData;
    }
    free(buffer);
    return nil;
}

#pragma mark - AES128加密(NSString)

+ (NSString *)AES128Encrypt:(NSString *)plainText key:(NSString *)key {
    char keyPtr[kCCKeySizeAES128+1];
    memset(keyPtr, 0, sizeof(keyPtr));
    [key getCString:keyPtr maxLength:sizeof(keyPtr) encoding:NSUTF8StringEncoding];
    
    NSData* data = [plainText dataUsingEncoding:NSUTF8StringEncoding];
    NSUInteger dataLength = [data length];
    
    size_t bufferSize = dataLength + kCCBlockSizeAES128;
    void *buffer = malloc(bufferSize);
    size_t numBytesEncrypted = 0;
    CCCryptorStatus cryptStatus = CCCrypt(kCCEncrypt,
                                          kCCAlgorithmAES128,
                                          kCCOptionPKCS7Padding|kCCOptionECBMode,
                                          keyPtr,
                                          kCCBlockSizeAES128,
                                          NULL,
                                          [data bytes],
                                          dataLength,
                                          buffer,
                                          bufferSize,
                                          &numBytesEncrypted);
    if (cryptStatus == kCCSuccess) {
        NSData *resultData = [NSData dataWithBytes:buffer length:numBytesEncrypted];
        free(buffer);
        return [self hexStringForData:resultData];
    }
    free(buffer);
    return nil;
}

#pragma mark - AES128解密(NSString)

+ (NSString *)AES128Decrypt:(NSString *)encryptText key:(NSString *)key {
    char keyPtr[kCCKeySizeAES128 + 1];
    memset(keyPtr, 0, sizeof(keyPtr));
    [key getCString:keyPtr maxLength:sizeof(keyPtr) encoding:NSUTF8StringEncoding];
    
    NSData *data = [self dataForHexString:encryptText];
    NSUInteger dataLength = [data length];
    size_t bufferSize = dataLength + kCCBlockSizeAES128;
    void *buffer = malloc(bufferSize);
    
    size_t numBytesCrypted = 0;
    CCCryptorStatus cryptStatus = CCCrypt(kCCDecrypt,
                                          kCCAlgorithmAES128,
                                          kCCOptionPKCS7Padding|kCCOptionECBMode,
                                          keyPtr,
                                          kCCBlockSizeAES128,
                                          NULL,
                                          [data bytes],
                                          dataLength,
                                          buffer,
                                          bufferSize,
                                          &numBytesCrypted);
    if (cryptStatus == kCCSuccess) {
        NSData *resultData = [NSData dataWithBytes:buffer length:numBytesCrypted];
        free(buffer);
        return [[NSString alloc] initWithData:resultData encoding:NSUTF8StringEncoding] ;
    }
    free(buffer);
    return nil;
}

+ (NSString *)AESCBCEncrypt:(NSString *)plainText key:(NSString *)key iv:(NSString *)iv
{
    NSData *data = [plainText dataUsingEncoding:NSUTF8StringEncoding];
    NSData *result = [self AES128operation:kCCEncrypt data:data key:key iv:iv];
    return [self hexStringForData:result];
}

//+ (NSString *)AESCBCEncrypt:(NSString *)plainText key:(NSString *)key iv:(NSString *)iv
//{
//    NSData *data = [plainText dataUsingEncoding:NSUTF8StringEncoding];
//    NSData *result = [[self AES128operation:kCCEncrypt data:data key:key iv:iv] base64EncodedDataWithOptions:0];
//    return [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
//}

+ (NSString *)AESCBCDecrypt:(NSString *)encryptText key:(NSString *)key iv:(NSString *)iv
{
    NSData* data = [self dataForHexString:encryptText];
    NSData *result = [self AES128operation:kCCDecrypt data:data key:key iv:iv];
    return [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
}

//+ (NSString *)AESCBCDecrypt:(NSString *)encryptText key:(NSString *)key iv:(NSString *)iv
//{
//    NSData *data = [[NSData alloc] initWithBase64EncodedString:encryptText options:0];
//    NSData *result = [self AES128operation:kCCDecrypt data:data key:key iv:iv];
//    return [[NSString alloc] initWithData:result encoding:NSUTF8StringEncoding];
//}

/**
 *  AES加解密算法
 *
 *  @param operation kCCEncrypt（加密）kCCDecrypt（解密）
 *  @param data      待操作Data数据
 *  @param key       key
 *  @param iv        向量
 *
 *
 */
+ (NSData *)AES128operation:(CCOperation)operation data:(NSData *)data key:(NSString *)key iv:(NSString *)iv
{    
    char keyPtr[kCCKeySizeAES128 + 1];  //kCCKeySizeAES128是加密位数 可以替换成256位的
    bzero(keyPtr, sizeof(keyPtr));
    [key getCString:keyPtr maxLength:sizeof(keyPtr) encoding:NSUTF8StringEncoding];
    // IV
    char ivPtr[kCCBlockSizeAES128 + 1];
    bzero(ivPtr, sizeof(ivPtr));
    [iv getCString:ivPtr maxLength:sizeof(ivPtr) encoding:NSUTF8StringEncoding];
    
    size_t bufferSize = [data length] + kCCBlockSizeAES128;
    void *buffer = malloc(bufferSize);
    size_t numBytesEncrypted = 0;
    
    // 设置加密参数
    /**
        这里设置的参数ios默认为CBC加密方式，如果需要其他加密方式如ECB，在kCCOptionPKCS7Padding这个参数后边加上kCCOptionECBMode，即kCCOptionPKCS7Padding | kCCOptionECBMode，但是记得修改上边的偏移量，因为只有CBC模式有偏移量之说

    */
    CCCryptorStatus cryptorStatus = CCCrypt(operation,
                                            kCCAlgorithmAES128,
                                            kCCOptionPKCS7Padding,
                                            keyPtr,
                                            kCCKeySizeAES128,
                                            ivPtr,
                                            [data bytes],
                                            [data length],
                                            buffer,
                                            bufferSize,
                                            &numBytesEncrypted);
    
    if(cryptorStatus == kCCSuccess) {
        NSData *cryptorData = [NSData dataWithBytes:buffer length:numBytesEncrypted];
        free(buffer);
        return cryptorData;
    }
    
    free(buffer);
    return nil;
}

// NSData 转换成 16进制小写字符串
+ (NSString *)hexStringForData:(NSData*)data {
    if (data == nil) {
        return nil;
    }
    NSMutableString* hexString = [NSMutableString string];
    const unsigned char *p = [data bytes];
    for (int i=0; i < [data length]; i++) {
        [hexString appendFormat:@"%02x", *p++];
    }
    return hexString;
}

// 16进制小写字符串 转换成 NSData
+ (NSData *)dataForHexString:(NSString*)hexString {
    if (hexString == nil) {
        return nil;
    }
    const char* ch = [[hexString lowercaseString] cStringUsingEncoding:NSUTF8StringEncoding];
    if(!ch) return nil;
    NSMutableData* data = [NSMutableData data];
    while (*ch) {
        if (*ch == ' ') {
            continue;
        }
        char byte = 0;
        if ('0' <= *ch && *ch <= '9') {
            byte = *ch - '0';
        }
        else if ('a' <= *ch && *ch <= 'f') {
            byte = *ch - 'a' + 10;
        }
        else if ('A' <= *ch && *ch <= 'F') {
            byte = *ch - 'A' + 10;
        }
        ch++;
        byte = byte << 4;
        if (*ch) {
            if ('0' <= *ch && *ch <= '9') {
                byte += *ch - '0';
            } else if ('a' <= *ch && *ch <= 'f') {
                byte += *ch - 'a' + 10;
            }
            else if('A' <= *ch && *ch <= 'F')
            {
                byte += *ch - 'A' + 10;
            }
            ch++;
        }
        [data appendBytes:&byte length:1];
    }
    return data;
}

+ (NSString *)convertDataToHexStr:(NSData *)data {
    if (!data || [data length] == 0) {
        return @"";
    }
    NSMutableString *string = [[NSMutableString alloc] initWithCapacity:[data length]];
    
    [data enumerateByteRangesUsingBlock:^(const void *bytes, NSRange byteRange, BOOL *stop) {
        unsigned char *dataBytes = (unsigned char*)bytes;
        for (NSInteger i = 0; i < byteRange.length; i++) {
            NSString *hexStr = [NSString stringWithFormat:@"%x", (dataBytes[i]) & 0xff];
            if ([hexStr length] == 2) {
                [string appendString:hexStr];
            } else {
                [string appendFormat:@"0%@", hexStr];
            }
        }
    }];
    
    return string;
}

+ (NSString *)hexStringFromString:(NSString *)string{
    NSData *myD = [string dataUsingEncoding:NSUTF8StringEncoding];
    Byte *bytes = (Byte *)[myD bytes];
    //下面是Byte 转换为16进制。
    NSString *hexStr=@"";
    for(int i=0;i<[myD length];i++) {
        NSString *newHexStr = [NSString stringWithFormat:@"%x",bytes[i]&0xff];///16进制数
        if([newHexStr length]==1)
            hexStr = [NSString stringWithFormat:@"%@0%@",hexStr,newHexStr];
        else {
            hexStr = [NSString stringWithFormat:@"%@%@",hexStr,newHexStr];
        }
    }
    return hexStr;
}

+ (NSString *)md5:(NSString *)str{
    const char *cStr = [str UTF8String];
    unsigned char result[32];
    CC_MD5( cStr, (CC_LONG)strlen(cStr), result );
    NSMutableString *Mstr = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH];
    for (int i=0; i<CC_MD5_DIGEST_LENGTH; i++) {
        [Mstr appendFormat:@"%02X",result[i]];
    }
    return [Mstr lowercaseString];
}

+ (NSString *)iOtOpenidEncrypt:(NSString *)plainText key:(NSString *)key {
    NSString*md5Str =  [MideaSecurity md5:key];
    NSString *newmd5Str = [md5Str substringToIndex:16];
    NSString *aesStr  = [MideaSecurity AES128Encrypt:plainText key:newmd5Str];
    return aesStr;
}

#pragma mark - HMAC-SHA256加密方法

/// HMAC-SHA256加密方法
/// @param secret 秘钥
/// @param content 要加密的文本
+ (NSString *)hmacSHA256WithSecret:(NSString *)secret
                           content:(NSString *)content {
    const char *cKey  = [secret cStringUsingEncoding:NSASCIIStringEncoding];
    const char *cData = [content cStringUsingEncoding:NSUTF8StringEncoding];// 有可能有中文 所以用NSUTF8StringEncoding -> NSASCIIStringEncoding
    unsigned char cHMAC[CC_SHA256_DIGEST_LENGTH];
    CCHmac(kCCHmacAlgSHA256, cKey, strlen(cKey), cData, strlen(cData), cHMAC);
    NSData *HMACData = [NSData dataWithBytes:cHMAC length:sizeof(cHMAC)];
    const unsigned char *buffer = (const unsigned char *)[HMACData bytes];
    NSMutableString *HMAC = [NSMutableString stringWithCapacity:HMACData.length * 2];
    for (int i = 0; i < HMACData.length; ++i){
        [HMAC appendFormat:@"%02x", buffer[i]];
    }
    return HMAC;
}

#pragma mark - 登录后的敏感数据加解密方法
//登录后的敏感数据加密方法
+ (NSString *)encryptDataAfterLogin:(NSString *)content {
    return [self AESCBCEncrypt:content key:[self decryptMideaCloudAccessToken] iv:[self decryptMideaCloudRandomData]];
}

//登录后的敏感数据解密方法
+ (NSString *)decryptDataAfterLogin:(NSString *)content {
    return [self AESCBCDecrypt:content key:[self decryptMideaCloudAccessToken] iv:[self decryptMideaCloudRandomData]];
}

//解密登录返回的accessToken
+ (NSString *)decryptMideaCloudAccessToken {
    NSString *accessToken = [MSUserInfoManager shareManager].loginInfoModel.accessToken;
    if (accessToken && ![accessToken isEqualToString:@""]) {
        NSString* appKey = [MSAppInfo appKey];
        appKey = [self getSha256String:appKey];
        if (appKey.length < 32) {
            return nil;
        }
        NSString *key = [appKey substringWithRange:NSMakeRange(0, 16)];
        NSString *iv = [appKey substringWithRange:NSMakeRange(16, 16)];
        
        return [self AESCBCDecrypt:accessToken key:key iv:iv];
    }
    return nil;
}

//解密登录返回的randomData
+ (NSString *)decryptMideaCloudRandomData {
    NSString *randomData = [MSUserInfoManager shareManager].loginInfoModel.accessToken;
    if (randomData && ![randomData isEqualToString:@""]) {
        NSString* appKey = [MSAppInfo appKey];
        appKey = [self getSha256String:appKey];
        if (appKey.length < 32) {
            return nil;
        }
        NSString *key = [appKey substringWithRange:NSMakeRange(0, 16)];
        NSString *iv = [appKey substringWithRange:NSMakeRange(16, 16)];
        
        return [self AESCBCDecrypt:randomData key:key iv:iv];
    }
    return nil;
}

#pragma mark - 登录前加密

//登录前的敏感数据加密方法
+ (NSString *)encryptDataBeforeLogin:(NSString *)content
{
    NSString* appKey = [MSAppInfo appKey];
    appKey = [MideaSecurity getSha256String:appKey];
    if (appKey.length < 32) {
        return nil;
    }
    NSString *key = [appKey substringWithRange:NSMakeRange(0, 16)];
    NSString *iv = [appKey substringWithRange:NSMakeRange(16, 16)];
    NSString *result = [[MideaSecurity AESCBCEncrypt:content key:key iv:iv] lowercaseString];
    return result;
}

//登录前的敏感数据解密方法
+ (NSString *)decryptDataBeforeLogin:(NSString *)content
{
    NSString* appKey = [MSAppInfo appKey];
    appKey = [MideaSecurity getSha256String:appKey];
    if (appKey.length < 32) {
        return nil;
    }
    NSString *key = [appKey substringWithRange:NSMakeRange(0, 16)];
    NSString *iv = [appKey substringWithRange:NSMakeRange(16, 16)];
    NSString *result = [MideaSecurity AESCBCDecrypt:content key:key iv:iv];
    return result;
}

#pragma mark - 本地敏感数据存取方法 （加解密+完整性校验）
+ (NSString *)saveSensitiveDataToLocal:(NSString *)content {
    if (![content isKindOfClass:[NSString class]] || content.length == 0) {
        return nil;
    }
    //1、对数据进行加密
    NSString *encryptContent = [self encryptDataBeforeLogin:content];
    //2、对数据进行hmacsha256处理，作为完整性校验的依据
    NSString *hmacContent = [self hmacSHA256WithSecret:[MSAppInfo hmacSha256SecretForLocalData] content:content];
    //3、拼接存储
    return [NSString stringWithFormat:@"%@%@", encryptContent, hmacContent];
}

+ (NSString *)getSensitiveDataFromLocal:(NSString *)content {
    if (content.length <= 64) {
        return nil;
    }
    //1、截取数据的最后64位=存储时的hmacsha256值（固定64位）
    NSString *hmacContent = [content substringFromIndex:content.length-64];
    //2、截取数据最后64位之前的数据=加密的content
    NSString *encryptContent = [content substringToIndex:content.length-64];
    //3、encryptContent 解密
    NSString *decryptContent = [self decryptDataBeforeLogin:encryptContent];
    if (!decryptContent) {
        return nil;
    }
    //4、对decryptContent进行hmacsha256处理，与hmacContent比较，校验完整性
    NSString *decryptHmacContent = [self hmacSHA256WithSecret:[MSAppInfo hmacSha256SecretForLocalData] content:decryptContent];
    if ([decryptHmacContent isEqualToString:hmacContent]) {
        return decryptContent;
    } else {
        return nil;
    }
}





@end
