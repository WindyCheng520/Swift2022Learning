//
//  MSUserDefaultTools.h
//  MSBusiness
//
//  Created by 及时行乐 on 2020/7/9.
//

#import <Foundation/Foundation.h>


typedef NS_ENUM(NSInteger, MSUrlEnvironmentType) {
    MSUrlEnvironmentTypeSit = 0,
    MSUrlEnvironmentTypeDev,
    MSUrlEnvironmentTypeUat,
    MSUrlEnvironmentTypeProd
};


@interface MSUserDefaultTools : NSObject

//userDefault 存储数据方法
+ (void)saveToUserDefaultWithKey:(NSString *)key value:(id)value;

//userDefault 获取数据方法
+ (id)getUserDefaultWithKey:(NSString *)key;

//userDefault 删除数据方法
+ (void)clearUserDefaultValueWithKey:(NSString *)key;

////存储云平台accessToken，用于加密敏感数据
//+ (void)saveMideaCloudAccessToken:(NSString*)accessToken;
//
//+ (NSString*)getMideaCloudAccessToken;
//
////存储云平台randomData，用于加密敏感数据
//+ (void)saveMideaCloudRandomData:(NSString*)randomData;
//
//+ (NSString*)getMideaCloudRandomData;
//
////存储用户账号
//+ (void)saveUserAccount:(NSString*)account;
//
//+ (NSString*)getUserAccount;
//
////存储中台accessToken，用于置换uid，判断登录
//+ (void)saveMasAccessToken:(NSString*)accessToken;
//
//+ (NSString*)getMasAccessToken;
//
////存储中台tokenPwd，用于刷新token
//+ (void)saveMasTokenPwd:(NSString*)tokenPwd;
//
//+ (NSString*)getMasTokenPwd;
//
////存储用户uid
//+ (void)saveUserUid:(NSString*)uid;
//
//+ (NSString*)getUserUid;
//
////存储用户昵称
//+ (void)saveUserNickname:(NSString *)nickname;
//
//+ (NSString *)getUserNickname;

//存储上次登录的account
+ (void)saveLastLoginAccount:(NSString *)account;

+ (NSString *)getLastLoginAccount;

//存储首次启动APP时同意了隐私协议
+ (void)saveUserFirstAgreePrivacy;

//获取首次启动APP时是否同意了隐私协议
+ (BOOL)judgeUserWhetherFirstAgreePrivacy;

//存储用户已经选择过是否更新的版本号（非强制）
+ (void)saveUpdateVersionNumber:(NSString *)versionNumber;

+ (NSString*)getUpdateVersionNumber;

//存储用户更新日期（非强制）
+ (void)saveDateToDisk;

//获取用户更新日期()
+ (NSString *)getDateFromDisk;


//获取本地存储的APNs的token
+ (NSString*)getAPNsToken;

////清除用户登录、注册成功相关信息
//+ (void)clearUserLoginOrRegisterData;



//存储Alexa Token
+ (void)saveAlexaTokenToDisk:(NSString *)token;


//获取Alexa Token
+ (NSString*)getAlexaToken;


//存储AlexaTokenTime
+ (void)saveAlexaTokenTimeToDisk:(NSString *)timestamp;

//存储AlexaRefleshToken
+ (void)saveAlexaRefleshTokenToDisk:(NSString *)token;

//获取AlexaRefleshToken
+ (NSString*)getAlexaRefleshToken;


//获取AlexaTokenTime
+ (NSString *)getAlexaTokenTimstamp;


//保存UrlEnvironmentType
+ (void)saveUrlEnvironmentType:(MSUrlEnvironmentType)type;


//获取UrlEnvironmentType
+ (MSUrlEnvironmentType)getUrlEnvironmentType;



@end

