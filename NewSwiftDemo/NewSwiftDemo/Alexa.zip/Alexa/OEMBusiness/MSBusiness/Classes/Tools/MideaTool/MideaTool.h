//
//  MideaTool.h
//  AFNetworking
//
//  Created by yanghy on 2020/5/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MideaTool : NSObject

+(NSString*)getFileMD5WithPath:(NSString*)path;
+ (NSString *)copyFileFromResourceTOSandbox:(NSString *)fileName type:(NSString *)type;

+ (NSString *)localHasPlugin:(NSString *)documentSubPath fileName:(NSString *)fileName;
+ (NSString *)getDocumentDirectoryPathComponent:(NSString *)path;

+(NSString *)getUUID;
+ (NSString *)getReqid;

+ (NSString *)currentWifiBSSID;
@end

NS_ASSUME_NONNULL_END
