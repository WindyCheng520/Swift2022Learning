//
//  MideaConfigDeviceTool.h
//  midea
//
//  Created by MaYifang on 16/6/13.
//  Copyright © 2016年 Midea. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MideaConfigDeviceTool : NSObject

///创建并获取配网埋点的device_session_id
+ (NSString *)getDeviceSessionId:(BOOL)isForceNew;

///获取配网埋点的device_session_id
+ (NSString *)getDeviceSessionId;
@end
