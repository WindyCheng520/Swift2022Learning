//
//  MideaTool.m
//  AFNetworking
//
//  Created by yanghy on 2020/5/18.
//

#import "MideaTool.h"
#import <OEMFoundation/SAMKeychain.h>
#import <CommonCrypto/CommonDigest.h>
#import "MideaSecurity.h"
#import <SystemConfiguration/CaptiveNetwork.h>

#define FileHashDefaultChunkSizeForReadingData 1024*8

@implementation MideaTool


+(NSString*)getFileMD5WithPath:(NSString*)path
{
    if(!path || path.length <= 0) return nil;
    return (__bridge_transfer NSString *)MD5StringForFilePath((__bridge CFStringRef)path, FileHashDefaultChunkSizeForReadingData);
}

+ (NSString *)copyFileFromResourceTOSandbox:(NSString *)fileName type:(NSString *)type {
    //文件类型
    NSString * docPath = [[NSBundle mainBundle] pathForResource:fileName ofType:type];

    // 沙盒Documents目录
    NSString * appDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    BOOL filesPresent = [self copyMissingFile:docPath toPath:appDir];
    if (filesPresent) {
        NSLog(@"Copy Success appDir:%@", appDir);
        return [NSString stringWithFormat:@"%@/%@.%@", appDir, fileName, type];
    }
    else {
        NSLog(@"Copy Fail");
        return nil;
    }
}

//判断document下 documentSubPath/fileName 是否存在，存在则返回，否则返回nil
+ (NSString *)localHasPlugin:(NSString *)documentSubPath fileName:(NSString *)fileName {
    NSString *plugRootPath = [MideaTool getDocumentDirectoryPathComponent:@"Plugins"];
    NSString *plugPath = [plugRootPath stringByAppendingPathComponent:documentSubPath];
    NSString *path = [plugPath stringByAppendingPathComponent:fileName];
    if ([[NSFileManager defaultManager] fileExistsAtPath:path]) {
        return path;
    }
    return nil;
}

+ (NSString *)getDocumentDirectoryPathComponent:(NSString *)path {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentPath = [paths objectAtIndex:0];
    NSString *downPath = documentPath;
    if (path) {
        downPath = [downPath stringByAppendingPathComponent:path];
    }
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:downPath]) {
        [fileManager createDirectoryAtPath:downPath withIntermediateDirectories:YES attributes:nil error:NULL];
    }

    return downPath;
}

+ (BOOL)copyMissingFile:(NSString *)sourcePath toPath:(NSString *)toPath {
    BOOL retVal = YES;
    NSString * finalLocation = [toPath stringByAppendingPathComponent:[sourcePath lastPathComponent]];
    if (![[NSFileManager defaultManager] fileExistsAtPath:finalLocation]) {
        retVal = [[NSFileManager defaultManager] copyItemAtPath:sourcePath toPath:finalLocation error:NULL];
    }
    return retVal;
}


CFStringRef MD5StringForFilePath(CFStringRef filePath,size_t chunkSizeForReadingData) {
    
    // Declare needed variables
    
    CFStringRef result = NULL;
    
    CFReadStreamRef readStream = NULL;
    
    // Get the file URL
    
    CFURLRef fileURL =
    
    CFURLCreateWithFileSystemPath(kCFAllocatorDefault,
                                  
                                  (CFStringRef)filePath,
                                  
                                  kCFURLPOSIXPathStyle,
                                  
                                  (Boolean)false);
    
    if (!fileURL) goto done;
    
    // Create and open the read stream
    
    readStream = CFReadStreamCreateWithFile(kCFAllocatorDefault,
                                            
                                            (CFURLRef)fileURL);
    
    if (!readStream) goto done;
    
    bool didSucceed = (bool)CFReadStreamOpen(readStream);
    
    if (!didSucceed) goto done;
    
    // Initialize the hash object
    
    CC_MD5_CTX hashObject;
    
    CC_MD5_Init(&hashObject);
    
    // Make sure chunkSizeForReadingData is valid
    
    if (!chunkSizeForReadingData) {
        
        chunkSizeForReadingData = FileHashDefaultChunkSizeForReadingData;
        
    }
    
    // Feed the data to the hash object
    
    bool hasMoreData = true;
    
    while (hasMoreData) {
        
        uint8_t buffer[chunkSizeForReadingData];
        
        CFIndex readBytesCount = CFReadStreamRead(readStream,(UInt8 *)buffer,(CFIndex)sizeof(buffer));
        
        if (readBytesCount == -1) break;
        
        if (readBytesCount == 0) {
            
            hasMoreData = false;
            
            continue;
            
        }
        
        CC_MD5_Update(&hashObject,(const void *)buffer,(CC_LONG)readBytesCount);
        
    }
    
    // Check if the read operation succeeded
    
    didSucceed = !hasMoreData;
    
    // Compute the hash digest
    
    unsigned char digest[CC_MD5_DIGEST_LENGTH];
    
    CC_MD5_Final(digest, &hashObject);
    
    // Abort if the read operation failed
    
    if (!didSucceed) goto done;
    
    // Compute the string result
    
    char hash[2 * sizeof(digest) + 1];
    
    for (size_t i = 0; i < sizeof(digest); ++i) {
        
        snprintf(hash + (2 * i), 3, "%02x", (int)(digest[i]));
        
    }
    
    result = CFStringCreateWithCString(kCFAllocatorDefault,(const char *)hash,kCFStringEncodingUTF8);
    
    
    
done:
    
    if (readStream) {
        
        CFReadStreamClose(readStream);
        
        CFRelease(readStream);
        
    }
    
    if (fileURL) {
        
        CFRelease(fileURL);
        
    }
    
    return result;
    
}

#pragma mark 获取设备UUID
static NSString *mideaUUID;
+(NSString *)getUUID
{
    if (mideaUUID.length > 0) {
        return mideaUUID;
    }
    
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *bundleIdentifier = [infoDictionary objectForKey:@"CFBundleIdentifier"];
    NSString *strUUID = [SAMKeychain passwordForService:bundleIdentifier account:@"UUID"];
//    if ([bundleIdentifier isEqualToString:@"com.msmart.meiju.inhouse"]) {
//        strUUID = [SAMKeychain passwordForService:@"com.msmart.meiju.inhouse"account:@"UUID"];
//    }
    
    //首次执行该方法时，uuid为空
    if (!strUUID)
    {
        CFUUIDRef uuidRef = CFUUIDCreate(kCFAllocatorDefault);
        strUUID = (NSString *)CFBridgingRelease(CFUUIDCreateString (kCFAllocatorDefault,uuidRef));
        strUUID = [strUUID stringByReplacingOccurrencesOfString:@"-" withString:@""];
//        if ([bundleIdentifier isEqualToString:@"com.msmart.meiju.inhouse"]) {
            [SAMKeychain setPassword: [NSString stringWithFormat:@"%@", strUUID]
                         forService:bundleIdentifier account:@"UUID"];
//        }
//        else {
//            [SAMKeychain setPassword: [NSString stringWithFormat:@"%@", strUUID]
//                         forService:@"com.midea.msmart.appstore"account:@"UUID"];
//        }
        
        CFRelease(uuidRef);
    }
    else if([strUUID rangeOfString:@"-"].length > 0){
        strUUID = [strUUID stringByReplacingOccurrencesOfString:@"-" withString:@""];
//        if ([bundleIdentifier isEqualToString:@"com.msmart.meiju.inhouse"]) {
            [SAMKeychain setPassword: [NSString stringWithFormat:@"%@", strUUID]
                         forService:bundleIdentifier account:@"UUID"];
//        }
//        else {
//            [SAMKeychain setPassword: [NSString stringWithFormat:@"%@", strUUID]
//                         forService:@"com.midea.msmart.appstore"account:@"UUID"];
//        }
    }
    
    mideaUUID = strUUID;
    return mideaUUID;
}

+ (NSString *)getReqid
{
    NSTimeInterval timeInterval = [[NSDate date] timeIntervalSince1970] * 1000;
    NSString *uuid = [self getUUID];
    int tag = arc4random() % UINT16_MAX;
    NSString *reqIdStr = [NSString stringWithFormat:@"%@%0.0f%d", uuid, timeInterval, tag];
    NSString *reqIdStr_md5 = [MideaSecurity getMD5_128:reqIdStr];
    return reqIdStr_md5;
    return nil;
}


+ (NSString *)currentWifiBSSID {
    NSString *bssid = nil;
    CFArrayRef arrRef = CNCopySupportedInterfaces();
    NSArray *ifs = (__bridge id)arrRef;
    for (NSString *ifnam in ifs) {
        CFDictionaryRef dicRef = CNCopyCurrentNetworkInfo((__bridge CFStringRef)ifnam);
        NSDictionary *info = (__bridge id)dicRef;
        
        if (info[@"BSSID"]) {
            bssid = info[@"BSSID"];
        }
        
        if (dicRef != nil) {
            CFRelease(dicRef);
        }
    }
    
    if (arrRef != nil) {
        CFRelease(arrRef);
    }
    
    return bssid;
}

@end
