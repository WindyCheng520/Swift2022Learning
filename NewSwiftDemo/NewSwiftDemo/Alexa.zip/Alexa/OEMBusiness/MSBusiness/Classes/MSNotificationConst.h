//  
//  MSNotificationConst.h
//  MSBusiness
//   
//  Created by 李 燕强 on 2020/7/30
//  Copyright © 2020 Midea. All rights reserved.
//   
   
#import <UIKit/UIKit.h>

// 登录成功
UIKIT_EXTERN NSString * const kMideaLoginSuccessNotification;

// 退出登录
UIKIT_EXTERN NSString * const kMideaQuitLoginNotification;

// 被踢下线
UIKIT_EXTERN NSString * const kMideaForceLogoutNotification;

// 密码改变(change or reset)
UIKIT_EXTERN NSString * const kMideaPasswordModifyNotification;
// 设备在线状态改变 userInfo e.g: @{@"deviceId":@"123",@"onLine":@(YES)};
UIKIT_EXTERN NSString * const kMideaDeviceOnLineStatusChangeNotification;

// 设备上报特殊状态 userInfo e.g: @{@"deviceId":@"123",...};
UIKIT_EXTERN NSString * const kMideaDeviceReportSpecialStatusNotification;

// 设备列表需要刷新
UIKIT_EXTERN NSString * const kMideaDeviceListDataNeedReloadNotification;

// 用户点击设备确权按钮上报消息(后确权)
UIKIT_EXTERN NSString * const kMideaDeviceAuthConfirmNotification;

// 分享出去的设备接收到回复
UIKIT_EXTERN NSString * const KMideaDeviceShareReceiveResponseNotification;

// APP语言发生改变
UIKIT_EXTERN NSString * const MSInternationalizationDidUpdateLanguageNotification;

// 国家、地区发生改变
UIKIT_EXTERN NSString * const MSInternationalizationDidUpdateCountryNotification;

// 隐私协议发生更新
UIKIT_EXTERN NSString * const kMideaPrivacyUpdateNotification;

// 获取dcp品类列表成功
UIKIT_EXTERN NSString * const kMideaDCPDidUpdateApplianceTypeDataNotification;

// 定位的授权状态发生改变 userInfo e.g: @{@"status":@(kCLAuthorizationStatusAuthorizedWhenInUse)}
UIKIT_EXTERN NSString * const kMideaLocationAuthorizationStatusDidChangeNotification;

// 蓝牙状态发生改变
UIKIT_EXTERN NSString * const kMideaBluetoothAuthorizationStatusDidChangeNotification;

// ReactNative全局event
UIKIT_EXTERN NSString * const kMideaGlobalEventToReactNativeNotification;

//设备状态改变
UIKIT_EXTERN NSString * const kReactNativeMethodDeviceStatusChange;

//本地设备数据库有更新，需要及时更新依赖于本地数据库的业务逻辑 （e.g. mqtt的主题订阅等）
UIKIT_EXTERN NSString * const kLocalDeviceDBDidUpdateNotification;


//开始监听配网结果mqtt topic 通知
UIKIT_EXTERN NSString * const kMideaStartMonitorBindResultNotification;

//触发获取设备mqtt证书
UIKIT_EXTERN NSString * const kMideaNotifyFetchDeviceMQTTCerNotification;
//设备mqtt证书获取结果

UIKIT_EXTERN NSString * const kMideaNotifyDeviceMQTTCerResultNotification;

//配网成功或失败结果通知
UIKIT_EXTERN NSString * const kMideaBindResultNotification;



