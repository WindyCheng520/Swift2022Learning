//  
//  MSNotificationConst.m
//  MSBusiness
//   
//  Created by 李 燕强 on 2020/7/30
//  Copyright © 2020 Midea. All rights reserved.
//   
   
#import <Foundation/Foundation.h>

// 登录成功
NSString * const kMideaLoginSuccessNotification = @"MideaLoginSuccessNotification";

// 退出登录
NSString * const kMideaQuitLoginNotification = @"MideaQuitLoginNotification";

// 被踢下线
NSString * const kMideaForceLogoutNotification = @"MideaForceLogoutNotification";

// 密码改变(change or reset)
NSString * const kMideaPasswordModifyNotification = @"MideaPasswordModifyNotification";

// 设备在线状态改变 userInfo e.g: @{@"deviceId":@"123",@"onLine":@(YES)};
NSString * const kMideaDeviceOnLineStatusChangeNotification = @"MideaDeviceOnLineStatusChangeNotification";

// 设备上报特殊状态 userInfo e.g: @{@"deviceId":@"123",...};
NSString * const kMideaDeviceReportSpecialStatusNotification = @"MideaDeviceReportSpecialStatusNotification";

// 设备列表需要刷新
NSString * const kMideaDeviceListDataNeedReloadNotification = @"MideaDeviceListDataNeedReloadNotification";

// 用户点击设备确权按钮上报消息(后确权)  userInfo e.g: @{@"applianceCode":@"123"}
NSString * const kMideaDeviceAuthConfirmNotification = @"MideaDeviceAuthConfirmNotification";

// 分享出去的设备接收到回复
NSString * const KMideaDeviceShareReceiveResponseNotification = @"MideaDeviceShareReceiveResponseNotification";

// APP语言发生改变
NSString * const MSInternationalizationDidUpdateLanguageNotification = @"MSInternationalizationDidUpdateLanguageNotification";

// 国家、地区发生改变
NSString * const MSInternationalizationDidUpdateCountryNotification = @"MSInternationalizationDidUpdateCountryNotification";

// 隐私协议发生更新
NSString * const kMideaPrivacyUpdateNotification = @"MideaPrivacyUpdateNotification";

// 获取dcp品类列表成功
NSString * const kMideaDCPDidUpdateApplianceTypeDataNotification = @"MideaDCPDidUpdateApplianceTypeDataNotification";

// 定位的授权状态发生改变 userInfo e.g: @{@"status":@(kCLAuthorizationStatusAuthorizedWhenInUse)}
NSString * const kMideaLocationAuthorizationStatusDidChangeNotification = @"MideaLocationAuthorizationStatusDidChangeNotification";

// 蓝牙状态发生改变
NSString * const kMideaBluetoothAuthorizationStatusDidChangeNotification = @"MideaBluetoothAuthorizationStatusDidChangeNotification";

// ReactNative全局event   userInfo e.g @{@"method":@"demoEvent",@"params":@{@"thingCode":@"112233445566",@"isOnline":@(YES)}}
NSString * const kMideaGlobalEventToReactNativeNotification = @"MideaGlobalEventToReactNativeNotification";

//设备在离线状态
NSString * const kReactNativeMethodDeviceStatusChange = @"DeviceStatusChange";

//本地设备数据库有更新，需要及时更新依赖于本地数据库的业务逻辑 （e.g. mqtt的主题订阅等）
NSString * const kLocalDeviceDBDidUpdateNotification = @"kLocalDeviceDBDidUpdateNotification";


//开始监听配网结果mqtt topic
NSString * const kMideaStartMonitorBindResultNotification = @"kMideaStartMonitorBindResultNotification";

//触发获取设备mqtt证书
NSString * const kMideaNotifyFetchDeviceMQTTCerNotification = @"kMideaNotifyFetchDeviceMQTTCerNotification";

//设备mqtt证书获取结果
NSString * const kMideaNotifyDeviceMQTTCerResultNotification = @"kMideaNotifyDeviceMQTTCerResultNotification";

//配网成功或失败结果通知
NSString * const kMideaBindResultNotification = @"kMideaBindResultNotification";
