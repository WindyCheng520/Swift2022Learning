//
//  MSPrivacyManager.m
//  MSBusiness
//
//  Created by pactera on 2020/11/21.
//

#import "MSPrivacyManager.h"
#import "MSPrivacyRepository.h"
#import "MSPrivacyPolicyView.h"
#import "MSNotificationConst.h"
#import "MSUIConfiguration.h"
#import "MSRouterUrl.h"
#import <OEMTheme/OEMHGAlertController.h>

@interface MSPrivacyManager ()

@property (nonatomic, assign) BOOL isNeedUpdate;
@property (nonatomic, strong) MSPrivacyResult *updateResult;

@end

@implementation MSPrivacyManager

+ (instancetype)shareManager {
    static MSPrivacyManager *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[MSPrivacyManager alloc] init];
    });
    return manager;
}

- (instancetype)init {
    if (self = [super init]) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginSuccessNotification:) name:kMideaLoginSuccessNotification object:nil];
    }
    return self;
}

//检查隐私协议是否有更新
- (void)checkPrivacyUpdate {
    if (self.isNeedUpdate) {   //防止多个弹框一起弹出
        return;
    }
    WEAK_SELF;
    [MSPrivacyRepository checkPrivacyUpdateWithSuccess:^(MSPrivacyResult *result) {
        STRONG_SELF;
        self.updateResult = result;
        if (result.update == 1) {
            self.isNeedUpdate = YES;
            [[NSNotificationCenter defaultCenter] postNotificationName:kMideaPrivacyUpdateNotification object:nil userInfo:nil];
        } else {
            self.isNeedUpdate = NO;
        }
        
    } failure:^(MSBusinessError *error) {
        STRONG_SELF;
        self.isNeedUpdate = NO;
    }];
}

//更新用户同意的隐私协议版本号
- (void)updateUserPrivacyVersionWithSuccess:(MSPrivacyRepositorySuccessBlock)success failure:(MSPrivacyRepositoryFailureBlock)failure {
    [MSPrivacyRepository privacyUpdateWithVersion:self.updateResult.privateVersion?:@"" Success:success failure:failure];
}

//弹框提示
- (void)showPrivacyUpdateAlertControllerWithPageName:(NSString *)pageName sourceController:(UIViewController *)sourceController {
    
    MSPrivacyPolicyView* privacyPolicyView = [[MSPrivacyPolicyView alloc]initWithType:MSPrivacyPolicyViewType_Update];
    HGAlertController* alertController = [[OEMHGAlertController alloc]initWithContentView:privacyPolicyView];
    UINavigationController* alertNavigationController = [[UINavigationController alloc]initWithRootViewController:alertController];
    [alertNavigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
    [alertNavigationController.navigationBar setShadowImage:[UIImage new]];
    alertNavigationController.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:alertNavigationController animated:NO completion:nil];
    
    WEAK_SELF;
    privacyPolicyView.agreeBlock = ^{
        STRONG_SELF;
        [self updateUserPrivacyVersionWithSuccess:^{
            self.isNeedUpdate = NO;
            [alertController dismiss];
        } failure:^(MSBusinessError *error) {
            [MSUIConfiguration sh_showBlackToastHudToView:alertController.view text:error.localizedDescription];
        }];
        
    };
    privacyPolicyView.exitBlock = ^{
        STRONG_SELF;
        self.isNeedUpdate = NO;
        [alertController dismiss];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [OEMRouter handleURL:MSRouterLoginIndex withParams:@{@"previousPageName":pageName} sourceController:sourceController andCompletion:nil];
        });
        [[NSNotificationCenter defaultCenter] postNotificationName:kMideaQuitLoginNotification object:nil userInfo:nil];
        
    };
    privacyPolicyView.privacyBlock = ^{
        [OEMRouter handleURL:MSRouterHtmlIndex withParams:@{@"type" : @(1)}];
    };
    privacyPolicyView.softwareBlock = ^{
        [OEMRouter handleURL:MSRouterHtmlIndex withParams:@{@"type" : @(2)}];
    };
    
}

//判断是否有更新
- (BOOL)privacyNeedUpdate {
    return self.isNeedUpdate;
}

//监听登录成功的通知
- (void)loginSuccessNotification:(NSNotification *)notification {
    self.isNeedUpdate = NO;
}


@end
