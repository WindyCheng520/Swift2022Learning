//
//  MSPrivacyResult.m
//  MSBusiness
//
//  Created by pactera on 2020/11/21.
//

#import "MSPrivacyResult.h"

NSString *const MSBusinessErrorDomain = @"MSBusinessErrorDomain";

@implementation MSPrivacyResult



@end
