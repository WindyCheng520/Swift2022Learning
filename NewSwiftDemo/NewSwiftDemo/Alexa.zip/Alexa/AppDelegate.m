//
//  AppDelegate.m
//  MSOEM
//
//  Created by yanghy on 2020/5/14.
//  Copyright © 2020 Midea. All rights reserved.
//

#import "AppDelegate.h"
#import <MSBusiness/MSRouterUrl.h>
#import <DolphinRouter/OEMRouter.h>
#import <OEMTheme/MSOEMThemesManager.h>
#import <OEMBluetooth/OEMMSNetAccessManager.h>
#import <OEMFoundation/OEMCustomize.h>
//正式环境开启AvoidCrash
#if AppStore_ENV==1
#import <AvoidCrash/AvoidCrash.h>
#endif

//非AppStore target，开启性能监控组件
#if AppStore_ENV==0
#import <DolphinPerformance/DOFPerformanceManager.h>
#endif

#import <MSBusiness/MSAppInfo.h>
#import <OEMFoundation/OEMMacros.h>
#import <React/RCTI18nUtil.h>

@interface AppDelegate ()
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

    [super application:application didFinishLaunchingWithOptions:launchOptions withType:OEMEnvironmentType_Dev];
    
    [self setWindowRootViewController];
    [self configureAVoidCrash];
    [self showPerformance];
    //初始化 MS配网SDK
    [OEMMSNetAccessManager shareManager];
    //适配阿拉伯
    if(isRTL()){
       [UIView appearance].semanticContentAttribute = UISemanticContentAttributeForceRightToLeft;
       [UISearchBar appearance].semanticContentAttribute = UISemanticContentAttributeForceRightToLeft;
        [[UINavigationBar appearance] setSemanticContentAttribute:UISemanticContentAttributeForceRightToLeft];

    }else{
        [UIView appearance].semanticContentAttribute = UISemanticContentAttributeForceLeftToRight;
        [UISearchBar appearance].semanticContentAttribute = UISemanticContentAttributeForceLeftToRight;
         [[UINavigationBar appearance] setSemanticContentAttribute:UISemanticContentAttributeForceLeftToRight];
    }
   
    return YES;
}

//设置跟控制器
- (void)setWindowRootViewController {
    [[MSOEMThemesManager sharedManager] configureThemeEnable:[OEMCustomize getBoolValueWithKey:@"EnableDarkMode"]];
    if (!self.window) {
        self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    }
    
    UIViewController *viewCtl = [OEMRouter objectForURL:MSRouterHomeIndex];
    if (!viewCtl) {
        viewCtl = UIViewController.new;
    }
    self.window.rootViewController = viewCtl;
    [self.window makeKeyAndVisible];
}

// 容错处理AvoidCrash
- (void)configureAVoidCrash {
#if AppStore_ENV==1
    [AvoidCrash makeAllEffective];
    NSArray *arr = @[@"NSString", @"NSArray", @"NSNumber", @"NSDictionary", @"NSNull"];
    [AvoidCrash setupNoneSelClassStringsArr:arr];
    [AvoidCrash setupNoneSelClassStringPrefixsArr:@[@"BH", @"MS", @"Midea",@"midea"]];
#endif
}

// 展示监控组件
- (void)showPerformance {
#if AppStore_ENV==0
    [[DOFPerformanceManager shareManager] install];
#endif
}

//- (UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window {
//    NSString * allowRotationStr = [[NSUserDefaults standardUserDefaults] objectForKey:@"allowRotation"];
//    if ([allowRotationStr isEqualToString:@"1"]) {
//        return UIInterfaceOrientationMaskLandscapeLeft;
//    }else if ([allowRotationStr isEqualToString:@"2"]){
//        return UIInterfaceOrientationMaskLandscapeRight;
//    }
//    NSString *videoAllowRotation = [[NSUserDefaults standardUserDefaults] objectForKey:@"videoAllowRotation"];
//    if ([videoAllowRotation isEqualToString:@"1"]) {
//        //菜谱视频跟随系统横竖屏播放
//        return UIInterfaceOrientationMaskAll;
//    }
//    return UIInterfaceOrientationMaskPortrait;
//}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    [super applicationDidBecomeActive:application];
}

#pragma mark - Push
- (void)application:(UIApplication *)app didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    [super application:app didRegisterForRemoteNotificationsWithDeviceToken:deviceToken];
}

- (void)application:(UIApplication *)app didFailToRegisterForRemoteNotificationsWithError:(nonnull NSError *)error {
    [super application:app didFailToRegisterForRemoteNotificationsWithError:error];
}

#pragma mark  收到APNs 远程推送  程序在前台 和后台 都会走这个方法
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(nonnull NSDictionary *)userInfo fetchCompletionHandler:(nonnull void (^)(UIBackgroundFetchResult))completionHandler {
    [super application:application didReceiveRemoteNotification:userInfo fetchCompletionHandler:completionHandler];
}

#pragma  mark 点击通知栏 唤醒APP
- (void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void (^)(void))completionHandler  API_AVAILABLE(ios(10.0)) {
    [super userNotificationCenter:center
   didReceiveNotificationResponse:response
            withCompletionHandler:completionHandler];
}

- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification {
    [super application:application didReceiveLocalNotification:notification];
}

// iOS10特性。App在前台获取通知
- (void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions))completionHandler  API_AVAILABLE(ios(10.0)) {
    [super userNotificationCenter:center
          willPresentNotification:notification
            withCompletionHandler:completionHandler];
}

#pragma mark - OpenUrl
- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<NSString*, id> *)options {
    BOOL result = [super application:app openURL:url options:options];
    
    //process
    
    return result;
}

@end
