//
//  MSMinePresenter.m
//  MSMine
//
//  Created by 及时行乐 on 2020/7/13.
//

#import "MSMinePresenter.h"
#import "MSMineItem.h"
#import "MSMineBundle.h"
#import <MSBusiness/BGFMDB.h>
#import <MSBusiness/MSHomeProtocol.h>
#import <OEMFoundation/OEMCustomize.h>

@interface MSMinePresenter ()

@property (nonatomic, strong) NSMutableArray<MSMineItem*> *mainItems;

@property (nonatomic, strong) NSMutableArray<MSMineItem*> *freeAccountItems;  //未登录
@property (nonatomic, strong) NSMutableArray<MSMineItem*> *loginAccountItems;
@property (nonatomic, strong) NSMutableArray<MSMineItem*> *extendAbilityItems;

@end

@implementation MSMinePresenter

- (void)loadCellData {
    self.mainItems = [NSMutableArray array];
    self.freeAccountItems = [NSMutableArray array];
    self.loginAccountItems = [NSMutableArray array];
    self.extendAbilityItems = [NSMutableArray array];
    
    MSMineItem *serviceItem = [MSMineItem new];
    serviceItem.title = MSResourceString(@"mine_page_service");
    serviceItem.icon = @"";
    serviceItem.desc = nil;

    
    MSMineItem *moreItem = [MSMineItem new];
    moreItem.title = MSResourceString(@"mine_page_more");
    moreItem.icon = @"";
    moreItem.desc = nil;
    [self.mainItems addObjectsFromArray:@[serviceItem, moreItem]];
    
    
    
    MSMineItem *myDevicesItem = [MSMineItem new];
    myDevicesItem.title = MSResourceString(@"mine_page_my_device");
    myDevicesItem.icon = @"me_ic_decice";
    myDevicesItem.desc = nil;

//    MSMineItem *privacyItem = [MSMineItem new];
//    privacyItem.title = MSResourceString(@"me_legal_provisions");
//    privacyItem.icon = @"me_ic_privacy";
//    privacyItem.desc = nil;
    
    MSMineItem *helpItem = [MSMineItem new];
    helpItem.title = MSResourceString(@"mine_page_help");
    helpItem.icon = @"me_ic_privacy";
    helpItem.desc = nil;

    MSMineItem *settingItem = [MSMineItem new];
    settingItem.title = MSResourceString(@"mine_page_settings");
    settingItem.icon = @"me_ic_setting";
    settingItem.desc = nil;
    
    MSMineItem *item1 = [MSMineItem new];
    item1.title = @"Amazon Alexa";//MSResourceString(@"Alexa");
    item1.icon = @"me_services_alexa";
    item1.desc = nil;

    MSMineItem *item2 = [MSMineItem new];
    item2.title =  @"Google Assistant"; //MSResourceString(@"me_legal_provisions");
    item2.icon = @"me_services_assistant";
    item2.desc = nil;

    // 最新需求去掉Duer
//    MSMineItem *item3 = [MSMineItem new];
//    item3.title = @"Duer";   //MSResourceString(@"mine_page_settings");
//    item3.icon = @"me_services_duer";
//    item3.desc = nil;
    
    [self.freeAccountItems addObjectsFromArray:@[helpItem]];
    [self.loginAccountItems addObjectsFromArray:@[myDevicesItem, helpItem]];

    
    NSMutableArray * exfuncItems = [NSMutableArray new];
    if ([OEMCustomize getBoolValueWithKey:@"EnableAlexa"]) {
        [exfuncItems addObject:item1];
    }
    if ([OEMCustomize getBoolValueWithKey:@"EnableGoogleAssistant"]) {
        [exfuncItems addObject:item2];
    }
    
    [self.extendAbilityItems addObjectsFromArray:exfuncItems];
    
    if ([self.view respondsToSelector:@selector(presenterLoadDataCompletion:)]) {
        [self.view presenterLoadDataCompletion:self];
    }
    
}

- (void)getUserInfo {
    @weakify(self)
    [[MSUserInfoManager shareManager] updateUserInfoFromNetworkWithSuccess:^{
        @strongify(self)
        if ([self.view respondsToSelector:@selector(presenter:getUserInfoCompletion:)]) {
            [self.view presenter:self getUserInfoCompletion:nil];
        }
    } failure:^(MSBusinessError *error) {
        @strongify(self)
        if ([self.view respondsToSelector:@selector(presenter:getUserInfoCompletion:)]) {
            [self.view presenter:self getUserInfoCompletion:error];
        }
    }];
}

- (void)getUserDeviceCount {
    
    id<MSHomeProtocol> homeService = [OEMRouter getServiceInstance:@protocol(MSHomeProtocol)];
    if (homeService) {
        WEAK_SELF;
        [homeService getUserDevicesCount:^(NSInteger count) {
            STRONG_SELF;
            [self updateDeviceDataWithCount:count];
        }];
    }
    
}

- (void)updateDeviceDataWithCount:(NSInteger)count {
    if (self.loginAccountItems.count > 0) {
        MSMineItem* deviceItem = self.loginAccountItems[0];
        if (count > 0) {
            deviceItem.desc = [NSString stringWithFormat:@"%ld", count];
        } else {
            deviceItem.desc = nil;
        }
        
        if ([self.view respondsToSelector:@selector(presenterLoadDataCompletion:)]) {
            [self.view presenterLoadDataCompletion:self];
        }
    }
}

- (void)clearDeviceData {
    if (self.loginAccountItems.count > 0) {
        MSMineItem* deviceItem = self.loginAccountItems[0];
        deviceItem.desc = nil;
        
        if ([self.view respondsToSelector:@selector(presenterLoadDataCompletion:)]) {
            [self.view presenterLoadDataCompletion:self];
        }
    }
}



@end
