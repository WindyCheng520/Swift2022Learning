//
//  MSMinePresenter.h
//  MSMine
//
//  Created by 及时行乐 on 2020/7/13.
//

#import <MSBusiness/MVPPresenter.h>
#import <MSBusiness/MSBusinessError.h>
#import <MSBusiness/MSUserInfoManager.h>

@class MSMinePresenter;
@class MSMineItem;
@protocol MSMineViewProtocol <MVPViewProtocol>

- (void)presenter:(MSMinePresenter *)presenter getUserInfoCompletion:(MSBusinessError *)error;
- (void)presenterLoadDataCompletion:(MSMinePresenter *)presenter;

@end


@interface MSMinePresenter : MVPPresenter<id<MSMineViewProtocol>>


@property (nonatomic, readonly) NSMutableArray<MSMineItem*> *mainItems;  

@property (nonatomic, readonly) NSMutableArray<MSMineItem*> *freeAccountItems;  //未登录
@property (nonatomic, readonly) NSMutableArray<MSMineItem*> *loginAccountItems;   //已登录
@property (nonatomic, readonly) NSMutableArray<MSMineItem*> *extendAbilityItems;

- (void)loadCellData;
- (void)getUserInfo;
- (void)getUserDeviceCount;
- (void)clearDeviceData;

@end

