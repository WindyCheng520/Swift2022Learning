//
//  MSMineService.h
//  MSMine
//
//  Created by pactera on 2020/7/28.
//

#import <Foundation/Foundation.h>
#import <MSBusiness/MSMeProtocol.h>
#import <DolphinRouter/OEMRouterBaseService.h>

@interface MSMineService : OEMRouterBaseService<MSMeProtocol>

@end
