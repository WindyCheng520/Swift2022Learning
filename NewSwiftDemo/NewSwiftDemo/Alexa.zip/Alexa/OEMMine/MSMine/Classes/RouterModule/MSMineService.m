//
//  MSMineService.m
//  MSMine
//
//  Created by pactera on 2020/7/28.
//

#import "MSMineService.h"
#import <MSBusiness/BGFMDB.h>
#import <MSBusiness/MSUserInfoManager.h>
#import <OEMLogger/OEMOCLog.h>
#import <OEMLogger/OEMLogger-Swift.h>
#import "MSMineRepository.h"

@DOFService(MSMeProtocol, MSMineService)

@interface MSMineService ()


@end

@implementation MSMineService

- (NSDictionary *)getLocalUserInfo {
    MSUserInfo *userInfo = [MSUserInfoManager shareManager].userInfoModel;
    if (userInfo) {
        return @{@"email" : userInfo.email?:@"",
                 @"nickName" : userInfo.nickName?:@"",
                 @"account" : userInfo.account?:@"",
                 @"uid" : userInfo.uid?:@"",
                 @"account_status" : userInfo.account_status?:@"",
                 @"profile_pic_url" : userInfo.profile_pic_url?:@""
        };
    }
    return nil;
}

- (void)getUserInfoWithSuccess:(void(^)(NSString* successCallBack))successCallBack fail:(void(^)(NSString* failCallBack))failCallBack {

    __weak typeof(self) weakSelf = self;
    [[MSUserInfoManager shareManager] updateUserInfoFromNetworkWithSuccess:^{
        NSString *jsonString = [weakSelf stringJsonWithDictionary:@{
            @"errorCode" : @"0",
            @"errorMessage" : @"",
        }];
        safeCallBlock(successCallBack, jsonString);
    } failure:^(MSBusinessError *error) {
        NSString *jsonString = [weakSelf stringJsonWithDictionary:@{
            @"errorCode" : @(error.code),
            @"errorMessage" : error.localizedDescription,
        }];
        safeCallBlock(failCallBack, jsonString);
    }];
    
}

- (void)uploadLog:(void (^)(BOOL isSuccess, NSDictionary * data, NSError * error))completion progressBlock:(void (^)(float p) )progressBlock{
    NSString * file = [OEMLogTools getNewOnlineLogFile];
    [OEMOCLog flushSyncWithTimeout:2 completion:^(BOOL success) {
        [MSMineRepository uploadOnlineLogWithFilePath:file success:^(NSDictionary *result) {
            safeCallBlock(completion, YES, nil, nil);
            [self silenceUploadMSDKLog];
        } progressBlock:^(float progress) {
            safeCallBlock(progressBlock, progress);
        } failure:^(NSError *error) {
            safeCallBlock(completion, NO, nil, error);
        }];
    }];
}

- (void)silenceUploadMSDKLog{
    NSString * docPath = [NSSearchPathForDirectoriesInDomains(NSDocumentationDirectory, NSAllDomainsMask, YES) firstObject];
    NSString * fileDir = [docPath stringByAppendingPathComponent:@"MideaSDKLog"];
    NSString * fileName = [OEMLogTools getLastedModifyFileInDirectory:fileDir fileSuffix:@"txt"];
    if ([[NSFileManager defaultManager] fileExistsAtPath:fileName]) {
        [MSMineRepository uploadOnlineLogWithFilePath:fileName success:^(NSDictionary *result) {
            
        } progressBlock:^(float progress) {
    
        } failure:^(NSError *error) {

        }];
    }
}

//字典转Json字符串
- (NSString *)stringJsonWithDictionary:(NSDictionary *)dic {
    NSError *parseError = nil;
    NSString *jsonString = nil;
    
    if (dic && [dic isKindOfClass:[NSDictionary class]]) {
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    
    return jsonString;
}


@end
