//
//  MSMineRouterModule.m
//  MSMine
//
//  Created by syp on 2020/6/11.
//

#import "MSMineRouterModule.h"
#import <DolphinRouter/OEMRouter.h>
#import <MSBusiness/MSRouterUrl.h>
//#import "MSBindAlexaViewController.h"

@DOFModule(MSMineRouterModule)
@interface MSMineRouterModule()<OEMModuleProtocol>

@end

@implementation MSMineRouterModule

- (NSInteger)modulePriority {
    return 2;
}

- (void)modInit:(OEMContext *)context {
    [OEMRouter registerWithURL:MSRouterMineIndex toClass:@"MSMineViewController"];
    [OEMRouter registerWithURL:MSRouterMineAlexa toClass:@"MSBindAlexaViewController"];
    [OEMRouter registerWithURL:MSRouterMineGoogleAuth toClass:@"MSBindGoogleAssitantVC"];
    [OEMRouter registerWithURL:MSRouterMineUploadLog toClass:@"MSUploadLogViewController"];
}

@end
