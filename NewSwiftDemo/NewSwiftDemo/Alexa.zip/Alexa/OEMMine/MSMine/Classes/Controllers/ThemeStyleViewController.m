//
//  ThemeStyleViewController.m
//  OEMTheme
//
//  Created by Neil 韦学宁 on 2021/7/8.
//

#import "ThemeStyleViewController.h"
#import "FollowSystemTraitCell.h"
#import "OEMThemeCell.h"
#import "MSMineBundle.h"

@interface ThemeStyleViewController ()<UITableViewDelegate, UITableViewDataSource>

@property(nonatomic, strong)UITableView * tableView;

@end

@implementation ThemeStyleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero];
    [self.view addSubview:self.tableView];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
    self.tableView.estimatedSectionHeaderHeight = 0;
    self.tableView.estimatedSectionFooterHeight = 0;
    [self.tableView registerClass:[FollowSystemTraitCell class] forCellReuseIdentifier:NSStringFromClass([FollowSystemTraitCell class])];
    [self.tableView registerClass:[OEMThemeCell class] forCellReuseIdentifier:NSStringFromClass([OEMThemeCell class])];
    self.title = @"Dark Mode";
    [self configureOEMTheme];
}

- (void)configureOEMTheme{
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    [self.view configureThemeTag:OEMThemesTag_UIView_Background];
    [self.tableView configureThemeTag:OEMThemesTag_UIView_Background];
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        [weakSelf setNavButton];
    } callImmidiately:YES];
}

- (void)setNavButton{
    if (OEMThemeIsDarkMode) {
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_dm")];
    }else{
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_lg")];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (![self supportTraitChangeWithSystemSetting]) {
        //iOS 13以下
        return [self cellSourceOfOEMThemeInTable:tableView indexPath:indexPath];
    }
    if ([MSOEMThemesManager sharedManager].themeFollowSystem) {
        return [self cellSourceOfFollowSystemTraitInTable:tableView];
    }else{
        if (indexPath.section == 0) {
            return [self cellSourceOfFollowSystemTraitInTable:tableView];
        }
        return [self cellSourceOfOEMThemeInTable:tableView indexPath:indexPath];
    }
    return [UITableViewCell new];
}

- (FollowSystemTraitCell *)cellSourceOfFollowSystemTraitInTable:(UITableView *)tableView{
    FollowSystemTraitCell * cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([FollowSystemTraitCell class])];
    WEAKSELF
    [cell.switchButton setOn:[MSOEMThemesManager sharedManager].themeFollowSystem];
    cell.followSystemChange = ^(BOOL followSystem) {
        [MSOEMThemesManager sharedManager].themeFollowSystem = followSystem;
        [weakSelf.tableView reloadData];
    };
    return cell;
}

- (OEMThemeCell *)cellSourceOfOEMThemeInTable:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath{
    OEMThemeCell * cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([OEMThemeCell class])];
    [cell setDarkTitle:(indexPath.row == 1)];
    BOOL hidden = YES;
    if (!OEMThemeIsDarkMode && indexPath.row == 0) {
        hidden = NO;
    }else if(OEMThemeIsDarkMode && indexPath.row == 1){
        hidden = NO;
    }
    if (indexPath.row == 0) {
        [cell addThemeBottomSeplineWithLeading:16 trailing:0];
    }else{
        [cell.contentView disableSepline];
    }
    cell.checkIcon.hidden = hidden;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    UITableViewCell * cell = [tableView cellForRowAtIndexPath:indexPath];
    if ([cell isKindOfClass:[FollowSystemTraitCell class]]) {
        return;
    }
    if ([cell isKindOfClass:[OEMThemeCell class]]) {
        OEMThemeCell * conCell = (OEMThemeCell *)cell;
        [[MSOEMThemesManager sharedManager] updateStyle:conCell.isdark ? OEMThemesStyle_Dark : OEMThemesStyle_Light];
        [self.tableView reloadData];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (![self supportTraitChangeWithSystemSetting]) {
        //dark light
        return 2;
    }
    if ([MSOEMThemesManager sharedManager].themeFollowSystem) {
        //system
        return 1;
    }
    if (section == 0) {
        return 1;
    }else{
        return 2;
    }
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (![self supportTraitChangeWithSystemSetting]) {
        return 56;
    }
    if ([MSOEMThemesManager sharedManager].themeFollowSystem) {
        //system
        return 84;
    }
    //both
    if (indexPath.section == 0) {
        return 84;
    }else{
        return 56;
    }
    return 84;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (![self supportTraitChangeWithSystemSetting]) {
        return 1;
    }
    if ([MSOEMThemesManager sharedManager].themeFollowSystem) {
        return 1;
    }
    return 2;
}

- (BOOL)supportTraitChangeWithSystemSetting{
    if ([UIDevice currentDevice].systemVersion.floatValue >= 13.0) {
        return YES;
    }
    return NO;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *view = [[UIView alloc] init];
    [view configureThemeTag:OEMThemesTag_UIView_Background];
    return view;
}

//heightForHeaderInSection
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 8;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
