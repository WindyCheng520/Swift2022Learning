//
//  MSMineViewController.m
//  MSMine
//
//  Created by syp on 2020/6/11.
//

#import "MSMineViewController.h"
#import <MSBusiness/MSRouterUrl.h>
#import "MSMineBundle.h"
#import "MSMineItemTableViewCell.h"
#import "MSMineHeaderView.h"
#import "MSMineAdditionalServiceCell.h"
#import "MSMineItem.h"
#import <MSBusiness/MSMessageCenterProtocol.h>
#import <MSBusiness/MideaTool.h>
#import <OEMFoundation/HGInternationalization.h>
#import <MSBusiness/MSNotificationConst.h>
#import <MSBusiness/MSPrivacyManager.h>
#import "ThemeStyleViewController.h"
#import "MSBindAlexaViewController.h"
//#import <MSMine/MSMine-Swift.h>
#import <OEMTheme/UIViewController+OEMTheme.h>
#import <OEMFoundation/OEMCustomize.h>

static NSString * const MSMineItemTableViewCellIdentifier = @"MSMineItemTableViewCellIdentifier";
static NSString * const kMSMineAdditionalServiceCellIdentifier = @"MSMineAdditionalServiceCellIdentifier";
@interface MSMineViewController () <UITableViewDelegate, UITableViewDataSource, MSMineHeaderViewDelegate>


@property (nonatomic, strong) HGButton *messageButton;
@property (nonatomic, strong) HGButton *msgCountView;
@property (nonatomic, strong) HGButton *settingButton;
@property (nonatomic, strong) MSMineHeaderView *headerView;
@property (nonatomic, strong) HGTableView *tableView;
//第二个section的数据源
@property (nonatomic, strong)NSArray *settingSectionDataSource;

@property (nonatomic, copy)NSString *tips;

@property (assign, nonatomic)__block NSInteger count;  //未读数量

@end

@implementation MSMineViewController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.presenter = [[MSMinePresenter alloc]initWithView:self];
        
        _messageButton = [HGButton new];
        _headerView = [MSMineHeaderView new];
        _tableView = [HGTableView new];
        _msgCountView = [HGButton new];
        _settingButton = [HGButton new];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
        
    [self.messageButton setImage:MSResourceImage(@"ic_n_msg") forState:UIControlStateNormal];
    [self.messageButton addTarget:self action:@selector(clickMessageButton) forControlEvents:UIControlEventTouchUpInside];
    self.messageButton.hidden = YES;
    
    self.msgCountView.titleLabel.font = [UIFont systemFontOfSize:10];
    self.msgCountView.backgroundColor = RGB_HEX(0xFF4627);
    self.msgCountView.titleEdgeInsets = UIEdgeInsetsMake(3, 3, 3, 3);
    self.msgCountView.userInteractionEnabled = NO;
    [self.msgCountView setTitle:@"" forState:UIControlStateNormal];
    self.msgCountView.layer.cornerRadius = 3.5;
    self.msgCountView.clipsToBounds = YES;
    [self.view addSubview:self.msgCountView];
    
    self.headerView.delegate = self;
    self.headerView.bounds = CGRectMake(0, 0, SCREEN_WIDTH, 100 + 48 + STATUSBAR_HEIGHT);
    self.tableView.tableHeaderView = self.headerView;
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.scrollEnabled = NO;
   // self.tableView.rowHeight = SCALE_SIZE_SMALL(64);
    [self.tableView registerClass:[MSMineItemTableViewCell class] forCellReuseIdentifier:MSMineItemTableViewCellIdentifier];
    [self.tableView registerClass:[MSMineAdditionalServiceCell class] forCellReuseIdentifier:kMSMineAdditionalServiceCellIdentifier];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.tableFooterView = [[UIView alloc] init];
    [self.view addSubview:self.tableView];
    
    [self.settingButton setImage:MSResourceImage(@"me_ic_setting") forState:UIControlStateNormal];
    [self.settingButton addTarget:self action:@selector(onSetingButton:) forControlEvents:UIControlEventTouchUpInside];
    //放最后，避免被UITableView挡住
    [self.view addSubview:self.settingButton];
    [self.view addSubview:self.messageButton];
    
    [self makeConstraints];
    [self.presenter loadCellData];
//    [self addTapGestureRecognize]; //整个view添加手势
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loginOutSuccess:) name:kMideaQuitLoginNotification object:nil];
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(languageDidChanged:) name:MSInternationalizationDidUpdateLanguageNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deviceCountNeedRefresh:) name:kMideaDeviceListDataNeedReloadNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidBecomActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(privacyUpdate:) name:kMideaPrivacyUpdateNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(passwordModify:) name:kMideaPasswordModifyNotification object:nil];
    [self configureOEMTheme];
}

- (void)configureOEMTheme{
    [self.view configureThemeTag:OEMThemesTag_UIView_Background];
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    [self.tableView configureThemeTag:OEMThemesTag_UIView_Background];
    [self.headerView configureThemeTag:OEMThemesTag_UIView_Foreground];
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        [weakSelf.tableView reloadData];
        if (OEMThemeIsDarkMode) {
            [self.settingButton setImage:MSResourceImage(@"me_ic_setting_dm") forState:UIControlStateNormal];
            [self.messageButton setImage:MSResourceImage(@"ic_n_msg_dm") forState:UIControlStateNormal];
           
        }else{
            [self.settingButton setImage:MSResourceImage(@"me_ic_setting") forState:UIControlStateNormal];
            [self.messageButton setImage:MSResourceImage(@"ic_n_msg") forState:UIControlStateNormal];
        }
        [weakSelf updateNavigationAppearance];
    } callImmidiately:YES];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
     self.msgCountView.hidden = YES;
     self.messageButton.hidden = NO;
    
    if ([MSUserInfoManager shareManager].isLogin) {
        NSString *nickname = [MSUserInfoManager shareManager].userInfoModel.nickName ?: [MSUserInfoManager shareManager].loginInfoModel.nickname;
        NSString *headIcon = [MSUserInfoManager shareManager].userInfoModel.profile_pic_url ?: [MSUserInfoManager shareManager].loginInfoModel.headPhoto;
        [self.headerView refreshDataWithLogin:YES nickname:nickname headIcon:headIcon];
        [self.presenter getUserInfo];
        [self.presenter getUserDeviceCount];
    } else {
        [self.headerView refreshDataWithLogin:NO nickname:nil headIcon:nil];
        [self.presenter clearDeviceData];
    }
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.6 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self refreshMessageCount];
    });
    
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    if ([MSUserInfoManager shareManager].isLogin) {
        //检查是否需要弹框更新隐私协议
        if ([[MSPrivacyManager shareManager] privacyNeedUpdate]) {
            [[MSPrivacyManager shareManager] showPrivacyUpdateAlertControllerWithPageName:@"personalPage" sourceController:self];
        }
      //  self.messageButton.hidden = NO;
    }else{
      //  self.messageButton.hidden = YES;
    }
    //self.settingButton.hidden = NO;
}

- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    //self.settingButton.hidden = YES;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (BOOL)navigationBarHidden {
    return YES;
}

- (void)makeConstraints {
    
    [self.settingButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.trailing.equalTo(self.settingButton.superview).offset(-16);
        make.top.equalTo(self.settingButton.superview).offset(8 + STATUSBAR_HEIGHT);
        make.size.mas_equalTo(CGSizeMake(28, 28));
    }];
    
    [self.messageButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(28, 28));
        make.trailing.equalTo(self.settingButton.mas_leading).offset(-19);
        make.centerY.equalTo(self.settingButton);
    }];
    
    [self.msgCountView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.mas_equalTo(7);
        make.width.mas_equalTo(7);
        make.trailing.equalTo(self.messageButton).offset(-2.5);
        make.top.equalTo(self.messageButton).offset(2.5);
    }];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.equalTo(self.view);
        make.top.equalTo(self.view.mas_top);
        make.bottom.equalTo(self.view);
    }];
}

#pragma mark - UITableViewDelegate, UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if ([self.presenter.extendAbilityItems count] == 0) {
        return 1;
    }
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if ([self.presenter.extendAbilityItems count] == 0) {
        return self.settingSectionDataSource.count;
    }
    return section == 0 ? 1 : self.settingSectionDataSource.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if ([self.presenter.extendAbilityItems count] > 0) {
        if (indexPath.section == 0) {
            return 124;
        }
        //扩展服务区域高度
        return 64;
    }else{
        return 64;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 8.;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *view = [[UIView alloc] init];
    view.backgroundColor = RGB(250, 250, 250);
    [view configureThemeTag:OEMThemesTag_UIView_Background];
    return view;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([self.presenter.extendAbilityItems count] > 0 &&
        indexPath.section == 0) {
        MSMineAdditionalServiceCell *cell = [tableView dequeueReusableCellWithIdentifier:kMSMineAdditionalServiceCellIdentifier forIndexPath:indexPath];
        cell.items0 = self.presenter.mainItems;
        cell.items = self.presenter.extendAbilityItems;
        WEAK_SELF;
        cell.block = ^(NSInteger index) {
            if(ISLOGIN){
                if (index == 0) {
                    MSBindAlexaViewController  *dest = [[MSBindAlexaViewController alloc] init];
                    dest.status =  AlexaStatusBindUnknow;
                    [weak_self.navigationController pushViewController:dest animated:YES];
                    return;
                }else if(index == 1){
                    [OEMRouter handleURL:MSRouterMineGoogleAuth withParams:@{@"a": @"b"}];
                    return;
                    UIViewController * googleVC = [OEMRouter objectForURL:MSRouterMineGoogleAuth];
                    [weak_self.navigationController pushViewController:googleVC animated:YES];
                }
               [weak_self toastText:weak_self.tips];
            }else{
                [weak_self clickToLogin];
            }
            
        };
        return cell;
    }else{
        
        MSMineItemTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MSMineItemTableViewCellIdentifier forIndexPath:indexPath];
        if (indexPath.row < self.settingSectionDataSource.count) {
            MSMineItem* item = [self.settingSectionDataSource objectAtIndex:indexPath.row];
            [cell refreshDataWithImage:item.icon title:item.title subtitle:item.desc];
            if (indexPath.row < [self.settingSectionDataSource count] - 1) {
                [cell addThemeBottomSeplineWithLeading:16 trailing:0];
            }else{
                [cell disableSepline];
            }
        }
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    BOOL isVoiceExtendSupport = [OEMCustomize getBoolValueWithKey:@"EnableAlexa"] || [OEMCustomize getBoolValueWithKey:@"EnableGoogleAssistant"];
    if (isVoiceExtendSupport) {
        if (indexPath.section == 0) {
            if(ISLOGIN){
                [self toastText:self.tips];
            }else{
                [self clickToLogin];
            }
            return;
        }
        [self clickNonVoiceSection:indexPath];
    }else{
        [self clickNonVoiceSection:indexPath];
    }
}

- (void)clickNonVoiceSection:(NSIndexPath *)indexPath{
    if(!ISLOGIN){
        if (indexPath.row == 0) {
            [OEMRouter handleURL:MSRouterReactNativeIndex withParams:@{ MSReactNativeModuleNameDefine : MSReactNativeInnerModule_usehelp}];
        } else if (indexPath.row == 1) {
        }
        return;
    }
       
    if (indexPath.row == 0) {
        if ([MSUserInfoManager shareManager].isLogin) {
            [OEMRouter handleURL:MSRouterReactNativeIndex withParams:@{ MSReactNativeModuleNameDefine: MSReactNativeInnerModule_mydevice}];
        } else {
            [self clickToLogin];
        }
    } else if (indexPath.row == 1) {
        [OEMRouter handleURL:MSRouterReactNativeIndex withParams:@{ MSReactNativeModuleNameDefine : MSReactNativeInnerModule_usehelp}];
    }
}

#pragma mark - clickevent
- (void)clickMessageButton {
    if ([MSUserInfoManager shareManager].isLogin) {
        [OEMRouter handleURL:MSRouterMessageCenterIndex withParams:@{@"count":@(self.count)}];
    } else {
        [self clickToLogin];
//        if (HGCurrentCountry) {
//            void(^viewControllerSuccessBlock)(void) = ^(void) {
//                [DOFRouter handleURL:MSRouterMessageCenterIndex withParams:@{@"count":@(self.count)}];
//            };
//            [DOFRouter handleURL:MSRouterLoginIndex withParams:@{@"previousPageName":@"personalPage", @"viewControllerSuccessBlock":viewControllerSuccessBlock} sourceController:self andCompletion:nil];
//        } else {
//            [DOFRouter handleURL:MSRouterCountryIndex withParams:@{@"enterType":@1} sourceController:self andCompletion:nil];
//        }
    }
}

- (void)onSetingButton:(UIButton *)button{
    [OEMRouter handleURL:MSRouterReactNativeIndex withParams:@{
        MSReactNativeModuleNameDefine : MSReactNativeInnerModule_settings,
        MSReactNativeViewProps: @{
                @"initialRouteName" : @"SettingIndex"
        }
    }];
}

#pragma mark - notification
- (void)loginOutSuccess:(NSNotification *)notification {
    [self.presenter loadCellData];
    [self.presenter clearDeviceData];
    [self.headerView refreshDataWithLogin:NO nickname:nil headIcon:nil];
    [self refreshMessageCount];
    self.messageButton.hidden = NO;
    
    NSDictionary *userInfo = notification.userInfo;
    if ([userInfo[@"account cancellation"] isEqualToString:@"1"]) {  //账号注销
        [self toastText:MSResourceString(@"mine_page_cancellation_scompleted")];
    } else if ([userInfo[@"isLoginExpired"] isEqualToString:@"1"]) {  //登录过期，刷新token失败
        return;
    }
    
    [self.navigationController popToRootViewControllerAnimated:NO];
}

#pragma mark - notification
- (void)passwordModify:(NSNotification *)notification{
    NSDictionary *userInfo = notification.userInfo;
    if ([userInfo[@"type"] isEqualToString:@"change password"]) {  //已登录状态修改密码
        [self toastText:MSResourceString(@"mine_page_me_password_reset_sucessfully")];
    }
}


//- (void)languageDidChanged:(NSNotification *)notification {
//    [self.presenter loadCellData];
//    [self.tableView reloadData];
//    self.tabBarItem.title = MSResourceString(@"mine_page_me");
//}

- (void)deviceCountNeedRefresh:(NSNotification *)notification {
    [self.presenter getUserDeviceCount];
}

- (void)applicationDidBecomActive:(NSNotification *)notification {
    [self refreshMessageCount];
}

- (void)privacyUpdate:(NSNotification *)notification {
    if ([[OEMRouterHandler getCurrentViewController] isKindOfClass:[self class]]) {
        [[MSPrivacyManager shareManager] showPrivacyUpdateAlertControllerWithPageName:@"personalPage" sourceController:self];
    }
}

#pragma mark - MSMineHeaderViewDelegate
- (void)headerViewDidClick:(MSMineHeaderView *)headerView {
    if ([MSUserInfoManager shareManager].isLogin) {
        [OEMRouter handleURL:MSRouterReactNativeIndex withParams:@{ MSReactNativeModuleNameDefine : MSReactNativeInnerModule_profile}];
    } else {
        [self clickToLogin];
    }
}

#pragma mark - MSMineViewProtocol
- (void)presenterLoadDataCompletion:(MSMinePresenter *)presenter {
    if(ISLOGIN){
        self.settingSectionDataSource = self.presenter.loginAccountItems.copy;
    }else{
        self.settingSectionDataSource = self.presenter.freeAccountItems.copy;
    }
    self.tips = MSResourceString(@"mine_page_comming_soon");
    [self.tableView reloadData];
}

- (void)presenter:(MSMinePresenter *)presenter getUserInfoCompletion:(MSBusinessError *)error {
    if (error) {
        [self toastText:error.localizedDescription];
    } else {
        [self.headerView refreshDataWithLogin:YES nickname:[MSUserInfoManager shareManager].userInfoModel.nickName headIcon:[MSUserInfoManager shareManager].userInfoModel.profile_pic_url];
    }
}

#pragma mark - private
- (void)clickToLogin {
    if (HGCurrentCountry) {
        [OEMRouter handleURL:MSRouterLoginIndex withParams:@{@"previousPageName":@"personalPage"} sourceController:self andCompletion:nil];
    } else {
        [OEMRouter handleURL:MSRouterCountryIndex withParams:@{@"enterType":@1} sourceController:self andCompletion:nil];
    }
}

- (void)refreshMessageCount {
    id<MSMessageCenterProtocol> messageService = [OEMRouter getServiceInstance:@protocol(MSMessageCenterProtocol)];
    if (messageService) {
        [messageService unreadMessageCountSuccess:^(NSInteger count) {
            self.msgCountView.hidden = (count == 0);
            self.count = count;
        }];
    }
}


@end

