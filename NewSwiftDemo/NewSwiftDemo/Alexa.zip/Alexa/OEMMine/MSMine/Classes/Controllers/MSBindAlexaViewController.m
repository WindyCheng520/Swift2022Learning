//
//  MSBindAlexaViewController.m
//  MSMine
//
//  Created by WindyCheng on 2021/8/24.
//

#import "MSBindAlexaViewController.h"
#import "MSWKWebViewController.h"

#import <MSBusiness/AuthorizationManager.h>
#import <MSBusiness/MSBusinessError.h>
#import "MSMineBundle.h"
#import <MJExtension/MJExtension.h>

#import <MSBusiness/MSUserDefaultTools.h>

#import "MSAlexaBindCell1.h"
#import "MSAlexaBindCell2.h"
#import "MSAlexaAuthorizationCell.h"

#import "MSAlexaBindEntity.h"
#import "MSMineRepository.h"

#import <MSBusiness/MSBusiness-Swift.h>
#import <MSBusiness/MSAppInfo.h>

//static NSString * const alexaAppBaseUrl = @"https://alexa.amazon.com/spa/skill-account-linking-consent";
//static NSString * const lwaUrl = @"https://www.amazon.com/ap/oa";

static NSString * const kAlexaUrlScheme = @"Alexa://";
@interface MSBindAlexaViewController ()<UITableViewDelegate, UITableViewDataSource>

@property(strong, nonatomic)HGTableView *tableView;
@property(strong, nonatomic)HGButton *rebindButton;
@property (nonatomic, strong) HGButton *bindButton;          //开始绑定接口
@property (nonatomic, strong) HGButton *backButton;          //返回按钮
@property (nonatomic, strong) HGLabel *tipsLabel;            //提示语
@property (nonatomic, strong) MSAlexaBindEntity *entity;



@end

@implementation MSBindAlexaViewController


- (void)msRouterParams:(NSDictionary *)params{
    if(params){
        self.status = [params[@"status"] integerValue];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
  //  self.edgesForExtendedLayout = UIRectEdgeNone;
    
    self.rebindButton = [HGButton new];
    [self.rebindButton setTitleColor:RGB_HEX(0x267AFF) forState:UIControlStateNormal];
    self.rebindButton.titleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
    [self.rebindButton setTitle:MSResourceString(@"alexa_page_alexa_rebind") forState:UIControlStateNormal];
    [self.rebindButton addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    self.rebindButton.hidden = YES;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.rebindButton];
    
    
    self.tableView = [[HGTableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
 //   self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.estimatedRowHeight = 200;
    [self.tableView registerClass:[MSAlexaAuthorizationCell class] forCellReuseIdentifier:NSStringFromClass([MSAlexaAuthorizationCell class])];
    [self.tableView registerClass:[MSAlexaBindCell1 class] forCellReuseIdentifier:NSStringFromClass([MSAlexaBindCell1 class])];
    [self.tableView registerClass:[MSAlexaBindCell2 class] forCellReuseIdentifier:NSStringFromClass([MSAlexaBindCell2 class])];
    self.tableView.allowsSelection = NO;
    self.tableView.showsVerticalScrollIndicator = NO;
    self.tableView.scrollEnabled = NO;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:self.tableView];
    
    self.bindButton = [HGButton new];
    [self.bindButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
    self.bindButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    self.bindButton.backgroundColor = RGB_HEX(0x267AFF);
    self.bindButton.layer.cornerRadius = 22.0;
    self.bindButton.clipsToBounds = YES;
    [self.bindButton setTitle:MSResourceString(@"alexa_page_alexa_start_binding") forState:UIControlStateNormal];
    [self.bindButton addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    self.bindButton.hidden = YES;
    [self.view addSubview:self.bindButton];
    
    
    self.backButton = [HGButton new];
    [self.backButton setTitleColor:RGB_HEX(0x267AFF) forState:UIControlStateNormal];
    self.backButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
    [self.backButton setTitle:MSResourceString(@"alexa_page_alexa_back") forState:UIControlStateNormal];
    self.backButton.layer.cornerRadius = 22.0;
    self.backButton.layer.borderColor = RGBA_HEX(0xBBBBBB,0.3).CGColor;
    self.backButton.layer.borderWidth = 1.0;
    self.backButton.clipsToBounds = YES;
    [self.backButton addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    self.backButton.hidden = YES;
    [self.view addSubview:self.backButton];
    
    
    self.tipsLabel = [HGLabel new];
    self.tipsLabel.textColor = RGBA_HEX(0x000000,0.4);
    self.tipsLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightRegular];
    NSString * contentDes = [NSString stringWithFormat:MSResourceString(@"alexa_page_alexa_unlink_tips"), [MSAppInfo appName]];
    self.tipsLabel.text = contentDes;
    self.tipsLabel.textAlignment = NSTextAlignmentCenter;
    self.tipsLabel.numberOfLines = 0;
   
    [self.tipsLabel sizeToFit];
    [self.view addSubview:self.tipsLabel];
    [self makeConstraints];
    [self configureOEMTheme];
    [self refreshByStatus:self.status];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getAlexaAuthorCodeComple:) name:@"getAlexaAuthorCodeSuccess" object:nil];
    
    if (self.status != AlexaStatusAuthorize) {
        [self getAlexaAuthorCode:NO];
    }
}

-(void)leftBarButtonClick:(UIButton *)button{
    if (self.status == AlexaStatusAuthorize) {
      [[AuthorizationManager sharedManager] cancelAuthorization];
    }
    [super leftBarButtonClick:button];
}

- (void)setNavButton{
    if (OEMThemeIsDarkMode) {
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_dm")];
        [self.backButton setTitleColor:RGBA_HEX(0xFFFFFF,0.9) forState:UIControlStateNormal];
    }else{
        [self createLeftButtonWithImage:MSResourceImage(@"ic_nav_back_lg")];
        [self.backButton setTitleColor:RGBA_HEX(0x000000,0.9)forState:UIControlStateNormal];
    }
}


-(void)click:(UIButton *)sender{
    
    if (self.rebindButton == sender || self.bindButton == sender) {
        if ([BusinessNetWorkTools isNetworkUnreachable]) {
            [self toastText:[MSBusinessError networkDisconnectTips]];
            return;
        }
        
        if ([[AuthorizationManager sharedManager] isInstallApp:kAlexaUrlScheme]) {
            [[AuthorizationManager sharedManager] jumpToAlexa];
        }else{
            [self jumpToWebView];
        }
        
        [self getAlexaAuthorCode:YES];
    }else if (self.backButton == sender){
        [self leftBarButtonClick:nil];
    }else{
    }
}

//跳转LWA
-(void)jumpToWebView{
    AlexaInfo *entity =  [AuthorizationManager sharedManager].entity.alexaInfo;
    NSMutableDictionary *itemDict = [NSMutableDictionary dictionaryWithDictionary:entity.alexaQueryItems];
    [itemDict removeObjectForKey:@"fragment"];
    [itemDict removeObjectForKey:@"skill_stage"];
    [itemDict removeObjectForKey:@"secret"];
    NSURLComponents *components = [[NSURLComponents alloc] initWithURL:[NSURL URLWithString:entity.lwaUrl] resolvingAgainstBaseURL:YES];
    __block NSMutableArray *itemArray = @[].mutableCopy;
    [itemDict enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        NSURLQueryItem *item = [[NSURLQueryItem alloc] initWithName:key value:obj];
        [itemArray addObject:item];
    }];
    components.queryItems = itemArray.copy;
    NSLog(@"跳转lwa----%@", components.URL.absoluteString);
    NSURL *url = components.URL;
    MSWKWebViewController  *dest = [[MSWKWebViewController alloc] init];
    dest.url = url;
    [self.navigationController pushViewController:dest animated:YES];
}


//是否只获取验证码
-(void)getAlexaAuthorCode:(BOOL)onlyGetCode{
    NSMutableArray *paras = @{}.mutableCopy;
    NSString *clientId = [AuthorizationManager sharedManager].entity.alexaInfo.client_id;
    NSString *redirectUri  = [[AuthorizationManager sharedManager].entity.alexaInfo.redirect_uri firstObject];
    [paras setValue:clientId ?: @"" forKey:@"client_id"];
    [paras setValue:@"ALEXA" forKey:@"scope"];
    [paras setValue:redirectUri ?: @"" forKey:@"redirect_uri"];
    [self getAuthorizeResultWithParam:paras.copy onlyGetCode:onlyGetCode];
}


- (void)getAlexaAuthorCodeComple:(NSNotification *)notification {
    if (notification.userInfo[@"code"]) {
        [self getAlexaBindStatusWithGrantType:@"authorization_code" athorCode:notification.userInfo[@"code"] isQuery:NO];
    }
}


//完整流程请求绑定状态
-(void)getAlexaBindStatusWithGrantType:(NSString *)grantType athorCode:(NSString *)athorCode isQuery:(BOOL)isQuery{
    NSDictionary *dic = [AuthorizationManager sharedManager].entity.alexaInfo.alexaQueryItems;
    NSString *clientId =  dic[@"client_id"];
    NSString *clientSecret = dic[@"secret"];
    NSString *redirectUri = dic[@"redirect_uri"];
    @weakify(self)
    [self showLoading];
    [MSMineRepository getAlexaAccessTokenWithGrantType:grantType
                                        alexaAthorCode:athorCode
                                         alexaClientID:clientId
                                     alexaClientSecret:clientSecret
                                           redirectUri:redirectUri
                                               isQuery:isQuery
                                               success:^(NSDictionary *result) {
        @strongify(self)
        [self hideLoading];
        AlexaBindStatusEntity *entity = [AlexaBindStatusEntity mj_objectWithKeyValues:result];
        if ([entity.accountLink.status isEqualToString:@"LINKED"]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self refreshByStatus:AlexaStatusBindAready];
               });
        }
        
    }
                                               failure:^(NSError *error) {
        @strongify(self)
        [self hideLoading];
        [self refreshByStatus:AlexaStatusBindFaild];
    }];
    
}



//alexatoken尚未失效直接请求绑定状态（非完整流程）
-(void)getAlexaBindStatusWithAuthorCode:(NSString *)authorCode accessToken:(NSString *)accesstoken{
    AlexaInfo *info =  [AuthorizationManager sharedManager].entity.alexaInfo;
    NSDictionary *dict = info.alexaQueryItems;
    NSString *skillStage = dict[@"skill_stage"];
    NSString *redirectUri = dict[@"redirect_uri"];
    NSString *authCode = authorCode;
    NSString *type = @"AUTH_CODE";
    NSString *skillID = info.skill_id;
    [AuthorizationManager sharedManager].authorCode = @"";
    @weakify(self)
    [MSMineRepository setAlexSkillStatusWithSkillStage:skillStage
                                           redirectUri:redirectUri
                                              authCode:authCode
                                                  type:type
                                           accessToken:accesstoken
                                               skillID:skillID
                                              fullFlow:NO
                                               success:^(NSDictionary *result) {
        @strongify(self)
        [self hideLoading];
        AlexaBindStatusEntity *entity = [AlexaBindStatusEntity mj_objectWithKeyValues:result];
        if ([entity.accountLink.status isEqualToString:@"LINKED"]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self refreshByStatus:AlexaStatusBindAready];
               });
        }
        
    } failure:^(NSError *error) {
        @strongify(self)
        [self hideLoading];
        [self refreshByStatus:AlexaStatusBindFaild];
    }];
    
}


//查询
-(void)queryAlexaBindStatusWithAccessToken:(NSString *)accesstoken{
    AlexaInfo *info =  [AuthorizationManager sharedManager].entity.alexaInfo;
    NSString *skillID = info.skill_id;
    @weakify(self)
    
    [MSMineRepository queryAlexSkillStatusWithAccessToken:accesstoken
                                                  skillID:skillID
                                                  success:^(NSDictionary *result) {
        @strongify(self)
        [self hideLoading];
        AlexaBindStatusEntity *entity = [AlexaBindStatusEntity mj_objectWithKeyValues:result];
        if ([entity.accountLink.status isEqualToString:@"LINKED"]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self refreshByStatus:AlexaStatusBindAready];
            });
        }
        
    } failure:^(NSError *error) {
        @strongify(self)
        [self hideLoading];
        [self refreshByStatus:AlexaStatusNotBind];
    }];
}

-(void)checkAlexSkillStatus{
    [self showLoading];
    [MSMineRepository checkOAuth2BindStatus:^(NSDictionary *result) {
        [self hideLoading];
        BOOL linking = [result[@"alexaBound"] boolValue];
        if (linking) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self refreshByStatus:AlexaStatusBindAready];
            });
        }else{
            dispatch_async(dispatch_get_main_queue(), ^{
                [self refreshByStatus:AlexaStatusNotBind];
            });
            
        }
        
    }
                                          failure:^(MSBusinessError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self refreshByStatus:AlexaStatusNotBind];
        });
        
    }];
}



- (void)configureOEMTheme{
    [self configureThemeTag:OEMThemesTag_UIViewController_Behavior];
    [self.view configureThemeTag:OEMThemesTag_UIView_Background];
    [self.view configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.tableView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.tipsLabel configure40TranslucentTrait];
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
        [weakSelf setNavButton];
    } callImmidiately:YES];
}


#pragma mark - UI
- (void)makeConstraints {
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.top.bottom.equalTo(self.view);
    }];
    
    [self.backButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.view).offset(24);
        make.trailing.equalTo(self.view).offset(-24);
        make.height.mas_equalTo(44);
        make.bottom.equalTo(self.view).offset(-96);
    }];
    
    [self.tipsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.backButton.mas_bottom).offset(16);
        make.leading.equalTo(self.view).offset(24);
        make.trailing.equalTo(self.view).offset(-24);
        // make.height.mas_equalTo(44);
        //  make.bottom.equalTo(self.view).offset(0);
    }];
    
    [self.bindButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.view).offset(24);
        make.trailing.equalTo(self.view).offset(-24);
        make.height.mas_equalTo(44);
        make.bottom.equalTo(self.view).offset(-96);
    }];
}

-(MSAlexaBindEntity *)entity{
    if (!_entity) {
        _entity = [[MSAlexaBindEntity alloc] init];
    }
    return _entity;
}


-(void)refreshByStatus:(AlexaBindStatus)status{
    self.status = status;
    switch (status) {
        case AlexaStatusAuthorize:
        {
            self.rebindButton.hidden = YES;
            self.backButton.hidden = YES;
            self.bindButton.hidden = YES;
            self.tipsLabel.hidden = YES;
            
        }
            break;
        case AlexaStatusNotBind:
        {
            self.rebindButton.hidden = YES;
            self.backButton.hidden = YES;
            self.tipsLabel.hidden = YES;
            self.bindButton.hidden = NO;
            self.entity.tips = MSResourceString(@"alexa_page_bind_amazon_alexa_content");
            self.entity.title = MSResourceString(@"alexa_page_bind_amazon_alexa");
            self.entity.status = self.status;
            [self.tableView reloadData];
        }
            break;
        case AlexaStatusBindAready:
        {
            self.rebindButton.hidden = NO;
            self.backButton.hidden = NO;
            self.tipsLabel.hidden = NO;
            self.bindButton.hidden = YES;
            self.entity.tips = MSResourceString(@"alexa_page_alexa_conrtrol_tips");
            self.entity.status = self.status;
            self.entity.title = MSResourceString(@"alexa_page_bind_amazon_already");
            [self.tableView reloadData];
        }
            break;
        case AlexaStatusBindFaild:
        {
            self.entity.tips = MSResourceString(@"alexa_page_alexa_bind_fail_tips");
            self.entity.status = self.status;
            self.entity.title = MSResourceString(@"alexa_page_bind_amazon_alexa_fail");
            self.bindButton.hidden = YES;
            self.backButton.hidden = YES;
            self.tipsLabel.hidden = YES;
            self.rebindButton.hidden = YES;
            [self.tableView reloadData];
            
        }
            break;
        case AlexaStatusBindUnknow:
        {
            self.rebindButton.hidden = YES;
            self.backButton.hidden = YES;
            self.bindButton.hidden = YES;
            self.tipsLabel.hidden = YES;
            
        }
            break;
            
        default:
            break;
    }
    
    
}


#pragma mark - UITableView datasource and delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    switch (self.status) {
        case AlexaStatusAuthorize:
        {
            return 1;
        }
            break;
        case AlexaStatusNotBind:
        {
            return 2;
        }
            break;
        case AlexaStatusBindAready:
        {
            return 2;
        }
            break;
        case AlexaStatusBindFaild:
        {
            return 1;
        }
            break;
        case AlexaStatusBindUnknow:
        {
            return 0;
        }
            break;
            
        default:
            return 0;
            break;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (self.status == AlexaStatusAuthorize) {
        MSAlexaAuthorizationCell *cell =  [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([MSAlexaAuthorizationCell class]) forIndexPath:indexPath];
        @weakify(self)
        cell.allowBlock = ^{
            @strongify(self)
            [self allowClcik];
        };
        
        cell.cancelBlock = ^{
            @strongify(self)
            [[AuthorizationManager sharedManager] cancelAuthorization];
            [self dismissViewControllerAnimated:NO completion:nil];
            
        };
        return cell;
    }else if (self.status == AlexaStatusBindAready || self.status == AlexaStatusNotBind) {
        if (indexPath.row == 0) {
            MSAlexaBindCell1 *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([MSAlexaBindCell1 class]) forIndexPath:indexPath];
            cell.entity = self.entity;
            return cell;
        }else{
            MSAlexaBindCell2 *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([MSAlexaBindCell2 class]) forIndexPath:indexPath];
            return cell;
        }
    }else if (self.status == AlexaStatusBindFaild){
        MSAlexaBindCell1 *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([MSAlexaBindCell1 class]) forIndexPath:indexPath];
        cell.entity = self.entity;
        @weakify(self)
        cell.retryBlock = ^{
            @strongify(self)
            if ([BusinessNetWorkTools isNetworkUnreachable]) {
                [self toastText:[MSBusinessError networkDisconnectTips]];
                return;
            }
            [[AuthorizationManager sharedManager] jumpToAlexa];
            [self getAlexaAuthorCode:YES];
        };
        
        cell.backBlock = ^{
            @strongify(self)
          //  [self leftBarButtonClick:nil];
            [self getAlexaAuthorCode:YES];
            [self refreshByStatus:AlexaStatusNotBind];
            
        };
        return cell;
    }else{
        return nil;
    }
}

-(void)allowClcik{
    [self getAuthorizeResultWithParam:nil onlyGetCode:YES];
}

-(void)getAuthorizeResultWithParam:(NSDictionary *)param onlyGetCode:(BOOL)onlyGetCode{
    @weakify(self)
    if (!onlyGetCode) {
        [self showLoading];
    }
    [[AuthorizationManager sharedManager] getAuthorizeResultWithParam:param completionHandler:^(AuthorizationResult * _Nonnull result, MSBusinessError * _Nonnull error) {
        @strongify(self)
        NSLog(@"获取授权结果:result = %@ \n error = %@", result, error);
       // [self hideLoading];
        if (error) {
             [self hideLoading];
            [self toastText:error.localizedDescription];
            if (self.status == AlexaStatusNotBind) {
                [self refreshByStatus:AlexaStatusNotBind];
            }
        } else {
            if (self.status == AlexaStatusAuthorize) {
                [self hideLoading];
               [[AuthorizationManager sharedManager] authSuccessWithResult:result];
                [self dismissViewControllerAnimated:NO completion:nil];
            }else{
                [AuthorizationManager sharedManager].authorCode = result.code;
                if (onlyGetCode) {
                    [self hideLoading];
                    return;
                }
                
                [self checkAlexSkillStatus]; //向OEM云端查询绑定转态
                
//                NSString *nowTimestamp = [self getNowTimestamp];
//                NSString *preTimestamp = [MSUserDefaultTools getAlexaTokenTimstamp];
//                NSString *accessToken = [MSUserDefaultTools getAlexaToken];
//                if (preTimestamp.length > 0 && accessToken.length > 0  ) { //已存alexa token
//                    if ((nowTimestamp.floatValue - preTimestamp.floatValue) < 3600) {//在有效期内(一小时内）
//                        [self queryAlexaBindStatusWithAccessToken:accessToken];
//                    }else{//token 过期续签
//                        [self getAlexaBindStatusWithGrantType:@"refresh_token" athorCode:@"" isQuery:YES];
//                    }
//                }else{ //未绑定
////                    [self hideLoading];
////                    [self refreshByStatus:AlexaStatusNotBind];
//                    [self checkAlexSkillStatus]; //向OEM云端查询绑定转态
//                }
            }
        }
    }];
    
}

- (NSString *)getNowTimestamp{
    NSDate *date = [NSDate dateWithTimeIntervalSinceNow:0];
    NSTimeInterval a = [date timeIntervalSince1970];
    NSString *timeString = [NSString stringWithFormat:@"%0.f", a];//转为字符型
    return timeString;
}



- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return CGFLOAT_MIN;
}



//- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
//    UIView * sectionView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 8)];
//    sectionView.backgroundColor = [UIColor clearColor];
//    return sectionView;
//}


@end
