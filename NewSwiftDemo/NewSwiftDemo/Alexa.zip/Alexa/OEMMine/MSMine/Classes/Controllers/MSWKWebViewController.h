//
//  MSWKWebViewController.h
//  MSMine
//
//  Created by WindyCheng on 2021/10/1.
//

#import <MSBusiness/MVPViewController.h>
#import "MSMinePresenter.h"

NS_ASSUME_NONNULL_BEGIN

@interface MSWKWebViewController : MVPViewController


@property (nonatomic, strong)NSURL *url;

@end

NS_ASSUME_NONNULL_END
