//
//  OEMUploadLogViewController.swift
//  MSMine
//
//  Created by Neil 韦学宁 on 2022/1/7.
//

import Foundation
import OEMTheme
import SnapKit
import MSBusiness
import WebKit
import OEMLogger

@objc(MSUploadLogViewController)
public class MSUploadLogViewController: HGViewController{
    
    var contentView = MSUploadLogView(frame: .zero)
    
    public override func viewDidLoad() {
        self.initSubViews()
        self.initData()
        self.configureOEMTheme()
    }
    
    func setNav(){
        self.title = String.localizeString(key: "upload_log_page_title")
        if (MSOEMThemesManager.shared().currentStyle == OEMThemesStyle.dark) {
            self.createLeftButton(with: UIImage.loadImage(imageName: "ic_nav_back_dm"))
        }else{
            self.createLeftButton(with: UIImage.loadImage(imageName: "ic_nav_back_lg"))
        }
    }
    
    func initSubViews(){
        self.view.addSubview(contentView)
        contentView.snp_makeConstraints{
            $0.edges.equalToSuperview()
        }
        contentView.setUploadStage(type: .readyToUpload)
        contentView.onButtonAction = { [weak self] in
            guard let ws = self else {
                return
            }
            if ws.contentView.viewType == .readyToUpload {
                let cancel = HGAlertAction(title: String.localizeString(key: "upload_log_page_alert_cancel"), style: .cancel) {
                }
                let confirm = HGAlertAction(title: String.localizeString(key: "upload_log_page_alert_confirm")) {
                    ws.doUpload()
                }
                let actions = [cancel, confirm] as? [HGAlertAction]
                let title:String = String(format:String.localizeString(key: "upload_log_page_alert_message") ,MSAppInfo.appName())
                let alert = OEMHGAlertController(title: title, message: "", actions: actions)
                alert?.show()
            }else{
                self?.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    func doUpload() {
        guard let _ = OEMLogTools.getNewOnlineLogFile() else {
            return
        }
        self.showLoading()
        
        let s = OEMRouter.getServiceInstance(MSMeProtocol.self) as? MSMeProtocol
        s?.uploadLog?({[weak self] success, data, error in
            guard let ws = self else{ return }
            ws.hideLoading()
            ws.contentView.setUploadStage(type: success ? .uploadSuccess : .uploadFail)
        }, progressBlock: { [weak self] p in
            guard let ws = self else{ return }
            guard p < 1, p > 1e-3 else{
                return
            }
            if ws.contentView.viewType != .uploading{
                ws.contentView.setUploadStage(type: .uploading)
            }
            ws.contentView.updateProgressStatus(p: p)
            ws.hideLoading()
        })
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    func initData(){
    }
    
    func configureOEMTheme() {
        self.configureThemeTag(.uiViewController_Behavior)
        self.view.configureThemeTag(.uiView_Foreground)
        self.registerTraitDidChangeCallback({[weak self] in
            guard let ws = self else{
                return
            }
            ws.setNav()
            
        }, callImmidiately: true)
    }
}
