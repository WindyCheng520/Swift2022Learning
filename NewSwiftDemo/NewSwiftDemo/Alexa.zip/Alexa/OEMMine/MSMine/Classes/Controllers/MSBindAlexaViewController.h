//
//  MSBindAlexaViewController.h
//  MSMine
//
//  Created by WindyCheng on 2021/8/24.
//

#import <MSBusiness/MVPViewController.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, AlexaBindStatus) {
    AlexaStatusAuthorize = 0,      //OEM授权Alexa(关联、连接）
    AlexaStatusNotBind,            //未绑定
    AlexaStatusBindAready,         //已绑定（绑定成功）
    AlexaStatusBindFaild,           //绑定失败
    AlexaStatusBindUnknow          //未知
    
};

@interface MSBindAlexaViewController : MVPViewController

@property(nonatomic, assign)AlexaBindStatus status;
@property(nonatomic, strong)NSDictionary *itemDict;

@end

NS_ASSUME_NONNULL_END
