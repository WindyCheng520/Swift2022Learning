//
//  ViewTools.swift
//  MSMine
//
//  Created by Neil 韦学宁 on 2021/11/25.
//

import Foundation
import OEMFoundation
import OEMTheme
import MSBusiness

extension UIButton{
    class func themeButton(title: String, cornerRadius: CGFloat = 22) -> UIButton{
        let themeButton = UIButton(type: .custom)
        themeButton.configureThemeTag(.uiView_Main_Color)
        themeButton.configureThemeTag(.uiButton_Background)
        themeButton.configureThemeTag(.uiButton_AttributedTraitColor)
        themeButton.layer.masksToBounds = true
        themeButton.layer.cornerRadius = cornerRadius
        themeButton.setTitle(title, for: .normal)
        return themeButton
    }
    class func borderStyleButton(title: String, cornerRadius: CGFloat = 22) -> UIButton{
        let button = UIButton(type: .custom)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        button.setTitle(title, for: .normal)
        button.layer.cornerRadius = cornerRadius
        button.layer.borderColor = UIColor(rgb: 0xBBBBBB, a: 0.3).cgColor
        button.layer.borderWidth = 1
        button.clipsToBounds = true
        button.specialProperties(forDarkMode: [NSNumber(integerLiteral: Int(OEMThemesTag.uiButton_TitleThemeColor.rawValue)) : UIColor(rgb: 0xFFFFFF, a: 0.9)], lightModeProperties: [NSNumber(integerLiteral: Int(OEMThemesTag.uiButton_TitleThemeColor.rawValue)) : UIColor(rgb: 0x000000, a: 0.9)])
        return button
    }
    class func attributedTextButton(title: String, cornerRadius: CGFloat = 22) -> UIButton{
        let button = UIButton(type: .custom)
        button.setTitle(title, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: .medium)
        button.configureThemeTag(.uiButton_TitleThemeColor)
        return button
    }
}

extension UIView{
    class func cellForItem(string: String) -> (UIView, CGFloat){
        let view = UIView()
        
        //此处高度建议计算
        let oneLineHeight = CGFloat(28)
        let dot = UIView(frame: .zero)
        let lightColor = UIColor(rgb: 0x666666, a: 1.0)
        let darkColor = UIColor(rgb: 0x666666, a: 1.0)
        dot.specialProperties(forDarkMode: [NSNumber(integerLiteral: Int(OEMThemesTag.uiView_Background.rawValue)) : lightColor], lightModeProperties: [NSNumber(integerLiteral: Int(OEMThemesTag.uiView_Background.rawValue)) : darkColor])
        view.addSubview(dot)
        let dotSize = CGSize(width: 5, height: 5)
        dot.snp.makeConstraints{
            $0.leading.equalToSuperview().offset(oneLineHeight)
            $0.top.equalToSuperview().offset((oneLineHeight - dotSize.width) * 0.5)
            $0.size.equalTo(dotSize)
        }
        dot.layer.cornerRadius = dotSize.height * 0.5
        dot.layer.masksToBounds = true
        
        let label = UILabel(frame: .zero)
        label.font = UIFont.systemFont(ofSize: 14, weight: .regular)
        label.numberOfLines = 0
        view.addSubview(label)
        label.text = string
        label.snp.makeConstraints{
            $0.leading.equalTo(dot.snp_trailing).offset(6)
            $0.trailing.equalToSuperview().offset(-20)
            $0.centerY.equalTo(dot)
            $0.height.greaterThanOrEqualTo(22)
        }
        label.sizeToFit()
        
        label.specialProperties(forDarkMode: [NSNumber(integerLiteral: Int(OEMThemesTag.uiLabel_TextColor.rawValue)) : lightColor], lightModeProperties: [NSNumber(integerLiteral: Int(OEMThemesTag.uiLabel_TextColor.rawValue)) : darkColor])
        //返回值 View， Cell height
        return (view, oneLineHeight)
    }
}

extension UIImage{
    class func loadImage(imageName:String, bundle: Bundle = MSMineBundle.currentBundle()) -> UIImage?{
        return HGLocalizationResource.localizedImage(forImageName: imageName, in: bundle)
    }
}

extension String{
    static func localizeString(key: String, bundle: Bundle = MSBusinessBundle.currentBundle()) -> String{
        return HGLocalizationResource.localizedString(forKey: key, table: nil, in: bundle)
    }
}

extension UIColor {
    convenience init(red: Int, green: Int, blue: Int, a: CGFloat = 1.0) {
        self.init(
            red: CGFloat(red) / 255.0,
            green: CGFloat(green) / 255.0,
            blue: CGFloat(blue) / 255.0,
            alpha: a
        )
    }

    convenience init(rgb: Int, a: CGFloat = 1.0) {
        self.init(
            red: (rgb >> 16) & 0xFF,
            green: (rgb >> 8) & 0xFF,
            blue: rgb & 0xFF,
            a: a
        )
    }
}

extension UILabel{
    func configureTheme() {
        
    }
}

extension UIViewController: MVPViewProtocol{
    
    public func showLoading() {
        MSUIConfiguration.sh_showBlackLoadingHud(to: self.view)
    }
    
    public func hideLoading(){
        MSUIConfiguration.sh_hideAllHud(for: self.view, animated: true)
    }
    
    public func toastText(_ text: String){
        MSUIConfiguration.sh_showBlackToastHud(to: self.view, text: text)
    }
    
}
