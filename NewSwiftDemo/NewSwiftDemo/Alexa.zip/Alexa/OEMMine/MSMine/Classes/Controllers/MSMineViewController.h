//
//  MSMineViewController.h
//  MSMine
//
//  Created by syp on 2020/6/11.
//

#import <MSBusiness/MVPViewController.h>
#import "MSMinePresenter.h"

@interface MSMineViewController : MVPViewController<MSMinePresenter *><MSMineViewProtocol>



@end


