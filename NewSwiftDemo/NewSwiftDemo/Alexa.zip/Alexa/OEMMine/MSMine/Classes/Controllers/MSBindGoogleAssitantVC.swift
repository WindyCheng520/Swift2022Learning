//
//  MSBindGoogleAssitantVC.swift
//  MSMine
//
//  Created by Neil 韦学宁 on 2021/11/23.
//

import Foundation
import OEMTheme
import SnapKit
import MSBusiness
import WebKit
import OEMLogger

@objc
public enum GoogleAsstiantViewType: Int {
    case toBind, auth, binded, bindError
}

let agenid_sit="dollin-smart-sit"
let agenid_production="dollin-smart"

let GoogleHomeApplinks = "https://madeby.google.com/home-app/?deeplink=setup%2Fha_linking%3Fagent_id%3D"

@objc(MSBindGoogleAssitantVC)
@objcMembers
public class MSBindGoogleAssitantVC: HGViewController{
    @objc public static let BindGoogleAssitantViewType = "BindGoogleAssitantViewType"
    public var viewType : GoogleAsstiantViewType = .toBind
    public var oauthInfo: OAuth2Info?
    public var navRightButton = UIButton(type: .custom)
    public var needsCheckBindStatus = false
    public override func viewDidLoad() {
        super.viewDidLoad()
        self.initSubViews()
        self.initData()
        self.configureOEMTheme()
    }
    
    func initSubViews(){
        navRightButton = UIButton.attributedTextButton(title: String.localizeString(key: "alexa_page_alexa_rebind"))
        navRightButton.addTarget(self, action: #selector(onNavRightButton), for: .touchUpInside)
        navRightButton.isHidden = true
        self.navigationItem.rightBarButtonItem = UIBarButtonItem.init(customView: navRightButton)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    func initData(){
        NotificationCenter.default.addObserver(self, selector: #selector(onEnterforground), name: UIApplication.willEnterForegroundNotification, object: nil)
    }
    
    public override func leftBarButtonClick(_ button: UIButton!) {
        super.leftBarButtonClick(button)
        if let tab = self.presentingViewController as? UITabBarController,
           let nav = tab.selectedViewController as? UINavigationController{
            nav.popToRootViewController(animated: true)
        }
    }
    
    func onEnterforground(){
        guard needsCheckBindStatus else {
            return
        }
        self.checkBindStatus()
    }
    
    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    @objc func onNavRightButton(){
        self.loadView(type: .toBind)
    }
    
    func configureOEMTheme() {
        self.configureThemeTag(.uiViewController_Behavior)
        self.view.configureThemeTag(.uiView_Foreground)
        self.registerTraitDidChangeCallback({[weak self] in
            guard let ws = self else{
                return
            }
            ws.setNav()
            
        }, callImmidiately: true)
    }
    
    func setNav(){
        if (MSOEMThemesManager.shared().currentStyle == OEMThemesStyle.dark) {
            self.createLeftButton(with: UIImage.loadImage(imageName: "ic_nav_back_dm"))
        }else{
            self.createLeftButton(with: UIImage.loadImage(imageName: "ic_nav_back_lg"))
        }
    }
    
    func loadView(type: GoogleAsstiantViewType){
        let tag = 999
        if let view = self.view.viewWithTag(tag) {
            view.removeFromSuperview()
        }
        var view = UIView()
        switch type {
        case .toBind:
            view = self.initToBindView()
            navRightButton.isHidden = true
        case .auth:
            view = self.initToAuthView()
            navRightButton.isHidden = true
        case .binded:
            view = self.initBindedView()
            navRightButton.isHidden = false
        case .bindError:
            view = self.initBindErrorView()
        }
        view.tag = tag
        self.view.addSubview(view)
        view.snp.makeConstraints{
            $0.edges.equalTo(self.view)
        }
    }
    
    func initToBindView() -> UIView{
        let connectView = GoogleAssitantConnectView(frame: .zero)
        self.view.addSubview(connectView)
        connectView.snp.makeConstraints{
            $0.edges.equalTo(self.view)
        }
        connectView.connectActionBlock = {
            var agenid = agenid_production
            let projectId = AuthorizationManager.shared().entity.googleInfo.projectId
            if projectId.count > 0{
                agenid = projectId
            }
            guard let url = URL(string: GoogleHomeApplinks + agenid) else{
                return
            }
            
            if #available(iOS 10.0, *) {
                OEMLogTools.logInfo(module: "MSMine", format: "appflip google assitant with url:\(url.absoluteString)")
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            } else {
                UIApplication.shared.openURL(url)
            }
        }
        connectView.tutorialActionBlock = { [weak self] in
            guard let ws = self else {
                return
            }
             //有可能是多语言，这里需要每次都拿
            ws.showLoading()
            AuthorizationManager.shared().fetchJumpInfo { success, err in
                ws.hideLoading()
                if success{
                    let url = AuthorizationManager.shared().entity.googleInfo.tutorialUrl
                    let param = [ "enterType": 2,
                                  "addtionParams":
                                    ["title": "",
                                     "url": url
                                    ]
                    ] as [String : Any]
                    let routerpath = MSRouterScheme + MSRouterHtmlIndexTag
                    OEMRouter.handleURL(routerpath, withParams: param)
                }else{
                    ws.toastText(err.localizedDescription)
                }
            }
        }
        return connectView
    }
    
    func initToAuthView() -> UIView{
        let authView = GoogleAssitantAuthView(frame: .zero)
        authView.cancelAuthAction = { [weak self] in
            guard let ws = self else {
                return
            }
            guard let oauth2 = ws.oauthInfo,
                  let uri = oauth2.redirectUri,
                  let redirectURL = URL(string: uri) else {
                return
            }
            
            var components = URLComponents(url: redirectURL, resolvingAgainstBaseURL: false)
            let paramError = URLQueryItem(name: "error", value: "cancel auth")
            let paramDescription = URLQueryItem(name: "error_description", value: "用户拒绝链接")
            components?.queryItems = [paramError, paramDescription]
            if let resultURL = components?.url{
                OEMLogTools.logInfo(module: "MSMine", format: "auth cancel google assitant with url:\(resultURL.absoluteString)")
                if #available(iOS 10.0, *) {
                    UIApplication.shared.open(resultURL,
                                              options: [UIApplication.OpenExternalURLOptionsKey.universalLinksOnly : true]) { ret in
                    }
                } else {
                    UIApplication.shared.openURL(resultURL)
                }
            }
        }
        authView.authAction = {[weak self] in
            guard let ws = self else {
                return
            }
            guard let oauth2 = ws.oauthInfo else {
                return
            }
            let param = [
                "redirect_uri": oauth2.redirectUri as Any,
                "client_id": oauth2.clientId as Any,
                "scope": "GOOGLE",
            ] as [AnyHashable : Any]
            AuthorizationManager.shared().getAuthorizeResult(withParam: param ) {  [weak self] result, error  in
                guard let ws = self else {
                    return
                }
                let redirectURL = URL(string: oauth2.redirectUri!)
                var components = URLComponents(url: redirectURL!, resolvingAgainstBaseURL: false)
                let paramAuthCode = URLQueryItem(name: "code", value: result.code)
                let paramState = URLQueryItem(name: "state", value: oauth2.state)
                components?.queryItems = [paramAuthCode, paramState]
                if let resultURL = components?.url{
                    OEMLogTools.logInfo(module: "MSMine", format: "google assitant get code done with url:\(resultURL.absoluteString)")
                    ws.needsCheckBindStatus = true
                    if #available(iOS 10.0, *) {
                        UIApplication.shared.open(resultURL,
                                                  options: [UIApplication.OpenExternalURLOptionsKey.universalLinksOnly : true]) {_ in
                        }
                    } else {
                        UIApplication.shared.openURL(resultURL)
                    }
                }
            }
        }
        return authView
    }
    
    func initBindedView() -> UIView{
        let connectView = GoogleAssitantConnectedView(frame: .zero)
        return connectView
    }
    
    func initBindErrorView() -> UIView{
        let connectView = GoogleAssitantConnectView(frame: .zero)
        return connectView
    }

}

extension MSBindGoogleAssitantVC: OEMRouterManagerProtocol{
    public func msRouterParams(_ params: [AnyHashable : Any]!) {
        guard let value = params["BindGoogleAssitantViewType"] as? NSNumber,
              let type = GoogleAsstiantViewType(rawValue: value.intValue) else {
            self.checkBindStatus()
            return
        }
        if let oauth2Info = params["OAuth2Info"] as? OAuth2Info{
            self.oauthInfo = oauth2Info
        }
        self.loadView(type: type)
    }
    
    public func checkBindStatus(){
        self.showLoading()
        MSMineRepository.checkOAuth2BindStatus { [weak self] result in
            guard let ws = self else{
                return
            }
            ws.hideLoading()
            if let binded = result?["googleBound"] as? Bool,
               binded == true{
                ws.viewType = .binded
            }else{
                ws.viewType = .toBind
            }
            ws.loadView(type: ws.viewType)
            ws.needsCheckBindStatus = false
        } failure: { [weak self] error in
            guard let ws = self else{
                return
            }
            ws.toastText(error?.localizedDescription ?? "")
        }
    }
}
