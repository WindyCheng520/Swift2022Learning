//
//  MSUploadLogView.swift
//  MSMine
//
//  Created by Neil 韦学宁 on 2022/1/7.
//

import Foundation
import SnapKit
import OEMFoundation
import OEMTheme

enum UploadLogViewType {
    case readyToUpload, uploading, uploadSuccess, uploadFail
}

class MSUploadLogView: UIView{
    
    var onButtonAction: (() -> ())?
    var viewType = UploadLogViewType.readyToUpload
    let centerIcon = UIImageView(frame: .zero)
    var uploadTip = UILabel(frame: .zero)
    let uploadProgress = UIProgressView(frame: .zero)
    var uploadButton = UIButton(frame: .zero)
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.initSubViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func initSubViews(){
        let headerSep = UIView(frame: .zero)
        self.addSubview(headerSep)
        headerSep.snp_makeConstraints{
            $0.leading.top.trailing.equalToSuperview();
            $0.height.equalTo(8)
        }
        headerSep.configureThemeTag(.uiView_Background)
        self.addSubview(centerIcon)

        self.addSubview(uploadTip)
        uploadTip.textAlignment = .center
        uploadTip.configure40TranslucentTrait()
        uploadTip.snp_makeConstraints{
            $0.leading.equalToSuperview().offset(48)
            $0.trailing.equalToSuperview().offset(-48)
            $0.top.equalTo(centerIcon.snp_bottom).offset(12);
        }
        
        uploadButton = UIButton.themeButton(title: String.localizeString(key: "upload_log_page_button"))
        uploadButton.addTarget(self, action: #selector(btnSel), for: .touchUpInside)
        self.addSubview(uploadButton)
        
        self.addSubview(uploadProgress)
        uploadProgress.isHidden = true
        uploadProgress.layer.masksToBounds = true
        uploadProgress.layer.cornerRadius = 5
        uploadProgress.tintColor = UIColor(rgb: 0x267AFF, a: 0.9)
        uploadProgress.snp_makeConstraints{
            $0.height.equalTo(10)
            $0.leading.equalToSuperview().offset(16)
            $0.trailing.equalToSuperview().offset(-16)
            $0.top.equalTo(centerIcon.snp_bottom).offset(87)
        }
        

    }
    
    func setUploadStage(type: UploadLogViewType) -> Void {
        self.viewType = type
        var iconSize = CGSize(width: 60.6, height: 76.6)
        switch type {
        case .readyToUpload:
            self.centerIcon.image = UIImage.loadImage(imageName: "loguploadIcon")
            uploadProgress.isHidden = true
            uploadButton.isHidden = false
        case .uploading:
            self.centerIcon.image = UIImage.loadImage(imageName: "loguploadIcon")
            uploadProgress.isHidden = false
            uploadButton.isHidden = true
        case .uploadSuccess:
            self.centerIcon.image = UIImage.loadImage(imageName: "loguploadsuccess")
            uploadProgress.isHidden = true
            uploadButton.isHidden = false
            iconSize = CGSize(width: 60, height: 60)
        case .uploadFail:
            self.centerIcon.image = UIImage.loadImage(imageName: "loguploadfail")
            uploadProgress.isHidden = true
            uploadButton.isHidden = false
            iconSize = CGSize(width: 60, height: 60)
        }

        if self.viewType == .uploadSuccess || self.viewType == .uploadFail {
            uploadTip.font = UIFont.systemFont(ofSize: 22, weight: .bold)
            uploadTip.configure90TranslucentTrait()
            uploadTip.text = (self.viewType == .uploadSuccess) ? String.localizeString(key: "upload_log_page_success_tip") : String.localizeString(key: "upload_log_page_fail_tip")
            uploadTip.numberOfLines = 1;
            uploadTip.adjustsFontSizeToFitWidth = true
            self.uploadButton.setTitle(String.localizeString(key: "alexa_page_alexa_back"), for: .normal)
        }else{
            uploadTip.font = UIFont.systemFont(ofSize: 14, weight: .medium)
            uploadTip.configure40TranslucentTrait()
            uploadTip.text = (self.viewType == .readyToUpload) ? String.localizeString(key: "upload_log_page_message") : String.localizeString(key: "upload_log_page_uploading")
            uploadTip.numberOfLines = 3;
            uploadTip.adjustsFontSizeToFitWidth = true
        }
        
        var buttonTopToBottom = 35
        var tipLabelTopPadding = 12.35
        var centerIconTopPadding = 128 + 5
        if self.viewType == .uploadSuccess || self.viewType == .uploadFail {
            buttonTopToBottom = 45
            tipLabelTopPadding = 29
            centerIconTopPadding = 137 + 5
        }
        centerIcon.snp_remakeConstraints{
            $0.centerX.equalToSuperview()
            $0.top.equalToSuperview().offset(centerIconTopPadding)
            $0.size.equalTo(iconSize)
        }
        uploadTip.snp_remakeConstraints{
            $0.leading.equalToSuperview().offset(48)
            $0.trailing.equalToSuperview().offset(-48)
            $0.top.equalTo(centerIcon.snp_bottom).offset(tipLabelTopPadding);
        }
        uploadButton.snp_makeConstraints{
            $0.leading.equalToSuperview().offset(16)
            $0.trailing.equalToSuperview().offset(-16)
            $0.height.equalTo(44)
            $0.top.equalTo(uploadTip.snp_bottom).offset(buttonTopToBottom)
        }
        
    }
    
    func updateProgressStatus(p: Float){
        self.uploadProgress.progress = p
    }
    
    @objc func btnSel(){
        guard let ac = self.onButtonAction else {
            return
        }
        ac()
    }
}
    


