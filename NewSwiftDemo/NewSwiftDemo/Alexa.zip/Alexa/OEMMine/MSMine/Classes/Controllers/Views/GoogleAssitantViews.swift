//
//  GoogleAssitantConnectView.swift
//  MSMine
//
//  Created by Neil 韦学宁 on 2021/11/25.
//

import UIKit
import SnapKit
import OEMFoundation
import OEMTheme

//跳转Google home页面
class GoogleAssitantConnectView: UIView {
    
    public var connectActionBlock: (() -> Void)?
    public var tutorialActionBlock: (() -> Void)?
    
    private var headerIcon = UIImageView()
    private let title = UILabel(frame: .zero)
    private var micIcon = UIImageView()
    private var arrowIcon1 = UIImageView()
    private var arrowIcon2 = UIImageView()
    private var centerAssitant = UIImageView()
    private var robotIcon = UIImageView()
    
    private let detailLabel = UILabel(frame: .zero)
    public var connectButton = UIButton(type: .custom)
    private var tutorialButton = UIButton(type: .custom)
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.initSubViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func initSubViews() {
        
        let headerIcon = UIImageView(image: UIImage.loadImage(imageName: "ic_n_ggassit"))
        let title = UILabel(frame: .zero)
        
        let micIcon = UIImageView(image: UIImage.loadImage(imageName: "google_voice"))
        let arrowIcon1 = UIImageView(image: UIImage.loadImage(imageName: "google_arrow"))
        let arrowIcon2 = UIImageView(image: UIImage.loadImage(imageName: "google_arrow"))
        let centerAssitant = UIImageView(image: UIImage.loadImage(imageName: "ic_n_ggassit"))
        let robotIcon = UIImageView(image: UIImage.loadImage(imageName: "google_robot"))
        
        self.addSubview(headerIcon)
        self.addSubview(title)
        
        self.addSubview(micIcon)
        self.addSubview(arrowIcon1)
        self.addSubview(centerAssitant)
        self.addSubview(arrowIcon2)
        self.addSubview(robotIcon)
        
        self.addSubview(detailLabel)
        
        title.text = "Google Assistant"
        title.font = UIFont.systemFont(ofSize: 22, weight: .medium)
        title.numberOfLines = 0
        title.sizeToFit()
        title.configure90TranslucentTrait()
        
        let assitantIconSize = 40
        title.snp.makeConstraints{
            $0.top.equalTo(self).offset(27)
            $0.centerX.equalTo(self).offset(assitantIconSize / 2)
            $0.height.equalTo(28)
            $0.width.greaterThanOrEqualTo(UIScreen.main.bounds.size.width / 2)
        }
        headerIcon.snp.makeConstraints{
            $0.centerY.equalTo(title)
            $0.trailing.equalTo(title.snp_leading).offset(-10)
            $0.size.equalTo(CGSize(width: 40, height: 40))
        }
        let centerIconSize = CGSize(width: 50, height: 50)
        centerAssitant.snp.makeConstraints{
            $0.top.equalTo(title.snp_bottom).offset(87)
            $0.centerX.equalTo(self)
            $0.size.equalTo(centerIconSize)
        }
        let arrorPadding = 14
        let arrorSize = CGSize(width: 30, height: 18)
        arrowIcon1.snp.makeConstraints{
            $0.trailing.equalTo(centerAssitant.snp_leading).offset(-arrorPadding)
            $0.size.equalTo(arrorSize)
            $0.centerY.equalTo(centerAssitant)
        }
        arrowIcon2.snp.makeConstraints{
            $0.leading.equalTo(centerAssitant.snp_trailing).offset(arrorPadding)
            $0.size.equalTo(arrorSize)
            $0.centerY.equalTo(centerAssitant)
        }
        micIcon.snp.makeConstraints{
            $0.centerY.equalTo(centerAssitant)
            $0.trailing.equalTo(arrowIcon1.snp_leading).offset(-arrorPadding)
            $0.size.equalTo(centerIconSize)
        }
        robotIcon.snp.makeConstraints{
            $0.centerY.equalTo(centerAssitant)
            $0.leading.equalTo(arrowIcon2.snp_trailing).offset(arrorPadding)
            $0.size.equalTo(centerIconSize)
        }
        detailLabel.text = String.localizeString(key: "google_assitant_link_page_description")
        detailLabel.font = UIFont.systemFont(ofSize: 14, weight: .regular)
        detailLabel.textColor = UIColor(rgb: 0x666666)
        detailLabel.sizeToFit()
        detailLabel.numberOfLines = 0
        detailLabel.snp.makeConstraints{
            $0.centerX.equalTo(self)
            $0.leading.equalTo(self).offset(32)
            $0.trailing.equalTo(self).offset(-32)
            $0.top.equalTo(centerAssitant.snp_bottom).offset(40)
            $0.height.greaterThanOrEqualTo(20)
            $0.height.lessThanOrEqualTo(100)
        }
    
        connectButton = UIButton.themeButton(title: String.localizeString(key: "google_assitant_link_page_bind_button"))
        self.addSubview(connectButton)
        connectButton.addTarget(self, action: #selector(onConnect), for: .touchUpInside)
        connectButton.snp.makeConstraints{
            $0.top.equalTo(detailLabel.snp_bottom).offset(100)
            $0.leading.equalToSuperview().offset(24)
            $0.trailing.equalToSuperview().offset(-24)
            $0.height.equalTo(44)
        }
        
        tutorialButton = UIButton.attributedTextButton(title: String.localizeString(key: "google_assitant_link_page_tutorial_button"))
        self.addSubview(tutorialButton)
        tutorialButton.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: .regular)
        tutorialButton.addTarget(self, action: #selector(onTutorial), for: .touchUpInside)
        tutorialButton.snp.makeConstraints{
            $0.top.equalTo(connectButton.snp_bottom).offset(18)
            $0.leading.equalToSuperview().offset(24)
            $0.trailing.equalToSuperview().offset(-24)
            $0.height.equalTo(20)
        }
    }

    @objc func onConnect(){
        if let block = self.connectActionBlock {
            block()
        }
    }
    
    @objc func onTutorial(){
        if let block = self.tutorialActionBlock {
            block()
        }
    }
}

//Google home正在申请授权页面
class GoogleAssitantAuthView: UIView {
    
    public var authAction: (() -> Void)?
    
    public var cancelAuthAction: (() -> Void)?
    
    public var authButton: UIButton?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.initSubViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func initSubViews() {
        
        var headerIcon = UIImageView(image: nil)
        headerIcon = UIImageView(image: OEMCustomize.customizableImage("login_page_icon"))
        let appInfo = UILabel(frame: .zero)
        appInfo.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        appInfo.configure90TranslucentTrait()
        appInfo.text = Bundle.main.infoDictionary?["CFBundleDisplayName"] as? String
        
        let centerTitle = UILabel(frame: .zero)
        centerTitle.font = UIFont.systemFont(ofSize: 22, weight: .bold)
        centerTitle.numberOfLines = 2
        centerTitle.configure90TranslucentTrait()
        centerTitle.textAlignment = .center
        centerTitle.text = String.localizeString(key: "google_assitant_link_page_title")
        
        let permissionDes = UILabel(frame: .zero)
        permissionDes.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        permissionDes.numberOfLines = 0
        permissionDes.configure90TranslucentTrait()
        permissionDes.text = String.localizeString(key: "google_assitant_link_page_permission_description")
        
        self.addSubview(headerIcon)
        headerIcon.snp.makeConstraints{
            $0.centerX.equalToSuperview()
            $0.top.equalToSuperview().offset(84 + 44)
            $0.size.equalTo(CGSize(width: 64, height: 64))
        }
        self.addSubview(appInfo)
        appInfo.snp.makeConstraints{
            $0.centerX.equalTo(headerIcon)
            $0.top.equalTo(headerIcon.snp_bottom).offset(14)
            $0.height.equalTo(20)
            $0.width.greaterThanOrEqualTo(100)
        }
        
        self.addSubview(centerTitle)
        centerTitle.snp.makeConstraints{
            $0.top.equalTo(appInfo).offset(50)
            $0.leading.equalToSuperview().offset(32)
            $0.trailing.equalToSuperview().offset(-32)
            $0.height.greaterThanOrEqualTo(52)
        }
        centerTitle.sizeToFit()
        
        self.addSubview(permissionDes)
        permissionDes.snp.makeConstraints{
            $0.top.equalTo(centerTitle.snp_bottom).offset(30)
            $0.leading.equalToSuperview().offset(20)
            $0.trailing.equalToSuperview().offset(-20)
            $0.height.greaterThanOrEqualTo(44)
        }
        permissionDes.sizeToFit()
        
        let cellTitles = [
            String.localizeString(key: "google_assitant_link_page_permission_device"),
        ]
        
        var previousCell : UIView?
        for string in cellTitles {
            let tuple = UIView.cellForItem(string: string)
            let view = tuple.0
            self.addSubview(view)
            view.snp.makeConstraints{
                $0.leading.trailing.equalToSuperview()
                if let pcell = previousCell{
                    $0.top.equalTo(pcell.snp_bottom).offset(4)
                }else{
                    $0.top.equalTo(permissionDes.snp_bottom).offset(12)
                }
                $0.height.equalTo(tuple.1)
            }
            previousCell = view
        }
        
        let authButton = UIButton.themeButton(title: String.localizeString(key: "google_assitant_link_page_confirm_button"))
        self.addSubview(authButton)
        self.authButton = authButton
        authButton.addTarget(self, action: #selector(onAuth), for: .touchUpInside)
        authButton.snp.makeConstraints{
            $0.top.equalTo(permissionDes.snp_bottom).offset(142)
            $0.leading.equalToSuperview().offset(24)
            $0.trailing.equalToSuperview().offset(-24)
            $0.height.equalTo(44)
        }
        
        let cancelButton = UIButton.borderStyleButton(title: String.localizeString(key: "google_assitant_link_page_deny_button"))
        self.addSubview(cancelButton)
        cancelButton.addTarget(self, action: #selector(onCancel), for: .touchUpInside)
        cancelButton.snp.makeConstraints{
            $0.size.equalTo(authButton)
            $0.top.equalTo(authButton.snp_bottom).offset(16)
            $0.centerX.equalTo(authButton)
        }
        
        
    }
    
    @objc func onAuth(){
        guard let block = self.authAction else {
            return
        }
        block()
    }
    
    @objc func onCancel(){
        guard let block = self.cancelAuthAction else {
            return
        }
        block()
    }
    

}

//Google home已经绑定页面
class GoogleAssitantConnectedView: UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.initSubViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func initSubViews() {
        var headerIcon = UIImageView(image: nil)
        headerIcon = UIImageView(image: OEMCustomize.customizableImage("login_page_icon"))
        let appInfo = UILabel(frame: .zero)
        appInfo.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        appInfo.configure90TranslucentTrait()
        appInfo.text = Bundle.main.infoDictionary?["CFBundleDisplayName"] as? String
        
        let centerTitle = UILabel(frame: .zero)
        centerTitle.font = UIFont.systemFont(ofSize: 22, weight: .bold)
        centerTitle.numberOfLines = 2
        centerTitle.configure90TranslucentTrait()
        centerTitle.textAlignment = .center
        centerTitle.text = String.localizeString(key: "google_assitant_linked_page_title")
        
        let permissionDes = UILabel(frame: .zero)
        permissionDes.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        permissionDes.numberOfLines = 0
        permissionDes.configure90TranslucentTrait()
        permissionDes.text = String.localizeString(key: "google_assitant_linked_page_description")
        
        
        self.addSubview(headerIcon)
        headerIcon.snp.makeConstraints{
            $0.centerX.equalToSuperview()
            $0.top.equalToSuperview().offset(84)
            $0.size.equalTo(CGSize(width: 64, height: 64))
        }
        self.addSubview(appInfo)
        appInfo.snp.makeConstraints{
            $0.centerX.equalTo(headerIcon)
            $0.top.equalTo(headerIcon.snp_bottom).offset(14)
            $0.height.equalTo(20)
            $0.width.greaterThanOrEqualTo(100)
        }
        
        self.addSubview(centerTitle)
        centerTitle.snp.makeConstraints{
            $0.top.equalTo(appInfo).offset(50)
            $0.leading.equalToSuperview().offset(32)
            $0.trailing.equalToSuperview().offset(-32)
            $0.height.greaterThanOrEqualTo(52)
        }
        centerTitle.sizeToFit()
        
        self.addSubview(permissionDes)
        permissionDes.snp.makeConstraints{
            $0.top.equalTo(centerTitle.snp_bottom).offset(30)
            $0.leading.equalToSuperview().offset(20)
            $0.trailing.equalToSuperview().offset(-20)
            $0.height.greaterThanOrEqualTo(44)
        }
        permissionDes.sizeToFit()
        
        let cellTitles = [
            String.localizeString(key: "google_assitant_linked_page_cmd1"),
            String.localizeString(key: "google_assitant_linked_page_cmd2"),
            String.localizeString(key: "google_assitant_linked_page_cmd3"),
        ]
        
        var previousCell : UIView?
        for string in cellTitles {
            let tuple = UIView.cellForItem(string: string)
            let view = tuple.0
            self.addSubview(view)
            view.snp.makeConstraints{
                $0.leading.trailing.equalToSuperview()
                if let pcell = previousCell{
                    $0.top.equalTo(pcell.snp_bottom).offset(4)
                }else{
                    $0.top.equalTo(permissionDes.snp_bottom).offset(12)
                }
                $0.height.equalTo(tuple.1)
            }
            previousCell = view
        }
        
    }
}
