//
//  MSMineResource.h
//  MSMine
//
//  Created by syp on 2020/6/17.
//

#import <OEMFoundation/OEMBundle.h>
#import <OEMFoundation/HGLocalizationResource.h>

#define MSCurrentBundle [MSMineBundle currentBundle]
#define OEMStringBundle [MSMineBundle strBundle]

#define MSResourceString(key) [HGLocalizationResource localizedStringForKey:key table:nil inBundle:OEMStringBundle]
#define MSResourceImage(imageName) [HGLocalizationResource localizedImageForImageName:imageName inBundle:MSCurrentBundle]

@interface MSMineBundle : OEMBundle

@end

