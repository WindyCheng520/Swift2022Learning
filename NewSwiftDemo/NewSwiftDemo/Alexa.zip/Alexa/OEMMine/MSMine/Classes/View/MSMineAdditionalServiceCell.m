//
//  MSMineAdditionalServiceCell.m
//  MSMine
//
//  Created by chengls1365 on 2021/5/27.
//

#import "MSMineAdditionalServiceCell.h"
#import "MSMineServiceItemCell.h"
#import "MSMineBundle.h"


static NSString * const KMSMineServiceItemCellIdentifier = @"MSMineServiceItemCellIdentifier";
@interface MSMineAdditionalServiceCell ()<UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout>

@property (nonatomic, strong) HGLabel *itemLabel; //扩展服务
@property (nonatomic, strong) HGLabel *moreLabel; //更多
@property (nonatomic, strong) HGImageView *arrowImageView; //箭头
@property (nonatomic, strong) HGCollectionView *collectionView;
@property (nonatomic, strong)UICollectionViewFlowLayout *collectionViewLayout;

@end

@implementation MSMineAdditionalServiceCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.itemLabel = [HGLabel new];
        self.itemLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightRegular];
        self.itemLabel.text =  @"";
        self.itemLabel.textColor = [UIColor blackColor];
        [self.contentView addSubview:self.itemLabel];
        
        self.moreLabel = [HGLabel new];
        self.moreLabel.font = [UIFont systemFontOfSize:18 weight:UIFontWeightRegular];
        self.moreLabel.text =  @"";
        self.moreLabel.textColor = RGB_HEX(0x666666);
        // 新交互去掉更多字样
        self.moreLabel.hidden = YES;
        [self.contentView addSubview:self.moreLabel];
        
        self.arrowImageView = [HGImageView new];
        self.arrowImageView.image = MSResourceImage(@"ic_list_go");
        // 新交互去掉箭头
        self.arrowImageView.hidden = YES;
        [self.contentView addSubview:self.arrowImageView];

        _collectionView = [[HGCollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:[self collectionViewLayout]];
        _collectionView.backgroundColor = [UIColor whiteColor];
        _collectionView.scrollEnabled = NO;
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        [_collectionView registerClass:[MSMineServiceItemCell class] forCellWithReuseIdentifier:KMSMineServiceItemCellIdentifier];
        [self.contentView addSubview:self.collectionView];
        
        [self makeConstraints];
        
        [self configureOEMTheme];
    }
    return self;
}

- (void)layoutSubviews{
    [super layoutSubviews];
}

- (void)configureOEMTheme{
    [self.contentView configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.itemLabel configure90TranslucentTrait];
    [self.moreLabel configure40TranslucentTrait];
    [self.collectionView configureThemeTag:OEMThemesTag_UIView_Foreground];
}

- (void)makeConstraints{
    
    [self.arrowImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(16, 16));
        make.top.equalTo(self).offset(20);
        make.trailing.equalTo(self).offset(-16);
    }];
    
    [self.moreLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).offset(21);
        make.height.mas_equalTo(16);
        make.trailing.equalTo(self.arrowImageView.mas_leading).offset(-8);
    }];
    
    
    [self.itemLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self).offset(16);
        make.top.equalTo(self).offset(20);
        make.height.mas_equalTo(19);
    }];
    
    [self.collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self).offset(0);
        make.trailing.equalTo(self).offset(0);
        make.top.equalTo(self.itemLabel.mas_bottom).offset(0);
        make.height.mas_equalTo(79);
    }];
}

-(void)setItems0:(NSArray<MSMineItem *> *)items0{
    _items0 = items0;
    if(_items0.count >= 2){
        MSMineItem *itemFirst = _items0.firstObject;
        self.itemLabel.text =  itemFirst.title;
        
        MSMineItem *itemLast = _items0.lastObject;
        self.moreLabel.text =  itemLast.title;
    }
}

-(void)setItems:(NSArray<MSMineItem *> *)items{
    _items = items;
    [self.collectionView reloadData];
}


- (UICollectionViewFlowLayout *)collectionViewLayout {
    if (!_collectionViewLayout) {
        _collectionViewLayout = [[UICollectionViewFlowLayout alloc] init];
       // _collectionViewLayout.sectionInset = UIEdgeInsetsMake(MIN(24, SCREEN_SCALE_WIDTH(24)), horizonMargin, MIN(8, SCREEN_SCALE_WIDTH(8)), horizonMargin);
        _collectionViewLayout.sectionInset = UIEdgeInsetsMake(0, 16, 0, 8);
        CGFloat itemW =  (SCREEN_WIDTH -32) / 2.0;
        CGFloat itemH =  68.;
        _collectionViewLayout.itemSize = CGSizeMake(itemW, itemH);
        _collectionViewLayout.minimumInteritemSpacing = 0;
        // 修改成两行
        _collectionViewLayout.minimumLineSpacing = 0;
        _collectionViewLayout.headerReferenceSize = CGSizeMake(0, 0);
        _collectionViewLayout.footerReferenceSize = CGSizeMake(0, 0);
        _collectionViewLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    }

    return _collectionViewLayout;
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return  self.items.count;
}
    
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    MSMineServiceItemCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:KMSMineServiceItemCellIdentifier forIndexPath:indexPath];
    cell.item = self.items[indexPath.item];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if (self.block) {
        self.block(indexPath.item);
    }
}



@end
