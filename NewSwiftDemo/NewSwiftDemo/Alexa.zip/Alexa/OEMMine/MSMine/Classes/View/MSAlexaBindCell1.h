//
//  MSAlexaBindCell1.h
//  MSMine
//
//  Created by WindyCheng on 2021/8/25.
//

#import <OEMFoundation/HGUIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class MSAlexaBindEntity;

@interface MSAlexaBindCell1 : HGTableViewCell

@property (nonatomic, strong) HGLabel *titleLabel;         //标题
@property (nonatomic, strong) HGLabel *contenLabel;         //内容描述
@property (nonatomic, strong) HGButton *retryButton;        //重试按钮
@property (nonatomic, strong) HGButton *backButton;         //返回按钮

@property (nonatomic, strong) MSAlexaBindEntity *entity;

@property (nonatomic, copy) dispatch_block_t retryBlock;
@property (nonatomic, copy) dispatch_block_t backBlock;




@end

NS_ASSUME_NONNULL_END
