//
//  FollowSystemTraitCell.h
//  MSLogin
//
//  Created by Neil 韦学宁 on 2021/7/13.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^FollowSystemTraitSwitch)(BOOL followSystem);

@interface FollowSystemTraitCell : UITableViewCell

@property(nonatomic, copy)FollowSystemTraitSwitch followSystemChange;

@property(nonatomic, strong)UILabel * textTitle;

@property(nonatomic, strong)UILabel * subTitleDescription;

@property(nonatomic, strong)UISwitch * switchButton;
@end

NS_ASSUME_NONNULL_END
