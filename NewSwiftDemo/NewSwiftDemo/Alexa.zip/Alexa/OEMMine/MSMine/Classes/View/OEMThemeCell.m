//
//  OEMThemeCell.m
//  MSLogin
//
//  Created by Neil 韦学宁 on 2021/7/13.
//

#import "OEMThemeCell.h"
#import "UIColor+OEMThemes.h"
#import "MSMineBundle.h"

@interface OEMThemeCell()

@property(nonatomic, assign)BOOL isdark;

@end

@implementation OEMThemeCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self initSubViews];
    }
    return self;
}

- (void)initSubViews{
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    self.textTitle = [[UILabel alloc] init];
    self.textTitle.font = [UIFont systemFontOfSize:16];
    self.textTitle.textAlignment = NSTextAlignmentLeft;
    
    self.checkIcon = [[UIImageView alloc] init];
    self.checkIcon.hidden = YES;
    self.checkIcon.image = MSResourceImage(@"ic_country_selected");
    
    [self.contentView addSubview:self.textTitle];
    [self.contentView addSubview:self.checkIcon];
    
    [self makeContraints];
    
    [self conifigureOEMTheme];
    
}

- (void)makeContraints{
    [self.textTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.textTitle.superview).offset(16);
        make.trailing.equalTo(self.textTitle.superview).offset(-80);
        make.centerY.equalTo(self.textTitle.superview);
    }];
    [self.checkIcon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.trailing.equalTo(self.checkIcon.superview).offset(-16);
        make.centerY.equalTo(self.checkIcon.superview);
        make.size.mas_equalTo(CGSizeMake(16, 16));
    }];
}

- (void)setDarkTitle:(BOOL)isDark{
    if (isDark) {
        self.textTitle.text = @"Dark";
    }else{
        self.textTitle.text = @"Light";
    }
    _isdark = isDark;
}

- (void)conifigureOEMTheme{
    [self.textTitle configure90TranslucentTrait];
    [self.contentView configureThemeTag:OEMThemesTag_UIView_Foreground];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
