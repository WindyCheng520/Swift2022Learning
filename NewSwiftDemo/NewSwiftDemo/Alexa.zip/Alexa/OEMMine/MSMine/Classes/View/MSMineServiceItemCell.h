//
//  MSMineServiceItemCell.h
//  MSMine
//
//  Created by WindyCheng on 2021/5/27.
//

#import <UIKit/UIKit.h>
#import "MSMineItem.h"

NS_ASSUME_NONNULL_BEGIN


@interface MSMineServiceItemCell : HGCollectionViewCell

@property (nonatomic, strong) HGImageView *iconImageView;
@property (nonatomic, strong) HGLabel *titleLabel;
@property (nonatomic, strong) MSMineItem *item;
@end





NS_ASSUME_NONNULL_END


