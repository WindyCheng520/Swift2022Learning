//
//  MSMineHeaderView.h
//  MSMine
//
//  Created by 及时行乐 on 2020/7/13.
//

#import <UIKit/UIKit.h>

@class MSMineHeaderView;
@protocol MSMineHeaderViewDelegate <NSObject>

- (void)headerViewDidClick:(MSMineHeaderView *)headerView;

@end

@interface MSMineHeaderView : HGView

@property (nonatomic, weak) id<MSMineHeaderViewDelegate> delegate;

-(void)refreshDataWithLogin:(BOOL)isLogin nickname:(NSString*)nickname headIcon:(NSString*)headIcon;


@end


