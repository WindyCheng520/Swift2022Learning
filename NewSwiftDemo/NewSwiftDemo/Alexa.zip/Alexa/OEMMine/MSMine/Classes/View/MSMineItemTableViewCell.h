//
//  MSMineItemTableViewCell.h
//  MSMine
//
//  Created by 及时行乐 on 2020/7/13.
//

#import <UIKit/UIKit.h>


@interface MSMineItemTableViewCell : HGTableViewCell

-(void)refreshDataWithImage:(NSString*)imageStr title:(NSString*)title subtitle:(NSString*)subtitle;


@end
