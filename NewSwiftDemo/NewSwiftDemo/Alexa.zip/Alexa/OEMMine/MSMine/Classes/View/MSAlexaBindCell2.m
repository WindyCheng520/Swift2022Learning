//
//  MSAlexaBindCell2.m
//  MSMine
//
//  Created by WindyCheng on 2021/8/26.
//

#import "MSAlexaBindCell2.h"
#import "MSMineBundle.h"

@implementation MSAlexaBindCell2

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.contentView.backgroundColor = [UIColor clearColor];
        self.backgroundColor = [UIColor clearColor];
        
        self.contenLabel = [HGLabel new];
        self.contenLabel.textColor = RGBA_HEX(0x000000,0.6);
        self.contenLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
        self.contenLabel.text = MSResourceString(@"alexa_page_alexa_voice_example");
        self.contenLabel.textAlignment = NSTextAlignmentLeft;
        self.contenLabel.numberOfLines = 0;
       
        [self.contenLabel sizeToFit];
        [self.contentView addSubview:self.contenLabel];
        
        
        [self makeConstraints];
        [self configureOEMTheme];
    }
    return self;
}

- (void)configureOEMTheme{
    [self configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.contentView configureThemeTag:OEMThemesTag_UIView_Foreground];
//    [self.contentView specialPropertiesForDarkMode:@{
//        @(OEMThemesTag_UIView_Foreground) : CommonDarkThemeForegroudColor,
//    } lightModeProperties:@{
//        @(OEMThemesTag_UIView_Foreground) : CommonLightThemeForegroudColor,
//    }];
    
  //  [self.retryButton configureThemeTag:OEMThemesTag_UIButton_TitleThemeColor];
  

    [self.contenLabel configure40TranslucentTrait];
    self.contenLabel.backgroundColor = [UIColor clearColor];
}

- (void)makeConstraints {
    
    [self.contenLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView).offset(14);
        make.leading.equalTo(self.contentView).offset(24);
        make.trailing.equalTo(self.contentView).offset(-24);
        make.bottom.equalTo(self.contentView).offset(-2);
    }];
}


@end
