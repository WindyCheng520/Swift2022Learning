//
//  MSMineItemTableViewCell.m
//  MSMine
//
//  Created by 及时行乐 on 2020/7/13.
//

#import "MSMineItemTableViewCell.h"
#import <MSBusiness/MSUIConfiguration.h>
#import "MSMineBundle.h"


@interface MSMineItemTableViewCell ()

@property (nonatomic, strong) HGImageView *iconImageView;
@property (nonatomic, strong) HGLabel *titleLabel;
@property (nonatomic, strong) HGLabel *descLabel;
@property (nonatomic, strong) HGImageView *arrowImageView;

@end

@implementation MSMineItemTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.iconImageView = [HGImageView new];
        [self.contentView addSubview:self.iconImageView];
        
        self.titleLabel = [HGLabel new];
        self.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightRegular];
        self.titleLabel.textColor = [UIColor blackColor];
        [self.contentView addSubview:self.titleLabel];
        
        self.descLabel = [HGLabel new];
        self.descLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightRegular];
        self.descLabel.textColor = [MSUIConfiguration sh_assistColor];
        [self.contentView addSubview:self.descLabel];
        
        self.arrowImageView = [HGImageView new];
        self.arrowImageView.image = MSResourceImage(@"ic_list_go");
        [self.contentView addSubview:self.arrowImageView];

        [self makeConstraints];
        
        [self configureOEMTheme];
    }
    return self;
}

- (void)configureOEMTheme{
    [self.titleLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
    [self.descLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
    [self.contentView configureThemeTag:OEMThemesTag_UIView_Foreground];
}

- (void)makeConstraints
{
    [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(24, 24));
        make.leading.equalTo(self).offset(16);
        make.top.equalTo(self).offset(20);
    }];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.iconImageView.mas_trailing).offset(8);
        make.centerY.equalTo(self);
        make.trailing.equalTo(self.descLabel.mas_leading);
    }];
    [self.descLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.trailing.equalTo(self.arrowImageView.mas_leading).offset(-8);
        make.width.mas_equalTo(5);
    }];
    [self.arrowImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(16, 16));
        make.centerY.equalTo(self);
        make.trailing.equalTo(self).offset(-16);
    }];
}
-(void)refreshDataWithImage:(NSString*)imageStr title:(NSString*)title subtitle:(NSString*)subtitle{
    self.iconImageView.image = MSResourceImage(imageStr);
    self.titleLabel.text = title;
    self.descLabel.text = subtitle;
    //计算字体大小,更新布局
    CGSize textSize1 = [subtitle sizeWithAttributes:@{NSFontAttributeName:self.descLabel.font}];
    [self.descLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.trailing.equalTo(self.arrowImageView.mas_leading).offset(-textSize1.width - 1);
        make.width.mas_equalTo(textSize1.width + 1);
    }];
}


@end
