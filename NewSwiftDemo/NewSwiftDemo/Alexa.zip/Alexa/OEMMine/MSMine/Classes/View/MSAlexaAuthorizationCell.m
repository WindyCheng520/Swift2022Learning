//
//  MSAlexaAuthorizationCell.m
//  MSMine
//
//  Created by WindyCheng on 2021/9/3.
//

#import "MSAlexaAuthorizationCell.h"
#import "MSMineBundle.h"

@interface MSAlexaAuthorizationCell ()

@property (nonatomic, strong) HGLabel *titleLabel;         //标题

@property (nonatomic, strong) HGImageView *imagesView;      //图片

@property (nonatomic, strong) HGLabel *contenLabel;          //内容
@property (nonatomic, strong) HGView *lineView;              //横线

@property (nonatomic, strong) HGLabel *desLabel;            //内容描述

@property (nonatomic, strong) HGLabel *tipsLabel;            //内容提示


@property (nonatomic, strong) HGButton *allowButton;          //允许
@property (nonatomic, strong) HGButton *cancelButton;         //取消


@end

@implementation MSAlexaAuthorizationCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.contentView.backgroundColor = [UIColor clearColor];
        self.backgroundColor = [UIColor clearColor];
        self.titleLabel = [HGLabel new];
        self.titleLabel.textColor = RGBA_HEX(0x000000,0.9);
        self.titleLabel.font = [UIFont systemFontOfSize:22 weight:UIFontWeightSemibold];
        self.titleLabel.text =  MSResourceString(@"alexa_page_bind_amazon_alexa");
        self.titleLabel.textAlignment = NSTextAlignmentLeft;
        self.titleLabel.numberOfLines = 1;
       
        [self.contentView addSubview:self.titleLabel];
        
        
        
        self.imagesView = [HGImageView new];
        self.imagesView.contentMode = UIViewContentModeScaleAspectFill;
        self.imagesView.image = MSResourceImage(@"img_expand_alexa.jpg");
        self.imagesView.layer.cornerRadius = 12.0;
        self.imagesView.clipsToBounds = YES;
        [self.contentView addSubview:self.imagesView];
        
        
     
        self.contenLabel = [HGLabel new];
        self.contenLabel.textColor = RGBA_HEX(0x000000,0.6);
        self.contenLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
        self.contenLabel.text = MSResourceString(@"alexa_page_bind_amazon_alexa_content");
        self.contenLabel.textAlignment = NSTextAlignmentLeft;
        self.contenLabel.numberOfLines = 0;
       
        [self.contenLabel sizeToFit];
        [self.contentView addSubview:self.contenLabel];
        
        self.lineView = [[HGView alloc] init];
        self.lineView.backgroundColor = RGBA_HEX(0x999999,0.15);
        [self.contentView addSubview:self.lineView];
        
        
        self.desLabel = [HGLabel new];
        self.desLabel.textColor = RGBA_HEX(0x000000,0.9);
        self.desLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
        self.desLabel.text =  MSResourceString(@"alexa_page_alexa_required");
        self.desLabel.textAlignment = NSTextAlignmentLeft;
        self.desLabel.numberOfLines = 1;
        [self.contentView addSubview:self.desLabel];
        
        
        self.tipsLabel = [HGLabel new];
        self.tipsLabel.textColor = RGBA_HEX(0x000000,0.6);
        self.tipsLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
        self.tipsLabel.text = MSResourceString(@"alexa_page_alexa_authorities");
        self.tipsLabel.textAlignment = NSTextAlignmentLeft;
        self.tipsLabel.numberOfLines = 0;
        [self.contentView addSubview:self.tipsLabel];
        
        self.allowButton = [HGButton new];
        [self.allowButton setTitleColor:RGB_HEX(0xFFFFFF) forState:UIControlStateNormal];
        self.allowButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
        self.allowButton.backgroundColor = RGB_HEX(0x267AFF);
        self.allowButton.layer.cornerRadius = 22.0;
        self.allowButton.clipsToBounds = YES;
        [self.allowButton setTitle:MSResourceString(@"alexa_page_alexa_allow") forState:UIControlStateNormal];
        [self.allowButton addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
        self.allowButton.hidden = NO;
        [self.contentView addSubview:self.allowButton];
        
        
        self.cancelButton = [HGButton new];
        [self.cancelButton setTitleColor:RGB_HEX(0x267AFF) forState:UIControlStateNormal];
        self.cancelButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightMedium];
        [self.cancelButton setTitle:MSResourceString(@"alexa_page_alexa_cancel") forState:UIControlStateNormal];
        self.cancelButton.layer.cornerRadius = 22.0;
        self.cancelButton.layer.borderColor = RGBA_HEX(0xBBBBBB,0.3).CGColor;
        self.cancelButton.layer.borderWidth = 1.0;
        self.cancelButton.clipsToBounds = YES;
        [self.cancelButton addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
        self.cancelButton.hidden = NO;
        [self.contentView addSubview:self.cancelButton];
        
        
        [self makeConstraints];
        [self configureOEMTheme];
    }
    return self;
}

-(void)click:(UIButton *)sender{
    if (self.allowButton == sender) {
        if (self.allowBlock) {
            self.allowBlock();
        }
    }else{
        if (self.cancelBlock) {
            self.cancelBlock();
        }
    }
}

- (void)configureOEMTheme{
    [self configureThemeTag:OEMThemesTag_UIView_Foreground];
    [self.contentView configureThemeTag:OEMThemesTag_UIView_Foreground];
   // [self.titleLabel configureThemeTag:OEMThemesTag_UIView_Foreground];
//    [self.contentView specialPropertiesForDarkMode:@{
//        @(OEMThemesTag_UIView_Foreground) : CommonDarkThemeForegroudColor,
//    } lightModeProperties:@{
//        @(OEMThemesTag_UIView_Foreground) : CommonLightThemeForegroudColor,
//    }];
    
    [self.titleLabel configure90TranslucentTrait];
    [self.contenLabel configure90TranslucentTrait];
    [self.desLabel configure90TranslucentTrait];
    [self.tipsLabel configure40TranslucentTrait];
    self.titleLabel.backgroundColor = [UIColor clearColor];
    self.contenLabel.backgroundColor = [UIColor clearColor];
    self.desLabel.backgroundColor = [UIColor clearColor];
    self.tipsLabel.backgroundColor = [UIColor clearColor];
//    [self.cancelButton configureThemeTag:OEMThemesTag_UIButton_TitleTraitColor];
//        [self.contentView specialPropertiesForDarkMode:@{
//            @(OEMThemesTag_UIView_Foreground) : CommonDarkThemeForegroudColor,
//        } lightModeProperties:@{
//            @(OEMThemesTag_UIView_Foreground) : CommonLightThemeForegroudColor,
//        }];
    WEAKSELF
    [self registerTraitDidChangeCallback:^{
//
        if (OEMThemeIsDarkMode) {
            [weakSelf.cancelButton setTitleColor:RGBA_HEX(0xFFFFFF,0.9) forState:UIControlStateNormal];
        }else{
            [weakSelf.cancelButton setTitleColor:RGBA_HEX(0x000000,0.9)forState:UIControlStateNormal];
        }
        
        
    } callImmidiately:YES];
}

- (void)makeConstraints {
    
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView).offset(40);
        make.leading.equalTo(self.contentView).offset(24);
        make.trailing.equalTo(self.contentView).offset(-16);
        make.height.mas_equalTo(26);
    }];
    
    [self.imagesView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleLabel.mas_bottom).offset(19);
        make.leading.equalTo(self.contentView).offset(24);
        make.trailing.equalTo(self.contentView).offset(-24);
        make.height.mas_equalTo(112);
    }];
    
    [self.contenLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.imagesView.mas_bottom).offset(24);
        make.leading.equalTo(self.contentView).offset(24);
        make.trailing.equalTo(self.contentView).offset(-24);
      //  make.bottom.equalTo(self.contentView).offset(-2);
    }];
    
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contenLabel.mas_bottom).offset(24);
        make.leading.equalTo(self.contentView).offset(24);
        make.trailing.equalTo(self.contentView).offset(-24);
        make.height.mas_equalTo(1);
    }];
    
    [self.desLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.lineView.mas_bottom).offset(24);
        make.leading.equalTo(self.contentView).offset(24);
        make.trailing.equalTo(self.contentView).offset(-24);
        make.height.mas_equalTo(20);
    }];
    
    [self.tipsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.desLabel.mas_bottom).offset(3);
        make.leading.equalTo(self.contentView).offset(24);
        make.trailing.equalTo(self.contentView).offset(-24);
    }];
    
    
    [self.allowButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.tipsLabel.mas_bottom).offset(40);
        make.leading.equalTo(self.contentView).offset(24);
        make.trailing.equalTo(self.contentView).offset(-24);
        make.height.mas_equalTo(44);
    }];
    
    [self.cancelButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.allowButton.mas_bottom).offset(12);
        make.leading.equalTo(self.contentView).offset(24);
        make.trailing.equalTo(self.contentView).offset(-24);
        make.height.mas_equalTo(44);
        make.bottom.equalTo(self.contentView).offset(-2);
    }];
}


@end
