//
//  MSMineServiceItemCell.m
//  MSMine
//
//  Created by WindyCheng on 2021/5/27.
//

#import "MSMineServiceItemCell.h"
#import "MSMineBundle.h"

@implementation MSMineServiceItemCell

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.iconImageView = [HGImageView new];
        [self.contentView addSubview:self.iconImageView];
        
        self.titleLabel = [HGLabel new];
        self.titleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightRegular];
        self.titleLabel.numberOfLines = 0;
        self.titleLabel.textAlignment = NSTextAlignmentLeft;
        [self.titleLabel sizeToFit];
        self.titleLabel.textColor = RGB_HEX(0x666666);
        [self.contentView addSubview:self.titleLabel];
        [self makeConstraints];
        [self configureOEMTheme];
    }
    return self;
}

- (void)configureOEMTheme{
    [self.titleLabel configure60TranslucentTrait];
}

-(void)setItem:(MSMineItem *)item{
    _item = item;
    self.titleLabel.text = _item.title;
    self.iconImageView.image = MSResourceImage(_item.icon);
}


- (void)makeConstraints{
    [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(40, 40));
//        make.top.equalTo(self).offset(0);
        make.centerY.equalTo(self).offset(-2);
        make.leading.equalTo(self);
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(self.iconImageView.mas_bottom).offset(6);
        make.centerY.equalTo(self.iconImageView);
        make.leading.equalTo(self.iconImageView.mas_trailing).offset(8);
        make.trailing.equalTo(self).offset(-40);
    }];
}

@end
