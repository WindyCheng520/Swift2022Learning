//
//  MSMineAdditionalServiceCell.h
//  MSMine
//
//  Created by chengls1365 on 2021/5/27.
//

#import <UIKit/UIKit.h>
#import "MSMineItem.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^AdditionalServiceItemBlock)(NSInteger index);
@interface MSMineAdditionalServiceCell : HGTableViewCell

@property (nonatomic, strong) NSArray<MSMineItem*> *items0;

@property (nonatomic, strong) NSArray<MSMineItem*> *items;

@property (nonatomic, copy)AdditionalServiceItemBlock block;
@end

NS_ASSUME_NONNULL_END
