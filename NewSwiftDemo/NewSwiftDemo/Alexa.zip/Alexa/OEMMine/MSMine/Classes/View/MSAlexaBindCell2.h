//
//  MSAlexaBindCell2.h
//  MSMine
//
//  Created by WindyCheng on 2021/8/26.
//

#import <OEMFoundation/HGUIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MSAlexaBindCell2 : HGTableViewCell


@property (nonatomic, strong) HGLabel *contenLabel;          //内容描述





@end

NS_ASSUME_NONNULL_END
