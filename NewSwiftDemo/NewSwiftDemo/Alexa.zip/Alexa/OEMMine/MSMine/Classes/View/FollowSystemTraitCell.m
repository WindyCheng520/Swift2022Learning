//
//  FollowSystemTraitCell.m
//  MSLogin
//
//  Created by Neil 韦学宁 on 2021/7/13.
//

#import "FollowSystemTraitCell.h"
#import "MSMineBundle.h"

@implementation FollowSystemTraitCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self initSubViews];
    }
    return self;
}

- (void)initSubViews{
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    self.textTitle = [[UILabel alloc] init];
    self.textTitle.font = [UIFont systemFontOfSize:16];
    self.textTitle.textAlignment = NSTextAlignmentLeft;
    self.textTitle.text = @"System";
    
    self.subTitleDescription = [[UILabel alloc] init];
    self.subTitleDescription.numberOfLines = 0;
    self.subTitleDescription.font = [UIFont systemFontOfSize:12];
    self.subTitleDescription.textAlignment = NSTextAlignmentLeft;
    self.subTitleDescription.adjustsFontSizeToFitWidth = YES;
    self.subTitleDescription.text = @"By enable this, the dark mode switch on or off automatically to match your system settings.";
    
    self.switchButton = [[UISwitch alloc] init];
    self.switchButton.tintColor = CommonThemeColor;
    [self.switchButton addTarget:self action:@selector(onSwitch:) forControlEvents:UIControlEventValueChanged];
    
    [self.contentView addSubview:self.textTitle];
    [self.contentView addSubview:self.subTitleDescription];
    [self.contentView addSubview:self.switchButton];
    
    [self makeConstraints];
    [self conifigureOEMTheme];
}

- (void)makeConstraints{
    [self.textTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.textTitle.superview).offset(16);
        make.top.equalTo(self.textTitle.superview).offset(15);
    }];
    [self.subTitleDescription mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.equalTo(self.subTitleDescription.superview).offset(16);
        make.top.equalTo(self.textTitle.mas_bottom).offset(4);
        make.trailing.equalTo(self.switchButton.mas_leading).offset(-16);
        //make.bottom.equalTo(self.subTitleDescription.superview).offset(5);
    }];
    [self.switchButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(48, 24));
        make.top.equalTo(self.switchButton.superview).offset(23.5);
        make.trailing.equalTo(self.switchButton.superview).offset(-16);
    }];
}

- (void)conifigureOEMTheme{
    [self.textTitle configure90TranslucentTrait];
    [self.subTitleDescription configure40TranslucentTrait];
    [self.contentView configureThemeTag:OEMThemesTag_UIView_Foreground];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)onSwitch:(UISwitch *)button{
    if (self.followSystemChange) {
        self.followSystemChange(button.isOn);
    }
}

@end
