//
//  OEMThemeCell.h
//  MSLogin
//
//  Created by Neil 韦学宁 on 2021/7/13.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface OEMThemeCell : UITableViewCell

@property(nonatomic, strong)UILabel * textTitle;

@property(nonatomic, strong)UIImageView * checkIcon;

@property(nonatomic, readonly, assign)BOOL isdark;

- (void)setDarkTitle:(BOOL)isDark;


@end

NS_ASSUME_NONNULL_END
