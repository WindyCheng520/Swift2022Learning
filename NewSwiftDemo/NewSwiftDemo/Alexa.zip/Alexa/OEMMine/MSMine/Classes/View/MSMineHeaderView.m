//
//  MSMineHeaderView.m
//  MSMine
//
//  Created by 及时行乐 on 2020/7/13.
//

#import "MSMineHeaderView.h"
#import "MSMineBundle.h"
#import <MSBusiness/MSUIConfiguration.h>
#import <SDWebImage/UIImageView+WebCache.h>
#import <MSBusiness/MSUserInfoManager.h>
#import <OEMFoundation/OEMCustomize.h>
#import <SDWebImage/SDImageCache.h>


@interface MSMineHeaderView ()

@property(nonatomic,strong)UIImageView * bgImageView;
@property (nonatomic, strong) UIView *containerView;
@property (nonatomic, strong) HGImageView *shadowImageView;
@property (nonatomic, strong) HGImageView *portraitImageView;
@property (nonatomic, strong) HGLabel *nickLabel;
@property (nonatomic, strong) HGLabel *loginOrEditLabel;
@property (nonatomic, strong) HGImageView *arrowImageView; //箭头

@end

@implementation MSMineHeaderView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
//        self.shadowImageView = [HGImageView new];
//        self.shadowImageView.image = MSResourceImage(@"me_avatar_shadow");
//        self.shadowImageView.contentMode = UIViewContentModeScaleToFill;
//        [self addSubview:self.shadowImageView];
        
        self.bgImageView = [UIImageView new];
        UIImage * headerBG = OEMCustomizableImage(@"personal_center_bg");
        if (headerBG) {
            self.bgImageView.image = headerBG;
            self.clipsToBounds = NO;
        }else{
            self.bgImageView.hidden = YES;
        }
        [self addSubview:self.bgImageView];
        
        self.containerView = [UIView new];
        self.containerView.alpha = 1;
        [self addSubview:self.containerView];
        
        self.portraitImageView = [HGImageView new];
//        self.portraitImageView.image = MSResourceImage(@"me_pic_avatar_gray");
        self.portraitImageView.layer.cornerRadius = 30;
        self.portraitImageView.layer.masksToBounds = YES;
        self.portraitImageView.clipsToBounds = YES;
        self.portraitImageView.contentMode = UIViewContentModeScaleAspectFill;
        [self.containerView addSubview:self.portraitImageView];
        
        self.nickLabel = [HGLabel new];
        self.nickLabel.text = MSResourceString(@"mine_page_login_button");
        self.nickLabel.font = [UIFont systemFontOfSize:22 weight:UIFontWeightBold];
        self.nickLabel.textColor = [UIColor blackColor];
        self.nickLabel.textAlignment = NSTextAlignmentLeft;
        [self.containerView addSubview:self.nickLabel];
        
        self.loginOrEditLabel = [HGLabel new];
        self.loginOrEditLabel.text = MSResourceString(@"mine_page_start_login");
        self.loginOrEditLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
        self.loginOrEditLabel.textColor = RGB_HEX(0x666666);
        self.loginOrEditLabel.textAlignment = NSTextAlignmentLeft;
        [self.containerView addSubview:self.loginOrEditLabel];
        
        self.arrowImageView = [HGImageView new];
        self.arrowImageView.image = MSResourceImage(@"ic_list_go");
        [self.containerView addSubview:self.arrowImageView];
        
        
        UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(clickLoginOrEdit)];
        [self addGestureRecognizer:tapGestureRecognizer];
        
        [self makeContstraints];
        
        [self configureOEMTheme];
    }
    return self;
}

- (void)configureOEMTheme{
    [self.nickLabel configureThemeTag:OEMThemesTag_UILabel_TextColor];
    [self.loginOrEditLabel configure40TranslucentTrait];
}

- (void)makeContstraints {
//    [self.shadowImageView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.center.equalTo(self.portraitImageView);
//        make.size.mas_equalTo(CGSizeMake(80, 80));
//    }];
    [self.bgImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self);
        make.leading.equalTo(self);
        make.trailing.equalTo(self);
        make.bottom.equalTo(self);
    }];
    
    [self.containerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.equalTo(self);
        make.bottom.equalTo(self.mas_bottom);
        make.height.mas_equalTo(100);
    }];
    
    [self.portraitImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.containerView).offset(20);
        make.leading.equalTo(self.containerView).offset(16);
        make.size.mas_equalTo(CGSizeMake(60, 60));
        make.centerY.equalTo(self.containerView);
    }];
    [self.nickLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(self.portraitImageView.mas_trailing).offset(16);
        make.trailing.equalTo(self.containerView).offset(-52);
        make.top.mas_equalTo(self.portraitImageView.mas_top).offset(10);
//        make.height.mas_equalTo(22);
    }];
    [self.loginOrEditLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.nickLabel.mas_bottom).offset(6);
        make.leading.mas_equalTo(self.portraitImageView.mas_trailing).offset(16);
        make.trailing.equalTo(self.containerView).offset(-52);
        make.height.mas_equalTo(16);
    }];
    
    [self.arrowImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(16, 16));
        make.centerY.equalTo(self.portraitImageView);
        make.trailing.equalTo(self.containerView).offset(-16);
    }];
}

- (void)refreshDataWithLogin:(BOOL)isLogin nickname:(NSString*)nickname headIcon:(NSString*)headIcon {
    if (isLogin) {
        
        NSString *url = @"";
        if ([headIcon isKindOfClass:[NSString class]]) {
            url = headIcon;
        }else{
            url = @"";
        }
        [self cacheImgView:self.portraitImageView url:url placeholderImage:self.portraitImageView.image?self.portraitImageView.image:MSResourceImage(@"me_pic_avatar_gray")];
//        [self.portraitImageView sd_setImageWithURL:[NSURL URLWithString:url] placeholderImage:MSResourceImage(@"me_pic_avatar_gray")];
//        NSLog(@"url======%@",url);
        self.nickLabel.text = nickname;
        NSString *email = [MSUserInfoManager shareManager].loginInfoModel.email;
        MSUserInfoManager * mgr = [MSUserInfoManager shareManager];
        if (mgr.isAppleSignIn) {
            email = [mgr appleSignInEmail];
        }
        self.loginOrEditLabel.text = email;
    } else {
        self.portraitImageView.image = MSResourceImage(@"me_pic_avatar_gray");
        self.nickLabel.text = MSResourceString(@"mine_page_login_button");
        self.loginOrEditLabel.text = MSResourceString(@"mine_page_start_login");
    }
    
}

- (void)clickLoginOrEdit {
    if (self.delegate && [self.delegate respondsToSelector:@selector(headerViewDidClick:)]) {
        [self.delegate headerViewDidClick:self];
    }
}

-(NSString *)getOtherCacheKey:(NSString *)urlStr {
    NSString *keyString = [urlStr componentsSeparatedByString:@"?"].firstObject;
    return keyString;
}
-(void)cacheImgView:(UIImageView *)myImgView url:(NSString *)urlString placeholderImage:(UIImage *)placeholderImage{
    NSString *headUrlPre = [self getOtherCacheKey:urlString];
    UIImage *cacheImage = [[SDImageCache sharedImageCache] imageFromCacheForKey:headUrlPre];
    if (cacheImage != nil) {
        myImgView.image = cacheImage;
    } else {
        
        NSURL *url = [NSURL URLWithString:urlString];

        //通过context参数指定存储的key，指定的key为截取urlString中"？"前面的内容
        SDWebImageCacheKeyFilter *cacheKeyFilter = [SDWebImageCacheKeyFilter cacheKeyFilterWithBlock:^NSString * _Nullable(NSURL * _Nonnull imageURL) {
            if ([url isEqual:imageURL]) {
                return headUrlPre;
            } else {
                return url.absoluteString;
            }
        }];
        SDWebImageContext *context = [NSDictionary dictionaryWithObject:cacheKeyFilter forKey:SDWebImageContextCacheKeyFilter];
        
        [myImgView sd_setImageWithURL:[NSURL URLWithString:cacheImage != nil ? headUrlPre : urlString] placeholderImage:placeholderImage options:0 context:context];
    }
}

@end

