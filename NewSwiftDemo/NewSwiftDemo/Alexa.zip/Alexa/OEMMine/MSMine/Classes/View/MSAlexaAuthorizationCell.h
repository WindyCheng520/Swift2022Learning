//
//  MSAlexaAuthorizationCell.h
//  MSMine
//
//  Created by WindyCheng on 2021/9/3.
//

#import <OEMFoundation/HGUIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MSAlexaAuthorizationCell : HGTableViewCell

@property (nonatomic, copy) dispatch_block_t allowBlock;
@property (nonatomic, copy) dispatch_block_t cancelBlock;

@end

NS_ASSUME_NONNULL_END
