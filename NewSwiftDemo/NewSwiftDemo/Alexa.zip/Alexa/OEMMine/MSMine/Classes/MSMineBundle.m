//
//  MSMineResource.m
//  MSMine
//
//  Created by syp on 2020/6/17.
//

#import "MSMineBundle.h"

@implementation MSMineBundle
+(NSBundle *)strBundle{
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *bundlePath = [bundle.resourcePath stringByAppendingPathComponent:@"MSBusiness.bundle"];
    return [NSBundle bundleWithPath:bundlePath];
}

+ (NSBundle *)currentBundle {
    NSBundle *bundle = [NSBundle mainBundle];
    NSString *bundlePath = [bundle.resourcePath stringByAppendingPathComponent:@"MSMine.bundle"];
    return [NSBundle bundleWithPath:bundlePath];
}

@end
