//
//  MSMineRepository.m
//  MSMine
//
//  Created by 及时行乐 on 2020/7/13.
//

#import "MSMineRepository.h"
#import "MSAlexaBindEntity.h"
#import <MJExtension/MJExtension.h>
#import "AuthorizationManager.h"
#import <MSBusiness/MSUserDefaultTools.h>
#import <MSBusiness/MSUserInfoManager.h>
#import <MSBusiness/BusinessRequestManager.h>
#import <MSBusiness/BusinessResponse.h>
//#import <MSBusiness/MSAppInfo.h>
#import <MSBusiness/MideaSecurity.h>
#import <MJExtension/MJExtension.h>


NSString *const MSMineErrorDomain = @"MSMineErrorDomain";

//查询Alexa 关联状态
#define MSMine_Check_Alexa_Linking_Status      @"/v1/user/oauth/status"

//上传日志文件
//http://confluence.msmart.com/pages/viewpage.action?pageId=94209442
#define MSMine_upload_log_file                 @"/v1/common/log/upload"

//上传日志文件新增记录
//http://confluence.msmart.com/pages/viewpage.action?pageId=92364356
#define MSMine_appUserLog_add                  @"/v1/operation/appUserLog/add"

@interface MSMineRepository ()

//@property(copy, nonatomic)MSMineRepositorySuccessBlock success;
//
//@property(copy, nonatomic)MSMineRepositoryFailureBlock failure;



@end


static MSMineRepositorySuccessBlock _success;
static MSMineRepositoryFailureBlock _failure;

@implementation MSMineRepository


////获取alexa AccessToken
+(void)getAlexaAccessTokenWithGrantType:(NSString *)grantType
                         alexaAthorCode:(NSString *)code
                          alexaClientID:(NSString *)clientID
                      alexaClientSecret:(NSString *)clientSecret
                            redirectUri:(NSString *)redirectUri
                                isQuery:(BOOL)isQuery
                                success:(MSMineRepositorySuccessBlock)success
                                failure:(MSMineRepositoryFailureBlock)failure{
    _success = success;
    _failure = failure;
    NSMutableDictionary *parameters = @{@"grant_type":grantType,
                                        @"client_id":clientID,
                                        @"client_secret": clientSecret,
                                        @"redirect_uri":redirectUri}.mutableCopy;
    if (code.length > 0) {
        parameters[@"code"] = code;
    }else{
        NSString *refreshToken = [MSUserDefaultTools getAlexaRefleshToken];
        parameters[@"refresh_token"] = refreshToken;
        [parameters removeObjectForKey:@"code"];
    }
    
    NSString *url = @"https://api.amazon.com/auth/o2/token";
    NSData * httpBodyData = nil;
    if (parameters) {
        httpBodyData = [NSJSONSerialization dataWithJSONObject:parameters options:0 error:nil];
    }
    NSMutableDictionary * header = [NSMutableDictionary new];
    [header setObject:@"application/json; text/json; text/javascript; text/html; text/plain" forKey:@"Content-Type"];
    BusinessRequest * reqconfig = [BusinessRequest new];
    reqconfig.requestTimeout = 15;
    [[BusinessRequestManager sharedInstance] commonRequestWithMethod:BusinessRequestMethodPost URLString:url httpBody:httpBodyData request:nil httpHeader:header cache:nil success:^(NSURLSessionTask * _Nullable httpbase, id  _Nonnull responseObject) {
        if ([responseObject isKindOfClass:[NSDictionary class]] ) {
            AlexaAccessToken *tokenEnity = [AlexaAccessToken mj_objectWithKeyValues:responseObject];
            AlexaInfo *info =  [AuthorizationManager sharedManager].entity.alexaInfo;
            NSDictionary *dict = info.alexaQueryItems;
            NSString *skillStage = dict[@"skill_stage"];
            NSString *redirectUri = dict[@"redirect_uri"];
            NSString *authCode = [AuthorizationManager sharedManager].authorCode;
            NSString *type = @"AUTH_CODE";
            NSString *skillID = info.skill_id;
            NSString *accessToken = tokenEnity.access_token;
            NSString *refleshToken = tokenEnity.refresh_token;
            NSString *nowTimestamp = [self getNowTimestamp];
            [MSUserDefaultTools saveAlexaTokenTimeToDisk:nowTimestamp];
            [MSUserDefaultTools saveAlexaTokenToDisk:accessToken];
            [MSUserDefaultTools saveAlexaRefleshTokenToDisk:refleshToken];
            [AuthorizationManager sharedManager].authorCode = @"";
            if (isQuery) {
                [self queryAlexSkillStatusWithAccessToken:accessToken
                                                  skillID:skillID
                                                  success:success
                                                  failure:failure];
            }else{
                [self setAlexSkillStatusWithSkillStage:skillStage
                                           redirectUri:redirectUri
                                              authCode:authCode
                                                  type:type
                                           accessToken:accessToken
                                               skillID:skillID
                                              fullFlow:YES
                                               success:success
                                               failure:failure];
            }
        }
    } failure:^(NSURLSessionTask * _Nullable httpbase, NSError * _Nonnull error) {
        if (failure) {
            failure(error);
        }
    }];
}

////设置与Alexa  关联状态
+(void)setAlexSkillStatusWithSkillStage:(NSString *)state
                            redirectUri:(NSString *)redirectUri
                               authCode:(NSString *)authCode
                                   type:(NSString *)type
                            accessToken:(NSString *)accessToken
                                skillID:(NSString *)skillID
                               fullFlow:(BOOL)fullFlow
                                success:(MSMineRepositorySuccessBlock)success
                                failure:(MSMineRepositoryFailureBlock)failure{
    // NSString *url = @"https://api.amazonalexa.com//v1/users/~current/skills/amzn1.ask.skill.a289de06-9704-4f87-bc1d-8ae677fe7fc4/enablement";
    NSString *url = [NSString stringWithFormat:@"https://api.amazonalexa.com/v1/users/~current/skills/%@/enablement", skillID];
    NSDictionary *parameters = @{@"stage":state,
                                 @"accountLinkRequest":@{
                                         @"redirectUri":redirectUri,
                                         @"authCode":authCode,
                                         @"type": type}
    };
    
    NSString *jsonString = [self dictionaryToJson:parameters];
    NSData *body  = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    
    NSMutableDictionary * header = [NSMutableDictionary new];
    [header setValue:@"application/json" forKey:@"Content-Type"];
    [header setValue:@"application/json" forKey:@"Accept"];
    [header setValue:[NSString stringWithFormat:@"Bearer %@", accessToken] forKey:@"Authorization"];
    
    [[BusinessRequestManager sharedInstance] commonRequestWithMethod:BusinessRequestMethodPost URLString:url httpBody:body request:nil httpHeader:header cache:nil success:^(NSURLSessionTask * _Nullable httpbase, id  _Nonnull responseObject) {
        if (_success){
            _success(responseObject);
        }
        if (success){
            success(responseObject);
        }
    } failure:^(NSURLSessionTask * _Nullable httpbase, NSError * _Nonnull error) {
        if (_failure){
            _failure(error);
        }
        if (failure){
            failure(error);
        }
    }];
}


////查询与Alexa  关联状态
+(void)queryAlexSkillStatusWithAccessToken:(NSString *)accessToken
                                   skillID:(NSString *)skillID
                                   success:(MSMineRepositorySuccessBlock)success
                                   failure:(MSMineRepositoryFailureBlock)failure{
    // NSString *url = @"https://api.amazonalexa.com//v1/users/~current/skills/amzn1.ask.skill.a289de06-9704-4f87-bc1d-8ae677fe7fc4/enablement";
    NSString *url = [NSString stringWithFormat:@"https://api.amazonalexa.com/v1/users/~current/skills/%@/enablement", skillID];
    NSMutableDictionary * header = [NSMutableDictionary new];
    [header setValue:@"application/json" forKey:@"Content-Type"];
    [header setValue:@"application/json" forKey:@"Accept"];
    [header setValue:[NSString stringWithFormat:@"Bearer %@", accessToken] forKey:@"Authorization"];
    BusinessRequest * reqconfig = [BusinessRequest new];
    reqconfig.requestTimeout = 15;
    [[BusinessRequestManager sharedInstance] commonGetWithURLString:url request:nil httpHeader:header cache:nil success:^(NSURLSessionTask * _Nullable httpbase, id  _Nonnull responseObject) {
        if (_success){
            _success(responseObject);
        }
        if (success){
            success(responseObject);
        }
    } failure:^(NSURLSessionTask * _Nullable httpbase, NSError * _Nonnull error) {
        if (_failure){
            _failure(error);
        }
        if (failure){
            failure(error);
        }
    }];
}

////向OEM云端查询与Alexa Google  关联状态
+(void)checkOAuth2BindStatus:(MSMineRepositorySuccessBlock)success
                           failure:(MSMineRepositoryOEMFailureBlock)failure{
    [self POST:MSMine_Check_Alexa_Linking_Status parameters:@{} success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK){
            if ([res.data isKindOfClass:[NSDictionary class]]){
                NSDictionary *result = res.data;
                safeCallBlock(success, result);
            }
        }else{
          MSBusinessError *e = [MSBusinessError errorWithDomain:MSMineErrorDomain code:res.code localizedDescription:res.msg];
            safeCallBlock(failure, e);
        }
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        MSBusinessError *e = [MSBusinessError errorWithNetwork:error];
        safeCallBlock(failure, e);
    }];
}

////设置与Google关联状态
+(void)googleOauthLink:(NSString *)state
           redirectUri:(NSString *)redirectUri
              authCode:(NSString *)authCode
                agentID:(NSString *)agentID
               success:(MSMineRepositorySuccessBlock)success
               failure:(MSMineRepositoryFailureBlock)failure{
    // NSString *url = @"https://api.amazonalexa.com//v1/users/~current/skills/amzn1.ask.skill.a289de06-9704-4f87-bc1d-8ae677fe7fc4/enablement";
    NSString *url = [NSString stringWithFormat:@"%@?code=%@&state=%@",
                     redirectUri,
                     authCode,
                     state];
    BusinessRequest * reqconfig = [BusinessRequest new];
    reqconfig.requestTimeout = 15;
    NSMutableDictionary * header = [NSMutableDictionary new];
    [header setValue:@"application/json" forKey:@"Content-Type"];
    [header setValue:@"application/json" forKey:@"Accept"];
    [[BusinessRequestManager sharedInstance] commonGetWithURLString:url request:nil httpHeader:header cache:nil success:^(NSURLSessionTask * _Nullable httpbase, id  _Nonnull responseObject) {
        if (_success){
            _success(responseObject);
        }
        if (success){
            success(responseObject);
        }
    } failure:^(NSURLSessionTask * _Nullable httpbase, NSError * _Nonnull error) {
        if (_failure){
            _failure(error);
        }
        if (failure){
            failure(error);
        }
    }];
}

+ (void)uploadOnlineLogWithFilePath:(NSString *)filePath
                            success:(MSMineRepositorySuccessBlock)success
                      progressBlock:(void (^)(float progress))progress
                            failure:(MSMineRepositoryFailureBlock)failure{
    [[BusinessRequestManager sharedInstance] uploadWithURLString:MSMine_upload_log_file parameters:nil uploadIntercept:^BusinessUploadItem * _Nullable{
        BusinessUploadItem * item = [BusinessUploadItem new];
        item.name = @"file";
        item.fileName = filePath.lastPathComponent;
        item.mimeType = @"text/plain";
        item.fileURL = filePath;
        return item;
    } progress:^(NSProgress * _Nullable pro) {
        float p = pro.completedUnitCount * 1.0 / pro.totalUnitCount * 1.0;
        dispatch_async(dispatch_get_main_queue(), ^{
            safeCallBlock(progress, p);
        });
    } success:^(NSURLSessionTask * _Nullable httpbase, id  _Nullable res) {
        if (![res isKindOfClass:[NSDictionary class]]) {
            safeCallBlock(failure, nil);
            return;
        }

        NSDictionary * groupDic = [res objectForKey:@"data"];
        if (![groupDic isKindOfClass:[NSDictionary class]] ) {
            safeCallBlock(failure, nil);
            return;
        }
        NSString * fileUrl = [groupDic objectForKey:@"url"];
        if (![fileUrl isKindOfClass:[NSString class]]) {
            safeCallBlock(failure, nil);
            return;
        }
        [self addUserLog:fileUrl success:^(NSDictionary *result) {
            safeCallBlock(success, nil);
        } failure:^(NSError *error) {
            safeCallBlock(failure, nil);
        }];
    } failure:^(NSURLSessionTask * _Nullable httpbase, NSError * _Nullable error) {
        safeCallBlock(failure, nil);
    }];
}

+ (void)addUserLog:(NSString *)fileURL
           success:(MSMineRepositorySuccessBlock)addUserLogSuccess
           failure:(MSMineRepositoryFailureBlock)addUserLogFailure{
    NSMutableDictionary * param = [NSMutableDictionary new];
    [param setObject:fileURL?:@"" forKey:@"fileUrl"];
    if ([fileURL rangeOfString:@".txt"].location != NSNotFound) {
        NSString * memo = [NSString stringWithFormat:@"%@_smart", [[UIDevice currentDevice] systemName]];
        [param setObject:memo forKey:@"memo"];
    }else{
        NSString * memo = [NSString stringWithFormat:@"%@_oem", [[UIDevice currentDevice] systemName]];
        [param setObject:memo forKey:@"memo"];
    }
    if ([MSUserInfoManager shareManager].isLogin) {
        NSString * email = [MSUserInfoManager shareManager].loginInfoModel.email;
        NSString * mobile = [MSUserInfoManager shareManager].loginInfoModel.mobile;
        if (email) {
            [param setObject:email forKey:@"email"];
        }
        if (mobile) {
            [param setObject:mobile forKey:@"mobile"];
        }
    }
    [self POST:MSMine_appUserLog_add parameters:param success:^(NSURLSessionTask *httpbase, id responseObject) {
        BusinessResponse *res = [BusinessResponse mj_objectWithKeyValues:responseObject];
        if (res.isOK) {
            safeCallBlock(addUserLogSuccess,nil);
        }else{
            NSError * error = [NSError errorWithDomain:MSMineErrorDomain code:res.code userInfo:@{NSLocalizedDescriptionKey: res.msg ?: @""}];
            safeCallBlock(addUserLogFailure, error);
        }
    } failure:^(NSURLSessionTask *httpbase, NSError *error) {
        safeCallBlock(addUserLogFailure,nil);
    }];
}

+ (NSURLSessionDataTask *_Nullable)POST:(NSString *_Nullable)URLString parameters:(NSDictionary *_Nullable)parameters success:(BusinessRequestManagerSuccess _Nullable )success failure:(BusinessRequestManagerFailure _Nullable )failure{
    return [[BusinessRequestManager sharedInstance] POST:URLString parameters:parameters cache:nil success:^(NSURLSessionTask * _Nonnull httpbase, id  _Nonnull responseObject) {
        safeCallBlock(success, httpbase, responseObject);
    } failure:^(NSURLSessionTask * _Nonnull httpbase, NSError * _Nonnull error) {
        safeCallBlock(failure, httpbase, error);
    }];
}


+ (NSString *)dictionaryToJson:(NSDictionary *)dic{
    NSError *parseError = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&parseError];
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
}


+ (NSString *)getNowTimestamp{
    NSDate *date = [NSDate dateWithTimeIntervalSinceNow:0];
    NSTimeInterval a = [date timeIntervalSince1970];
    NSString *timeString = [NSString stringWithFormat:@"%0.f", a];//转为字符型
    return timeString;
}

@end
