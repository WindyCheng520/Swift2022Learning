//
//  MSMineRepository.h
//  MSMine
//
//  Created by 及时行乐 on 2020/7/13.
//

#import <Foundation/Foundation.h>
#import <MSBusiness/MSBusinessError.h>


typedef void(^MSMineRepositoryFailureBlock)(NSError *error);
typedef void(^MSMineRepositorySuccessBlock)(NSDictionary *result);
typedef void(^MSMineRepositoryOEMFailureBlock)(MSBusinessError *error);


@interface MSMineRepository : NSObject


////获取alexa AccessToken
+(void)getAlexaAccessTokenWithGrantType:(NSString *)grantType
                         alexaAthorCode:(NSString *)code
                          alexaClientID:(NSString *)clientID
                      alexaClientSecret:(NSString *)clientSecret
                            redirectUri:(NSString *)redirectUri
                                isQuery:(BOOL)isQuery
                                success:(MSMineRepositorySuccessBlock)success
                                failure:(MSMineRepositoryFailureBlock)failure;


////设置与Alexa  关联状态
+(void)setAlexSkillStatusWithSkillStage:(NSString *)state
                            redirectUri:(NSString *)redirectUri
                               authCode:(NSString *)authCode
                                   type:(NSString *)type
                            accessToken:(NSString *)accessToken
                                skillID:(NSString *)skillID
                               fullFlow:(BOOL)fullFlow
                                success:(MSMineRepositorySuccessBlock)success
                                failure:(MSMineRepositoryFailureBlock)failure;


////向Alexa后台查询与Alexa  关联状态
+(void)queryAlexSkillStatusWithAccessToken:(NSString *)accessToken
                                   skillID:(NSString *)skillID
                                   success:(MSMineRepositorySuccessBlock)success
                                   failure:(MSMineRepositoryFailureBlock)failure;


////向OEM云端查询与Alexa, Google  关联状态
+(void)checkOAuth2BindStatus:(MSMineRepositorySuccessBlock)success
                           failure:(MSMineRepositoryOEMFailureBlock)failure;

/// google获取code
+(void)googleOauthLink:(NSString *)state
           redirectUri:(NSString *)redirectUri
              authCode:(NSString *)authCode
                agentID:(NSString *)agentID
               success:(MSMineRepositorySuccessBlock)success
               failure:(MSMineRepositoryFailureBlock)failure;

//上传日志
+ (void)uploadOnlineLogWithFilePath:(NSString *)filePath
                            success:(MSMineRepositorySuccessBlock)success
                      progressBlock:(void (^)(float progress))progress
                            failure:(MSMineRepositoryFailureBlock)failure;



@end

