//
//  MSAlexaBindEntity.m
//  MSMine
//
//  Created by WindyCheng on 2021/9/4.
//

#import "MSAlexaBindEntity.h"
#import <MJExtension/MJExtension.h>

@implementation MSAlexaBindEntity

@end


@implementation AlexaAccessToken

@end




@implementation Skill

+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"skillID":@"id"};
}


@end


@implementation User

+ (NSDictionary *)replacedKeyFromPropertyName{
    return @{@"userId":@"id"};
}

@end


@implementation AccountLink
@end


@implementation AlexaBindStatusEntity
@end
