//
//  MSMineItem.h
//  MSMine
//
//  Created by 及时行乐 on 2020/7/13.
//

#import <Foundation/Foundation.h>

@interface MSMineItem : NSObject

@property (nonatomic, strong) NSString *icon;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *desc;

@end
