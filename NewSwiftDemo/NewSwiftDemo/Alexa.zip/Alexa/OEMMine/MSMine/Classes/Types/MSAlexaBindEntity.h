//
//  MSAlexaBindEntity.h
//  MSMine
//
//  Created by WindyCheng on 2021/9/4.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MSAlexaBindEntity : NSObject

@property(nonatomic, copy)NSString *title;  //标题
@property(nonatomic, assign)NSInteger status;
@property(nonatomic, copy)NSString *tips;  //未绑定与绑定失败提示


@end

@interface AlexaAccessToken : NSObject

@property(nonatomic, copy)NSString *access_token;    //Alexa 授权token
@property(nonatomic, assign)NSInteger expires_in;     //失效时间秒(3600s/1小时）
@property(nonatomic, copy)NSString *refresh_token;    //重新刷新token
@property(nonatomic, copy)NSString *token_type;       //请求头(Authorization)   bearer
@end




@interface Skill :NSObject
@property (nonatomic , copy) NSString   *stage;
@property (nonatomic , copy) NSString   *skillID;
@end


@interface User :NSObject
@property (nonatomic , copy) NSString    *userId;
@end


@interface AccountLink :NSObject
@property (nonatomic , copy) NSString     *status;    //"LINKED"  已绑定
@end

@interface AlexaBindStatusEntity :NSObject
@property (nonatomic , strong) Skill       *skill;
@property (nonatomic , strong) User        *user;
@property (nonatomic , strong) AccountLink *accountLink;
@property (nonatomic , copy) NSString       *status;      //"ENABLED"  已启用

@end


NS_ASSUME_NONNULL_END
