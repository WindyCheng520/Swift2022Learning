//
//  ViewController.swift
//  OEMMineModule
//
//  Created by zhongch18 on 2022/2/25.
//

import UIKit
import MSMine
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let btn = UIButton.init(frame: CGRect.init(x:20, y:100, width:100, height:100))
        btn.backgroundColor = UIColor.black
        btn.addTarget(self, action: #selector(btnCli), for: .touchUpInside)
        self.view.addSubview(btn)
        // Do any additional setup after loading the view.
    }
    
    @objc func btnCli(){
        let mine:MSMineViewController = MSMineViewController.init()
//        mine.modalPresentationStyle = .fullScreen
        self.present(mine, animated: true, completion: nil)
    }


}

