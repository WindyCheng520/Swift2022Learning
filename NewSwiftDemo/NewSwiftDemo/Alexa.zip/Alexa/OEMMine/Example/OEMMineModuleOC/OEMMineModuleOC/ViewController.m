//
//  ViewController.m
//  OEMMineModuleOC
//
//  Created by zhongch18 on 2022/2/25.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    MSMineViewController * vc = [[MSMineViewController alloc] init];
    // Do any additional setup after loading the view.
}


@end
