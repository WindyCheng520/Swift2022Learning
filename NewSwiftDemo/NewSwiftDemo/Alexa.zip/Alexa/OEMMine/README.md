# MSMine

[![CI Status](https://img.shields.io/travis/yanghy2013@163.com/MSMine.svg?style=flat)](https://travis-ci.org/yanghy2013@163.com/MSMine)
[![Version](https://img.shields.io/cocoapods/v/MSMine.svg?style=flat)](https://cocoapods.org/pods/MSMine)
[![License](https://img.shields.io/cocoapods/l/MSMine.svg?style=flat)](https://cocoapods.org/pods/MSMine)
[![Platform](https://img.shields.io/cocoapods/p/MSMine.svg?style=flat)](https://cocoapods.org/pods/MSMine)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

MSMine is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'MSMine'
```

## Author

63414472@qq.com, shiyp4@midea.com

## License

MSMine is available under the MIT license. See the LICENSE file for more info.
