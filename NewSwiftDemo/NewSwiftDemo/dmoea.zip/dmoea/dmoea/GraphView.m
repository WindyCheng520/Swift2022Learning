//
//  GraphView.m
//  dmoea
//
//  Created by Windy on 2023/3/2.
//

#import "GraphView.h"

// CurveView.h



// CurveView.m

#define kPadding 40

@interface GraphView ()

//@property (nonatomic, assign) CGRect rect;
//@property (nonatomic, assign) CGFloat spacing;
//@property (nonatomic, assign) CGPoint startPoint;
//@property (nonatomic, assign) CGFloat startY;

@end

@implementation GraphView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        self.dataSource = [NSMutableArray array];
        self.spacing = (frame.size.width - kPadding * 2) / 9;
        
        UIPanGestureRecognizer *panGestureRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanGesture:)];
        [self addGestureRecognizer:panGestureRecognizer];
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    self.rect = rect;
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    // 绘制网格线
    CGContextSetStrokeColorWithColor(context, [UIColor lightGrayColor].CGColor);
    CGContextSetLineWidth(context, 1.0);
    CGFloat dashes[] = {3, 3};
    CGContextSetLineDash(context, 0, dashes, 2);
    for (NSInteger i = 1; i < self.rect.size.width / self.spacing; i++) {
        CGContextMoveToPoint(context, kPadding + i * self.spacing, kPadding);
        CGContextAddLineToPoint(context, kPadding + i * self.spacing, self.rect.size.height - kPadding);
    }
    for (NSInteger i = 1; i < (self.rect.size.height - kPadding * 2) / self.spacing; i++) {
        CGContextMoveToPoint(context, kPadding, kPadding + i * self.spacing);
        CGContextAddLineToPoint(context, self.rect.size.width - kPadding, kPadding + i * self.spacing);
    }
    CGContextStrokePath(context);
    
    // 绘制曲线
    CGContextSetStrokeColorWithColor(context, [UIColor blackColor].CGColor);
    CGContextSetLineWidth(context, 2.0);
    CGContextSetLineDash(context, 0, NULL, 0);
    CGContextBeginPath(context);
    CGFloat x = kPadding;
    CGFloat y = (1 - self.dataSource.firstObject.floatValue) * (self.rect.size.height - kPadding * 2) / 2 + kPadding;
    CGContextMoveToPoint(context, x, y);
    for (NSInteger i = 1; i < self.dataSource.count; i++) {
        x += self.spacing;
        y = (1 - self.dataSource[i].floatValue) * (self.rect.size.height - kPadding * 2) / 2 + kPadding;
        CGContextAddLineToPoint(context, x, y);
    }
    CGContextStrokePath(context);
    
    // 绘制坐标轴和标注
    CGContextSetStrokeColorWithColor(context, [UIColor blackColor].CGColor);
    CGContextSetLineWidth(context, 2.0);
    CGContextSetLineDash(context, 0, NULL, 0);
    CGContextMoveToPoint(context, kPadding, kPadding);
    CGContextAddLineToPoint(context, kPadding, self.rect.size.height - kPadding);
    CGContextAddLineToPoint(context, self.rect.size.width - kPadding, self.rect.size.height - kPadding);
    CGContextStrokePath(context);
    
    NSDictionary *attributes = @{    NSFontAttributeName: [UIFont systemFontOfSize:12.0],
                                     NSForegroundColorAttributeName: [UIColor blackColor],
    };
    CGFloat maxValue = [[self.dataSource valueForKeyPath:@"@max.floatValue"] floatValue];
    CGFloat minValue = [[self.dataSource valueForKeyPath:@"@min.floatValue"] floatValue];
    CGFloat middleValue = (maxValue + minValue) / 2;
    NSString *maxStr = [NSString stringWithFormat:@"%.1f", maxValue];
    NSString *minStr = [NSString stringWithFormat:@"%.1f", minValue];
    NSString *middleStr = [NSString stringWithFormat:@"%.1f", middleValue];
    [maxStr drawAtPoint:CGPointMake(kPadding - 24, kPadding - 10) withAttributes:attributes];
    [minStr drawAtPoint:CGPointMake(kPadding - 24, self.rect.size.height - kPadding - 10) withAttributes:attributes];
    [middleStr drawAtPoint:CGPointMake(kPadding - 24, (self.rect.size.height - kPadding * 2) / 2 + kPadding - 6) withAttributes:attributes];
}

-(void)setDataSource:(NSMutableArray<NSNumber *> *)dataSource {
    _dataSource = dataSource;
    [self setNeedsDisplay];
}

-(void)handlePanGesture:(UIPanGestureRecognizer *)gestureRecognizer {
    if (gestureRecognizer.state == UIGestureRecognizerStateBegan) {
        self.startPoint = [gestureRecognizer locationInView:self];
        self.startY = self.dataSource.firstObject.floatValue * (self.rect.size.height - kPadding * 2) / 2 + (self.rect.size.height - kPadding * 2) / 2 + kPadding;
    } else if (gestureRecognizer.state == UIGestureRecognizerStateChanged) {
        CGPoint point = [gestureRecognizer locationInView:self];
        CGFloat offsetY = point.y - self.startPoint.y;
        CGFloat scale = offsetY / ((self.rect.size.height - kPadding * 2) / 2);
        [self.dataSource enumerateObjectsUsingBlock:^(NSNumber * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            CGFloat oldValue = obj.floatValue;
            CGFloat newValue = oldValue + scale;
            newValue = fmax(newValue, -1);
            newValue = fmin(newValue, 1);
            self.dataSource[idx] = @(newValue);
        }];
        [self setNeedsDisplay];
    }
}

@end



       

