//
//  SmoothCurveView.m
//  dmoea
//
//  Created by Windy on 2023/3/3.
//

// SmoothCurveView.m

#import "SmoothCurveView.h"

@implementation SmoothCurveView

- (void)setDataSource:(NSArray<NSNumber *> *)dataSource {
    _dataSource = dataSource;
    [self setNeedsDisplay]; // 数据源更新时重绘
}

- (void)drawRect:(CGRect)rect {
    // 计算坐标轴的宽高
    CGFloat xAxisWidth = CGRectGetWidth(rect) - 40;
    CGFloat yAxisHeight = CGRectGetHeight(rect) - 40;
    
    
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
//    // 绘制网格线
//    CGContextSetStrokeColorWithColor(context, [UIColor lightGrayColor].CGColor);
//    CGContextSetLineWidth(context, 1.0);
//    CGFloat dashes[] = {3, 3};
//    CGContextSetLineDash(context, 0, dashes, 2);
//    for (NSInteger i = 1; i < self.rect.size.width / self.spacing; i++) {
//        CGContextMoveToPoint(context, kPadding + i * self.spacing, kPadding);
//        CGContextAddLineToPoint(context, kPadding + i * self.spacing, self.rect.size.height - kPadding);
//    }
//    for (NSInteger i = 1; i < (self.rect.size.height - kPadding * 2) / self.spacing; i++) {
//        CGContextMoveToPoint(context, kPadding, kPadding + i * self.spacing);
//        CGContextAddLineToPoint(context, self.rect.size.width - kPadding, kPadding + i * self.spacing);
//    }
//    CGContextStrokePath(context);
//    
    
    
    // 绘制X轴
    UIBezierPath *xAxisPath = [UIBezierPath bezierPath];
    [xAxisPath moveToPoint:CGPointMake(20, 20 + yAxisHeight)];
    [xAxisPath addLineToPoint:CGPointMake(20 + xAxisWidth, 20 + yAxisHeight)];
    xAxisPath.lineWidth = 1;
    [[UIColor blackColor] setStroke];
    [xAxisPath stroke];
    
    // 绘制X轴刻度和标注
    NSInteger count = self.dataSource.count;
    CGFloat xInterval = xAxisWidth / (count - 1);
    for (NSInteger i = 0; i < count; i++) {
        CGFloat x = 20 + i * xInterval;
        UIBezierPath *tickPath = [UIBezierPath bezierPath];
        [tickPath moveToPoint:CGPointMake(x, 20 + yAxisHeight)];
        [tickPath addLineToPoint:CGPointMake(x, 20 + yAxisHeight + 5)];
        tickPath.lineWidth = 1;
        [[UIColor blackColor] setStroke];
        [tickPath stroke];
        
        NSNumber *yValue = self.dataSource[i];
        NSString *yString = [NSString stringWithFormat:@"%@", yValue];
        NSDictionary *attributes = @{NSFontAttributeName: [UIFont systemFontOfSize:10], NSForegroundColorAttributeName: [UIColor blackColor]};
        CGSize size = [yString sizeWithAttributes:attributes];
        CGRect labelRect = CGRectMake(x - size.width / 2, 20 + yAxisHeight + 5, size.width, size.height);
        [yString drawInRect:labelRect withAttributes:attributes];
    }
    
    // 绘制Y轴
    UIBezierPath *yAxisPath = [UIBezierPath bezierPath];
    [yAxisPath moveToPoint:CGPointMake(20, 20)];
    [yAxisPath addLineToPoint:CGPointMake(20, 20 + yAxisHeight)];
    yAxisPath.lineWidth = 1;
    [[UIColor blackColor] setStroke];
    [yAxisPath stroke];
    
    // 绘制Y轴刻度和标注
    CGFloat yMax = [[self.dataSource valueForKeyPath:@"@max.doubleValue"] floatValue];
    CGFloat yInterval = yAxisHeight / (yMax + 1);
    for (NSInteger i = 0; i <= yMax; i++) {
        CGFloat y = 20 + yAxisHeight - i * yInterval;
        UIBezierPath *tickPath = [UIBezierPath bezierPath];
        [tickPath moveToPoint:CGPointMake(20, y)];
        [tickPath addLineToPoint:CGPointMake(15, y)];
        tickPath.lineWidth = 1;
        [[UIColor blackColor] setStroke];
        [tickPath stroke];
        
        NSString *yString = [NSString stringWithFormat:@"%ld", i];
        NSDictionary *attributes = @{NSFontAttributeName: [UIFont systemFontOfSize:10], NSForegroundColorAttributeName: [UIColor blackColor]};
        CGSize size = [yString sizeWithAttributes:attributes];
        CGRect labelRect = CGRectMake(5 - size.width / 2, y - size.height / 2, size.width, size.height);
        [yString drawInRect:labelRect withAttributes:attributes];
    }
    
    // 绘制曲线
    UIBezierPath *curvePath = [UIBezierPath bezierPath];
    curvePath.lineWidth = 2;
    [[UIColor redColor] setStroke];
    
    for (NSInteger i = 0; i < count; i++) {
        NSNumber *yValue = self.dataSource[i];
        CGFloat y = 20 + yAxisHeight - [yValue floatValue] * yInterval;
        CGFloat x = 20 + i * xInterval;
        if (i == 0) {
            [curvePath moveToPoint:CGPointMake(x, y)];
        } else {
            NSNumber *prevYValue = self.dataSource[i - 1];
            CGFloat prevY = 20 + yAxisHeight - [prevYValue floatValue] * yInterval;
            CGFloat c1x = (x + (x - xInterval)) / 2;
            CGFloat c1y = prevY;
            CGFloat c2x = (x + (x - xInterval)) / 2;
            CGFloat c2y = y;
            [curvePath addCurveToPoint:CGPointMake(x, y) controlPoint1:CGPointMake(c1x, c1y) controlPoint2:CGPointMake(c2x, c2y)];
        }
    }
    [curvePath stroke];
}

@end
