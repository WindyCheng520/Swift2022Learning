//
//  CurveGraphView.m
//  dmoea
//
//  Created by Windy on 2023/3/3.
//

// CurveGraphView.h

#import <UIKit/UIKit.h>


// CurveGraphView.m

#import "CurveGraphView.h"

@implementation CurveGraphView

- (void)drawRect:(CGRect)rect {
    // 创建绘图上下文
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    // 设置画笔颜色和线宽度
    CGContextSetStrokeColorWithColor(context, [UIColor blackColor].CGColor);
    CGContextSetLineWidth(context, 1.0);
    
    // 绘制网格线
    for (int i = 0; i <= 10; i++) {
        // 水平网格线
        CGContextMoveToPoint(context, 50, 50 + i * 30);
        CGContextAddLineToPoint(context, 350, 50 + i * 30);
        CGContextStrokePath(context);
        
        // 垂直网格线
        CGContextMoveToPoint(context, 50 + i * 30, 50);
        CGContextAddLineToPoint(context, 50 + i * 30, 350);
        CGContextStrokePath(context);
    }
    
    // 绘制坐标轴和标注
    CGContextSetStrokeColorWithColor(context, [UIColor redColor].CGColor);
    CGContextMoveToPoint(context, 50, 350);
    CGContextAddLineToPoint(context, 350, 350);
    CGContextMoveToPoint(context, 50, 50);
    CGContextAddLineToPoint(context, 50, 350);
    CGContextStrokePath(context);
    
    // 绘制X轴标注
    CGContextSetFillColorWithColor(context, [UIColor blackColor].CGColor);
    CGContextSetTextDrawingMode(context, kCGTextFill);
    CGContextSetTextMatrix(context, CGAffineTransformIdentity);
    CGContextSelectFont(context, "Helvetica", 12, kCGEncodingMacRoman);
    int countX = (int)self.xLabels.count;
    CGFloat intervalX = (CGFloat)300 / (countX - 1);
    for (int i = 0; i < countX; i++) {
        NSString *label = self.xLabels[i];
        CGSize size = [label sizeWithAttributes:@{NSFontAttributeName: [UIFont fontWithName:@"Helvetica" size:12]}];
        CGFloat x = 50 + i * intervalX - size.width / 2;
        CGFloat y = 350 + 5;
        [label drawAtPoint:CGPointMake(x, y) withAttributes:@{NSFontAttributeName: [UIFont fontWithName:@"Helvetica" size:12]}];
    }
    
    // 绘制Y轴标注
    CGContextSetFillColorWithColor(context, [UIColor blackColor].CGColor);
    CGContextSetTextDrawingMode(context, kCGTextFill);
    CGContextSetTextMatrix(context, CGAffineTransformIdentity);
    CGContextSelectFont(context, "Helvetica", 12, kCGEncodingMacRoman);
    int countY = (int)self.yLabels.count;
    CGFloat intervalY = (CGFloat)300 / (countY - 1);
    for (int i = 0; i < countY; i++) {
        NSString *label = self.yLabels[i];
        CGSize size = [label sizeWithAttributes:@{NSFontAttributeName: [UIFont fontWithName:@"Helvetica" size:12]}];
        CGFloat x = 50 - size.width - 5;
        CGFloat y = 350 - i * intervalY - size.height / 2;
        [label drawAtPoint:CGPointMake(x, y) withAttributes:@{NSFontAttributeName: [UIFont fontWithName:@"Helvetica" size:12]}];
    }
    // 绘制曲线
    CGContextSetStrokeColorWithColor(context, [UIColor blueColor].CGColor);
    CGContextSetLineWidth(context, 2.0);
    CGContextBeginPath(context);
    int count = (int)self.data.count;
    if (count > 0) {
        CGFloat interval = (CGFloat)300 / (count - 1);
        CGFloat firstX = 50;
        CGFloat firstY = [self.data[0] floatValue] * 30 + 50;
        CGContextMoveToPoint(context, firstX, firstY);
        for (int i = 1; i < count; i++) {
            CGFloat x = 50 + i * interval;
            CGFloat y = [self.data[i] floatValue] * 30 + 50;
            CGContextAddQuadCurveToPoint(context, firstX, firstY, (firstX + x) / 2, (firstY + y) / 2);
            firstX = x;
            firstY = y;
        }
        CGContextAddLineToPoint(context, firstX, firstY);
    }
    CGContextStrokePath(context);
}


@end
