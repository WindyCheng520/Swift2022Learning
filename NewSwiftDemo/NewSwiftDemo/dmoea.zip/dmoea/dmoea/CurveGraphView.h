//
//  CurveGraphView.h
//  dmoea
//
//  Created by Windy on 2023/3/3.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CurveGraphView : UIView

@property (nonatomic, strong) NSArray *data;
@property (nonatomic, strong) NSArray *xLabels;
@property (nonatomic, strong) NSArray *yLabels;

@end

NS_ASSUME_NONNULL_END
