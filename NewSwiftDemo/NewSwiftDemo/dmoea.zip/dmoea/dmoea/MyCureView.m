////
////  MyCureView.m
////  dmoea
////
////  Created by Windy on 2023/3/3.
////
//
//#import "MyCureView.h"
//
//
//@interface MyCurveView ()
//
////@property (nonatomic, strong) NSArray<NSValue *> *intersectionPoints;
////@property (nonatomic, assign) NSInteger draggingIndex;
////@property (nonatomic, assign) CGPoint previousPoint;
//
//@end
//
//@implementation MyCureView
//
//- (void)drawRect:(CGRect)rect {
//    [super drawRect:rect];
//    
//    CGContextRef context = UIGraphicsGetCurrentContext();
//    [self drawGridLinesWithContext:context];
//    [self drawAxisWithContext:context];
//    [self drawCurveWithContext:context];
//    [self drawIntersectionPointsWithContext:context];
//}
//
//- (void)drawGridLinesWithContext:(CGContextRef)context {
//    CGContextSetLineWidth(context, 1.0);
//    CGContextSetStrokeColorWithColor(context, [UIColor lightGrayColor].CGColor);
//    
//    CGFloat xStep = (CGRectGetWidth(self.bounds) - 2 * kMargin) / (self.numberOfPoints - 1);
//    CGFloat yStep = (CGRectGetHeight(self.bounds) - 2 * kMargin) / (self.yRange);
//    
//    for (NSInteger i = 1; i < self.numberOfPoints; i++) {
//        CGFloat x = kMargin + i * xStep;
//        CGContextMoveToPoint(context, x, kMargin);
//        CGContextAddLineToPoint(context, x, CGRectGetHeight(self.bounds) - kMargin);
//        CGContextStrokePath(context);
//    }
//    
//    for (NSInteger i = 1; i <= self.yRange; i++) {
//        CGFloat y = kMargin + i * yStep;
//        CGContextMoveToPoint(context, kMargin, y);
//        CGContextAddLineToPoint(context, CGRectGetWidth(self.bounds) - kMargin, y);
//        CGContextStrokePath(context);
//    }
//}
//
//- (void)drawAxisWithContext:(CGContextRef)context {
//    CGContextSetLineWidth(context, kAxisLineWidth);
//    CGContextSetStrokeColorWithColor(context, [UIColor blackColor].CGColor);
//    
//    CGContextMoveToPoint(context, kMargin - kAxisLineWidth / 2, CGRectGetHeight(self.bounds) - kMargin);
//    CGContextAddLineToPoint(context, CGRectGetWidth(self.bounds) - kMargin + kAxisLineWidth / 2, CGRectGetHeight(self.bounds) - kMargin);
//    
//    CGContextMoveToPoint(context, kMargin, kMargin - kAxisLineWidth / 2);
//    CGContextAddLineToPoint(context, kMargin, CGRectGetHeight(self.bounds) - kMargin + kAxisLineWidth / 2);
//    
//    CGContextStrokePath(context);
//    
//    NSDictionary *attributes = @{ NSFontAttributeName: [UIFont systemFontOfSize:14.0],
//                                  NSForegroundColorAttributeName: [UIColor blackColor] };
//    
//    CGFloat xStep = (CGRectGetWidth(self.bounds) - 2 * kMargin) / (self.numberOfPoints - 1);
//    CGFloat yStep = (CGRectGetHeight(self.bounds) - 2 * kMargin) / (self.yRange);
//    
//    for (NSInteger i = 0; i < self.numberOfPoints; i++) {
//        NSString *text = [NSString stringWithFormat:@"%ld", i + 1];
//        CGSize size = [text sizeWithAttributes:attributes];
//        CGPoint point = CGPointMake(kMargin + i * xStep - size.width / 2, CGRectGetHeight(self.bounds) - kMargin + kAxisLineWidth / 2);
//        [text drawAtPoint:point withAttributes:attributes];
//    }
//    
//    for (NSInteger i = 0; i <= self.yRange; i++)
//
//
//@end
