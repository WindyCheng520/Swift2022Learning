//
//  ViewController.m
//  dmoea
//
//  Created by Windy on 2023/3/2.
//

#import "ViewController.h"
#import "GraphView.h"
#import "CurveView.h"
#import "SmoothCurveView.h"

@interface ViewController ()

@property (nonatomic, strong) NSArray<NSNumber *> *dataSource;
@property (nonatomic, strong) SmoothCurveView *curveView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
//    GraphView *curveView = [[GraphView alloc] initWithFrame:CGRectMake(0, 100, self.view.frame.size.width, 300)];
//    curveView.center = self.view.center;
//    [self.view addSubview:curveView];
//
//    NSMutableArray *dataSource = [NSMutableArray array];
//    for (NSInteger i = 0; i < 10; i++) {
//        CGFloat value = ((CGFloat)arc4random_uniform(200) - 100) / 100;
//        [dataSource addObject:@(value)];
//    }
//    curveView.dataSource = dataSource;
    
    
    
    // 构造数据源
    self.dataSource = @[@(4), @(5), @(6), @(7), @(8), @(9), @(10), @(11), @(12)];

    // 创建 SmoothCurveView 并设置数据源
    self.curveView = [[SmoothCurveView alloc] initWithFrame:CGRectMake(50, 50, 300, 200)];
    self.curveView.backgroundColor = [UIColor whiteColor];
    self.curveView.center = self.view.center;
    self.curveView.dataSource = self.dataSource;
    [self.view addSubview:self.curveView];
}


@end
