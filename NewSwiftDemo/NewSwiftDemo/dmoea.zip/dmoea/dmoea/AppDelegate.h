//
//  AppDelegate.h
//  dmoea
//
//  Created by Windy on 2023/3/2.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

