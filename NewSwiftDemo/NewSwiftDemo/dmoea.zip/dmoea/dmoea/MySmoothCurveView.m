//
//  MySmoothCurveView.m
//  dmoea
//
//  Created by Windy on 2023/3/3.
//

#import "MySmoothCurveView.h"

@interface MySmoothCurveView()
@property (nonatomic, strong) UIFont *xAxisLabelFont;

@property (nonatomic, strong) UIFont *yAxisLabelFont;


@end


@implementation MySmoothCurveView

#pragma mark - Initialization

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        self.xAxisLabelFont = [UIFont systemFontOfSize:12];
        self.yAxisLabelFont = [UIFont systemFontOfSize:12];
        self.gridLineColor = [UIColor lightGrayColor];
        self.gridLineWidth = 0.5;
        self.curveLineColor = [UIColor blueColor];
        self.curveLineWidth = 1.5;
        self.curvePoints = @[];
        self.xAxisValues = @[];
        self.yAxisValues = @[];
        self.pointViews = [NSMutableArray array];
        self.selectedPointIndex = -1;
        self.minCurveY = CGFLOAT_MAX;
        self.maxCurveY = CGFLOAT_MIN;
        
        [self addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(deselectPoint)]];
    }
    return self;
}

#pragma mark - Drawing

- (void)drawRect:(CGRect)rect {
    [self drawGridLines];
    [self drawCurveLine];
    [self addPointViews];
}

- (void)drawGridLines {
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetStrokeColorWithColor(context, self.gridLineColor.CGColor);
    CGContextSetLineWidth(context, self.gridLineWidth);
    
    // 绘制X轴和Y轴
    CGContextMoveToPoint(context, kMargin, CGRectGetHeight(self.frame) - kMargin);
    CGContextAddLineToPoint(context, CGRectGetWidth(self.frame) - kMargin, CGRectGetHeight(self.frame) - kMargin);
    CGContextMoveToPoint(context, kMargin, CGRectGetHeight(self.frame) - kMargin);
    CGContextAddLineToPoint(context, kMargin, kMargin);
    CGContextStrokePath(context);
    
    // 绘制X轴上的刻度线和标签
    CGFloat xInterval = (CGRectGetWidth(self.frame) - kMargin * 2) / (self.xAxisValues.count - 1);
    for (NSInteger i = 0; i < self.xAxisValues.count; i++) {
        CGFloat x = kMargin + xInterval * i;
        CGContextMoveToPoint(context, x, CGRectGetHeight(self.frame) - kMargin);
        CGContextAddLineToPoint(context, x, CGRectGetHeight(self.frame) - kMargin - kGridLineLength);
        CGContextStrokePath(context);
        
        NSString *xValue = self.xAxisValues[i];
        CGSize xValueSize = [xValue sizeWithAttributes:@{NSFontAttributeName:self.xAxisLabelFont}];
        CGPoint xValuePoint = CGPointMake(x - xValueSize.width / 2, CGRectGetHeight(self.frame) - kMargin + kAxisLabelMargin);
        [xValue drawAtPoint:xValuePoint withAttributes:@{NSFontAttributeName:self.xAxisLabelFont}];
    }
    
    // 绘制Y轴上的刻度线和标签
    CGFloat yInterval = (CGRectGetHeight(self.frame) - kMargin * 2) / (self.yAxisValues.count - 1);
    for (NSInteger i = 0; i < self.yAxisValues.count; i++) {
        CGFloat y = CGRectGetHeight(self.frame) - kMargin - yInterval * i;
        CGContextMoveToPoint(context, kMargin, y);
        CGContextAddLineToPoint(context, kMargin + kGridLineLength, y);
        CGContextStrokePath(context);
        
        NSString *yValue = self.yAxisValues[i];
        CGSize yValueSize = [yValue sizeWithAttributes:@{NSFontAttributeName:self.yAxisLabelFont}];
        CGPoint yValuePoint = CGPointMake(kMargin - yValueSize.width - kAxisLabelMargin, y - yValueSize.height / 2);
        [yValue drawAtPoint:yValuePoint withAttributes:@{NSFontAttributeName:self.yAxisLabelFont}];
    }
}

- (void)drawCurveLine {
    if (self.curvePoints.count < 2) {
        return;
    }
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetStrokeColorWithColor(context, self.curveLineColor.CGColor);
    CGContextSetLineWidth(context, self.curveLineWidth);
    
    UIBezierPath *curvePath = [UIBezierPath bezierPath];
    [curvePath moveToPoint:[self.curvePoints[0] CGPointValue]];
    
    for (NSInteger i = 1; i < self.curvePoints.count - 2; i++) {
        CGPoint p1 = [self.curvePoints[i] CGPointValue];
        CGPoint p2 = [self.curvePoints[i + 1] CGPointValue];
        CGPoint midPoint = midPointForPoints(p1, p2);
        
        [curvePath addQuadCurveToPoint:midPoint controlPoint:controlPointForPoints(midPoint, p1)];
        [curvePath addQuadCurveToPoint:p2 controlPoint:controlPointForPoints(midPoint, p2)];
    }
    
    // 将曲线上的点连成平分线
    [self drawMidLines];
    
    // 绘制曲线
    [curvePath stroke];
}

- (void)drawMidLines {
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetStrokeColorWithColor(context, self.midLineColor.CGColor);
    CGContextSetLineWidth(context, self.midLineWidth);
    
    for (NSInteger i = 0; i < self.curvePoints.count - 1; i++) {
        CGPoint p1 = [self.curvePoints[i] CGPointValue];
        CGPoint p2 = [self.curvePoints[i + 1] CGPointValue];
        
        for (NSInteger j = 1; j < self.midLineCount; j++) {
            CGFloat x = p1.x + (p2.x - p1.x) / (self.midLineCount + 1) * j;
            CGFloat y = p1.y + (p2.y - p1.y) / (self.midLineCount + 1) * j + self.midLineOffsets[i][j - 1];
            CGContextMoveToPoint(context, x, y);
            CGContextAddLineToPoint(context, x, p1.y + (p2.y - p1.y) / (self.midLineCount + 1) * j);
            CGContextStrokePath(context);
        }
    }
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self];
    for (NSInteger i = 0; i < self.curvePoints.count; i++) {
        CGPoint p = [self.curvePoints[i] CGPointValue];
        if (fabs(p.x - point.x) < kTouchRadius && fabs(p.y - point.y) < kTouchRadius) {
            self.selectedPointIndex = i;
            break;
        }
    }
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if (self.selectedPointIndex != NSNotFound) {
        UITouch *touch = [touches anyObject];
        CGPoint point = [touch locationInView:self];
        [self.curvePoints replaceObjectAtIndex:self.selectedPointIndex withObject:[NSValue valueWithCGPoint:CGPointMake(point.x, MAX(kMargin, MIN(CGRectGetHeight(self.frame) - kMargin, point.y)))]];
        [self setNeedsDisplay];
    }
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    self.selectedPointIndex = NSNotFound
}


- (void)drawXAxisLabels {
    if (self.xAxisValues.count == 0) {
        return;
    }
    
    CGFloat labelWidth = CGRectGetWidth(self.bounds) / (self.xAxisValues.count + 1);
    for (NSInteger i = 0; i < self.xAxisValues.count; i++) {
        NSString *text = self.xAxisValues[i];
        CGFloat x = labelWidth * (i + 1);
        CGRect textRect = CGRectMake(x - labelWidth / 2, CGRectGetHeight(self.bounds) - kMargin, labelWidth, kMargin);
        
        NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
        paragraphStyle.alignment = NSTextAlignmentCenter;
        
        NSDictionary *attributes = @{NSFontAttributeName: self.xAxisLabelFont,
                                     NSForegroundColorAttributeName: self.xAxisLabelColor,
                                     NSParagraphStyleAttributeName: paragraphStyle};
        
        [text drawInRect:textRect withAttributes:attributes];
    }
}

- (void)drawYAxisLabels {
    CGFloat labelHeight = (CGRectGetHeight(self.bounds) - 2 * kMargin) / (self.yAxisValues.count - 1);
    for (NSInteger i = 0; i < self.yAxisValues.count; i++) {
        NSString *text = self.yAxisValues[i];
        CGFloat y = CGRectGetHeight(self.bounds) - kMargin - labelHeight * i;
        CGRect textRect = CGRectMake(0, y - labelHeight / 2, kMargin, labelHeight);
        
        NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
        paragraphStyle.alignment = NSTextAlignmentRight;
        
        NSDictionary *attributes = @{NSFontAttributeName: self.yAxisLabelFont,
                                     NSForegroundColorAttributeName: self.yAxisLabelColor,
                                     NSParagraphStyleAttributeName: paragraphStyle};
        
        [text drawInRect:textRect withAttributes:attributes];
    }
}

- (void)drawGrid {
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetStrokeColorWithColor(context, self.gridColor.CGColor);
    CGContextSetLineWidth(context, self.gridLineWidth);
    
    // 绘制X轴网格线
    for (NSInteger i = 0; i < self.xAxisValues.count; i++) {
        CGFloat x = CGRectGetWidth(self.bounds) / (self.xAxisValues.count + 1) * (i + 1);
        CGContextMoveToPoint(context, x, kMargin);
        CGContextAddLineToPoint(context, x, CGRectGetHeight(self.bounds) - kMargin);
    }
    
    // 绘制Y轴网格线
    CGFloat labelHeight = (CGRectGetHeight(self.bounds) - 2 * kMargin) / (self.yAxisValues.count - 1);
    for (NSInteger i = 0; i < self.yAxisValues.count; i++) {
        CGFloat y = CGRectGetHeight(self.bounds) - kMargin - labelHeight * i;
        CGContextMoveToPoint(context, kMargin, y);
        CGContextAddLineToPoint(context, CGRectGetWidth(self.bounds) - kMargin, y);
    }
    
    CGContextStrokePath(context);
}

- (void)setXAxisValues:(NSArray<NSString *> *)xAxisValues {
    _xAxisValues = xAxisValues;
    [self setNeedsDisplay];
}

- (void)setYAxisValues:(NSArray<NSString *> *)yAxisValues {
    _yAxisValues = yAxisValues;
    [self setNeedsDisplay];
}

- (void)setCurvePoints:(NSMutableArray<NSValue *> *)curvePoints {
    _curvePoints = curvePoints;
    [self setNeedsDisplay];
}

-(void)setMidLineOffsets:(NSMutableArray<NSMutableArray<NSNumber *> *> *)midLineOffsets {
    _midLineOffsets = midLineOffsets;
    [self setNeedsDisplay];
}

-(void)panGestureAction:(UIPanGestureRecognizer *)gesture {
    if (gesture.state == UIGestureRecognizerStateChanged || gesture.state == UIGestureRecognizerStateEnded) {
        CGPoint translation = [gesture translationInView:self];
        [gesture setTranslation:CGPointZero inView:self];
        NSInteger selectedPointIndex = -1;
        for (NSInteger i = 0; i < self.curvePoints.count; i++) {
            CGPoint point = [self.curvePoints[i] CGPointValue];
            CGFloat distance = hypotf(point.x - gesture.view.center.x, point.y - gesture.view.center.y);
            if (distance < kPointRadius * 2) {
                selectedPointIndex = i;
                break;
            }
        }
        
        if (selectedPointIndex != -1) {
            NSMutableArray *midLineOffsets = self.midLineOffsets[selectedPointIndex];
            for (NSInteger i = 0; i < midLineOffsets.count; i++) {
                CGFloat offsetY = translation.y / (CGRectGetHeight(self.bounds) - 2 * kMargin);
                CGFloat newOffsetY = midLineOffsets[i].floatValue + offsetY;
                newOffsetY = MIN(MAX(newOffsetY, -1), 1);
                midLineOffsets[i] = @(newOffsetY);
            }
            
            [self setNeedsDisplay];
        }
    }
}

-(void)setNeedsDisplay {
    [super setNeedsDisplay];
    [self updateCurvePoints];
}

-(void)updateCurvePoints {
    if (self.curvePoints.count < 2) {
        return;
    }
    
    NSMutableArray *points = [NSMutableArray arrayWithCapacity:self.curvePoints.count];
    for (NSInteger i = 0; i < self.curvePoints.count; i++) {
        CGPoint point = [self.curvePoints[i] CGPointValue];
        NSMutableArray *midLineOffsets = self.midLineOffsets[i];
        CGFloat offsetY = 0;
        for (NSInteger j = 0; j < midLineOffsets.count; j++) {
            offsetY += midLineOffsets[j].floatValue;
        }
        offsetY /= midLineOffsets.count;
        CGFloat x = CGRectGetWidth(self.bounds) / (self.xAxisValues.count + 1) * (i + 1);
        CGFloat y = CGRectGetHeight(self.bounds) - kMargin - (point.y + offsetY) / self.yAxisMaxValue * (CGRectGetHeight(self.bounds) - 2 * kMargin);
        [points addObject:[NSValue valueWithCGPoint:CGPointMake(x, y)]];
    }

    self.curveLayer.path = [self curvePathWithPoints:points].CGPath;
    }

-(UIBezierPath *)curvePathWithPoints:(NSArray<NSValue *> *)points {
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:[points.firstObject CGPointValue]];
    
    for (NSInteger i = 1; i < points.count - 2; i++) {
        CGPoint point1 = [points[i - 1] CGPointValue];
        CGPoint point2 = [points[i] CGPointValue];
        CGPoint point3 = [points[i + 1] CGPointValue];
        CGPoint point4 = [points[i + 2] CGPointValue];
        [path addCurveToPoint:point3 controlPoint1:[self controlPointForPoint1:point1 point2:point2 point3:point3] controlPoint2:[self controlPointForPoint1:point2 point2:point3 point3:point4]];
        
    }
  //  CGPoint secondLastPoint = [points[points.count]
    
    return  path;
}

        @end
