//
//  SmoothCurveView.h
//  dmoea
//
//  Created by Windy on 2023/3/3.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SmoothCurveView : UIView

// 数据源，格式为 @[@(y1), @(y2), @(y3), ...]
@property (nonatomic, strong) NSArray<NSNumber *> *dataSource;

@end

NS_ASSUME_NONNULL_END
