//
//  MySmoothCurveView.h
//  dmoea
//
//  Created by Windy on 2023/3/3.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MySmoothCurveView : UIView

@property (nonatomic, strong) NSMutableArray *pointViews;  // 保存曲线上的点视图
@property (nonatomic, assign) NSInteger selectedPointIndex;  // 选中的点索引
@property (nonatomic, assign) CGPoint selectedPointOrigin;  // 选中的点初始位置
@property (nonatomic, strong) UIView *selectedPointView;  // 选中的点视图
@property (nonatomic, assign) CGFloat minCurveY;  // 曲线的最小Y值
@property (nonatomic, assign) CGFloat maxCurveY;  // 曲线的最大Y值

- (void)drawGridLines;  // 绘制网格线
- (void)drawCurveLine;  // 绘制曲线
- (void)addPointViews;  // 添加曲线上的点视图
- (void)moveSelectedPoint:(UIPanGestureRecognizer *)recognizer;  // 移动选中的点
- (void)updateCurvePoints;  // 更新曲线上的点
- (void)updateCurvePath;  // 更新曲线路径
- (CGFloat)clampValue:(CGFloat)value toMinimum:(CGFloat)min andMaximum:(CGFloat)max;  // 将数值约束到指定范围内


@end

NS_ASSUME_NONNULL_END
