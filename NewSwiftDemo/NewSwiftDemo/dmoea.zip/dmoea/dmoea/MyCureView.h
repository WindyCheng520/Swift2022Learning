//
//  MyCureView.h
//  dmoea
//
//  Created by Windy on 2023/3/3.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

static const CGFloat kMargin = 40.0;
static const CGFloat kAxisLineWidth = 2.0;
static const CGFloat kCurveLineWidth = 2.0;
static const CGFloat kIntersectionPointRadius = 5.0;

@interface MyCureView : UIView

@property (nonatomic, strong) NSArray<NSValue *> *intersectionPoints;
@property (nonatomic, assign) NSInteger draggingIndex;
@property (nonatomic, assign) CGPoint previousPoint;

@end

NS_ASSUME_NONNULL_END
