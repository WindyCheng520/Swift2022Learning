//
//  CurveView.m
//  dmoea
//
//  Created by Windy on 2023/3/2.
//

#import "CurveView.h"

@implementation CurveView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        self.dataSource = [NSMutableArray array];
        self.spacing = (frame.size.width - kPadding * 2) / 9;
        
        UIPanGestureRecognizer *panGestureRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanGesture:)];
        [self addGestureRecognizer:panGestureRecognizer];
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    self.rect = rect;
    [super drawRect:rect];

    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(context, 2.0);
    CGContextSetLineJoin(context, kCGLineJoinRound);
    CGContextSetLineCap(context, kCGLineCapRound);

    CGFloat gridSize = (self.rect.size.width - kPadding * 2) / (self.dataSource.count - 1);
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(kPadding, [self yValueWithIndex:0])];
    for (NSInteger i = 1; i < self.dataSource.count; i++) {
        CGFloat x = kPadding + i * gridSize;
        CGFloat y = [self yValueWithIndex:i];
        [path addLineToPoint:CGPointMake(x, y)];
        [path moveToPoint:CGPointMake(x, y)];
    }
    [[UIColor blueColor] setStroke];
    [path stroke];

    for (NSInteger i = 0; i < self.dataSource.count; i++) {
        CGFloat x = kPadding + i * gridSize;
        CGFloat y = [self yValueWithIndex:i];
        UIBezierPath *circlePath = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(x - 4, y - 4, 8, 8)];
        [[UIColor whiteColor] setStroke];
        [[UIColor blueColor] setFill];
        [circlePath fill];
        [circlePath stroke];
    }

    NSDictionary *attributes = @{
        NSFontAttributeName: [UIFont systemFontOfSize:12.0],
        NSForegroundColorAttributeName: [UIColor blackColor],
    };
    CGFloat maxValue = [[self.dataSource valueForKeyPath:@"@max.floatValue"] floatValue];
    CGFloat minValue = [[self.dataSource valueForKeyPath:@"@min.floatValue"] floatValue];
    CGFloat middleValue = (maxValue + minValue) / 2;
    NSString *maxStr = [NSString stringWithFormat:@"%.1f", maxValue];
    NSString *minStr = [NSString stringWithFormat:@"%.1f", minValue];
    NSString *middleStr = [NSString stringWithFormat:@"%.1f", middleValue];
    [maxStr drawAtPoint:CGPointMake(kPadding - 24, kPadding - 10) withAttributes:attributes];
    [minStr drawAtPoint:CGPointMake(kPadding - 24, self.rect.size.height - kPadding - 10) withAttributes:attributes];
    [middleStr drawAtPoint:CGPointMake(kPadding - 24, (self.rect.size.height - kPadding * 2) / 2 + kPadding - 6) withAttributes:attributes];
}

- (void)setDataSource:(NSMutableArray<NSNumber *> *)dataSource {
    _dataSource = dataSource;
    [self setNeedsDisplay];
}

- (CGFloat)yValueWithIndex:(NSInteger)index {
    CGFloat value = self.dataSource[index].floatValue;
    return value * (self.rect.size.height - kPadding * 2) / 2 + (self.rect.size.height - kPadding * 2) / 2 + kPadding;
}

- (void)handlePanGesture:(UIPanGestureRecognizer *)gestureRecognizer {
    if (gestureRecognizer.state == UIGestureRecognizerStateBegan) {
        self.startPoint = [gestureRecognizer locationInView:self];
        self.startY = self.dataSource.firstObject.floatValue * (self.rect.size.height - kPadding * 2) / 2 + (self.rect.size.height - kPadding * 2) / 2 + kPadding;
    } else if (gestureRecognizer.state == UIGestureRecognizerStateChanged) {
            CGPoint currentPoint = [gestureRecognizer locationInView:self];
            CGFloat offsetY = currentPoint.y - self.startPoint.y;
            CGFloat yValue = (self.startY - offsetY - kPadding - (self.rect.size.height - kPadding * 2) / 2) / ((self.rect.size.height - kPadding * 2) / 2);
            if (yValue < -1.0) {
                yValue = -1.0;
            } else if (yValue > 1.0) {
                yValue = 1.0;
            }
            self.dataSource[0] = @(yValue);
            [self setNeedsDisplay];
        }
    }




@end
