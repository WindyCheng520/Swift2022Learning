//
//  GraphView.h
//  dmoea
//
//  Created by Windy on 2023/3/2.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface GraphView : UIView

@property (nonatomic, assign) CGRect rect;
@property (nonatomic, assign) CGFloat spacing;
@property (nonatomic, strong) NSMutableArray<NSNumber *> *dataSource;
@property (nonatomic, assign) CGFloat startY;
@property (nonatomic, assign) CGPoint startPoint;

@end

NS_ASSUME_NONNULL_END
