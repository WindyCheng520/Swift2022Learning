//
//  SmootView.m
//  Mydemo
//
//  Created by Windy on 2023/3/3.
//

#import "SmootView.h"

@implementation SmootView

- (void)drawRect:(CGRect)rect {
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    // 绘制虚线网格
    CGFloat gridSpacing = 40; // 网格间距
    CGFloat xMargin = 40; // X轴留白
    CGFloat yMargin = 40; // Y轴留白
    CGFloat gridWidth = rect.size.width - 2 * xMargin;
    CGFloat gridHeight = rect.size.height - 2 * yMargin;
    CGContextSetStrokeColorWithColor(context, [UIColor lightGrayColor].CGColor);
    CGContextSetLineWidth(context, 1);
    CGFloat dash[] = {3, 3};
    CGContextSetLineDash(context, 0, dash, 2);
    for (int i = 1; i <= 10; i++) {
        // 绘制横向虚线
        CGFloat y = yMargin + i * gridHeight / 10;
        CGContextMoveToPoint(context, xMargin, y);
        CGContextAddLineToPoint(context, xMargin + gridWidth, y);
        CGContextStrokePath(context);
        // 绘制纵向虚线
        CGFloat x = xMargin + i * gridWidth / 10;
        CGContextMoveToPoint(context, x, yMargin);
        CGContextAddLineToPoint(context, x, yMargin + gridHeight);
        CGContextStrokePath(context);
    }
    
    // 绘制X轴和Y轴
    CGContextSetStrokeColorWithColor(context, [UIColor blackColor].CGColor);
    CGContextSetLineDash(context, 0, nil, 0);
    CGContextSetLineWidth(context, 2);
    CGContextMoveToPoint(context, xMargin, yMargin);
    CGContextAddLineToPoint(context, xMargin, yMargin + gridHeight);
    CGContextAddLineToPoint(context, xMargin + gridWidth, yMargin + gridHeight);
    CGContextStrokePath(context);
    
    // 标注X轴和Y轴
    CGContextSetFillColorWithColor(context, [UIColor blackColor].CGColor);
    UIFont *font = [UIFont systemFontOfSize:14];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.alignment = NSTextAlignmentCenter;
    NSDictionary *attributes = @{NSFontAttributeName: font,
                                 NSForegroundColorAttributeName: [UIColor blackColor],
                                 NSParagraphStyleAttributeName: paragraphStyle};
    CGFloat labelHeight = 20; // 标注高度
    for (int i = 0; i <= 10; i++) {
        // 标注横坐标
        CGFloat x = xMargin + i * gridWidth / 10;
        CGFloat labelWidth = gridWidth / 10;
        NSString *labelText = [NSString stringWithFormat:@"%d", i * 10];
        CGRect labelRect = CGRectMake(x - labelWidth / 2, yMargin + gridHeight + 5, labelWidth, labelHeight);
        [labelText drawInRect:labelRect withAttributes:attributes];
        
        // 标注纵坐标
        CGFloat y = yMargin + (10 - i) * gridHeight / 10;
        labelText = [NSString stringWithFormat:@"%d", i * 10];
        labelRect = CGRectMake(xMargin - labelWidth - 5, y - labelHeight / 2, labelWidth, labelHeight);
        [labelText drawInRect:labelRect withAttributes:attributes];
    }

    // 绘制平滑曲线
    if (self.dataPoints.count >= 2) {
        CGContextSetStrokeColorWithColor(context, self.lineColor.CGColor);
        CGContextSetLineWidth(context, self.lineWidth);
        CGContextSetLineJoin(context, kCGLineJoinRound);
        CGContextSetLineCap(context, kCGLineCapRound);
        CGContextBeginPath(context);
        CGPoint startPoint = [self.dataPoints[0] CGPointValue];
        CGContextMoveToPoint(context, startPoint.x, startPoint.y);
        for (int i = 1; i < self.dataPoints.count; i++) {
            CGPoint endPoint = [self.dataPoints[i] CGPointValue];
            CGFloat xc = (startPoint.x + endPoint.x) / 2;
            CGFloat yc = (startPoint.y + endPoint.y) / 2;
            CGContextAddQuadCurveToPoint(context, startPoint.x, startPoint.y, xc, yc);
            startPoint = endPoint;
        }
        CGContextAddLineToPoint(context, startPoint.x, startPoint.y);
        CGContextStrokePath(context);
    }

    // 绘制拐点和圆点
    if (self.dataPoints.count >= 2) {
        CGContextSetFillColorWithColor(context, self.pointColor.CGColor);
        for (int i = 0; i < self.dataPoints.count; i++) {
            CGPoint point = [self.dataPoints[i] CGPointValue];
            CGFloat x = xMargin + point.x / 100.0 * gridWidth;
            CGFloat y = yMargin + (100 - point.y) / 100.0 * gridHeight;
            CGContextFillEllipseInRect(context, CGRectMake(x - self.pointRadius, y - self.pointRadius, self.pointRadius * 2, self.pointRadius * 2));
        }
    }
}

-(void)setFrame:(CGRect)frame {
[super setFrame:frame];
[self setNeedsDisplay];
}

-(void)setDataPoints:(NSArray *)dataPoints {
_dataPoints = dataPoints;
[self setNeedsDisplay];
}

-(UIColor *)lineColor {
if (!_lineColor) {
_lineColor = [UIColor blueColor];
}
return _lineColor;
}

-(CGFloat)lineWidth {
if (_lineWidth <= 0) {
_lineWidth = 2;
}
return _lineWidth;
}

-(CGFloat)pointRadius {
if (_pointRadius <= 0) {
_pointRadius = 5;
}
return _pointRadius;
}

-(UIColor *)pointColor {
if (!_pointColor) {
_pointColor = [UIColor redColor];
}
return _pointColor;
}

@end

