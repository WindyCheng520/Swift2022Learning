//
//  SmoothCurveGraphView.h
//  Mydemo
//
//  Created by Windy on 2023/3/3.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SmoothCurveGraphView : UIView

@property(nonatomic, strong)NSArray *dataPoints;

@property(nonatomic, assign)CGFloat maxValue;
@property(nonatomic, assign)CGFloat minValue;

@end

NS_ASSUME_NONNULL_END
