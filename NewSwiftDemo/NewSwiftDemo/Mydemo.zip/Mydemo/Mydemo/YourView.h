//
//  YourView.h
//  Mydemo
//
//  Created by Windy on 2023/3/3.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface YourView : UIView


@property (nonatomic, strong) NSMutableArray<NSValue *> *dataPoints;
@property (nonatomic, assign) CGFloat lineWidth;
@property (nonatomic, strong) UIColor *lineColor;
@property (nonatomic, assign) CGFloat dotRadius;
@property (nonatomic, strong) UIColor *dotColor;
@property (nonatomic, strong) UIColor *gridColor;
@property (nonatomic, assign) CGFloat gridWidth;
@property (nonatomic, strong) UIFont *xAxisLabelFont;
@property (nonatomic, strong) UIFont *yAxisLabelFont;
@property (nonatomic, strong) UIColor *xAxisLabelColor;
@property (nonatomic, strong) UIColor *yAxisLabelColor;

@end

NS_ASSUME_NONNULL_END
