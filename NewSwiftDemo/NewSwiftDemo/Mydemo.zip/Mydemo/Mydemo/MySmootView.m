//
//  MySmootView.m
//  Mydemo
//
//  Created by Windy on 2023/3/3.
//

#import "MySmootView.h"


@implementation MySmootView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        // 设置默认属性值
        _lineColor = [UIColor blueColor];
        _lineWidth = 2.0;
        _gridColor = [UIColor lightGrayColor];
        _gridWidth = 0.5;
        _gridDashLength = 4.0;
        _minYValue = 16;
        _maxYValue = 30;
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    // 绘制Y轴标注
    CGFloat yInterval = self.bounds.size.height /  (self.maxYValue - self.minYValue);
    CGFloat yValue = self.minYValue;
    CGFloat yLabelHeight = 20.0;
    UIFont *yLabelFont = [UIFont systemFontOfSize:12.0];
    UIColor *yLabelColor = [UIColor blackColor];
    for (int i = 0; i <= 15; i++) {
        CGFloat y = self.bounds.size.height - (i * self.bounds.size.height /14.0) - yLabelHeight / 2.0;
        NSString *yLabelString = [NSString stringWithFormat:@"%.f", i + self.minYValue];    //[NSString stringWithFormat:@"%.0f", yValue];
        CGSize yLabelSize = [yLabelString sizeWithAttributes:@{NSFontAttributeName: yLabelFont}];
        CGRect yLabelRect = CGRectMake(0.0, y - yLabelSize.height / 2.0, yLabelSize.width, yLabelSize.height);
     //   [yLabelString drawInRect:yLabelRect withAttributes:@{NSFontAttributeName: yLabelFont, NSForegroundColorAttributeName: yLabelColor}];
        yValue += yInterval;
    }
    
    // 绘制X轴标注
    NSArray *xLabels = @[@"0h", @"1h", @"2h", @"3h", @"4h", @"5h", @"6h", @"7h", @"8h", @"9h", @"10h", @"11h"];
    CGFloat xLabelWidth = self.bounds.size.width / (xLabels.count + 1);
    CGFloat xLabelHeight = 20.0;
    UIFont *xLabelFont = [UIFont systemFontOfSize:12.0];
    UIColor *xLabelColor = [UIColor blackColor];
    for (int i = 0; i < xLabels.count; i++) {
        CGFloat x = (i + 1) * xLabelWidth - xLabelWidth / 2.0;
        NSString *xLabelString = xLabels[i];
        CGSize xLabelSize = [xLabelString sizeWithAttributes:@{NSFontAttributeName: xLabelFont}];
        CGRect xLabelRect = CGRectMake(x - xLabelSize.width / 2.0, self.bounds.size.height - xLabelHeight, xLabelSize.width, xLabelSize.height);
    //    [xLabelString drawInRect:xLabelRect withAttributes:@{NSFontAttributeName: xLabelFont, NSForegroundColorAttributeName: xLabelColor}];
    }
    
    // 绘制网格线
    [self.gridColor setStroke];
    CGContextSetLineWidth(context, self.gridWidth);
    CGFloat dashLengths[] = {self.gridDashLength, self.gridDashLength};
    CGContextSetLineDash(context, 0, dashLengths, 2);
    CGFloat xInterval = self.bounds.size.width / (xLabels.count + 1);
    CGFloat yIntervalPixels = self.bounds.size.height / 14.0;
    for (int i = 0; i <= 15; i++) {
        
//        if (i == 1){
//            CGContextSetLineDash(context, 0, dashLengths, 0);
//        }else {
//            CGContextSetLineDash(context, 0, dashLengths, 2);
//        }
        
        CGFloat y = i * yIntervalPixels;
        CGContextMoveToPoint(context, 0.0, y);
        CGContextAddLineToPoint(context, self.bounds.size.width, y);
    }
    for (int i = 1; i < xLabels.count; i++) {
        CGFloat x = i * xInterval;
        CGContextMoveToPoint(context, x, 0.0);
        CGContextAddLineToPoint(context, x, self.bounds.size.height);
    }
    CGContextStrokePath(context);
    
    // 绘制曲线
    [self.lineColor setStroke];
    CGContextSetLineWidth(context, self.lineWidth);
    CGContextSetLineDash(context, 0, NULL, 0);
    if (self.dataPoints.count > 1) {
        CGContextMoveToPoint(context, [self.dataPoints[0] CGPointValue].x, [self.dataPoints[0] CGPointValue].y);
        for (int i = 1; i < self.dataPoints.count; i++) {
            CGPoint point = [self.dataPoints[i] CGPointValue];
            CGContextAddQuadCurveToPoint(context, [self.dataPoints[i-1] CGPointValue].x, [self.dataPoints[i-1] CGPointValue].y, point.x, point.y);
        }
        CGContextStrokePath(context);
    }
    
    // 绘制拐点圆点
    CGFloat circleRadius = 6.0;
    CGFloat pointX = 0.0;
    for (int i = 0; i < self.dataPoints.count; i++) {
        CGPoint point = [self.dataPoints[i] CGPointValue];
        pointX = i * xInterval + xInterval;
        CGFloat pointY = self.bounds.size.height - (point.y / self.maxYValue) * self.bounds.size.height;
        CGContextSetFillColorWithColor(context, self.lineColor.CGColor);
        CGContextFillEllipseInRect(context, CGRectMake(pointX - circleRadius, pointY - circleRadius, circleRadius * 2.0, circleRadius * 2.0));
    }
}
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    CGPoint touchPoint = [[touches anyObject] locationInView:self];
    touchPoint.x = MAX(touchPoint.x, 0.0);
    touchPoint.x = MIN(touchPoint.x, self.bounds.size.width);
    touchPoint.y = MAX(touchPoint.y, 0.0);
    touchPoint.y = MIN(touchPoint.y, self.bounds.size.height);
    CGFloat xInterval = self.bounds.size.width / (self.xLabels.count + 1);
    int closestPointIndex = -1;
    CGFloat closestDistance = CGFLOAT_MAX;
    for (int i = 0; i < self.dataPoints.count; i++) {
        CGPoint point = [self.dataPoints[i] CGPointValue];
        CGFloat pointX = i * xInterval + xInterval;
        CGFloat pointY = self.bounds.size.height - (point.y / self.maxYValue) * self.bounds.size.height;
        CGFloat distance = hypotf(pointX - touchPoint.x, pointY - touchPoint.y);
        if (distance < closestDistance) {
            closestDistance = distance;
            closestPointIndex = i;
        }
    }
    if (closestPointIndex >= 0) {
        CGPoint point = [[self.dataPoints objectAtIndex:closestPointIndex] CGPointValue];
        CGFloat newYValue = self.maxYValue - (touchPoint.y / self.bounds.size.height) * self.maxYValue;
        point.y = newYValue;
       // [self.dataPoints repl]
        [self.dataPoints replaceObjectAtIndex:closestPointIndex withObject:[NSValue valueWithCGPoint:point]];
        [self setNeedsDisplay];
    }
}


//由于我无法直接运行您的代码，以下是我对您的代码的检查和建议：
//
//您定义了一个名为SmoothCurveView的UIView子类，并实现了drawRect方法来绘制曲线和虚线网格。但是，您应该考虑将绘制代码放在单独的UIView子类中，并将平滑曲线图和虚线网格绘制代码分离。这样可以使您的代码更清晰、易于维护和测试。
//在SmoothCurveView类中，您在xInterval的计算中使用了hardcoded值40.0来作为虚线网格的行间距，这可能会导致您的视图在不同设备上显示效果不一致。您应该考虑根据视图的高度和y轴的最大值来动态计算行间距。
//在SmoothCurveView类中，您在计算拐点和圆点的位置时，使用了一个比例因子，即point.y / self.maxYValue和touchPoint.y / self.bounds.size.height。然而，这种方式可能会导致精度丢失，并且不适用于y轴值为负数的情况。相反，您应该将所有的点和值都转换为相对坐标系，其中原点位于视图的左下角，y轴向上。
//在SmoothCurveView类中，您实现了touchesMoved方法来处理圆点的拖动。然而，您应该考虑在touchesBegan方法中记录起始位置，并在touchesMoved方法中计算拖动距离，以避免意外的跳跃和不良交互。
//在SmoothCurveView类中，您没有提供设置y轴最小值的方法。在某些情况下，您可能希望将y轴最小值设置为0，以使数据更易于理解。
//在ViewController类中，您在设置数据点时，没有确保它们按x值的顺序排列。您应该考虑在设置数据点之前将它们按x值的顺序排序。
//希望这些建议能帮助您改进您的代码并使其更健壮和可维护。


//以下是我进一步完善您的代码的一些建议：
//
//在SmoothCurveView类中，您可以添加一个名为updateCurve的方法，它可以接受一个曲线数据数组，然后更新曲线并重绘视图。这样，您可以更轻松地更新曲线数据而无需重新创建SmoothCurveView实例。
//在SmoothCurveView类中，您可以添加一个名为setYAxisMinimumValue的方法，它可以接受一个y轴最小值，并更新视图以反映此更改。这样，您可以更轻松地控制y轴的最小值，而无需重新创建SmoothCurveView实例。
//在SmoothCurveView类中，您可以添加一个名为clearCurve的方法，它可以清除曲线数据和圆点的位置，以及重新绘制视图。这可以使您更轻松地清除视图并开始一个新的曲线绘制。
//在ViewController类中，您可以添加一个名为sortDataPoints的方法，它可以按x值的顺序对数据点进行排序。这样，您可以确保数据点在设置时按照正确的顺序进行设置。
//在ViewController类中，您可以添加一个名为updateCurve的方法，它可以获取SmoothCurveView实例，并使用新的曲线数据来更新曲线。这样，您可以在视图中更新曲线，而无需重新创建SmoothCurveView实例。
//在ViewController类中，您可以添加一个名为clearCurve的方法，它可以获取SmoothCurveView实例，并清除曲线数据和圆点的位置，并重新绘制视图。这可以使您更轻松地清除视图并开始一个新的曲线绘制。
//希望这些建议能够帮助您完善您的代码并使其更加健壮和可维护。
       







@end
