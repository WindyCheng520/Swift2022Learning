//
//  SmootView.h
//  Mydemo
//
//  Created by Windy on 2023/3/3.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SmootView : UIView

@property (nonatomic, strong) NSArray *dataPoints; // 数据点，NSArray of NSValue(CGPoint)
@property (nonatomic, strong) UIColor *lineColor; // 线条颜色
@property (nonatomic, assign) CGFloat lineWidth; // 线条宽度
@property (nonatomic, assign) CGFloat pointRadius; // 拐点半径
@property (nonatomic, strong) UIColor *pointColor; // 拐点颜色

@end

NS_ASSUME_NONNULL_END
