//
//  MySmootView.h
//  Mydemo
//
//  Created by Windy on 2023/3/3.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MySmootView : UIView

@property (nonatomic, strong) UIColor *lineColor; // 曲线颜色
@property (nonatomic, assign) CGFloat lineWidth; // 曲线宽度
@property (nonatomic, strong) UIColor *gridColor; // 网格颜色
@property (nonatomic, assign) CGFloat gridWidth; // 网格线宽度
@property (nonatomic, assign) CGFloat gridDashLength; // 虚线网格线段长度
@property (nonatomic, strong) NSMutableArray *dataPoints; // 数据点数组，其中每个元素是一个CGPoint对象
@property (nonatomic, assign) CGFloat minYValue; // Y轴最小值
@property (nonatomic, assign) CGFloat maxYValue; // Y轴最大值

@property (nonatomic, strong) NSMutableArray *xLabels; 


@end

NS_ASSUME_NONNULL_END
