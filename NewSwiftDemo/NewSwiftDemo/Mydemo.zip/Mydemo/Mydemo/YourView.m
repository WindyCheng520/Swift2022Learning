//
//  YourView.m
//  Mydemo
//
//  Created by Windy on 2023/3/3.
//

#import "YourView.h"


@interface YourView ()

@property (nonatomic, assign) CGFloat xMinValue;
@property (nonatomic, assign) CGFloat xMaxValue;
@property (nonatomic, assign) CGFloat yMinValue;
@property (nonatomic, assign) CGFloat yMaxValue;
@property (nonatomic, assign) CGFloat xRange;
@property (nonatomic, assign) CGFloat yRange;
@property (nonatomic, strong) CALayer *dotLayer;
@property (nonatomic, assign) CGFloat dotPosition;
@property (nonatomic, assign) BOOL isDragging;
@property (nonatomic, assign) CGPoint dragStartPoint;
@property (nonatomic, assign) CGFloat originalDotPosition;
@property (nonatomic, strong) NSMutableArray<CAShapeLayer *> *lineLayers;
@property (nonatomic, strong) NSMutableArray<CATextLayer *> *xAxisLabelLayers;
@property (nonatomic, strong) NSMutableArray<CATextLayer *> *yAxisLabelLayers;

@property (nonatomic, strong) CALayer *selectedDotLayer;



@property(nullable, copy) NSArray<NSNumber *> *gridLineDashPattern;

@end

@implementation YourView

- (instancetype)initWithFrame:(CGRect)frame dataPoints:(NSMutableArray<NSValue *> *)dataPoints {
    self = [super initWithFrame:frame];
    if (self) {
        _dataPoints = dataPoints;
        _lineWidth = 1;
        _lineColor = UIColor.blackColor;
        _dotRadius = 4;
        _dotColor = UIColor.blackColor;
        _gridColor = UIColor.lightGrayColor;
        _gridWidth = 0.5;
        _xAxisLabelFont = [UIFont systemFontOfSize:10];
        _yAxisLabelFont = [UIFont systemFontOfSize:10];
        _xAxisLabelColor = UIColor.blackColor;
        _yAxisLabelColor = UIColor.blackColor;
        
        [self setup];
    }
    return self;
}

- (void)setDataPoints:(NSMutableArray<NSValue *> *)dataPoints {
    _dataPoints = dataPoints;
    [self setup];
}

- (void)setLineWidth:(CGFloat)lineWidth {
    _lineWidth = lineWidth;
    for (CAShapeLayer *layer in self.lineLayers) {
        layer.lineWidth = lineWidth;
    }
}

- (void)setLineColor:(UIColor *)lineColor {
    _lineColor = lineColor;
    for (CAShapeLayer *layer in self.lineLayers) {
        layer.strokeColor = lineColor.CGColor;
    }
}

- (void)setDotRadius:(CGFloat)dotRadius {
    _dotRadius = dotRadius;
    self.dotLayer.bounds = CGRectMake(0, 0, 2 * dotRadius, 2 * dotRadius);
    self.dotLayer.cornerRadius = dotRadius;
}

- (void)setDotColor:(UIColor *)dotColor {
    _dotColor = dotColor;
    self.dotLayer.backgroundColor = dotColor.CGColor;
}

- (void)setGridColor:(UIColor *)gridColor {
    _gridColor = gridColor;
    [self setNeedsDisplay];
}

-(void)setGridWidth:(CGFloat)gridWidth {
    _gridWidth = gridWidth;
    [self setNeedsDisplay];
}

-(void)setXAxisLabelFont:(UIFont *)xAxisLabelFont {
    _xAxisLabelFont = xAxisLabelFont;
    for (CATextLayer *layer in self.xAxisLabelLayers) {
        layer.font = (__bridge CFTypeRef)xAxisLabelFont;
    }
}

-(void)setYAxisLabelFont:(UIFont *)yAxisLabelFont {
    _yAxisLabelFont = yAxisLabelFont;
    for (CATextLayer *layer in self.yAxisLabelLayers) {
        layer.font = (__bridge CFTypeRef)yAxisLabelFont;
    }
}

-(void)setXAxisLabelColor:(UIColor *)xAxisLabelColor {
    _xAxisLabelColor = xAxisLabelColor;
    for (CATextLayer *layer in self.xAxisLabelLayers) {
        layer.foregroundColor = xAxisLabelColor.CGColor;
    }
}

-(void)setYAxisLabelColor:(UIColor *)yAxisLabelColor {
    _yAxisLabelColor = yAxisLabelColor;
    for (CATextLayer *layer in self.yAxisLabelLayers) {
        layer.foregroundColor = yAxisLabelColor.CGColor;
    }
}

-(void)setup {
    [self calculateDataRange];
    [self createGrid];
    [self createLine];
    [self createDot];
}

-(void)calculateDataRange {
    if (self.dataPoints.count == 0) {
        return;
    }
    NSValue *firstPoint = self.dataPoints.firstObject;
    CGPoint firstPointValue = firstPoint.CGPointValue;
    self.xMinValue = firstPointValue.x;
    self.xMaxValue = firstPointValue.x;
    self.yMinValue = firstPointValue.y;
    self.yMaxValue = firstPointValue.y;
    for (NSValue *value in self.dataPoints) {
        CGPoint pointValue = value.CGPointValue;
        if (pointValue.x < self.xMinValue) {
            self.xMinValue = pointValue.x;
        }
        if (pointValue.x > self.xMaxValue) {
            self.xMaxValue = pointValue.x;
        }
        if (pointValue.y < self.yMinValue) {
            self.yMinValue = pointValue.y;
        }
        if (pointValue.y > self.yMaxValue) {
            self.yMaxValue = pointValue.y;
        }
    }
    self.xRange = self.xMaxValue - self.xMinValue;
    self.yRange = self.yMaxValue - self.yMinValue;
}

-(void)createGrid {
    // X 轴标注
    CGFloat xAxisLabelWidth = 40;
    CGFloat xAxisLabelHeight = 20;
    CGFloat xAxisHeight = self.bounds.size.height - xAxisLabelHeight;
    NSInteger numOfXAxisLabels = (NSInteger)ceil(self.xRange);
    CGFloat xStep = xAxisHeight / numOfXAxisLabels;
    self.xAxisLabelLayers = [NSMutableArray array];
    for (NSInteger i = 0; i <= numOfXAxisLabels; i++) {
        CGFloat y = self.bounds.size.height - xAxisLabelHeight - i * xStep;
        CATextLayer *labelLayer = [self axisLabelLayerWithText:[NSString stringWithFormat:@"%.0f", self.xMinValue + i] font:self.xAxisLabelFont color:self.xAxisLabelColor];
        labelLayer.frame = CGRectMake(xAxisLabelWidth + i * xStep - xAxisLabelWidth / 2, y - xAxisLabelHeight / 2, xAxisLabelWidth, xAxisLabelHeight);
        [self.layer addSublayer:labelLayer];
        [self.xAxisLabelLayers addObject:labelLayer];
        CAShapeLayer *gridLineLayer = [CAShapeLayer layer];
        gridLineLayer.strokeColor = self.gridColor.CGColor;
        gridLineLayer.lineWidth = self.gridWidth;
        gridLineLayer.lineDashPattern = self.gridLineDashPattern;
        gridLineLayer.path = [self gridLinePathWithStartPoint:CGPointMake(xAxisLabelWidth + i * xStep, xAxisHeight) endPoint:CGPointMake(xAxisLabelWidth + i * xStep, 0)].CGPath;
        [self.layer addSublayer:gridLineLayer];
    }
    // Y 轴标注
    CGFloat yAxisLabelWidth = 50;
    CGFloat yAxisLabelHeight = 20;
    CGFloat yAxisWidth = self.bounds.size.width - yAxisLabelWidth;
    NSInteger numOfYAxisLabels = (NSInteger)ceil(self.yRange);
    CGFloat yStep = yAxisWidth / numOfYAxisLabels;
    self.yAxisLabelLayers = [NSMutableArray array];
    for (NSInteger i = 0; i <= numOfYAxisLabels; i++) {
        CGFloat x = yAxisLabelWidth + i * yStep;
        CATextLayer *labelLayer = [self axisLabelLayerWithText:[NSString stringWithFormat:@"%.0f", self.yMinValue + i] font:self.yAxisLabelFont color:self.yAxisLabelColor];
        labelLayer.frame = CGRectMake(x - yAxisLabelWidth / 2, xAxisHeight, yAxisLabelWidth, xAxisLabelHeight);
        [self.layer addSublayer:labelLayer];
        [self.yAxisLabelLayers addObject:labelLayer];
        CAShapeLayer *gridLineLayer = [CAShapeLayer layer];
        gridLineLayer.strokeColor = self.gridColor.CGColor;
        gridLineLayer.lineWidth = self.gridWidth;
        gridLineLayer.lineDashPattern = self.gridLineDashPattern;
        gridLineLayer.path = [self gridLinePathWithStartPoint:CGPointMake(x, 0) endPoint:CGPointMake(x, xAxisHeight)].CGPath;
        [self.layer addSublayer:gridLineLayer];
    }
}

-(void)createLine {
    if (self.dataPoints.count == 0) {
        return;
    }
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:[self pointForValue:self.dataPoints.firstObject.CGPointValue]];
    for (NSValue *value in self.dataPoints) {
        CGPoint pointValue = value.CGPointValue;
        [path addLineToPoint:[self pointForValue:pointValue]];
    }
    CAShapeLayer *lineLayer = [CAShapeLayer layer];
    lineLayer.strokeColor = self.lineColor.CGColor;
    lineLayer.fillColor = nil;
    lineLayer.lineWidth = self.lineWidth;
    lineLayer.path = path.CGPath;
    [self.layer addSublayer:lineLayer];
}

-(void)createDot {
    if (self.dataPoints.count == 0) {
        return;
    }
    for (NSValue *value in self.dataPoints) {
        CGPoint pointValue = value.CGPointValue;
        CALayer *dotLayer = [CALayer layer];
        dotLayer.backgroundColor = self.dotColor.CGColor;
        dotLayer.bounds = CGRectMake(0, 0, self.dotRadius * 2, self.dotRadius * 2);
        dotLayer.cornerRadius = self.dotRadius;
        dotLayer.position = [self pointForValue:pointValue];
        [self.layer addSublayer:dotLayer];
    }
}

-(CATextLayer *)axisLabelLayerWithText:(NSString *)text font:(UIFont *)font color:(UIColor *)color {
    CATextLayer *layer = [CATextLayer layer];
    layer.string = text;
    layer.font = (__bridge CFTypeRef _Nullable)(font.fontName);
    layer.fontSize = font.pointSize;
    layer.foregroundColor = color.CGColor;
    layer.alignmentMode = kCAAlignmentCenter;
    return layer;
}

-(UIBezierPath *)gridLinePathWithStartPoint:(CGPoint)startPoint endPoint:(CGPoint)endPoint {
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:startPoint];
    [path addLineToPoint:endPoint];
    return path;
}

-(CGPoint)pointForValue:(CGPoint)value {
    CGFloat xAxisLabelWidth = 50;
    CGFloat yAxisLabelHeight = 20;
    CGFloat xAxisHeight = self.bounds.size.height - yAxisLabelHeight;
    CGFloat yAxisLabelWidth = 50;
    CGFloat yAxisWidth = self.bounds.size.width - yAxisLabelWidth;
    CGFloat x = xAxisLabelWidth + (value.x - self.xMinValue) / self.xRange * yAxisWidth;
    CGFloat y = xAxisHeight - (value.y - self.yMinValue) / self.yRange * xAxisHeight;
    return CGPointMake(x, y);
}

-(CGPoint)valueForPoint:(CGPoint)point {
    CGFloat xAxisLabelWidth = 50;
    CGFloat yAxisLabelHeight = 20;
    CGFloat xAxisHeight = self.bounds.size.height - yAxisLabelHeight;
    CGFloat yAxisLabelWidth = 50;
    CGFloat yAxisWidth = self.bounds.size.width - yAxisLabelWidth;
    CGFloat xValue = (point.x - xAxisLabelWidth) / yAxisWidth * self.xRange + self.xMinValue;
    CGFloat yValue = (xAxisHeight - point.y) / xAxisHeight * self.yRange + self.yMinValue;
    return CGPointMake(xValue, yValue);
}

#pragma mark - Touch Handling

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    CGPoint touchPoint = [touches.anyObject locationInView:self];
    for (CALayer *layer in self.layer.sublayers) {
        if ([layer isKindOfClass:[CALayer class]]) {
            if (CGRectContainsPoint(layer.frame, touchPoint)) {
                self.selectedDotLayer = layer;
                break;
            }
        }
    }
}

-(void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    CGPoint touchPoint = [touches.anyObject locationInView:self];
    if (self.selectedDotLayer) {
        CGPoint oldValue = [self valueForPoint:self.selectedDotLayer.position];
        CGPoint newValue = CGPointMake(oldValue.x, [self roundValue:touchPoint.y]);
        CGPoint newPoint = [self pointForValue:newValue];
        self.selectedDotLayer.position = newPoint;
        NSInteger index = [self.dataPoints indexOfObject:[NSValue valueWithCGPoint:oldValue]];
        if (index != NSNotFound) {
            [self.dataPoints replaceObjectAtIndex:index withObject:[NSValue valueWithCGPoint:newValue]];
           // [self ];
        }
    }
}

-(void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    self.selectedDotLayer = nil;
}

-(CGFloat)roundValue:(CGFloat)value {
    CGFloat yAxisLabelWidth = 50;
    CGFloat yAxisWidth = self.bounds.size.width - yAxisLabelWidth;
    CGFloat numOfYAxisLabels = ceil(self.yRange);
    CGFloat yStep = yAxisWidth / numOfYAxisLabels;
    CGFloat remainder = fmodf(value - yAxisLabelWidth, yStep);
    if (remainder < yStep / 2) {
        return floor((value - yAxisLabelWidth) / yStep) * yStep + yAxisLabelWidth;
    } else {
        return ceil((value - yAxisLabelWidth) / yStep) * yStep + yAxisLabelWidth;
    }
}



@end
