//
//  ViewController.m
//  Mydemo
//
//  Created by Windy on 2023/3/3.
//

#import "ViewController.h"
#import "SmoothCurveGraphView.h"
#import "SmoothCureGroupView1.h"

#import "SmootView.h"

#import "MySmootView.h"

#import "YourView.h"

#import "MyView.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    SmoothCureGroupView1 *view = [[SmoothCureGroupView1 alloc] initWithFrame:CGRectMake(0, 0, 300, 300)];
//    view.backgroundColor = [UIColor whiteColor];
//    view.center = self.view.center;
//
//    view.xValues = @[@"0h", @"1h",@"2h",@"3h",@"4h",@"5h",@"6h",@"7h",@"8h",@"9h", @"10h",@"11h"];
//    view.yValues = @[@"16", @"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25", @"26",@"27", @"28",@"29", @"30"];
//    view.dataPoints = @[@(17), @(26), @(30), @(18), @(17), @(26), @(30), @(18), @(30), @(18), @(17), @(26)];
//
//    [self.view addSubview:view];
//
//
//    SmootView *view = [[SmootView alloc] initWithFrame:CGRectMake(0, 0, 300, 300)];
//    view.backgroundColor = [UIColor whiteColor];
//    view.center = self.view.center;
//
//
//
////    view.xValues = @[@"0h", @"1h",@"2h",@"3h",@"4h",@"5h",@"6h",@"7h",@"8h",@"9h", @"10h",@"11h"];
////    view.yValues = @[@"16", @"17",@"18",@"19",@"20",@"21",@"22",@"23",@"24",@"25", @"26",@"27", @"28",@"29", @"30"];
//    view.dataPoints = @[@(17), @(26), @(30), @(18), @(17), @(26), @(30), @(18), @(30), @(18), @(17), @(26)];
//
//    [self.view addSubview:view];
    
    

    MySmootView *curveView = [[MySmootView alloc] initWithFrame:CGRectMake(20, 100, self.view.bounds.size.width - 40, 300)];
    curveView.backgroundColor = [UIColor clearColor];
    curveView.center = self.view.center;
    curveView.xLabels = @[@"0", @"10", @"20", @"30", @"40", @"50", @"60", @"70", @"80", @"90", @"100"].mutableCopy;
    curveView.maxYValue = 30;
    curveView.dataPoints = @[[NSValue valueWithCGPoint:CGPointMake(0, 18)],
    [NSValue valueWithCGPoint:CGPointMake(1, 20)],
    [NSValue valueWithCGPoint:CGPointMake(3, 25)],
    [NSValue valueWithCGPoint:CGPointMake(4, 22)],
    [NSValue valueWithCGPoint:CGPointMake(5, 19)],
                             [NSValue valueWithCGPoint:CGPointMake(6, 25)],
                             [NSValue valueWithCGPoint:CGPointMake(7, 22)],
                             [NSValue valueWithCGPoint:CGPointMake(8, 19)],
    [NSValue valueWithCGPoint:CGPointMake(9, 28)],
                             [NSValue valueWithCGPoint:CGPointMake(10, 22)],
                             [NSValue valueWithCGPoint:CGPointMake(11, 20)],
    ].mutableCopy;
    [self.view addSubview:curveView];
    
    
//    YourView *lineChart = [[YourView alloc] initWithFrame:CGRectMake(20, 100, 280, 200)];
//    lineChart.dataPoints = @[[NSValue valueWithCGPoint:CGPointMake(0, 1)],
//                             [NSValue valueWithCGPoint:CGPointMake(1, 2)],
//                             [NSValue valueWithCGPoint:CGPointMake(2, 3)],
//                             [NSValue valueWithCGPoint:CGPointMake(3, 2)],
//                             [NSValue valueWithCGPoint:CGPointMake(4, 4)]].mutableCopy;
//    [self.view addSubview:lineChart];
    
    
//    // 初始化视图
//    MyView *curveView = [[MyView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 300)];
//
//    curveView.center = self.view.center;
//
//    [self.view addSubview:curveView];

//    NSMutableArray *tem = [NSMutableArray array];
//
//    [tem addObject:[NSValue valueWithCGPoint:CGPointMake(0, 5)]];
//    [tem addObject:[NSValue valueWithCGPoint:CGPointMake(1, 7)]];
//    [tem addObject:[NSValue valueWithCGPoint:CGPointMake(2, 6)]];
//    [tem addObject:[NSValue valueWithCGPoint:CGPointMake(3, 8)]];
//    [tem addObject:[NSValue valueWithCGPoint:CGPointMake(4, 5)]];
//    [tem addObject:[NSValue valueWithCGPoint:CGPointMake(5, 7)]];

//    // 更新视图
//    [curveView updatePointsAndLabels];
//    [curveView updatePath];

    
    
}
@end
