//
//  SmoothCureGroupView1.h
//  Mydemo
//
//  Created by Windy on 2023/3/3.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SmoothCureGroupView1 : UIView


// 数据源数组
@property (nonatomic, strong) NSArray *dataPoints;

@property (nonatomic, strong) NSArray *xValues;

@property (nonatomic, strong) NSArray *yValues;





@property(nonatomic, assign)CGFloat marginLeft;
@property(nonatomic, assign)CGFloat chartHeight;
@property(nonatomic, assign)CGFloat marginTop;
@property(nonatomic, assign)CGFloat chartWidth;


@property(nonatomic, assign)CGFloat gridHeight;

@property(nonatomic, assign)CGFloat gridWidth;





@end

NS_ASSUME_NONNULL_END
