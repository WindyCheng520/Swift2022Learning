//
//  SmoothCureGroupView1.m
//  Mydemo
//
//  Created by Windy on 2023/3/3.
//



#import "SmoothCureGroupView1.h"


@implementation SmoothCureGroupView1

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        // 初始化一些参数
        self.marginLeft = 30;
        self.chartHeight  = 320;
        self.chartWidth = self.bounds.size.width;
        self.marginTop = 10;
        self.gridWidth = self.bounds.size.width / (self.dataPoints.count-1);
        
        self.gridHeight = self.bounds.size.height / 14;
    }
    return self;
}

-(void)setDataPoints:(NSArray *)dataPoints{
    _dataPoints = dataPoints;
    self.gridWidth = self.bounds.size.width / (self.dataPoints.count-1);
    [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect {
    // 设置网格线和坐标轴颜色
    UIColor *gridColor = [UIColor lightGrayColor];
    UIColor *axisColor = [UIColor blackColor];
    // 绘制坐标轴和网格线
    [self drawAxisAndGridLinesWithGridColor:gridColor axisColor:axisColor];
    // 绘制曲线
    [self drawSmoothCurveWithDataPoints:self.dataPoints];
}

- (void)drawAxisAndGridLinesWithGridColor:(UIColor *)gridColor axisColor:(UIColor *)axisColor {
    // 获取画布上下文
    CGContextRef context = UIGraphicsGetCurrentContext();
    // 设置坐标轴线宽和颜色
    CGContextSetLineWidth(context, 2.0);
    CGContextSetStrokeColorWithColor(context, axisColor.CGColor);
    // 绘制X轴和Y轴
    CGContextMoveToPoint(context, self.marginLeft, self.chartHeight + self.marginTop);
    CGContextAddLineToPoint(context, self.marginLeft + self.chartWidth, self.chartHeight + self.marginTop);
    CGContextMoveToPoint(context, self.marginLeft, self.marginTop);
    CGContextAddLineToPoint(context, self.marginLeft, self.chartHeight + self.marginTop);
    CGContextStrokePath(context);
    // 设置网格线颜色
    CGContextSetStrokeColorWithColor(context, gridColor.CGColor);
    // 绘制X轴上的标注和网格线
    for (int i = 0; i < self.xValues.count; i++) {
        CGFloat x = self.marginLeft + i * self.gridWidth;
        CGFloat y1 = self.marginTop;
        CGFloat y2 = self.marginTop + self.chartHeight;
        CGContextMoveToPoint(context, x, y1);
        CGContextAddLineToPoint(context, x, y2);
        CGContextStrokePath(context);
        // 绘制X轴上的标注
        NSString *text = self.xValues[i];
        CGRect textRect = CGRectMake(x - self.gridWidth / 2.0, y2 + 5, self.gridWidth, 20);
        [text drawInRect:textRect withAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:10], NSForegroundColorAttributeName: axisColor}];
    }
    // 绘制Y轴上的标注和网格线
    for (int i = 0; i < self.yValues.count; i++) {
        CGFloat x1 = self.marginLeft;
        CGFloat x2 = self.marginLeft + self.chartWidth;
        CGFloat y = self.marginTop + i * self.gridHeight;
        CGContextMoveToPoint(context, x1, y);
        CGContextAddLineToPoint(context, x2, y);
        CGContextStrokePath(context);
        // 绘制Y轴上的标注
        NSString *text = self.yValues[i];
        CGRect textRect = CGRectMake(x1 - self.gridWidth, y - 10, self.gridWidth, 20);
        [text drawInRect:textRect withAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:10], NSForegroundColorAttributeName: axisColor}];
    }
    
}

-(void)drawSmoothCurveWithDataPoints:(NSArray *)dataPoints {
    if (dataPoints.count <= 1) {
        return;
    }
    //获取画布上下文
    CGContextRef context = UIGraphicsGetCurrentContext();
    // 设置曲线颜色和线宽
    UIColor *lineColor = [UIColor redColor];
    CGContextSetStrokeColorWithColor(context, lineColor.CGColor);
    CGContextSetLineWidth(context, 2.0);
    // 绘制曲线路径
    UIBezierPath *path = [UIBezierPath bezierPath];
    // 画第一个点
    CGPoint point1 = [self pointAtIndex:0 inDataPoints:dataPoints];
    [path moveToPoint:point1];
    for (int i = 1; i < dataPoints.count; i++) {
        // 画拐点
        CGPoint point2 = [self pointAtIndex:i inDataPoints:dataPoints];
        CGContextFillEllipseInRect(context, CGRectMake(point2.x - 3, point2.y - 3, 6, 6));
        // 画曲线
        CGPoint midPoint = [self midPointBetweenPoint1:point1 andPoint2:point2];
        [path addQuadCurveToPoint:midPoint controlPoint:[self controlPointBetweenPoint1:midPoint andPoint2:point1]];
        [path addQuadCurveToPoint:point2 controlPoint:[self controlPointBetweenPoint1:midPoint andPoint2:point2]];
        // 更新点的位置
        point1 = point2;
    }
    // 绘制曲线
    [lineColor setStroke];
    [path stroke];
}

-(CGPoint)pointAtIndex:(NSUInteger)index inDataPoints:(NSArray *)dataPoints {
    // 根据数据点的值，计算点在坐标系中的位置
    NSNumber *value = dataPoints[index];
    CGFloat x = self.marginLeft + index * self.gridWidth;
    CGFloat y = self.marginTop + self.chartHeight - [value floatValue] * self.gridHeight;
    return CGPointMake(x, y);
}

-(CGPoint)midPointBetweenPoint1:(CGPoint)point1 andPoint2:(CGPoint)point2 {
    return CGPointMake((point1.x + point2.x) / 2.0, (point1.y + point2.y) / 2.0);
}

-(CGPoint)controlPointBetweenPoint1:(CGPoint)point1 andPoint2:(CGPoint)point2 {
    CGPoint controlPoint = [self midPointBetweenPoint1:point1 andPoint2:point2];
    CGFloat diffY = fabs(point2.y - controlPoint.y);
    if (point1.y < point2.y) {
        controlPoint.y += diffY;
    } else if (point1.y > point2.y) {
        controlPoint.y -= diffY;
    }
    return controlPoint;
}

//    // 处理拖动事件，更新数据源和重绘曲线
//
//    (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    CGPoint location = [[touches anyObject] locationInView:self];
//    NSInteger index = (location.x - self.marginLeft) / self.gridWidth;
//    if (index >=
//
//
//
//    ralphnamer32d@hotmail.com
//    继续
//    !
//    Too many requests in 1 hour. Try again later.


@end



