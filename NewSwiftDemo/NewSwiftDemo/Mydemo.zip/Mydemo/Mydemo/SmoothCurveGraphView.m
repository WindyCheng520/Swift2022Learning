//
//  SmoothCurveGraphView.m
//  Mydemo
//
//  Created by Windy on 2023/3/3.
//

#import "SmoothCurveGraphView.h"

@implementation SmoothCurveGraphView


- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];

    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(context, 1.0);

    // 绘制网格线
    [self drawGridLines:context];

    // 绘制平滑曲线
    [self drawSmoothCurve:context];
    
    // 在拐角处绘制圆点
//      CGContextRef context = UIGraphicsGetCurrentContext();
//      CGContextSaveGState(context);
//      CGContextSetFillColorWithColor(context, [UIColor whiteColor].CGColor);
//      for (NSInteger i = 1; i < _dataPoints.count - 1; i++) {
//          CGPoint previousPoint = [self pointAtIndex:i - 1 width:width height:height];
//          CGPoint currentPoint = [self pointAtIndex:i width:width height:height];
//          CGPoint nextPoint = [self pointAtIndex:i + 1 width:width height:height];
//          CGFloat angle1 = atan2f(currentPoint.y - previousPoint.y, currentPoint.x - previousPoint.x);
//          CGFloat angle2 = atan2f(nextPoint.y - currentPoint.y, nextPoint.x - currentPoint.x);
//          CGFloat angleDiff = fabs(angle2 - angle1);
//          if (angleDiff > M_PI) {
//              angleDiff = M_PI * 2 - angleDiff;
//          }
//          if (angleDiff > M_PI / 2.0) {
//              CGRect dotRect = CGRectMake(currentPoint.x - _dotRadius, currentPoint.y - _dotRadius, _dotRadius * 2.0, _dotRadius * 2.0);
//              CGContextFillEllipseInRect(context, dotRect);
//          }
//      }
//      CGContextRestoreGState(context);

    // 绘制X轴和Y轴的标注
    [self drawAxisLabels:context];
}

- (void)setDataPoints:(NSArray *)dataPoints {
    _dataPoints = dataPoints;
    _maxValue = [self maxValueInDataPoints:dataPoints];
    _minValue = [self minValueInDataPoints:dataPoints];
    [self setNeedsDisplay];
}

- (void)drawGridLines:(CGContextRef)context {
    // 绘制横向网格线
    for (NSInteger i = 1; i <= 10; i++) {
        CGFloat y = self.frame.size.height / 11.0 * i;
        CGContextMoveToPoint(context, 0, y);
        CGContextAddLineToPoint(context, self.frame.size.width, y);
        CGContextSetStrokeColorWithColor(context, [UIColor lightGrayColor].CGColor);
        CGContextStrokePath(context);
    }

    // 绘制纵向网格线
    for (NSInteger i = 1; i <= 10; i++) {
        CGFloat x = self.frame.size.width / 11.0 * i;
        CGContextMoveToPoint(context, x, 0);
        CGContextAddLineToPoint(context, x, self.frame.size.height);
        CGContextSetStrokeColorWithColor(context, [UIColor lightGrayColor].CGColor);
        CGContextStrokePath(context);
    }
}

- (void)drawSmoothCurve:(CGContextRef)context {
    if (_dataPoints.count == 0) {
        return;
    }

    CGFloat width = self.frame.size.width;
    CGFloat height = self.frame.size.height;

    CGContextSetStrokeColorWithColor(context, [UIColor blueColor].CGColor);
    CGContextSetFillColorWithColor(context, [UIColor clearColor].CGColor);
    CGContextSetLineWidth(context, 2.0);

    CGFloat startPointX = 0.0;
    CGFloat startPointY = 0.0;

    for (NSInteger i = 0; i < _dataPoints.count; i++) {
        CGFloat x = width / (_dataPoints.count - 1) * i;
        CGFloat y = height - (height / (_maxValue - _minValue) * ([_dataPoints[i] floatValue] - _minValue));

        if (i == 0) {
            CGContextMoveToPoint(context, x, y);
            startPointX = x;
            startPointY = y;
        } else {
            CGContextAddQuadCurveToPoint(context, startPointX, startPointY, (x + startPointX) / 2.0, (y + startPointY) / 2.0);
            startPointX = x;
            startPointY = y;
        }
    }

    CGContextStrokePath(context);
}

- (void)drawAxisLabels:(CGContextRef)context {
    CGFloat width = self.frame.size.width;
    CGFloat height = self.frame.size.height;
    
    //// 绘制X轴标注
    for (NSInteger i = 0; i < _dataPoints.count; i++) {
        CGFloat x = width / (_dataPoints.count - 1) * i;
        NSString *text = [NSString stringWithFormat:@"%ld", (long)i];
        CGRect textRect = CGRectMake(x - 10.0, height + 5.0, 20.0, 20.0);
        [self drawText:text inRect:textRect withColor:[UIColor blackColor] font:[UIFont systemFontOfSize:10.0] alignment:NSTextAlignmentCenter];
    }
    
    // 绘制Y轴标注
    for (NSInteger i = 0; i < 11; i++) {
        CGFloat y = height / 11.0 * (11 - i);
        NSString *text = [NSString stringWithFormat:@"%.1f", _minValue + (_maxValue - _minValue) / 10.0 * i];
        CGRect textRect = CGRectMake(-30.0, y - 10.0, 30.0, 20.0);
        [self drawText:text inRect:textRect withColor:[UIColor blackColor] font:[UIFont systemFontOfSize:10.0] alignment:NSTextAlignmentRight];
    }
}

-(void)drawText:(NSString *)text inRect:(CGRect)rect withColor:(UIColor *)color font:(UIFont *)font alignment:(NSTextAlignment)alignment {
    [color setFill];
    NSMutableParagraphStyle *style = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
    style.alignment = alignment;
    NSDictionary *attributes = @{NSFontAttributeName: font,
                                 NSParagraphStyleAttributeName: style};
    CGSize textSize = [text sizeWithAttributes:attributes];
    CGRect textRect = CGRectMake(rect.origin.x + (rect.size.width - textSize.width) / 2.0,
                                 rect.origin.y + (rect.size.height - textSize.height) / 2.0,
                                 textSize.width,
                                 textSize.height);
    [text drawInRect:textRect withAttributes:attributes];
}

-(CGFloat)maxValueInDataPoints:(NSArray *)dataPoints {
    CGFloat maxValue = CGFLOAT_MIN;
    for (NSNumber *number in dataPoints) {
        maxValue = fmax(maxValue, [number floatValue]);
    }
    return maxValue;
}

-(CGFloat)minValueInDataPoints:(NSArray *)dataPoints {
    CGFloat minValue = CGFLOAT_MAX;
    for (NSNumber *number in dataPoints) {
        minValue = fmin(minValue, [number floatValue]);
    }
    return minValue;
}


@end
