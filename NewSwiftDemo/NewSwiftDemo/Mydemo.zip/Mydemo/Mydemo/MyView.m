//
//  MyView.m
//  Mydemo
//
//  Created by Windy on 2023/3/3.
//

#import "MyView.h"



@implementation MyView {
    CGFloat xAxisLength;
    CGFloat yAxisLength;
    CGFloat pointRadius;
    CGFloat gridWidth;
    CGFloat margin;
    CGFloat axisMargin;
    CGFloat gridHeight;
    CGFloat xStep;
    CGFloat yStep;
    CGPoint startPoint;
    CGPoint endPoint;
    NSMutableArray *pointsArray;
    NSMutableArray *labelsArray;
    NSMutableArray *dotArray;
    UIBezierPath *path;
    CAShapeLayer *lineLayer;
    BOOL dragging;
    CGPoint lastDragPoint;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        self.dataPoints = @[@2.0, @3.0, @4, @6.0, @7.0, @8.0, @8, @9.0, @7.0, @6.0, @4.0, @3.0].mutableCopy;
        xAxisLength = frame.size.width - 40;
        yAxisLength = frame.size.height - 60;
        pointRadius = 4;
        gridWidth = xAxisLength / 10.0;
        margin = 20;
        axisMargin = 10;
        gridHeight = yAxisLength / 10.0;
        xStep = xAxisLength / 11.0;
        yStep = yAxisLength / 11.0;
        startPoint = CGPointMake(margin + axisMargin, margin + yAxisLength);
        endPoint = CGPointMake(margin + xAxisLength, margin + yAxisLength);
        pointsArray = [NSMutableArray array];
        labelsArray = [NSMutableArray array];
        dotArray = [NSMutableArray array];
        path = [UIBezierPath bezierPath];
        lineLayer = [CAShapeLayer layer];
        lineLayer.lineWidth = 2;
        lineLayer.strokeColor = [UIColor blueColor].CGColor;
        lineLayer.fillColor = [UIColor clearColor].CGColor;
        [self.layer addSublayer:lineLayer];
        
        [self addGrid];
        [self addAxis];
        [self addPointsAndLabels];
        [self updatePath];
    }
    return self;
}

//-(void)addDataPoint:(CGPoint)point {
//    [self.dataPoints addObject:@{@"x": @(point.x), @"y": @(1 - point.y / self.frame.size.height)}];
//    [self updatePointsAndLabels];
//    [self setNeedsDisplay];
//}


- (void)setdataPoints:(NSMutableArray *)dataPoints {
    _dataPoints = dataPoints;
    [self updatePointsAndLabels];
    [self updatePath];
}

- (void)addGrid {
    for (int i = 0; i <= 10; i++) {
        CGFloat x = margin + axisMargin + i * gridWidth;
        CGFloat y = margin + i * gridHeight;
        CGPoint startPoint = CGPointMake(margin + axisMargin, y);
        CGPoint endPoint = CGPointMake(margin + xAxisLength, y);
        [self addLineFromPoint:startPoint toPoint:endPoint];
        if (i < 10) {
            [self addLineFromPoint:CGPointMake(x, margin) toPoint:CGPointMake(x, margin + yAxisLength)];
        }
    }
}

- (void)addAxis {
    [self addLineFromPoint:startPoint toPoint:endPoint];
    [self addLineFromPoint:startPoint toPoint:CGPointMake(margin + axisMargin, margin)];
    [self addLabel:@"Y" atPoint:CGPointMake(margin + axisMargin / 2.0, margin / 2.0)];
    [self addLabel:@"X" atPoint:CGPointMake(margin + xAxisLength + axisMargin / 2.0, margin + yAxisLength + axisMargin / 2.0)];
    for (int i = 1; i <= 10; i++) {
        CGFloat x = margin + axisMargin + i * xStep;
        CGPoint point = CGPointMake(x, margin + yAxisLength + axisMargin / 2.0);
        [self addLabel:[NSString stringWithFormat:@"%d", i] atPoint:point];
    }
    for (int i = 1; i <= 10; i++) {
        CGFloat y = margin + (10 - i) * yStep;
        CGPoint point = CGPointMake(margin, y);
        [self addLabel:[NSString stringWithFormat:@"%d", i] atPoint:point];
    }
}

-(void)addPointsAndLabels {
    for (int i = 0; i < self.dataPoints.count; i++) {
        CGFloat x = margin + axisMargin + (i + 1) * xStep;
        CGFloat y = margin + yAxisLength - ([self.dataPoints[i] floatValue] / 10.0) * yAxisLength;
        [pointsArray addObject:[NSValue valueWithCGPoint:CGPointMake(x, y)]];
        [self addDotAtPoint:CGPointMake(x, y)];
        [self addLabel:[NSString stringWithFormat:@"%@", self.dataPoints[i]] atPoint:CGPointMake(x - 10, y - 20)];
    }
}

-(void)updatePointsAndLabels {
    [pointsArray removeAllObjects];
    [labelsArray makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [dotArray makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [self addPointsAndLabels];
}

-(void)updatePath {
    [path removeAllPoints];
    if (pointsArray.count > 1) {
        CGPoint startPoint = [[pointsArray firstObject] CGPointValue];
        [path moveToPoint:startPoint];
        for (int i = 1; i < pointsArray.count; i++) {
            CGPoint endPoint = [[pointsArray objectAtIndex:i] CGPointValue];
            CGPoint controlPoint1 = CGPointMake((startPoint.x + endPoint.x) / 2.0, startPoint.y);
            CGPoint controlPoint2 = CGPointMake((startPoint.x + endPoint.x) / 2.0, endPoint.y);
            [path addCurveToPoint:endPoint controlPoint1:controlPoint1 controlPoint2:controlPoint2];
            startPoint = endPoint;
        }
        lineLayer.path = path.CGPath;
    }
}

-(void)addLineFromPoint:(CGPoint)startPoint toPoint:(CGPoint)endPoint {
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:startPoint];
    [path addLineToPoint:endPoint];
    CAShapeLayer *lineLayer = [CAShapeLayer layer];
    lineLayer.lineWidth = 1;
    lineLayer.strokeColor = [UIColor lightGrayColor].CGColor;
    lineLayer.fillColor = [UIColor clearColor].CGColor;
    lineLayer.path = path.CGPath;
    [self.layer addSublayer:lineLayer];
}

-(void)addLabel:(NSString *)text atPoint:(CGPoint)point {
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 20, 20)];
    label.text = text;
    label.font = [UIFont systemFontOfSize:12];
    label.textColor = [UIColor grayColor];
    label.textAlignment = NSTextAlignmentCenter;
    label.center = point;
    [self addSubview:label];
    [labelsArray addObject:label];
}
-(void)addDotAtPoint:(CGPoint)point {
    UIView *dot = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 10)];
    dot.backgroundColor = [UIColor blackColor];
    dot.layer.cornerRadius = 5;
    dot.center = point;
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    [dot addGestureRecognizer:panGesture];
    [self addSubview:dot];
    [dotArray addObject:dot];
}

-(void)handlePan:(UIPanGestureRecognizer *)gesture {
    UIView *dot = gesture.view;
    CGPoint translation = [gesture translationInView:self];
    CGPoint center = dot.center;
    center.y += translation.y;
    if (center.y < margin) {
        center.y = margin;
    }
    if (center.y > margin + yAxisLength) {
        center.y = margin + yAxisLength;
    }
    dot.center = center;
    NSUInteger index = [dotArray indexOfObject:dot];
    CGFloat newY = (margin + yAxisLength - center.y) / yAxisLength * 10.0;
    [self.dataPoints replaceObjectAtIndex:index withObject:@(newY)];
    NSMutableArray *temp = self.dataPoints;
    
    [self.dataPoints removeAllObjects];
    
    
//    [self updatePointsAndLabels];
//    [self updatePath];
    
    self.dataPoints = temp.mutableCopy;
    [gesture setTranslation:CGPointZero inView:self];
}




@end
