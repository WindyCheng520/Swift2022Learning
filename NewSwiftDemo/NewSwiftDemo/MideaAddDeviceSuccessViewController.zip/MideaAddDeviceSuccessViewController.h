//
//  MideaAddDeviceSuccessViewController.h
//  BHSmartHome
//
//  Created by 邓立兵 on 2018/6/11.
//

#import <DolphinFramework/DolphinFramework.h>

#import <BHBusiness/MideaDeviceConnectInfoModel.h>

@interface MideaAddDeviceSuccessViewController : MSBaseViewController

@property (nonatomic, strong) MideaDeviceConnectInfoModel *categoryModel;

@property (nonatomic, strong) NSDictionary *subDeviceInfo;

@property (nonatomic, assign) NSTimeInterval addDeviceStartTime;
///埋点上报的sn
@property (nonatomic, strong) NSString *sn;

@property (nonatomic, strong) NSString *btToken;  //校验token
@property (nonatomic, assign) BOOL isForceBindCode; //去强制绑定(已确权）

@end
