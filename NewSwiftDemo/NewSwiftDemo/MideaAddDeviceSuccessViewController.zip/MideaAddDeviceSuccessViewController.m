//
//  MideaAddDeviceSuccessViewController.m
//  BHSmartHome
//
//  Created by 邓立兵 on 2018/6/11.
//

#import "MideaAddDeviceSuccessViewController.h"
#import "MideaAddDeviceSelectWiFiViewController.h"
#import <BHXiaoMeiVoice/MideaRequestManager+BHAIAudioModule.h>
#import <DolphinFramework/FSActionSheet.h>
#import "UIAlertController+Blocks.h"
#import <BHBusiness/MideaUserDataCenter+room.h>
#import <BHBusiness/MideaUserDataCenter+Device.h>
#import <BHMap/BHBaiduMapCenter.h>
#import <BHBusiness/MideaNotificationConst.h>
#import "MSBaseViewController+AppCommon.h"
#import "MideaSHDeviceManager.h"
#import <BHBusiness/MideaFamilyModel.h>
#import <BHBusiness/MideaRoomModel.h>
#import "MideaSHFamilymanager.h"
#import <BHBusiness/MideaUserDataCenter+Family.h>
#import <BHBusiness/MideaCategorySubTypeModel.h>
#import "MideaLockViewController.h"
#import <DolphinFramework/NeuAlertView.h>
#import <BHBusiness/MideaApplianceModel.h>
#import <BHBusiness/MideaSoftWareUpdateManager.h>
#import <BHBusiness/MideaDevicePluginManager.h>
#import <BHWeex/MideaWeexPluginViewController.h>
#import <BHBusiness/MideaUserManager+EngineeringMode.h>
#import <BHBusiness/MideaRequestManager+BHSAddDeviceModule.h>
#import <BHBusiness/MideaShoppingDefine.h>
#import <BHBusiness/MideaCurrentManager.h>
#import <BHBusiness/BHNFCManagerProtocol.h>
#import <BHBusiness/BHHomeProtocol.h>
#import "MideaAddDevicePluginDownloadViewController.h"
#import <BHBluetoothService/MideaBleDeviceConfigManager.h>
#import "MideaAutoFindDeviceManager.h"
#import "BHSceneRecommendModel.h"
#import <BHBusiness/NSString+Extension.h>
#import "MideaDeviceAuthorityPresenter.h"
#import <BHBusiness/BHFamilyHomeProtocol.h>
#import <DolphinFramework/NSDate+Extension.h>

#define RoomButtonHeight 36
#define RoomButtonSpan_H 8
#define RoomButtonSpan_V 8

@interface MideaAddDeviceAddRoomAlertController : UIAlertController

+ (instancetype)addRoomAlertControllerWithSureBlock:(void(^)(NSString *roomName))block;

@end


@interface MideaAddDeviceSuccessViewController () <UITextFieldDelegate,DOFRouterManagerProtocol>

@property (nonatomic, strong) UIScrollView *guideScrollView;

@property (nonatomic, strong) UIImageView *successImageView;
@property (nonatomic, strong) UILabel *successLabel;

@property (nonatomic, strong) UILabel *deviceNameLabel;
@property (nonatomic, strong) UITextField *deviceNameTextField;

@property (nonatomic, strong) UILabel *homeNameLabel;
@property (nonatomic, strong) UITextField *homeNameTextField;
@property (nonatomic, strong) UIView *homeNameTouchView;

@property (nonatomic, strong) UILabel *roomNameLabel;
//@property (nonatomic, strong) UITextField *roomNameTextField;
@property (nonatomic, strong) NSMutableArray<UIButton *> *roomButtons;

@property (nonatomic, strong) UILabel *nfcNameLabel;
@property (nonatomic, strong) UITextField *nfcNameTextField;

@property (nonatomic, strong) UIButton *finishButton;

@property (nonatomic, strong) NSMutableArray *ownerFamilyList;      //自己创建的家庭列表
@property (nonatomic, strong) NSMutableArray<MideaRoomModel *> *roomList;
@property (nonatomic, strong) MideaFamilyModel *selectFamily;
@property (nonatomic, strong) MideaRoomModel *selectRoom;

@property (nonatomic, assign) BOOL shouldCreateFamily;
@property (nonatomic, strong) NSString *extra2;
@property (nonatomic, assign) BOOL isNFCFun2;

@property (nonatomic, strong) MideaDeviceAuthorityPresenter *authorPresenter;

@property (nonatomic, strong) MideaApplianceModel *appliance;
@property (nonatomic, assign) BOOL isPostNoti;//只发一次延保卡通知
@end

@implementation MideaAddDeviceSuccessViewController

#pragma mark - BHSRouteManagerProtocol
- (void)msRouterParams:(NSDictionary *)params {
    
}

- (NSString *)msPageName
{
    return @"linkSuccessPage";
}

- (void)dealloc {
    DDLogDeviceVerbose(@"%@ 已释放", NSStringFromClass(self.class));
}


-(void)leftBarButtonClick{
    
    if (self.categoryModel.peripheral && self.categoryModel.deviceMac) {
        [[MideaBleDeviceConfigManager shareInstance] stopConfig:self.categoryModel.peripheral];
    }
    [[MideaAutoFindDeviceManager shareInstance] cleanBLEGEN2];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.navigationController.viewControllers enumerateObjectsUsingBlock:^(__kindof UIViewController * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj isKindOfClass:MideaAddDeviceSelectWiFiViewController.class]) {
            MideaAddDeviceSelectWiFiViewController *vc = (MideaAddDeviceSelectWiFiViewController *)obj;
            [vc saveWifiInfo];
        }
    }];
    [self hideLeftBarButtonItem];
    [self hidePopGestureRecognizer];
    [self openTapToHideKeyboardFunction];
    
    [self loadData];
    [self setupUI];
    
    NSString *extra2 = @"";
    NSInteger modeValue = _categoryModel.mode.integerValue;
    if (modeValue == 0) {
        extra2 = @"AP";
    }
    else if (modeValue == 1) {
        extra2 = @"quicklink";
    }
    else if (modeValue == 3) {
        extra2 = @"Bluetooth";
    }
    else if (modeValue == 4) {
        extra2 = @"zibee";
    }
    else if (modeValue == 100) {
        extra2 = @"dynamicQR";
    }
    else if (modeValue == 5) {
        extra2 = @"singlebluetooth";
    }
    // 二代网关单独处理 默认mqtt
    if([_categoryModel isSecondGateway]) {
        extra2 = @"mqtt";
    }
    
    self.extra2 = extra2;
    
    if (_categoryModel.deviceId.length > 0) {
        //        [[MideaCurrentManager sharedCurrentInfo].deviceAuthCacheDict setObject:@NO forKey:_categoryModel.deviceId];
        [[MideaCurrentManager sharedCurrentInfo].deviceAuthCacheDict removeObjectForKey:_categoryModel.deviceId];
    }
    
    [self uploadDeviceGPS];
    
    //语音静默授权
    [self.authorPresenter silencAuthorDeviceWithCategoryModel:self.categoryModel];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:animated];
    
    // 配网埋点#90
    NSString *sn = self.sn;
    if (!sn) sn = @"00000000000000000000000000000001";
    NSDictionary *params = @{
        @"iot_device_id" : [NSString stringWithFormat:@"%@|%@", _categoryModel.category, _categoryModel.productId ? : [sn deviceSn8]],
        @"action_result" : sn,
        @"extra2" : self.extra2 ? :@"",
        @"device_session_id":[MideaConfigDeviceTool getDeviceSessionId]
    };
    AppAction_CommonAdd(BHAppActionTypeDevice, @"deviceConnectPage", @"connect_device_fix", params);
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:animated];
}

- (void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    CGFloat width = CGRectGetWidth(self.view.bounds);
    CGFloat heigt = CGRectGetHeight(self.view.bounds);
    
    self.finishButton.frame = CGRectMake(15,
                                         heigt - kMSCommonViewHeight - (MideaUIConfiguration.sh_bottomDistance_24 + [UIDevice ms_tabBarBottomHeight]),
                                         width - 30,
                                         kMSCommonViewHeight);
    
    _guideScrollView.frame = CGRectMake(0, 0, width, CGRectGetMinY(self.finishButton.frame) - 10);
    
    [self resetScrollViewContentSizeAndLayouSubviews];
}

#pragma mark - 设备位置上传
- (void)uploadDeviceGPS
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSDictionary *dic = [[BHBaiduMapCenter sharedInstance] currentLocation];
        
        NSString *cityName = dic[@"city"];
        if (cityName) {
            
            NSString *path = [[NSBundle mainBundle] pathForResource:@"city" ofType:@"plist"];
            NSDictionary *cityInfos = [NSDictionary dictionaryWithContentsOfFile:path];
            
            NSDictionary *cityInfo = cityInfos[cityName];
            NSString *provinceCode = cityInfo[@"province"];
            NSString *cityCode = cityInfo[@"city"];
            NSMutableDictionary * locationDic = [[NSMutableDictionary alloc]init];
            [locationDic setObject:@"10000" forKey:kMSServerKeyCountryId];
            !cityCode?:[locationDic setObject:cityCode forKey:kMSServerKeyCityId];
            !provinceCode?:[locationDic setObject:provinceCode forKey:kMSServerKeyProvinceId];
            !dic[@"longitude"]?:[locationDic setObject:dic[@"longitude"]  forKey:kMSServerKeyLongitudes];
            !dic[@"latitude"]?:[locationDic setObject:dic[@"latitude"]  forKey:kMSServerKeyLatitudes];
            WEAKSELF
            dispatch_async(dispatch_get_main_queue(), ^{
                [[MideaSHDeviceManager shareInstance] uploadGPSInfoWithDeviceId:weakSelf.categoryModel.deviceId locationDic:locationDic completion:^(NSError *error) {
                }];
            });
        }
    });
}

#pragma mark - 初始化方
- (void)setupUI
{
    _guideScrollView = [[UIScrollView alloc] init];
    [self.view addSubview:_guideScrollView];
    
    if (@available(iOS 11.0,*)) {
        self.additionalSafeAreaInsets = UIEdgeInsetsMake(0, [UIDevice ms_statusHeight], 0, 0);
    } else {
        self.automaticallyAdjustsScrollViewInsets = NO;
    }
    
    _successImageView = [[UIImageView alloc] init];
    _successImageView.image = LIMAGENAMED(@"succeed_icon_right");
    [_guideScrollView addSubview:_successImageView];
    
    NSString *successText = [NSString stringWithFormat:@"%@联网成功",[MideaTool applianceName:self.categoryModel.category]];
    CGFloat textSize = 24;
    if (SCREEN_WIDTH < 321) {
        textSize = 20;
    }
    _successLabel = [MideaUIConfiguration sh_createLabelWithFrame:CGRectZero
                                                             text:successText
                                                        textColor:MideaUIConfiguration.sh_titleColor
                                                             font:[MideaUIConfiguration sh_pingFangSC_mediumFont:textSize]];
    _successLabel.textAlignment = NSTextAlignmentCenter;
    [_guideScrollView addSubview:_successLabel];
    
    id <BHNFCManagerProtocol> nfcService = [DOFRouter getServiceInstance:@protocol(BHNFCManagerProtocol)];
    NSInteger nfcFunType = 0;
    if (nfcService) {
        nfcFunType = [nfcService nfcFunType];
    }
    //原有逻辑是只显示fun=2的标签的，有7.3NFC冰箱食材管理夹需求进行了本次更改
//    self.isNFCFun2 = (nfcFunType == 2 && [nfcService isNfcAddDevice]);
    self.isNFCFun2 = [nfcService isNfcAddDevice];
    
    
    _deviceNameLabel = [MideaUIConfiguration sh_createLabelWithFrame:CGRectZero
                                                                text:@"设备名称"
                                                           textColor:MideaUIConfiguration.sh_hintColor
                                                                font:MideaUIConfiguration.sh_assistFont];
    [_guideScrollView addSubview:_deviceNameLabel];
    
    _deviceNameTextField = [MideaUIConfiguration sh_createTextFieldWithFrame:CGRectZero
                                                                   leftSpace:16
                                                                cornerRadius:0
                                                                 borderWidth:0.5
                                                                 borderColor:MideaUIConfiguration.sh_hintColor];
    _deviceNameTextField.returnKeyType = UIReturnKeyDone;
    _deviceNameTextField.delegate = self;
    _deviceNameTextField.placeholder = @"家电名称";
    [_deviceNameTextField setMs_maxLength:15];
    if (![_categoryModel.deviceName isKindOfClass:NSNull.class] && _categoryModel.deviceName) {
        _deviceNameTextField.text = _categoryModel.deviceName;
        if ([_categoryModel.category isEqualToString:@"16"] && _categoryModel.mac4){
            //一代,二代网关 加上Mac后四位
            _deviceNameTextField.text = [NSString stringWithFormat:@"%@%@",_categoryModel.deviceName,_categoryModel.mac4];
        }
    }
    _deviceNameTextField.font = MideaUIConfiguration.sh_thirdLevelTitleFont;
    [_guideScrollView addSubview:_deviceNameTextField];
    
    if (self.ownerFamilyList.count > 1) {
        _homeNameLabel = [MideaUIConfiguration sh_createLabelWithFrame:CGRectZero
                                                                  text:@"所属家庭"
                                                             textColor:MideaUIConfiguration.sh_hintColor
                                                                  font:MideaUIConfiguration.sh_assistFont];
        [_guideScrollView addSubview:_homeNameLabel];
        
        _homeNameTextField = [MideaUIConfiguration sh_createTextFieldWithFrame:CGRectZero
                                                                     leftSpace:16
                                                                  cornerRadius:0
                                                                   borderWidth:0.5
                                                                   borderColor:MideaUIConfiguration.sh_hintColor];
        _homeNameTextField.returnKeyType = UIReturnKeyDone;
        _homeNameTextField.delegate = self;
        _homeNameTextField.placeholder = @"所属家庭";
        _homeNameTextField.font = MideaUIConfiguration.sh_thirdLevelTitleFont;
        [_guideScrollView addSubview:_homeNameTextField];
        
        NSString *temp = [_categoryModel.category lowercaseString];
        if (([_categoryModel.category isEqualToString:@"1C"] || [temp isEqualToString:@"0x1c"])&& !self.selectFamily.isOwn) {
            NSArray * sortAry = [self compareFamilyWithArray:self.ownerFamilyList];
            if (sortAry.count) {
                MideaFamilyModel * nowFamily = (MideaFamilyModel *)[sortAry objectAtIndex:0];
                _homeNameTextField.text = nowFamily.name;
            }
        } else {
            _homeNameTextField.text = self.currentUserDataCenter.currentFamily.name;
        }
        
        UIView *rightView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 40, 40)];
        _homeNameTextField.rightView = rightView;
        _homeNameTextField.rightViewMode = UITextFieldViewModeAlways;
        _homeNameTextField.userInteractionEnabled = NO;
        
        UIImageView *tipIView = [[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 20, 20)];
        tipIView.image = [UIImage imageNamed:@"public_ic_more_gray"];
        tipIView.contentMode = UIViewContentModeScaleAspectFit;
        [rightView addSubview:tipIView];
        
        _homeNameTouchView = [[UIView alloc] init];
        _homeNameTouchView.backgroundColor = [UIColor clearColor];
        @weakify(self);
        [_homeNameTouchView ms_addTapActionWithBlock:^(UIGestureRecognizer *gestureRecoginzer) {
            @strongify(self);
            [self choiceHomeAction];
        }];
        [_guideScrollView addSubview:_homeNameTouchView];
        
        if (!self.currentUserDataCenter.currentFamily.isOwn) {
            rightView.hidden = YES;
            _homeNameTouchView.hidden = YES;
        }
        else {
            rightView.hidden = NO;
            _homeNameTouchView.hidden = NO;
        }
        
        if ([_categoryModel.category isEqualToString:@"16"] == YES ||
            [_categoryModel.category isEqualToString:@"2A"] == YES ||
            [_categoryModel.category isEqualToString:@"1A"] == YES ||
            [_categoryModel.category isEqualToString:@"9D"] == YES ||
            [MideaUserManager shareInstance].hdLogin == YES) {
            tipIView.hidden = YES;
            _homeNameTouchView.hidden = YES;
        }
    }
    
    _roomNameLabel = [MideaUIConfiguration sh_createLabelWithFrame:CGRectZero
                                                              text:@"所属房间"
                                                         textColor:MideaUIConfiguration.sh_hintColor
                                                              font:MideaUIConfiguration.sh_assistFont];
    [_guideScrollView addSubview:_roomNameLabel];
    
    for (int i = 0; i < self.roomButtons.count; ++i) {
        [self.guideScrollView addSubview:self.roomButtons[i]];
    }
    
    if (self.isNFCFun2) {
        _nfcNameLabel = [MideaUIConfiguration sh_createLabelWithFrame:CGRectZero
                                                                 text:@"标签名称"
                                                            textColor:MideaUIConfiguration.sh_hintColor
                                                                 font:MideaUIConfiguration.sh_assistFont];
        [_guideScrollView addSubview:_nfcNameLabel];
        
        _nfcNameTextField = [MideaUIConfiguration sh_createTextFieldWithFrame:CGRectZero
                                                                    leftSpace:16
                                                                 cornerRadius:0
                                                                  borderWidth:0.5
                                                                  borderColor:MideaUIConfiguration.sh_hintColor];
        _nfcNameTextField.returnKeyType = UIReturnKeyDone;
        _nfcNameTextField.delegate = self;
        _nfcNameTextField.placeholder = @"标签名称";
        [_nfcNameTextField setMs_maxLength:15];
        if (![_categoryModel.deviceName isKindOfClass:NSNull.class] && _categoryModel.deviceName) {
            _nfcNameTextField.text = [NSString stringWithFormat:@"%@标签",_categoryModel.deviceName];
        }
        if (nfcService && [nfcService nfcLabelName].length > 0) {
            _nfcNameTextField.text = [nfcService nfcLabelName];
        }
        _nfcNameTextField.font = MideaUIConfiguration.sh_thirdLevelTitleFont;
        [_guideScrollView addSubview:_nfcNameTextField];
    }
    
    NSString *title = @"保存";
    _finishButton = [MideaUIConfiguration sh_createButtonWithFrame:CGRectZero
                                                             title:title
                                                        titleColor:[UIColor whiteColor]
                                                              font:[UIFont systemFontOfSize:16]];
    _finishButton.layer.cornerRadius = kMSCommonViewHeight/2.0;
    _finishButton.layer.masksToBounds = YES;
    [_finishButton ms_setBackgroundColor:MideaUIConfiguration.sh_blueColor forState:UIControlStateNormal];
    [_finishButton ms_setBackgroundColor:[MideaUIConfiguration.sh_blueColor ms_colorByDarkeningColorWithValue:kMSDarkeningValue] forState:UIControlStateHighlighted];
    [self.view addSubview:_finishButton];
    WEAKSELF;
    [_finishButton jk_touchUpInside:^{
        [weakSelf leftBarButtonClick];
        [weakSelf gotoDeviceInfoVC];
    }];
}

- (void)resetScrollViewContentSizeAndLayouSubviews
{
    CGFloat width = CGRectGetWidth(self.guideScrollView.bounds);
    
    CGFloat imgWidth = ConvertIPhone6X(108);
    self.successImageView.frame = CGRectMake((width - imgWidth) / 2, ConvertIPhone6X(60) + [UIDevice ms_statusHeight], imgWidth, imgWidth);
    self.successLabel.frame = CGRectMake(10, self.successImageView.frameMaxY + 22, width -  20, 24);
    
    self.deviceNameLabel.frame = CGRectMake(16, CGRectGetMaxY(self.successLabel.frame) + 50, 200, 17);
    self.deviceNameTextField.frame = CGRectMake(self.deviceNameLabel.frameOriginX, self.deviceNameLabel.frameMaxY + 4, width - 32, kMSCommonViewHeight);
    self.deviceNameTextField.layer.cornerRadius = kMSCommonViewHeight / 2;
    
    self.nfcNameLabel.frame = CGRectMake(16, self.deviceNameTextField.frameMaxY + 12, 200, 17);
    self.nfcNameTextField.frame = CGRectMake(_nfcNameLabel.frameOriginX, _nfcNameLabel.frameMaxY + 4, width - 32, kMSCommonViewHeight);
    self.nfcNameTextField.layer.cornerRadius = kMSCommonViewHeight / 2;
    
    CGFloat homeNameLabelY;
    if (self.isNFCFun2) {
        homeNameLabelY = self.nfcNameTextField.frameMaxY + 12;
    } else {
        homeNameLabelY = self.deviceNameTextField.frameMaxY + 12;
    }
    
    self.homeNameLabel.frame = CGRectMake(16, homeNameLabelY, 200, 17);
    self.homeNameTextField.frame = CGRectMake(_deviceNameLabel.frameOriginX, _homeNameLabel.frameMaxY + 4, width - 32, kMSCommonViewHeight);
    self.homeNameTextField.layer.cornerRadius = kMSCommonViewHeight / 2;
    self.homeNameTouchView.frame = self.homeNameTextField.frame;
    
    if (self.ownerFamilyList.count > 1) {
        self.roomNameLabel.frame = CGRectMake(16, self.homeNameTextField.frameMaxY + 12, 200, 17);
    } else {
        if (self.isNFCFun2) {
            self.roomNameLabel.frame = CGRectMake(16, self.nfcNameTextField.frameMaxY + 12, 200, 17);
        } else {
            self.roomNameLabel.frame = CGRectMake(16, self.deviceNameTextField.frameMaxY + 12, 200, 17);
        }
    }
    
    CGFloat roomButtonY = self.roomNameLabel.frameMaxY + 10;
    CGFloat roomButtonX = 16;
    UIButton *roomButton = nil;
    NSInteger btnCont = 4;
    if (width < 321) {
        btnCont = 3;
    }
    CGFloat btnWidth = (width - 16 * 2 - 8 * (btnCont -1)) / btnCont;
    for (int i = 0; i < self.roomButtons.count; ++i) {
        roomButton = self.roomButtons[i];
        roomButton.frame = CGRectMake(roomButtonX, roomButtonY, btnWidth, RoomButtonHeight);
        if (roomButtonX + roomButton.frameSizeWidth + 16 > width) {
            if (roomButtonX == 16) { //一整行都放不下，说明button太大，压缩
                
                roomButtonX += roomButton.frameSizeWidth + RoomButtonSpan_H;
            } else { //换到下一行
                roomButtonY += RoomButtonHeight + RoomButtonSpan_V;
                roomButtonX = 16;
                
                roomButton.frameOriginX = roomButtonX;
                roomButton.frameOriginY = roomButtonY;
                
                roomButtonX += roomButton.frameSizeWidth + RoomButtonSpan_H;
            }
        } else {
            roomButton.frameOriginX = roomButtonX;
            roomButton.frameOriginY = roomButtonY;
            
            roomButtonX += roomButton.frameSizeWidth + RoomButtonSpan_H;
        }
    }
    
    if (roomButton){
        self.guideScrollView.contentSize = CGSizeMake(width, roomButton.frameMaxY + 10);
    } else {
        self.guideScrollView.contentSize = CGSizeMake(width, self.roomNameLabel.frameMaxY + 10);
    }
}

- (void)loadData
{
    self.selectFamily = self.currentUserDataCenter.currentFamily;
    
    self.ownerFamilyList = [NSMutableArray arrayWithCapacity:self.currentUserDataCenter.familyList.count];
    for (MideaFamilyModel *model in self.currentUserDataCenter.familyList) {
        if (model.isOwn) {
            [self.ownerFamilyList addObject:model];
        }
    }
    
    self.roomList = nil;
    [self requestRoomList];
}

- (NSMutableArray<UIButton *> *)roomButtons
{
    if (!_roomButtons) {
        _roomButtons = [NSMutableArray new];
    }
    return _roomButtons;
}

- (void)setRoomList:(NSMutableArray<MideaRoomModel *> *)roomList
{
    _roomList = roomList;
    
    [self.roomButtons enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [obj removeFromSuperview];
    }];
    
    __block MideaRoomModel *selectedRoom = nil;
    NSMutableArray *roomButtons = [[NSMutableArray alloc] initWithCapacity:roomList.count + 1];
    [roomList enumerateObjectsUsingBlock:^(MideaRoomModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        UIButton *roomButton;
        if (idx < self.roomButtons.count) { //reuse button
            roomButton = self.roomButtons[idx];
        } else {
            roomButton = [UIButton new];
        }
        [self configButton:roomButton roomIndex:idx];
        [self.guideScrollView addSubview:roomButton];
        if ([obj.roomId isEqualToString:self.categoryModel.roomId]) {
            selectedRoom = obj;
        }
        [roomButtons addObject:roomButton];
    }];
    
    //+
    UIButton *addButton = [UIButton new];
    [self configButton:addButton roomIndex:-1];
    [self.guideScrollView addSubview:addButton];
    [roomButtons addObject:addButton];
    
    self.roomButtons = roomButtons;
    self.selectRoom = selectedRoom;
    
    if (self.selectRoom == nil && _roomList.count > 0) {
        self.selectRoom = _roomList[0];
    }
    
    [self resetScrollViewContentSizeAndLayouSubviews];
}

- (void)addRoom:(MideaRoomModel *)room
{
    [self.roomList addObject:room];
    
    UIButton *roomButton = [UIButton new];
    [self configButton:roomButton roomIndex:self.roomList.count - 1];
    [self.guideScrollView addSubview:roomButton];
    
    if (self.roomButtons.count > 0) {
        [self.roomButtons insertObject:roomButton atIndex:self.roomButtons.count - 1];
    } else {
        [self.roomButtons addObject:roomButton];
    }
    
    self.selectRoom = room;
    
    [self resetScrollViewContentSizeAndLayouSubviews];
}

- (void)configButton:(UIButton *)button roomIndex:(NSInteger)roomIndex
{
    MideaRoomModel *room = nil;
    if (roomIndex < 0) { //+
        roomIndex = -1;
    } else {
        if (roomIndex < self.roomList.count) {
            room = self.roomList[roomIndex];
        } else {
            return;
        }
    }
    
    if (roomIndex == -1) {
        [button setTitle:nil forState:UIControlStateNormal];
        
        [button setImage:[UIImage imageNamed:@"add_device_home_ic_addroom"] forState:UIControlStateNormal];
        
        [button ms_setBackgroundColor:[UIColor colorWithHex:0xF6F6F6] forState:UIControlStateNormal];
        [button ms_setBackgroundColor:[UIColor colorWithHex:0xF6F6F6] forState:UIControlStateSelected];
        
        button.frameSize = CGSizeMake(60, RoomButtonHeight);
    } else {
        NSString *title = room.roomName;
        [button setTitle:title forState:UIControlStateNormal];
        button.titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        button.titleLabel.font = [MideaUIConfiguration sh_pingFangSC_lightFont:14];
        [button setTitleColor:[MideaUIConfiguration sh_summaryColor] forState:UIControlStateNormal];
        [button setTitleColor:[UIColor colorWithHex:0x267AFF] forState:UIControlStateSelected];
        
        [button setImage:nil forState:UIControlStateNormal];
        
        [button ms_setBackgroundColor:[UIColor colorWithHex:0xF6F6F6] forState:UIControlStateNormal];
        [button ms_setBackgroundColor:[UIColor colorWithHex:0x267AFF alpha:0.1] forState:UIControlStateSelected];
        
        [button sizeToFit];
        button.frameSize = CGSizeMake(16 + button.frameSize.width + 16, RoomButtonHeight);
    }
    
    [button addTarget:self action:@selector(clickRoomButton:) forControlEvents:UIControlEventTouchUpInside];
    button.selected = NO;
    button.layer.cornerRadius = RoomButtonHeight / 2;
    button.clipsToBounds = YES;
    button.tag = roomIndex;
}

- (void)clickRoomButton:(UIButton *)button
{
    if (button.tag == -1) {
        // 配网埋点#92
        AppAction_CommonAdd(BHAppActionTypeDevice,
                            @"deviceFitFinishPage",
                            @"PD_addRoom_click",
                            @{@"device_session_id":[MideaConfigDeviceTool getDeviceSessionId]});
        
        MideaAddDeviceAddRoomAlertController *alertController = [MideaAddDeviceAddRoomAlertController addRoomAlertControllerWithSureBlock:^(NSString *roomName) {
            [self requestAddRoom:roomName];
        }];
        [self presentViewController:alertController animated:YES completion:nil];
    } else {
        
        if (button.tag < self.roomList.count) {
            self.selectRoom = self.roomList[button.tag];
        } else {
            self.selectRoom = nil;
        }
        // 配网埋点#91
        NSDictionary *paramDic = @{@"action_result":self.selectRoom.roomName?:@"",
                                   @"device_session_id":[MideaConfigDeviceTool getDeviceSessionId]};
        AppAction_CommonAdd(BHAppActionTypeDevice,
                            @"deviceFitFinishPage",
                            @"PD_chooseRoom_click",
                            paramDic);
        
    }
}

- (void)setSelectRoom:(MideaRoomModel *)selectRoom
{
    _selectRoom = selectRoom;
    
    if (selectRoom) {
        NSUInteger index = [self.roomList indexOfObject:selectRoom];
        [self.roomButtons enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            obj.selected = obj.tag == index;
        }];
    } else {
        [self.roomButtons enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            obj.selected = NO;
        }];
    }
}

- (void)requestRoomList
{
    __block BOOL haveCache = NO;
    @weakify(self);
    
    MideaFamilyModel * nowFamily;
    
    NSString *temp = [_categoryModel.category lowercaseString];
    if (([_categoryModel.category isEqualToString:@"1C"] || [temp isEqualToString:@"0x1c"])&& !self.selectFamily.isOwn) {
        NSArray * sortAry = [self compareFamilyWithArray:self.ownerFamilyList];
        if (sortAry.count) {
            MideaFamilyModel * tmpFamily = (MideaFamilyModel *)[sortAry objectAtIndex:0];
            nowFamily = tmpFamily;
        }
    } else {
        nowFamily = _selectFamily;
    }
    
    [self.currentUserDataCenter getRoomListWithFamilyId:nowFamily.familyId
                                                  cache:^(NSArray<MideaRoomModel *> *roomList) {
        if (roomList.count > 0) {
            haveCache = YES;
            @strongify(self);
            self.roomList = [NSMutableArray arrayWithArray:roomList];
        }
    } completion:^(NSError *error, NSArray<MideaRoomModel *> *roomList) {
        if (!haveCache) {
            @strongify(self);
            self.roomList = [NSMutableArray arrayWithArray:roomList];
            // 请求失败取本地缓存数据
            if (error.code != 0 && self.roomList.count == 0) {
                self.roomList = nowFamily.roomList.mutableCopy;
            }
        }
    }];
}

///获取当前设备的详细信息
- (void)getDeviceInfoWithBlock:(void (^) (NSError * error, MideaApplianceModel *appliance))completion {
    @weakify(self)
    if(self.appliance) {
        safeCallBlock(completion,nil,weak_self.appliance);
        return;
    }
    
    NSString *deviceId = _categoryModel.deviceId;
    if (deviceId.length == 0) {
        safeCallBlock(completion,nil,nil);
        return;
    }
    
    [[MideaSHDeviceManager shareInstance] getDeviceArrayInfoWithDeviceIds:@[deviceId] completion:^(NSError *error, NSArray *list) {
        if (error.code == 0) {
            if (list > 0) {
                NSMutableArray *deviceModelArray = [MideaApplianceModel mj_objectArrayWithKeyValuesArray:list];
                if (deviceModelArray.count > 0) {
                    MideaApplianceModel *appliance = deviceModelArray[0];
                    safeCallBlock(completion,error,appliance);
                    return ;
                }
            }
        }
        safeCallBlock(completion,error,nil);
    }];
}

#pragma mark - 私有方法

- (void)choiceHomeAction
{
    NSMutableArray *items = [NSMutableArray array];
    for (MideaFamilyModel *model in self.ownerFamilyList) {
        FSActionSheetItem *item = FSActionSheetTitleItemMake(FSActionSheetTypeNormal, model.name);
        [items addObject:item];
    }
    FSActionSheetItem *item = FSActionSheetTitleWithColorItemMake(FSActionSheetTypeNormal, @"新增家庭", MideaUIConfiguration.sh_blueColor);
    [items addObject:item];
    FSActionSheet *actionSheet = [[FSActionSheet alloc] initWithTitle:@""
                                                          cancelTitle:@"取消"
                                                                items:items];
    @weakify(self);
    [actionSheet showWithSelectedCompletion:^(NSInteger selectedIndex) {
        @strongify(self);
        if (selectedIndex == items.count-1) {
            id<BHFamilyHomeProtocol> familyService = [DOFRouter getServiceInstance:@protocol(BHFamilyHomeProtocol)];
            if (familyService) {
                if ([familyService isReachFamilyCeiling]) {
                    [MideaUIConfiguration sh_showBlackToastHudToView:self.view text:@"您的家庭数量已达上限"];
                    return;
                }
            }
            //新增家庭
            UIAlertController *aController = [UIAlertController alertControllerWithTitle:@"家庭名称" message:nil preferredStyle:UIAlertControllerStyleAlert];
            [aController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
            }];
            UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            }];
            [aController addAction:cancelAction];
            UIAlertAction *sureAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                UITextField *textFiled = [aController.textFields firstObject];
                [self requestAddHome:textFiled.text];
            }];
            [aController addAction:sureAction];
            UITextField *textFiled = [aController.textFields firstObject];
            [textFiled setMs_maxLength:15];
            [self presentViewController:aController animated:YES completion:nil];
        }
        else {
            if (self.ownerFamilyList.count > selectedIndex) {
                self.selectFamily = self.ownerFamilyList[selectedIndex];
                self.homeNameTextField.text = self.selectFamily.name;
                [self requestRoomList];
            }
        }
    }];
    
    // 配网埋点#96
    AppAction_CommonAdd(BHAppActionTypeDevice,
                        @"deviceFitFinishPage",
                        @"PD_chooseFamily_click",
                        @{@"device_session_id":[MideaConfigDeviceTool getDeviceSessionId]});
    
}

#pragma mark - 网络请求

- (void)requestAddHome:(NSString *)homeName
{
    if ([NSString BH_isBlankString:homeName]) {
        [MideaUIConfiguration sh_showBlackToastHudToView:self.view.window
                                                    text:@"家庭名称不能为空"];
        return;
    }
    BHBaiduMapCenter *mapCenter = [BHBaiduMapCenter sharedInstance];
    __block MideaFamilyModel *familyModel = [MideaFamilyModel new];
    familyModel.name = homeName;
    if (mapCenter.currentLocation) {
        familyModel.address = [NSString stringWithFormat:@"%@ %@ %@", mapCenter.currentLocation[@"province"], mapCenter.currentLocation[@"city"], mapCenter.currentLocation[@"district"]];
        familyModel.coordinate = [NSString stringWithFormat:@"%0.6f,%0.6f", [mapCenter.currentLocation[@"longitude"] floatValue], [mapCenter.currentLocation[@"latitude"] floatValue]];
        [self requestAddHomeModel:familyModel];
    }
    else {
        _shouldCreateFamily = YES;
        NSDictionary *params = @{
            @"accuracy"    : @"1",
            @"alwaysAuthorization" : @"0",
            @"distanceFilter" : @"100",
        };
        __block BHReverseGeoCodeBlock block = ^(NSDictionary *obj, NSError *error) {
            if (obj[@"province"]) {
                familyModel.address = [NSString stringWithFormat:@"%@ %@ %@", obj[@"province"], obj[@"city"], obj[@"district"]];
            }
            if (obj[@"longitude"] && obj[@"latitude"]) {
                familyModel.coordinate = [NSString stringWithFormat:@"%0.6f,%0.6f", [obj[@"longitude"] floatValue], [obj[@"latitude"] floatValue]];
            }
            if (self.shouldCreateFamily) {
                [self requestAddHomeModel:familyModel];
                self.shouldCreateFamily = NO;
            }
        };
        [mapCenter removeReverseGeoCodeCompletion:block];
        [mapCenter startUserLocationServiceAndReverseGeoCode:params
                                                  completion:^(NSDictionary *obj, NSError *error) {
            safeCallBlock(block,obj,error);
        }];
    }
}

- (void)requestAddHomeModel:(MideaFamilyModel *)familyModel
{
    WEAKSELF
    RUN_ON_MAIN_THREAD(^{
        [MideaUIConfiguration sh_showBlackLoadingHudToView:weakSelf.view];
    });
    @weakify(self);
    [self.currentUserDataCenter createFamilyWithEntity:familyModel
                                            completion:^(NSError *error, MideaFamilyModel *model) {
        @strongify(self);
        [MideaUIConfiguration sh_hideAllHudForView:self.view animated:NO];
        if (error.code == 0) {
            self.homeNameTextField.text = familyModel.name;
            self.selectFamily = familyModel;
            [self requestRoomList];
            [self.ownerFamilyList addObject:familyModel];
            [MideaUIConfiguration sh_showBlackToastHudToView:self.view text:@"创建家庭成功"];
        }
    } failedBlock:^(NSError *error) {
         @strongify(self);
        [MideaUIConfiguration sh_hideAllHudForView:self.view animated:NO];
        if (error.code == 332019) {
            [MideaUIConfiguration sh_showBlackToastHudToView:self.view
                                                        text:@"您的家庭数量已达上限"];
        } else if (error.code == 331000) {
            [MideaUIConfiguration sh_showBlackToastHudToView:self.view text:@"创建家庭失败"];
        } else {
            [MideaUIConfiguration sh_showBlackToastHudToView:self.view text:error.localizedDescription.length > 0 ? error.localizedDescription : @"创建家庭失败"];
        }
    }];
}

- (void)requestAddRoom:(NSString *)roomName
{
    WEAKSELF
    RUN_ON_MAIN_THREAD(^{
        [MideaUIConfiguration sh_showBlackLoadingHudToView:weakSelf.view];
    });
    @weakify(self);
    [self.currentUserDataCenter createRoomWithFamilyId:self.selectFamily.familyId roomName:roomName roomDes:@"" completion:^(NSError *error, MideaRoomModel *room) {
        @strongify(self);
        [MideaUIConfiguration sh_hideAllHudForView:self.view animated:NO];
        if (error.code == 0) {
            [self addRoom:room];
            [MideaUIConfiguration sh_showBlackToastHudToView:self.view text:@"创建房间成功"];
        }
        else if (error.code == 332021){
            [MideaUIConfiguration sh_showBlackToastHudToView:self.view text:@"当前家庭房间数量已达上限"];
        }
        else {
            [MideaUIConfiguration sh_showBlackToastHudToView:self.view text:error.localizedDescription.length > 0 ? error.localizedDescription : @"创建房间失败"];
        }
    }];
}


#pragma mark - MSBasePresenterProtocol

- (void)msBasePresenter:(MSBasePresenter *)msPresenter resposeSuccess:(BOOL)success
{
    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == self.deviceNameTextField) {
        // 配网埋点#95
        AppAction_CommonAdd(BHAppActionTypeDevice,
                            @"deviceFitFinishPage",
                            @"PD_editDeviceName_click",
                            @{@"device_session_id":[MideaConfigDeviceTool getDeviceSessionId]});
    }
}

#pragma mark - 页面跳转
- (void)gotoDeviceInfoVC
{
    if (self.deviceNameTextField.text.length == 0) {
        [MideaUIConfiguration sh_showBlackToastHudToView:self.view text:@"请设置家电名称"];
        return;
    }
    
    if (!self.selectRoom) {
        [MideaUIConfiguration sh_showBlackToastHudToView:self.view text:@"请设置房间"];
        return;
    }
    
    if (!self.isPostNoti) {
        [[NSNotificationCenter defaultCenter] postNotificationName:kMideaGuaranteeCardCode object:nil userInfo:@{@"applianceCode":StringOf(self.categoryModel.deviceId)}];
        self.isPostNoti = YES;
    }
    //绑定NFC与卡片
    [self sensorCardAssociatedDeviceRequest:nil];
    
    @weakify(self);
    NSString * nowFamilyID;
    
    NSString *temp = [self.categoryModel.category lowercaseString];
    if (([self.categoryModel.category isEqualToString:@"1C"] || [temp isEqualToString:@"0x1c"]) && !self.selectFamily.isOwn) {
        NSArray * sortAry = [self compareFamilyWithArray:self.ownerFamilyList];
        if (sortAry.count) {
            MideaFamilyModel * nowFamily = (MideaFamilyModel *)[sortAry objectAtIndex:0];
            self.selectFamily = nowFamily;
            nowFamilyID = nowFamily.familyId;
        }
    } else {
        nowFamilyID = self.selectFamily.familyId;
    }
    
    [MideaUIConfiguration sh_showBlackDefaultLoadingHudToView:self.view];
    [self.currentUserDataCenter modifyDeviceLocationWithDeviceId:_categoryModel.deviceId headers:nil familyId:nowFamilyID roomId:self.selectRoom.roomId deviceName:_deviceNameTextField.text productCode:_categoryModel.productCode isOtherEquipment:nil completion:^(NSError *error) {
        @strongify(self);
        [MideaUIConfiguration sh_hideAllHudForView:self.view animated:YES];
        if (error.code == 0) {
            [self.currentUserDataCenter setNeedRefreshData];
            [self.currentUserDataCenter refreshDataIfNeed];
            [self popVC];
            [[NSNotificationCenter defaultCenter] postNotificationName:kMideaAddDeviceSuccessNotification object:self.selectRoom.roomId userInfo:nil];
            
            // 配网埋点#97
            NSDictionary *params = @{
                @"action_result" : [NSString stringWithFormat:@"%@|%@|%@", self.deviceNameTextField.text, self.selectFamily.name, self.selectRoom.roomName],
                @"iot_device_id":[NSString stringWithFormat:@"%@|%@",self.categoryModel.category,(self.categoryModel.productId ?:[self.sn deviceSn8])],
                @"device_session_id":[MideaConfigDeviceTool getDeviceSessionId]
            };
            AppAction_CommonAdd(BHAppActionTypeDevice, @"deviceFitFinishPage", @"Finish_click", params);
        }
        else if (error.code == 331502){
            [MideaUIConfiguration sh_showBlackToastHudToView:self.view text:@"当前家庭设备数量已达上限"];
        }
        else {
            [MideaUIConfiguration sh_hideAllHudForView:self.view animated:YES];
            [MideaUIConfiguration sh_showBlackToastHudToView:self.view text:error.localizedDescription.length > 0 ? error.localizedDescription : @"保存失败"];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self popVC];
            });
        }
    }];
}

- (BOOL)isThridSubDevice
{
    NSString *type = self.categoryModel.category;
    if ([type hasPrefix:@"0X"]) {
        type = [type stringByReplacingOccurrencesOfString:@"0X" withString:@""];
    }
    if ([type hasPrefix:@"0x"]) {
        type = [type stringByReplacingOccurrencesOfString:@"0x" withString:@""];
    }
    if ([type isEqualToString:@"21"] || [type isEqualToString:@"16"] || [type isEqualToString:@"2A"] || //网关子设备
        [type isEqualToString:@"0F"] || //健康秤/体脂秤
        [type isEqualToString:@"1B"] || //美的路由器
        //        [type isEqualToString:@"C0"] || //厨房秤
        [type isEqualToString:@"2B"] //摄像头
        ) {
        return YES;
    }
    return NO;
}

- (void)popVC
{
    __block BOOL isNext = YES;
    id <BHNFCManagerProtocol> nfcService = [DOFRouter getServiceInstance:@protocol(BHNFCManagerProtocol)];
    @weakify(self);
    [self.navigationController.viewControllers enumerateObjectsUsingBlock:^(__kindof UIViewController * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        @strongify(self);
        if ([obj isKindOfClass:MideaWeexPluginViewController.class]) {
            // NFC从weex场景进入的绑定设备，需要回到weex页面
            MideaWeexPluginViewController *weexVC = (MideaWeexPluginViewController *)obj;
            if (weexVC.nfcTag) {
                MideaFamilyModel *family = self.currentUserDataCenter.currentFamily;
                [self.currentUserDataCenter requestDeviceListWithFamily:family cache:nil complete:^(NSError *error, NSArray<MideaApplianceModel *> *deviceList) {
                    NSString *nfcId = @"";
                    if (nfcService)
                        nfcId = [nfcService getNfcId];
                    NSString *pramStr = [NSString stringWithFormat:@"from=nfc&labelId=%@&deviceType=0x%@&sn8=%@&mode=%@", nfcId, self.categoryModel.category, self.categoryModel.sn8, self.categoryModel.mode];
                    weexVC.pramStr = pramStr;
                    [weexVC refreshWeex];
                }];
                [self.navigationController popToViewController:weexVC animated:YES];
                isNext = NO;
                return;
            }
        }
    }];
    
    if (nfcService && [nfcService isNfcAddDevice]) {
        if ([self isThridSubDevice]) {
            [nfcService setNfcToAddDevice:NO];
            [MideaUIConfiguration sh_showBlackToastHudToView:self.view text:@"该设备暂不支持NFC功能"];
        }
    }
    if (isNext)
        [self prePopToRootViewContoller];
}

- (void)sensorCardAssociatedDeviceRequest:(MideaApplianceModel *)model
{
    id <BHNFCManagerProtocol> nfcService = [DOFRouter getServiceInstance:@protocol(BHNFCManagerProtocol)];
    if (!nfcService || ![nfcService isNfcAddDevice]) return;
    NSInteger nfcFunType = 0;
    NSString *nfcId = @"";
    NSString *nfcName = @"";
    if (nfcService) {
        nfcFunType = [nfcService nfcFunType];
        nfcId = [nfcService getNfcId];
        nfcName = [nfcService nfcLabelName];
    }
    if (self.nfcNameTextField.text.length > 0) {
        nfcName = self.nfcNameTextField.text;
    }
    NSDictionary *params = @{@"funId" : [NSString stringWithFormat:@"%d", (int)nfcFunType],
                             @"labelId"    : nfcId ? : @"",
                             @"name"    : nfcName ? :@"",
                             @"applianceCode" : _categoryModel.deviceId ? : @"",
                             @"homegroupId" : _selectFamily.familyId ? : @"",
                             @"appId" : [MideaRequestUrlCenter sharedInstance].mcloudAppid ? : @"900"};
    [MideaUIConfiguration sh_showBlackLoadingHudToView:self.view text:nil];
    @weakify(self);
    [[MideaRequestManager sharedInstance] sensorCardAssociatedDeviceRequest:params cache:^(id  _Nullable responseObject) {
        
    } success:^(NSURLSessionTask * _Nullable httpbase, id  _Nullable responseObject) {
        @strongify(self);
        [MideaUIConfiguration sh_hideAllHudForView:self.view animated:YES];
        [MideaUIConfiguration sh_showBlackToastHudToView:self.view text:@"绑定成功"];
        
    } failure:^(NSURLSessionTask * _Nullable httpbase, MSNetworkingError * _Nullable error) {
        @strongify(self);
        [MideaUIConfiguration sh_hideAllHudForView:self.view animated:YES];
        [MideaUIConfiguration sh_showBlackToastHudToView:self.view text:error.errorMessage ? : @"NFC绑定失败，请重试"];
    }];
}

- (void)jumpToBluetoothDoor
{
    MideaLockViewController *vc = [[MideaLockViewController alloc] initWithHtmlUrl:lockURL useUIWebView:YES];
    vc.useUIWebView = YES;
    vc.miniDic = @{@"deviceId":_categoryModel.deviceId};
    vc.fromSuccess = @"Addsuccess";
    [self.navigationController pushViewController:vc animated:YES];
}

- (NSArray *)compareFamilyWithArray:(NSArray *)dataArray
{
    NSArray *array =[dataArray sortedArrayUsingComparator:^NSComparisonResult(id obj1,id obj2) {//这个是调用系统的方法
        MideaFamilyModel *object1 = (MideaFamilyModel *)obj1;//NewModel是我需要排序的Model模型
        MideaFamilyModel *object2 = (MideaFamilyModel *)obj2;
        BOOL asResult = [object1.createTime compare:object2.createTime] == NSOrderedAscending;
        BOOL deResult = [object1.createTime compare:object2.createTime] == NSOrderedDescending;
        if (deResult) {
            return NSOrderedDescending;
        } else if (asResult) {
            return NSOrderedAscending;
        }
        return NSOrderedSame;
    }];
    return array;//返回的就是按照时间降序的数组啦
}

- (void)prePopToRootViewContoller
{
    if (_categoryModel.deviceId.length > 0) {
        [self checkDeviceAuthWithDeviceId:_categoryModel.deviceId];
    } else {
        [self goToPlugin];
    }
}

#pragma mark -蓝牙直连后确权 -
- (void)checkBLEDeviceAuthWithDeviceId:(NSString *)deviceId{
    WEAKSELF
    [[MideaSHDeviceManager shareInstance] getDeviceArrayInfoWithDeviceIds:@[deviceId] completion:^(NSError *error, NSArray *list) {
        if (error.code == 0) {
            if (list > 0) {
                NSMutableArray *deviceModelArray = [MideaApplianceModel mj_objectArrayWithKeyValuesArray:list];
                if (deviceModelArray.count > 0) {
                    MideaApplianceModel *applianceModel = deviceModelArray[0];
                    [[MideaCurrentManager sharedCurrentInfo].deviceAuthCacheDict removeObjectForKey:deviceId];
                    [weakSelf getIoTDeviceConfirmInfoRequest:applianceModel];
//                    id<BHHomeProtocol> homeService = [DOFRouter getServiceInstance:@protocol(BHHomeProtocol)];
//                    if(homeService)
//                        [homeService applianceAuthGet:applianceModel andCarries:weakSelf completion:^(BOOL next, NSString * _Nonnull errorMessage) {
//                            [MideaUIConfiguration sh_hideAllHudForView:weakSelf.view animated:YES];
//                            if (next) {
//                                //已经确权
//                                [weakSelf requestRecommendWithApplianceModel:applianceModel completion:^(BOOL success, BHSceneRecommendModel *recommendModel) {
//                                    //有推荐场景去场景，无推荐场景去插件
//                                    if (success) {
//                                        //推荐场景
//                                        [weakSelf jumpSceneRecommend:recommendModel];
//
//                                    }else{
//                                        //处理跳转下一页逻辑
//                                        [weakSelf handleNextPage];
//                                    }
//                                }];
//                            }else{
//                                if (errorMessage) {//设备确权状态查询失败
//                                    [weakSelf goToPlugin];
//                                }else{
//
//                                    [weakSelf getIoTDeviceConfirmInfoRequest:applianceModel];
//                                }
//                            }
//
//                        }];
                }
            }
        } else {
            //配网成功跳转插件通知到首页是否展示邀请家庭tip
            if (weakSelf.selectFamily.isOwn) {
                id<BHHomeProtocol> homeService =
                [DOFRouter getServiceInstance:@protocol(BHHomeProtocol)];
                NSDictionary *dict = @{ @"operation" : kMideaShowInviteTipNotification,
                                        @"type" : @"1" };
                [homeService transferHomeRouterParams:dict];
            }
            [DOFRouter handleURL:BHRouterTabHome];
        }
    }];
}




#pragma mark - 后确权 -
- (void)checkDeviceAuthWithDeviceId:(NSString *)deviceId
{
    if (self.btToken > 0) {
        [self checkBLEDeviceAuthWithDeviceId:deviceId];
        return;
    }
    
    WEAKSELF
    [[MideaSHDeviceManager shareInstance] getDeviceArrayInfoWithDeviceIds:@[deviceId] completion:^(NSError *error, NSArray *list) {
        if (error.code == 0) {
            if (list > 0) {
                NSMutableArray *deviceModelArray = [MideaApplianceModel mj_objectArrayWithKeyValuesArray:list];
                if (deviceModelArray.count > 0) {
                    MideaApplianceModel *applianceModel = deviceModelArray[0];
                    [[MideaCurrentManager sharedCurrentInfo].deviceAuthCacheDict removeObjectForKey:deviceId];
                    id<BHHomeProtocol> homeService = [DOFRouter getServiceInstance:@protocol(BHHomeProtocol)];
                    if(homeService)
                        [homeService applianceAuthGet:applianceModel andCarries:weakSelf completion:^(BOOL next, NSString * _Nonnull errorMessage) {
                            [MideaUIConfiguration sh_hideAllHudForView:weakSelf.view animated:YES];
                            if (next) {
                                //已经确权
                                [weakSelf requestRecommendWithApplianceModel:applianceModel completion:^(BOOL success, BHSceneRecommendModel *recommendModel) {
                                    //有推荐场景去场景，无推荐场景去插件
                                    if (success) {
                                        //推荐场景
                                        [weakSelf jumpSceneRecommend:recommendModel];
                                        
                                    }else{
                                        //处理跳转下一页逻辑
                                        [weakSelf handleNextPage];
                                    }
                                }];
                            }else{
                                if (errorMessage) {//设备确权状态查询失败
                                    [weakSelf goToPlugin];
                                }else{
                                    
                                    [weakSelf getIoTDeviceConfirmInfoRequest:applianceModel];
                                }
                            }
                            
                        }];
                }
            }
        } else {
            //配网成功跳转插件通知到首页是否展示邀请家庭tip
            if (weakSelf.selectFamily.isOwn) {
                id<BHHomeProtocol> homeService =
                [DOFRouter getServiceInstance:@protocol(BHHomeProtocol)];
                NSDictionary *dict = @{ @"operation" : kMideaShowInviteTipNotification,
                                        @"type" : @"1" };
                [homeService transferHomeRouterParams:dict];
            }
            [DOFRouter handleURL:BHRouterTabHome];
            
        }
    }];
}
#pragma mark- 跳转到场景推荐页-
- (void)jumpSceneRecommend:(BHSceneRecommendModel *)sceneRecommendModel{
    //配网成功跳转插件通知到首页是否展示邀请家庭tip
    if (self.selectFamily.isOwn) {
        id<BHHomeProtocol> homeService =
        [DOFRouter getServiceInstance:@protocol(BHHomeProtocol)];
        NSDictionary *dict = @{ @"operation" : kMideaShowInviteTipNotification,
                                @"type" : @"3" };
        [homeService transferHomeRouterParams:dict];
    }
    
    MideaApplianceModel *appliance = sceneRecommendModel.appliance;
    NSString *pramStr =
    [NSString stringWithFormat:@"applianceCode=%@&deviceName=%@&sceneType=%@&sn8=%@&subType=%@&applianceType=%@&recommendId=%@&sceneName=%@&homeId=%@", StringOf(appliance.applianceId), StringOf(appliance.name),@(sceneRecommendModel.sceneType),[appliance.decodeSn deviceSn8] ,StringOf(appliance.subType),StringOf(appliance.type),StringOf(sceneRecommendModel.recommendId),StringOf(sceneRecommendModel.name),StringOf(self.selectFamily.familyId)];
//    [self jumpToWeexWithPluginType:BHLocalPluginMideaRooms
//                          fileName:@"recommend/rec-scene.js"
//                           pramStr:pramStr
//                           viewTag:nil];
    
    [self jumpToWeexWithParamStr:pramStr];
}

- (void)jumpToWeexWithParamStr:(NSString *)paramStr {
    NSString *env = @"prod";
    switch ([MideaRequestUrlCenter sharedInstance].mideaRequestUrlEnv) {
        case MideaRequestUrlEnv_Dev:
            env = @"dev";
            break;
            
        case MideaRequestUrlEnv_Sit:
            env = @"sit";
            break;
            
        case MideaRequestUrlEnv_Uat:
            env = @"uat";
            break;
            
        case MideaRequestUrlEnv_Pro:
            env = @"prod";
            break;
            
        default:
            break;
    }
    //跳转至线上weex页面
    NSString *weexPath = [NSString stringWithFormat:@"https://meiju-scene.smartmidea.net/%@/web/bind-recommend.js",env];
    
    [DOFRouter handleURL:BHRouterWeexIndex withParams:@{@"url":NONULLSTRING(weexPath), @"pramStr":paramStr,@"viewTag":@"rootView",@"isForbidSideBack":@(YES)}];
}

/*
- (void)jumpToWeexWithPluginType:(BHLocalPluginType)pluginType
                        fileName:(NSString *)fileName
                         pramStr:(NSString *)pramStr
                         viewTag:(NSString *)viewTag  {
    if (!viewTag) {
        viewTag = @"rootView";
    }
    @weakify(self);
    [MideaTool getWeexPathWithLocalPluginType:pluginType
                                     fileName:fileName
                                       result:^(NSString *weexPath) {
        @strongify(self);
        MideaWeexPluginViewController *weexVC =
        [MideaWeexPluginViewController jumpToWeexWithWeexPath:weexPath
                                                      pramStr:pramStr
                                                      viewTag:viewTag
                                                    appliance:nil];
        weexVC.isForbidSideBack = YES;
        [self.navigationController pushViewController:weexVC animated:YES];
    }];
}
*/

#pragma mark - 场景推荐接口-
- (void)requestRecommendWithApplianceModel:(MideaApplianceModel *)appliance completion:(void (^)(BOOL success, BHSceneRecommendModel *recommendModel))completion{
    NSString *reqId = [MideaTool getReqid];
    NSString *stamp = [NSDate dof_getNSStringFromNSDate:[NSDate date] withFormat:@"yyyyMMddHHmmss"];
    NSMutableDictionary *param = [[NSMutableDictionary alloc] init];
    [param setObject:StringOf(reqId) forKey:@"reqId"];
    [param setObject:StringOf(stamp) forKey:@"stamp"];
    [param setObject:StringOf(appliance.applianceId) forKey:@"applianceCode"];
    [param setObject:[MideaRequestUrlCenter sharedInstance].mcloudAppid ? : @"900" forKey:@"appId"];
    [param setObject:StringOf(appliance.familyId) forKey:@"homegroupId"];
    NSData *postData =
    [NSJSONSerialization dataWithJSONObject:param options:0 error:nil];
    MideaRequestManager *mgr = [MideaRequestManager sharedInstance];
    WS(weakSelf);
    [MideaUIConfiguration sh_showBlackLoadingHudToView:self.view];
    [mgr requestMethod:MSRequestMethodPost
             URLString:@"/v1/scene/recommend/query/by/appliance"
              httpBody:postData
  configurationHandler:^(MSRequestManagerConfig *configuration) {
        configuration.baseURL = [[MideaRequestUrlCenter sharedInstance] mccBaseUrl];
    } cache:nil success:^(NSURLSessionTask *httpbase, id responseObject) {
        
        if ([[responseObject objectForKeySafe:@"code"] integerValue] == 0) {
            NSDictionary *dataDic = GetObjectFromDicWithKey(responseObject, kMideaSHCommonData, NSDictionary);
            NSArray *sceneList = GetObjectFromDicWithKey(dataDic, kMideaSHCommonList, NSArray);
            NSMutableArray *list =[NSMutableArray array];
            for (NSDictionary *dic in sceneList) {
                BHSceneRecommendModel *model = [BHSceneRecommendModel mj_objectWithKeyValues:dic];
                [list addObject:model];
            }
            if (list.count > 0) {
                //B3053目前只推荐一个场景，故获取第一个场景
                BHSceneRecommendModel *model = list[0];
                if (model.recommendId && model.recommendId.length > 0) {
                    model.appliance = appliance;
                    if (completion) {
                        completion(YES,model);
                    }
                }else{
                    if (completion) {
                        completion(NO,nil);
                    }
                }
            }else{
                if (completion) {
                    completion(NO,nil);
                }
            }
            
        }else{
            if (completion) {
                completion(NO,nil);
            }
        }
        [MideaUIConfiguration sh_hideAllHudForView:weakSelf.view animated:YES];
        
    } failure:^(NSURLSessionTask * _Nonnull httpbase, MSNetworkingError * _Nonnull error) {
        [MideaUIConfiguration sh_hideAllHudForView:weakSelf.view animated:YES];
        if (completion) {
            completion(NO,nil);
        }
    }];
    
    
}
#pragma mark- 去确权页确权
- (void)getIoTDeviceConfirmInfoRequest:(MideaApplianceModel *)appliance
{
    WEAKSELF
    void(^viewControllerActionBlock)(UIViewController *vc, BOOL success) = ^(UIViewController *vc, BOOL success) {
        if (success) {
            [weakSelf requestRecommendWithApplianceModel:appliance completion:^(BOOL success, BHSceneRecommendModel *recommendModel) {
                if (success) {
                    //推荐场景
                    [weakSelf jumpSceneRecommend:recommendModel];
                }else{
                    [weakSelf handleNextPage];
                }
            }];
        }
    };
    if (self.isForceBindCode) {
        viewControllerActionBlock(nil, YES);
        return;
    }
    
    if (self.btToken.length > 0) { 
        [DOFRouter handleURL:BHRouterAuthorityUrl withParams:@{@"appliance":appliance,
                                                               @"canPass":@(YES),
                                                               @"isNative":@(YES),
                                                               @"isBluetooth":@(YES),
                                                               @"viewControllerActionBlock":viewControllerActionBlock}];
    }else{
        
        [DOFRouter handleURL:BHRouterAuthorityUrl withParams:@{@"appliance":appliance,
                                                               @"canPass":@(YES),
                                                               @"viewControllerActionBlock":viewControllerActionBlock}];
        
    }
    

}

- (void)handleNextPage {
    if(self.selectFamily.isOwn){//家庭主人
        @weakify(self);
        [self getDeviceInfoWithBlock:^(NSError *error, MideaApplianceModel *appliance) {
            @strongify(self);
            //邀请家庭成员页
            [DOFRouter handleURL:BHRouterInvideFamilyAfterAddDeviceUrl withParams:@{@"homeId":NONULLSTRING(self.selectFamily.familyId),@"applianceModel":NONULLSTRING(appliance)}];
        }];
    } else {//成员
        [self goToPlugin];
    }
}

//去首页/插件页
- (void)goToPlugin {
    
    if (![self isNeedGotoPlugin]) {
        [DOFRouter handleURL:BHRouterTabHome];
        return;
    }
    
    @weakify(self);
    [self getDeviceInfoWithBlock:^(NSError *error, MideaApplianceModel *appliance) {
        @strongify(self);
        if ([appliance isKindOfClass:[MideaApplianceModel class]]) {
            [DOFRouter handleURL:BHRouterAddDevicePluginDownloadUrl withParams:@{@"applianceModel":appliance} sourceController:self andCompletion:nil];
        }
    }];
    [DOFRouter handleURL:BHRouterTabHome];
}

- (BOOL)isNeedGotoPlugin {
    // 2a品类没有插件，不用跳转到插件内
    if ([self.categoryModel.category.lowercaseString isEqualToString:@"2a"]) {
        return NO;
    }
    return YES;
}

/*
- (void)gotoPluginWithModel:(MideaApplianceModel *)model {
    
    MideaDownLoadItem *downloadItem = self.downloadItem;
    downloadItem.device.familyId = self.selectFamily.familyId;
    NSString *deviceId = self.categoryModel.deviceId;

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
         UIViewController<MSBasePresenterProtocol> *currentViewController = (UIViewController<MSBasePresenterProtocol> *)[MideaTool getCurrentViewController];
         dispatch_block_t gotoPluginDownload = ^ () {
             MideaAddDevicePluginDownloadViewController *downloadViewController = [MideaAddDevicePluginDownloadViewController alertControllerWithDownload:downloadItem];
             [currentViewController presentViewController:downloadViewController animated:YES completion:nil];
         };
         @weakify(self);
         dispatch_block_t gotoPlugin = ^ () {
             @strongify(self);
             id<BHHomeProtocol> homeService = [DOFRouter getServiceInstance:@protocol(BHHomeProtocol)];
             id <BHNFCManagerProtocol> nfcService = [DOFRouter getServiceInstance:@protocol(BHNFCManagerProtocol)];
             ///如果是从nfc配网进来，走nfc的跳转逻辑
             if (nfcService && [nfcService isNfcAddDevice]) {
                 UIViewController<MSBasePresenterProtocol> *currentVC = (UIViewController<MSBasePresenterProtocol> *)[MideaTool getCurrentViewController];
                 id<BHHomeProtocol> homeService = [DOFRouter getServiceInstance:@protocol(BHHomeProtocol)];
                 if(homeService) {
                     [homeService gotoPluginByNFCWithDeviceId:self.categoryModel.deviceId andCarries:currentVC];
                 }
             }else{
                 if (homeService) {
                     [homeService gotoPluginDeviceId:deviceId changeFamily:YES andCarries:currentViewController];
                 }

             }
             //配网成功跳转插件通知到首页是否展示邀请家庭tip
             if (self.selectFamily.isOwn) {
                 [[NSNotificationCenter defaultCenter] postNotificationName:kMideaShowInviteTipNotification object:nil userInfo:@{@"type":@"1"}];
             }
         };
         DDLogWeex(@"配网完成后--downloadItem地址：%@, 下载状态--%ld",downloadItem,(long)downloadItem.downLoadStatus);
         if(downloadItem.downLoadStatus == MideaDownLoadStatus_Downning){
             gotoPluginDownload();
             return;
         }
         //是否已下载
         BOOL hasDownload =  [[MideaDevicePluginManager shareManager] hasDownloadDevicePlugin:model];
         DDLogWeex(@"配网完成后--是否下载%@, 设备类型--%@",hasDownload ? @"已下载":@"未下载",model.type);
         if (hasDownload) {
             gotoPlugin();
         } else {
             gotoPluginDownload();
         }
     });
}
 */

- (MideaDeviceAuthorityPresenter *)authorPresenter{
    if (!_authorPresenter) {
        _authorPresenter = [[MideaDeviceAuthorityPresenter alloc]init];
    }
    return _authorPresenter;
}

@end

@interface MideaAddDeviceAddRoomAlertController () <UITextFieldDelegate>

@property (nonatomic, strong) UIAlertAction *sureAction;
@property (nonatomic, strong) UIAlertAction *cancelAction;
@property (nonatomic, strong) UITextField *inputTextField;

@end

@implementation MideaAddDeviceAddRoomAlertController

+ (instancetype)addRoomAlertControllerWithSureBlock:(void(^)(NSString *roomName))block
{
    MideaAddDeviceAddRoomAlertController *alertController = [MideaAddDeviceAddRoomAlertController alertControllerWithTitle:@"请输入房间名称" message:nil preferredStyle:UIAlertControllerStyleAlert];
    __weak MideaAddDeviceAddRoomAlertController *weakController = alertController;
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        weakController.inputTextField = textField;
    }];
    alertController.cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        // 配网埋点#94
        AppAction_CommonAdd(BHAppActionTypeDevice,
                            @"addRoomPop",
                            @"PD_cancel_click",
                            @{@"device_session_id":[MideaConfigDeviceTool getDeviceSessionId]});
        [weakController.inputTextField resignFirstResponder];
    }];
    alertController.sureAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        // 配网埋点#93
        AppAction_CommonAdd(BHAppActionTypeDevice,
                            @"addRoomPop",
                            @"PD_fix_click",
                            @{@"device_session_id":[MideaConfigDeviceTool getDeviceSessionId]});
        
        if (block) {
            block(weakController.inputTextField.text);
        }
        [weakController.inputTextField resignFirstResponder];
    }];
    alertController.sureAction.enabled = NO;
    
    return alertController;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(textFieldTextDidChangeNotification:)
                                                 name:UITextFieldTextDidChangeNotification
                                               object:nil];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UITextFieldTextDidChangeNotification object:nil];
}

- (void)setInputTextField:(UITextField *)inputTextField
{
    _inputTextField = inputTextField;
    
    inputTextField.delegate = self;
    [inputTextField setMs_maxLength:15];
}

- (void)setSureAction:(UIAlertAction *)sureAction
{
    _sureAction = sureAction;
    
    [self addAction:sureAction];
}

- (void)setCancelAction:(UIAlertAction *)cancelAction
{
    _cancelAction = cancelAction;
    
    [self addAction:cancelAction];
}

- (void)textFieldTextDidChangeNotification:(NSNotification *)notification
{
    if (self.inputTextField == notification.object) {
        self.sureAction.enabled = [self.inputTextField.text ms_trimmingWhitespaceAndNewlines].length > 0;
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    return NO;
}

@end
